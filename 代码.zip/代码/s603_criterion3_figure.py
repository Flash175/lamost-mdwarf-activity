# -*- coding: utf-8 -*-
"""s603：第三判据分档曲线图（新图）—— 两目录并列 + 与活动率同形对照

左：第三判据通过率 vs |Z|（dr13 活动富集 vs dr13_rest 非富集，Wilson 95%）
右：合并活动率 vs |Z|（far400_2d_audit.csv），与左图同 x 轴，用来看两条曲线是否同形
输出：APJS/图五及相关数据/图_20261103/新图/新图_第三判据分档曲线.png
"""
import io, sys, os
import numpy as np, pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
D = r'C:\Users\lingz\Desktop\复现老师工作\APJS\多个图及讨论'
OUTDIR = r'C:\Users\lingz\Desktop\复现老师工作\APJS\图五及相关数据\图_20261103\新图'
os.makedirs(OUTDIR, exist_ok=True)

T = pd.read_csv(os.path.join(D, 'criterion3_full_spectra.csv'), comment='#')
A = pd.read_csv(os.path.join(D, 'far400_2d_audit.csv'), comment='#').set_index('zbin')
ORDER = ['<100','100-200','200-400','400-600','600-1000','>1000']
XC = {'<100': 50, '100-200': 150, '200-400': 300, '400-600': 500, '600-1000': 800, '>1000': 1200}

fig, ax = plt.subplots(1, 2, figsize=(11.2, 4.3))
for src, color, marker, lab in [('dr13', 'tab:red', 'o', 'dr13 archive (90% active)'),
                                ('dr13_rest', 'tab:blue', 's', 'dr13_rest (new, 99.99% inactive)')]:
    q = T[T.src == src].set_index('zbin').reindex(ORDER)
    x = [XC[z] for z in ORDER]
    ax[0].errorbar(x, q.pass_pct.values, yerr=[q.pass_pct-q.lo, q.hi-q.pass_pct],
                   color=color, marker=marker, ms=5, lw=1.6, capsize=3, label=lab)
ax[0].set_xscale('log'); ax[0].set_xlabel(r'$|Z|$  (pc)')
ax[0].set_ylabel(r'fraction passing peak $>3\sigma$  (%)')
ax[0].set_title('Third criterion: peak significance', fontsize=10)
ax[0].legend(fontsize=7.5, frameon=False); ax[0].grid(alpha=.25)

f = A['frac'].reindex(ORDER).values
ax[1].plot([XC[z] for z in ORDER], f, 'k-o', ms=5, lw=1.6, label='merged activity fraction')
ax[1].set_xscale('log'); ax[1].set_xlabel(r'$|Z|$  (pc)')
ax[1].set_ylabel('active fraction  (%)')
ax[1].set_title('Activity fraction (catalogue EW)', fontsize=10)
ax[1].legend(fontsize=7.5, frameon=False); ax[1].grid(alpha=.25)
for a in ax: a.tick_params(labelsize=8)
fig.suptitle('Third criterion vs activity: same shape, not a distance-monotonic detection effect', fontsize=10.5)
fig.tight_layout(rect=[0, 0, 1, 0.95])
fp = os.path.join(OUTDIR, '新图_第三判据分档曲线.png')
fig.savefig(fp, dpi=180); plt.close(fig)
print('写出 %s（%d B）' % (fp, os.path.getsize(fp)))

# 同时把左图数据存成表，便于复算
rows = []
for src in ['dr13','dr13_rest']:
    q = T[T.src == src].set_index('zbin')
    for z in ORDER:
        if z in q.index:
            rows.append(dict(src=src, zbin=z, z_rep=XC[z], n=int(q.loc[z,'n']), n_pass=int(q.loc[z,'n_pass']),
                             pass_pct=float(q.loc[z,'pass_pct']), lo=float(q.loc[z,'lo']), hi=float(q.loc[z,'hi'])))
pd.DataFrame(rows).to_csv(os.path.join(D, 'criterion3_figure_data.csv'), index=False, encoding='utf-8')
print('写出 criterion3_figure_data.csv（%d 行）' % len(rows))
