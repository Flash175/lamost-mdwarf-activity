# -*- coding: utf-8 -*-
"""s553：重绘图 1（左 2D 主结果 + 右 6D 细档）与图 2（描述性标题 + Wilson 误差棒）。"""
import io, sys, os
import numpy as np, pandas as pd
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
from astropy.coordinates import SkyCoord
import astropy.units as un

OUT = r'C:\Users\lingz\Desktop\复现老师工作\APJS\多个图及讨论'

def wilson(k, n, z=1.96):
    if n == 0: return (np.nan, np.nan)
    p = k/n; d = 1 + z*z/n
    c = (p + z*z/(2*n))/d
    h = z*np.sqrt(p*(1-p)/n + z*z/(4*n*n))/d
    return (100*(c-h), 100*(c+h))

def save(df, name, comments):
    fp = os.path.join(OUT, name)
    df.to_csv(fp, index=False, encoding='utf-8')
    txt = open(fp, encoding='utf-8').read()
    with open(fp, 'w', encoding='utf-8-sig') as f:
        f.write('\n'.join('# ' + c for c in comments) + '\n' + txt)
    print('  写出 %s（%d 行）' % (name, len(df)))

# ---------- 载入 ----------
cat = pd.read_csv('data/lamost/dr13/dr13_mstellar_dM.csv', low_memory=False,
                  usecols=['uid','subclass','teff','ewha','ewha_err','snrr','ra','dec',
                           'gaia_source_id','gaia_g_mean_mag'])
cat = cat[(cat.ewha > -20) & (cat.ewha <= 50) & (cat.ewha_err > 0) & (cat.ewha_err <= 5)].copy()
cat['active'] = (cat.ewha >= 0.75) & (cat.ewha > 3*cat.ewha_err)
cat['gaia_source_id'] = pd.to_numeric(cat.gaia_source_id, errors='coerce')
g = pd.read_csv('data/gaia/gaia_dr3_mstars.csv', low_memory=False,
                usecols=['source_id','parallax','parallax_error','pmra','pmdec','radial_velocity','ruwe'])
m = cat.merge(g, left_on='gaia_source_id', right_on='source_id', how='inner')
m = m[(m.parallax > 0.2) & (m.parallax/m.parallax_error > 5) & (m.ruwe < 1.4)].copy()
m['rv'] = m.radial_velocity
u2 = m.sort_values('ewha', ascending=False).drop_duplicates('uid').copy()
# [giant-cut] 去巨星：M_G >= 6（M 矮星 +8~+16；切口同时含亚巨星与误分类早型矮星）
u2['MG'] = u2.gaia_g_mean_mag.values - 5*np.log10(np.clip(1000.0/u2.parallax.values, 1, None)) + 5
u2 = u2[u2.MG >= 6].copy()
d_pc = 1000.0/u2.parallax.values
sc = SkyCoord(ra=u2.ra.values*un.deg, dec=u2.dec.values*un.deg, distance=d_pc*un.pc, frame='icrs')
u2['absz_pc'] = np.abs(d_pc*np.sin(np.deg2rad(sc.galactic.b.deg)))
u2 = u2[u2.absz_pc <= 3000].copy()

# ---------- A：2D 分箱 ----------
E2 = [0,100,200,400,600,1000,1e9]; L2 = ['<100','100-200','200-400','400-600','600-1000','>1000']
u2['zb'] = pd.cut(u2.absz_pc, E2, labels=L2)
rows = []
for lb in L2:
    s = u2[u2.zb == lb]; k = int(s.active.sum()); n = len(s); lo, hi = wilson(k, n)
    rows.append(dict(zbin=lb, n=n, n_act=k, frac=100*k/n, lo=lo, hi=hi,
                     absz_med=float(s.absz_pc.median()), dm0_share=100*(s.subclass == 'dM0').mean(),
                     snr_med=float(s.snrr.median()), g_med=float(s.gaia_g_mean_mag.median())))
A = pd.DataFrame(rows)
save(A, '新图1_数据_2D分箱.csv', [
    '图 A（新图1）左panel 数据源：2D 样本（只需视差；每星取最大 EW 谱）',
    'active = EW(Ha)>=0.75 A 且 >3sigma；frac 为百分数，lo/hi 为 Wilson 95% 区间',
    'absz_med 为该档 |Z| 中位（pc）；dm0_share 为 dM0 占比（组成效应）',
    '生成脚本：代码/s553_fig1_fig2_v2.py'])

# ---------- B：6D 细档 ----------
six = m.sort_values('ewha', ascending=False).drop_duplicates('uid').copy()
# [giant-cut] 去巨星：M_G >= 6（M 矮星 +8~+16；切口同时含亚巨星与误分类早型矮星）
six['MG'] = six.gaia_g_mean_mag.values - 5*np.log10(np.clip(1000.0/six.parallax.values, 1, None)) + 5
six = six[six.MG >= 6].copy()
six = six[np.isfinite(six.rv) & (np.abs(six.rv) < 500)].copy()
c6 = SkyCoord(ra=six.ra.values*un.deg, dec=six.dec.values*un.deg,
              distance=(1000.0/six.parallax.values)*un.pc,
              pm_ra_cosdec=six.pmra.values*un.mas/un.yr, pm_dec=six.pmdec.values*un.mas/un.yr,
              radial_velocity=six.rv.values*un.km/un.s, frame='icrs')
gc = c6.transform_to('galactocentric')
v6 = gc.velocity.d_xyz.to(un.km/un.s).value
six = six.assign(vx=v6[0], vy=v6[1], vz=v6[2], zgc_pc=np.abs(gc.z.to(un.kpc).value)*1000)
six = six[six.zgc_pc <= 3000]
E6 = [0,50,100,150,200,400,3000]; L6 = ['0-50','50-100','100-150','150-200','200-400','>400']
six['zb'] = pd.cut(six.zgc_pc, E6, labels=L6)
rows = []
for lb in L6:
    s = six[six.zb == lb]; act, ina = s[s.active], s[~s.active]
    k, n = len(act), len(s); lo, hi = wilson(k, n)
    rows.append(dict(zbin=lb, n=n, n_act=k, frac=100*k/n, lo=lo, hi=hi,
                     zmed_act=float(act.zgc_pc.median()), zmed_inact=float(ina.zgc_pc.median()),
                     svx_act=act.vx.std(), svy_act=act.vy.std(), svz_act=act.vz.std(),
                     svx_inact=ina.vx.std(), svy_inact=ina.vy.std(), svz_inact=ina.vz.std(),
                     teff_act=float(act.teff.median()), teff_inact=float(ina.teff.median())))
B = pd.DataFrame(rows)
save(B, '新图1_数据_6D分箱.csv', [
    '图 A（新图1）右panel 数据源：6D 子样本（Gaia 视差+自行+RV；83,274 颗；占 2D 的 13%）',
    '|Z| 为 astropy galactocentric z 的绝对值；sigma 为各分量样本标准差（km/s）',
    'zmed_act/zmed_inact 为两类各自的 |Z| 中位（pc），用于判断档内 |Z| 是否对齐',
    '生成脚本：代码/s553_fig1_fig2_v2.py'])
print(B.to_string(index=False, float_format=lambda x: '%.1f' % x))

# ---------- 图 1 ----------
fig, ax = plt.subplots(1, 2, figsize=(11.6, 4.4))
x1 = np.arange(len(L2))
err = np.vstack([A.frac-A.lo, A.hi-A.frac])
cols = ['#c0392b']*3 + ['#e08a7f']*2 + ['#bdc3c7']
bars = ax[0].bar(x1, A.frac, color=cols, yerr=err, capsize=3, ecolor='#555555')
bars[-1].set_hatch('//')
for i, r in A.iterrows():
    ax[0].text(i, r.hi+0.6, '%.1f%%\nn=%s' % (r.frac, format(int(r.n), ',')), ha='center', fontsize=7)
ax[0].set_xticks(x1); ax[0].set_xticklabels(L2, fontsize=8)
ax[0].set_xlabel('|Z|  (pc)'); ax[0].set_ylabel('Active fraction (%)')
ax[0].set_ylim(0, max(A.hi)*1.35)
ax[0].set_title('2D sample, parallax only (639,702 stars)', fontsize=10)
ax[0].text(0.02, 0.95, 'EW(Ha) >= 0.75 A and > 3 sigma', transform=ax[0].transAxes,
           fontsize=7, va='top', color='#444444')

x2 = np.arange(len(L6))
ok = x2[:4]
ax[1].plot(ok, B.svz_act[:4], 'o-', color='#c0392b', ms=6, label='active')
ax[1].plot(ok, B.svz_inact[:4], 's-', color='#2c3e50', ms=6, label='inactive')
ax[1].plot(x2[4:], B.svz_act[4:], 'o', mfc='none', mec='#c0392b', ms=9, mew=1.8, label='active (hollow: not connected)')
ax[1].plot(x2[4:], B.svz_inact[4:], 's', mfc='none', mec='#2c3e50', ms=9, mew=1.8, label='inactive (hollow: not connected)')
ax[1].set_xticks(x2); ax[1].set_xticklabels(L6, fontsize=8)
ax[1].set_xlabel('|Z|  (pc), galactocentric z'); ax[1].set_ylabel('sigma(vz)  (km s$^{-1}$)')
ax[1].set_title(('RV subsample, 13%% of parent (%s stars)' % format(len(six), ',')), fontsize=10)
ax[1].legend(fontsize=7, loc='upper left', framealpha=0.9)
plt.tight_layout(); plt.savefig(os.path.join(OUT, '新图1_活动率与运动学随银盘高度.png'), dpi=200); plt.close()
print('图 1 已重绘')

# ---------- 图 2：全样本分亚型 + Wilson ----------
EA = ['dM0','dM1','dM2','dM3','dM4','dM5','dM6','dM7','dM8']
rows = []
for sp in EA:
    s = u2[u2.subclass == sp]
    if len(s) < 30: continue
    det = 100*(s.ewha_err*3 <= 0.75).mean()
    for tag, sub in (('all', s), ('sn36', s[(s.snrr >= 3) & (s.snrr < 6)]),
                     ('sn612', s[(s.snrr >= 6) & (s.snrr < 12)])):
        k, n = int(sub.active.sum()), len(sub)
        lo, hi = wilson(k, n)
        rows.append(dict(subtype=sp, cut=tag, n=n, n_act=k, frac=100*k/n if n else np.nan,
                         lo=lo, hi=hi, detect_pct=det))
F2 = pd.DataFrame(rows)
save(F2, '新图2_数据_分亚型SN匹配.csv', [
    '图 B（新图2）数据源：2D 样本按亚型，全谱 / S/N 3-6 / S/N 6-12 三档',
    'frac 为百分数，lo/hi 为 Wilson 95% 区间；detect_pct = 3*sigma(EW)<=0.75 A 的谱占比',
    '生成脚本：代码/s553_fig1_fig2_v2.py'])
P = F2.pivot(index='subtype', columns='cut', values=['frac','lo','hi','n'])
xs = np.arange(len(P)); w = 0.27
fig, ax = plt.subplots(figsize=(7.8, 4.8))
for j, (tag, col, lab) in enumerate([('all','#7f8c8d','all spectra'),
                                     ('sn36','#c0392b','S/N 3-6'),
                                     ('sn612','#2980b9','S/N 6-12')]):
    f = P['frac'][tag].values; lo = P['lo'][tag].values; hi = P['hi'][tag].values
    ax.bar(xs + (j-1)*w, f, w, color=col, label=lab, yerr=np.vstack([f-lo, hi-f]), capsize=2, ecolor='#444444')
ax.plot(xs, [F2[(F2.subtype == sp) & (F2.cut == 'all')].detect_pct.values[0] for sp in P.index],
        'k^--', ms=5, lw=1, label='detectable: 3 x sigma(EW) <= 0.75 A')
ax.set_xticks(xs)
ax.set_xticklabels(['%s\n(n=%s)' % (sp, format(int(P['n']['all'].values[i]), ',')) for i, sp in enumerate(P.index)], fontsize=8)
ax.set_xlabel('Spectral subtype (n = stars in the 2D sample)'); ax.set_ylabel('Active fraction (%)')
ax.set_ylim(0, 115)
ax.set_title('Active fraction by subtype, all spectra versus S/N-matched', fontsize=10)
ax.legend(fontsize=8, loc='upper left')
plt.tight_layout(); plt.savefig(os.path.join(OUT, '新图2_活动率与亚型_SN匹配.png'), dpi=200); plt.close()
print('图 2 已重绘')
print('2D 合计 %d 颗；6D 合计 %d 颗' % (len(u2), len(six)))
