# -*- coding: utf-8 -*-
"""交付包代码目录补入 s189（终版图5脚本），并把 复现入口.py 的 fig5 步骤指向它"""
import io, os, shutil, sys
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
W = r'C:\Users\lingz\OneDrive\Desktop\复现老师工作'
D = r'C:\Users\lingz\Desktop\复现老师工作'
A = r'C:\Users\lingz\Desktop\APJS\图五及相关数据'
cp = [(os.path.join(W, 'repro', 'src', 's189_fig5_official_v4.py'), os.path.join(D, '代码', 'src', 's189_fig5_official_v4.py')),
      (os.path.join(W, 'repro', 'src', 's189_fig5_official_v4.py'), os.path.join(A, '代码', 's189_fig5_official_v4.py')),
      (os.path.join(W, 'repro', 'src', 's197_audit_fig5_data.py'), os.path.join(A, '代码', 's197_audit_fig5_data.py')),
      (os.path.join(W, 'repro', 'src', 's118_export_delivery.py'), os.path.join(D, '代码', 'src', 's118_export_delivery.py')),
      (os.path.join(W, 'repro', 'src', 's182_alias_fig_sync.py'), os.path.join(D, '代码', 'src', 's182_alias_fig_sync.py'))]
for s, d in cp:
    if not os.path.exists(s): print('  !! 源缺失', s); continue
    os.makedirs(os.path.dirname(d), exist_ok=True); shutil.copy2(s, d)
    print('  copied %-34s -> %s' % (os.path.basename(s), os.path.dirname(d).replace('C:\\Users\\lingz\\Desktop\\', '')))
P = os.path.join(D, '复现入口.py'); s = open(P, encoding='utf-8').read(); o = s
s = s.replace("('fig5', ['src/s49_dr13_fig5_v2.py']", "('fig5', ['src/s189_fig5_official_v4.py']")
s = s.replace("('fig5', ['src/s49_dr13_fig5_v2.py'], ", "('fig5', ['src/s189_fig5_official_v4.py'], ")
if s != o:
    open(P, 'w', encoding='utf-8').write(s); print('  复现入口.py: fig5 步骤已指向 s189')
else:
    print('  !! fig5 步骤未改动，当前行：')
    for l in s.splitlines():
        if 'fig5' in l: print('     ', l.strip())
for l in open(P, encoding='utf-8').read().splitlines():
    if 'fig5' in l: print('   现:', l.strip()[:120])
