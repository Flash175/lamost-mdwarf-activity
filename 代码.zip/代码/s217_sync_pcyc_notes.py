# -*- coding: utf-8 -*-
"""同步 P_cyc 图并写入周期证据的注意事项"""
import io, os, shutil, sys
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
W = r'C:\Users\lingz\OneDrive\Desktop\复现老师工作'
D = r'C:\Users\lingz\Desktop\复现老师工作'
A = r'C:\Users\lingz\Desktop\APJS\图五及相关数据'
fig = os.path.join(W, 'figures', 'dr13_figPcyc_Prot.png')
for tgt in (os.path.join(D, '图', '对照与备选', 'dr13_figPcyc_Prot.png'),
            os.path.join(A, '图', '附_Pcyc_vs_Prot_文献样本N8.png')):
    shutil.copy2(fig, tgt); print('  同步 ->', tgt.split('\\')[-1])
NOTE = """
## 八、活动周（P_cyc）证据的注意事项（2026-10-21 修订）

* 文献周期不可互证：同一颗星在不同工作中的周期可相差到 2.7 倍（例如 GJ 229 A），因此 P_cyc 只能作定性示意。
* 本图 N 由 9 降为 **8**：
  - **GJ 551（Proxima Cen）**：SM2016 报 6.8 yr，但 SM2020 未检出、Ibañez Bustos 2025 给 11.3 yr —— 属争议个例，已从图中剔除。
  - **Gl 273**：GomesdaSilva2012 曾报 3.5 yr，后续复核（GdS2012、SM2016、IB2025）均未证实 —— 按"未检出"处理，本就不在图中。
  - **GJ 740**：P_rot = **36.3 d**（HADES VII 表 A.2），旧版 CSV 误记 38.3 d，已更正并注明出处。
* 现有 8 点的 log P_cyc–log P_rot 相关系数 r = −0.35，样本量与动态范围都不足以支持任何"关系"论断，仅作为"周期活动在 M 矮星中确实存在、且跨饱和边界"的示意。
* Ibañez Bustos et al. (2025) 在 35 颗 dM0–dM6 中给出 13 个周期（3–19 yr），可补强"周期活动跨越饱和边界"这一存在性证据；其中双周期仅见于 GJ 536、GJ 825、GJ 752 A 等对流星，可能为 αΩ/α² 发电机的新判别线索。**本文未纳入该表的具体数值**（未取得机读表），如果需要在正文引用，请提供该表后我再补入并重绘。
"""
for p in (os.path.join(D, '文档', '图05_Methods文字_中英文.md'), os.path.join(A, '方法说明', '图05_Methods文字_中英文.md')):
    s = open(p, encoding='utf-8').read()
    if '八、活动周（P_cyc）证据的注意事项' in s: print('  已有该节', p.split('\\')[-1]); continue
    open(p, 'w', encoding='utf-8').write(s.rstrip() + '\n' + NOTE); print('  已追加第八节:', p.split('\\')[-3:])
p = os.path.join(A, 'README.md'); s = open(p, encoding='utf-8').read()
s = s.replace('附_Pcyc_vs_Prot_文献样本N9.png', '附_Pcyc_vs_Prot_文献样本N8.png')
if 'P_cyc 图的 N' not in s:
    s += ('\n> **P_cyc 图（N=8）**：Proxima（GJ 551）因 SM2020 未检出、IB2025 改给 11.3 yr 已剔除；Gl 273 的 3.5 yr 未获证实；'
          'GJ 740 的 P_rot 应为 36.3 d（HADES VII 表 A.2）。详见 方法说明/图05_Methods文字_中英文.md 第八节。\n')
open(p, 'w', encoding='utf-8').write(s)
print('  README 已更新 P_cyc 说明')
print('\n=== 图03/图06 两个被脚本误判为 HTML 的文件，实际首行 ===')
for f in ('图03_自测Hb_逐谱.csv', '图06_光变振幅_Rvar.csv'):
    p2 = os.path.join(D, '数据', f)
    with open(p2, 'rb') as fh: head = fh.read(160)
    print('   %-24s %r' % (f, head[:110]))
