# -*- coding: utf-8 -*-
"""图5 稳健性重做：周期误差 / 去别名 / ruwe 双星剔除 / M3-M4 边界剔除 / 三种拟合(OLS,WLS,σ_int ML)"""
import io, os, re, sys
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
import numpy as np, pandas as pd
from scipy.spatial import cKDTree
from scipy.optimize import minimize
sys.path.insert(0, 'repro/src')

cat = pd.read_csv('data/lamost/dr13/dr13_mstellar_dM.csv', low_memory=False,
                  usecols=['uid','designation','subclass','ewha','ewha_err','teff','ra','dec','gaia_source_id'])
for c in ('ewha','ewha_err','teff','ra','dec'): cat[c] = pd.to_numeric(cat[c], errors='coerce')
cat['ewha_err'] = cat.ewha_err.abs()
cat = cat[(cat.ewha > -20) & (cat.ewha <= 50) & (cat.ewha_err > 0) & (cat.ewha_err <= 5)]
# 多历元子型是否跨 M3/M4
sub_span = cat.groupby('uid').subclass.agg(lambda s: set(str(x).strip() for x in s))
border = set(sub_span[sub_span.apply(lambda s: ('dM3' in s) and ('dM4' in s))].index)
star = cat.loc[cat.groupby('uid').ewha.idxmax()].dropna(subset=['ra','dec']).copy()
star['spt'] = star.subclass.astype(str).str.strip()
star['border34'] = star.uid.isin(border)
print('逐星 %d；跨 M3/M4 边界的星 %d（%.1f%%）' % (len(star), int(star.border34.sum()), 100*star.border34.mean()))

# VSX（带 u_Period）
v = pd.read_csv('repro/_vsx/VSX_catalog_sample.csv', low_memory=False,
                usecols=['Type','Period','u_Period','RAJ2000','DEJ2000'])
v['Period'] = pd.to_numeric(v.Period, errors='coerce'); v['u_Period'] = pd.to_numeric(v.u_Period, errors='coerce')
v = v[v.Period.gt(0) & v.RAJ2000.notna() & v.DEJ2000.notna()]
v = v[v.Type.astype(str).str.upper().str.contains('ROT')]
print('VSX ROT 行 %d；u_Period 非空 %d（%.1f%%）' % (len(v), int(v.u_Period.notna().sum()), 100*v.u_Period.notna().mean()))
def uv(ra, dec):
    ra = np.radians(np.asarray(ra, float)); dec = np.radians(np.asarray(dec, float))
    return np.column_stack([np.cos(dec)*np.cos(ra), np.cos(dec)*np.sin(ra), np.sin(dec)])
tree = cKDTree(uv(star.ra.values, star.dec.values))
dist, idx = tree.query(uv(v.RAJ2000.values, v.DEJ2000.values), k=1, distance_upper_bound=np.radians(3/3600))
ok = np.isfinite(dist) & (idx < len(star))
vsx = pd.DataFrame({'idx': idx[ok], 'P': v.Period.values[ok], 'eP': v.u_Period.values[ok]}).drop_duplicates('idx')
S = star.iloc[vsx.idx.values].copy(); S['P'] = vsx.P.values; S['eP'] = vsx.eP.values; S['src'] = 'VSX'
print('VSX 命中 %d 颗；中位 u_Period %.3f d（有值者 %.1f%% 有误差）'
      % (len(S), np.nanmedian(S.eP), 100*S.eP.notna().mean()))
# Fetherolf
fe = pd.read_csv('data/processed/dr13/dr13_fig5_sample.csv', low_memory=False, usecols=['designation','P'])
fe['designation'] = fe.designation.astype(str)
F = star[star.designation.astype(str).isin(set(fe.designation)) & ~star.uid.isin(set(S.uid))].merge(
    fe.drop_duplicates('designation'), on='designation', how='inner')
F['src'] = 'Fetherolf'; F['eP'] = np.nan
A = pd.concat([S[['uid','designation','spt','ewha','ewha_err','teff','P','eP','src','gaia_source_id','border34']],
               F[['uid','designation','spt','ewha','ewha_err','teff','P','eP','src','gaia_source_id','border34']]], ignore_index=True)
# ruwe（双星代理）
g = pd.read_csv('data/gaia/gaia_dr3_mstars.csv', low_memory=False,
                usecols=lambda c: c in {'source_id','ruwe','parallax','parallax_error','phot_g_mean_mag','bp_rp'})
g['sid'] = g.source_id.astype('int64').astype(str)
A['sid'] = A.gaia_source_id.astype(str).str.split('.').str[0]
A = A.merge(g[['sid','ruwe']], on='sid', how='left')
print('ruwe 可用 %d / %d' % (int(A.ruwe.notna().sum()), len(A)))
# 质量/τ/χ
c2 = pd.read_csv('data/vizier/apjs274_36_mdwarfs.csv', low_memory=False, usecols=lambda c: c in {'EWHa','RHa','Teff','Mstar'})
c3 = c2[(c2.EWHa > 0.1) & (c2.RHa > 0) & (c2.Teff > 2800) & (c2.Teff < 4600)].copy()
c3['chi'] = c3.RHa/c3.EWHa
bins = np.arange(2800, 4601, 100); cent = 0.5*(bins[1:]+bins[:-1]); c3['b'] = np.digitize(c3.Teff, bins)
chi_med = np.array([c3.loc[c3.b == i, 'chi'].median() for i in range(1, len(bins))])
cm = c2[(c2.Teff > 2800) & (c2.Teff < 4600) & (c2.Mstar > 0.05) & (c2.Mstar < 0.8)]
coef = np.polyfit(cm.Teff, cm.Mstar, 2)
A['M'] = np.clip(np.polyval(coef, A.teff.values), 0.08, 0.75)
A['tau'] = 10 ** (2.33 - 1.5*A.M - 0.30*A.M**2)
A['Ro'] = A.P / A.tau
A['RHa'] = np.interp(A.teff, cent, chi_med) * A.ewha
A['sRo'] = np.where(A.eP.notna(), A.Ro * (A.eP / A.P).abs(), np.where(A.src == 'Fetherolf', 0.03*A.Ro, np.nan))
A['sRHa'] = np.abs(np.interp(A.teff, cent, chi_med) * A.ewha_err)
A = A[(A.Ro > 0) & (A.RHa > 0)]
def dealias(d):
    m = np.ones(len(d), bool)
    for t in (0.5, 1.0, 2.0):
        m &= ~(np.abs(d.P.values/t - 1) < 0.05)
    return d[m]
def fit_ols(q):
    x, y = np.log10(q.Ro.values), np.log10(q.RHa.values)
    best = None
    for rs in np.linspace(-1.1, -0.4, 80):
        s, u = x <= rs, x > rs
        if s.sum() < 20 or u.sum() < 20: continue
        rss = ((y[s]-y[s].mean())**2).sum()
        sl, ic = np.polyfit(x[u], y[u], 1)
        rss += ((y[u]-(sl*x[u]+ic))**2).sum()
        if best is None or rss < best[0]: best = (rss, 10**rs, sl)
    return best[1], best[2]
def fit_wls(q):
    x, y = np.log10(q.Ro.values), np.log10(q.RHa.values)
    m = q.sRo.notna() & (q.sRo > 0)
    w = np.where(m, 1/np.maximum((q.sRo.values/np.maximum(q.Ro.values,1e-9))/np.log(10), 1e-3)**2, 1.0)
    best = None
    for rs in np.linspace(-1.1, -0.4, 80):
        s, u = x <= rs, x > rs
        if s.sum() < 20 or u.sum() < 20: continue
        rss = (w[s]*(y[s]-np.average(y[s], weights=w[s]))**2).sum()
        A2 = np.vstack([np.ones_like(x[u]), x[u]]).T
        W = np.diag(w[u]); beta = np.linalg.lstsq(A2.T@W@A2, A2.T@W@y[u], rcond=None)[0]
        rss += (w[u]*(y[u]-A2@beta)**2).sum()
        if best is None or rss < best[0]: best = (rss, 10**rs, beta[1])
    return best[1], best[2]
def fit_ml(q):
    """带内禀弥散的极大似然（同一分段模型）：lnL = -0.5 Σ [r²/(σi²+σint²) + ln(σi²+σint²)]"""
    x, y = np.log10(q.Ro.values), np.log10(q.RHa.values)
    sy = np.where(q.sRHa.notna() & (q.sRHa > 0), q.sRHa.values/np.maximum(q.RHa.values,1e-12)/np.log(10), 0.3)
    def nll(p):
        lrs, beta, c, lsi = p
        rs = 10**lrs; si = np.exp(lsi)
        model = np.where(x <= lrs, c, c + beta*(x-lrs))
        v = sy**2 + si**2
        return 0.5*np.sum((y-model)**2/v + np.log(v))
    best = None
    for lrs0 in (-1.0, -0.85, -0.7):
        r = minimize(nll, [lrs0, -0.7, np.median(y), np.log(0.2)], method='Nelder-Mead',
                     options={'maxiter': 4000, 'xatol': 1e-4, 'fatol': 1e-6})
        if best is None or r.fun < best.fun: best = r
    return 10**best.x[0], best.x[1], np.exp(best.x[3])
rows = []
for tag, d in [('全部(含边界/双星/别名)', A), ('去别名', dealias(A)),
               ('去别名+ruwe<1.4', dealias(A)[dealias(A).ruwe.fillna(0) < 1.4]),
               ('去别名+ruwe<1.4+去M3/M4边界', dealias(A)[dealias(A).ruwe.fillna(0) < 1.4].query('border34 == False')),
               ('同上+Ro<=3', dealias(A)[dealias(A).ruwe.fillna(0) < 1.4].query('border34 == False').query('Ro <= 3'))]:
    if len(d) < 100: continue
    ro, bb = fit_ols(d); wro, wbb = fit_wls(d); mro, mbb, si = fit_ml(d)
    rows.append((tag, len(d), ro, bb, wro, wbb, mro, mbb, si))
t = pd.DataFrame(rows, columns=['样本', 'n', 'Ro_sat(OLS)', 'β(OLS)', 'Ro_sat(WLS)', 'β(WLS)', 'Ro_sat(ML)', 'β(ML)', 'σ_int'])
print('\n== 稳健性表 ==')
print(t.round(3).to_string(index=False))
t.to_csv('data/processed/dr13/fig5_robustness.csv', index=False)
print('\n已存 data/processed/dr13/fig5_robustness.csv')
