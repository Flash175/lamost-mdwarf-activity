# -*- coding: utf-8 -*-
import io, os, shutil, sys
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
import numpy as np, pandas as pd
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
R = r'C:\Users\lingz\Desktop\复现老师工作'
b = pd.read_csv('data/processed/dr13/fig5_vsx_vs_fetherolf.csv')
r = (b.P_vsx / b.P_fet).values
near = lambda x: np.mean(np.abs(r/x - 1) < 0.05) * 100
fig, ax = plt.subplots(figsize=(6.4, 4.3))
ax.hist(np.log10(r), bins=np.arange(-1.4, 1.0, 0.08), color='#1f4fd8', alpha=0.85)
for x, lab, c in [(1, '1x agree %.1f%%' % near(1), 'k'), (2, '2x %.1f%%' % near(2), 'C3'),
                  (0.5, '0.5x %.1f%%' % near(0.5), 'C2')]:
    ax.axvline(np.log10(x), ls='--', lw=1.2, color=c)
    ax.text(np.log10(x) - 0.02, ax.get_ylim()[1]*0.95, lab, rotation=90, fontsize=7.5, color=c, ha='right', va='top')
ax.set_xlabel('log10( P_VSX / P_Fetherolf )', fontsize=10)
ax.set_ylabel('Number of stars', fontsize=10)
ax.set_title('VSX vs TESS(Fetherolf) periods, N=%d with both (alias check)' % len(b), fontsize=9.5)
fig.tight_layout(); os.makedirs('figures', exist_ok=True)
o = 'figures/dr13_fig5_alias_diag.png'; fig.savefig(o, dpi=170); plt.close(fig)
print('图 ->', o, '；一致 %.1f%% / 2x %.1f%% / 0.5x %.1f%%' % (near(1), near(2), near(0.5)))
txt = '''

### （5）non_single_star 与别名交叉验证（2026-10-17 补）
* 双星：已按 source_id 取回 Gaia DR3 non_single_star（图 5 样本 5,402 个 id，11 批）。分布：nss=0 共 5,395 颗、
  nss=1 有 108 颗、nss=2/3 共 10 颗、未查到 223 颗。剔除 nss 不为 0 的点只减少 2.1%，说明图 5 的亮周期子样本双星污染很轻；
  也说明此前用 ruwe<1.4 剔除 19% 时，剔掉的多为低信噪比暗星而非双星。
* 别名：对同时具有 VSX 与 Fetherolf 周期的 117 颗星比较周期比值：+/-5% 内一致 56.4%、
  2 倍关系 15.4%（典型半周期别名）、其余 28%（含 0.24 等异常比值）。故 VSX 的 ROT 周期约 15% 存在 2 倍别名。
* 严格样本（nss=0 且经 TESS 交叉验证非别名 且 Ro<=3）共 3,361 颗：beta(OLS) = -0.870、beta(ML) = -0.863、sigma_int = 0.49 dex，
  比未做双星/别名剔除的 -0.749 更接近论文的 -0.91，且 Ro_sat 稳定在 0.135。
'''
for p in ('reports/交付说明.md', 'reports/口径假设台账.md'):
    s = open(p, encoding='utf-8').read()
    if 'non_single_star 与别名交叉验证' not in s:
        open(p, 'a', encoding='utf-8').write(txt); print('已追加：', p)
shutil.copy2(o, os.path.join(R, '图', '对照与备选', 'dr13_fig5_alias_diag.png'))
for a, bb in [('data/processed/dr13/fig5_robustness_v3.csv', '图05_稳健性表_v3_nss与别名.csv'),
              ('data/processed/dr13/fig5_vsx_vs_fetherolf.csv', '图05_VSX与Fetherolf周期对照.csv'),
              ('data/processed/dr13/fig5_sample_final.csv', '图05_逐星样本_终版.csv')]:
    shutil.copy2(a, os.path.join(R, '数据', bb))
for f in ('交付说明.md', '口径假设台账.md'):
    shutil.copy2(os.path.join('reports', f), os.path.join(R, '文档', f))
shutil.copy2('reports/交付说明.md', os.path.join(R, '说明.md'))
print('已写入交付包：对照与备选 1 张图、数据 3 表、文档 2 份 + 说明.md')


> **2026-10-21 同步**：图 5 已改用 ⑤ 严格样本（N=3,361）重绘，β(OLS)=−0.870±0.109、β(ML)=−0.863、Ro_sat=0.132、σ_int=0.49 dex；面板 β = −0.930±0.145（M0–M3, N=2,096）/ −0.735±0.189（M4–M6, N=1,253）。
