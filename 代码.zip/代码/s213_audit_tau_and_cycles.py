# -*- coding: utf-8 -*-
"""核查：τ 公式符号、②行β相同、VizieR HTML、周期文献表、bootstrap 表述"""
import io, os, sys, glob
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
import numpy as np, pandas as pd
from scipy.optimize import minimize
P = lambda f: os.path.join('data', 'processed', 'dr13', f)
S = pd.read_csv(P('fig5_sample_strict_v4.csv'))
A = pd.read_csv(P('fig5_sample_period_v4.csv'))
A = A[(A.Ro > 0) & (A.RHa > 0)]
def ols(d):
    x, y = np.log10(d.Ro.values), np.log10(d.RHa.values); best = None
    for rs in np.linspace(-1.1, -0.4, 401):
        s, u = x <= rs, x > rs
        if s.sum() < 20 or u.sum() < 20: continue
        rss = ((y[s]-y[s].mean())**2).sum(); sl, ic = np.polyfit(x[u], y[u], 1)
        rss += ((y[u]-(sl*x[u]+ic))**2).sum()
        if best is None or rss < best[0]: best = (rss, 10**rs, sl)
    return best[1], best[2], best[0]
def ml(d):
    x, y = np.log10(d.Ro.values), np.log10(d.RHa.values)
    sy = np.maximum(d.sRHa.values/np.maximum(d.RHa.values, 1e-12)/np.log(10), 0.02)
    def nll(p):
        l, b, c, ls = p; si = np.exp(ls)
        m = np.where(x <= l, c, c + b*(x - l)); v = sy**2 + si**2
        return 0.5*np.sum((y-m)**2/v + np.log(v))
    best = None
    for l0 in (-1.0, -0.85, -0.7):
        r = minimize(nll, [l0, -0.7, np.median(y), np.log(.3)], method='Nelder-Mead',
                     bounds=[(-1.3,-0.5),(-1.6,0.1),(-9,0),(-4,0)], options={'maxiter': 5000})
        if best is None or r.fun < best.fun: best = r
    return 10**best.x[0], best.x[1], np.exp(best.x[3])
def tau(M, coef): return 10 ** (2.33 - 1.5*M + coef*M**2)
print('=== A. τ 二次项系数对比（⑤ 严格样本 n=%d）===' % len(S))
for coef, tag in ((-0.30, '采用 −0.30（Li et al. 2024 印刷式）'),
                  (-0.31, '对照 −0.31（Wright et al. 2018 式(6) 原值）'),
                  (+0.31, '假想 +0.31（二次项取正号，仅鲁棒性检验，非任何原文）')):
    d = S.copy()
    d['Ro'] = d.P / tau(d.M.values, coef)
    d = d[d.Ro <= 3]
    ro, b, rss = ols(d); r3, b3, si = ml(d)
    print('   %-38s Ro范围 %.4f~%.3f  中位 %.4f' % (tag, d.Ro.min(), d.Ro.max(), d.Ro.median()))
    print('      OLS: Ro_sat=%.4f  β=%.4f (RSS %.1f)  |  ML: Ro_sat=%.4f  β=%.4f  σ_int=%.3f' % (ro, b, rss, r3, b3, si))
print('\n=== B. 稳健性表 ② 行 β 与 ① 完全相同的原因 ===')
import re
def dealias(d):
    m = np.ones(len(d), bool)
    for t in (0.5, 1.0, 2.0): m &= ~(np.abs(d.P.values/t - 1) < 0.05)
    return d[m]
D = dealias(A)
removed = A[~A.uid.isin(D.uid)]
print('   ① %d 颗 → ② %d 颗，被剔除 %d 颗' % (len(A), len(D), len(removed)))
print('   被剔除星的 P 范围 %.3f ~ %.3f d，Ro 范围 %.4f ~ %.4f，Ro 中位 %.4f' % (
    removed.P.min(), removed.P.max(), removed.Ro.min(), removed.Ro.max(), removed.Ro.median()))
print('   被剔除星中 Ro > 0.137（断点以上，会影响幂律分支）的颗数：%d' % int((removed.Ro > 0.137).sum()))
r1, b1, _ = ols(A); r2, b2, _ = ols(D)
print('   ① OLS: Ro_sat=%.5f β=%.10f | ② OLS: Ro_sat=%.5f β=%.10f  Δβ=%.2e' % (r1, b1, r2, b2, abs(b1-b2)))
print('   → 若上两值为 0 或 ~1e-16，说明“去别名只砍掉低 Ro 短周期点，幂律分支数据不变”，β 必然相同，不是漏拟合')
print('\n=== C. VizieR 文件是否为 HTML 错误页 ===')
for p in sorted(glob.glob('data/vizier/*')):
    head = open(p, 'rb').read(220)
    tag = 'HTML/错误页' if (b'<!DOCTYPE' in head or b'<html' in head.lower() or b'404' in head) else '数据文件'
    print('   %-58s %8.0f KB  %s' % (os.path.basename(p), os.path.getsize(p)/1024, tag))
print('\n=== D. 文献活动周周期表内容 ===')
for p in ('data/processed/dr13/activity_cycle_data_complete.csv',):
    if os.path.exists(p):
        t = pd.read_csv(p)
        print('   %s  行数 %d  列 %s' % (os.path.basename(p), len(t), list(t.columns)))
        print(t.head(22).to_string(index=False))
