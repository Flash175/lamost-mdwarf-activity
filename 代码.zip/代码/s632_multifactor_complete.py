
# -*- coding: utf-8 -*-
"""s632：按修订版流程补齐 (a) 两渠道对齐表、(b) R3/R4/R5/R8、(c) 瀑布图/条形图。
主方案沿用合并样本 LPM + 64 子集 Shapley（K=6）。不写入草稿。
"""
import os, sys, io, json, math, itertools
import numpy as np, pandas as pd
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
D = r'C:\Users\lingz\Desktop\复现老师工作\APJS\多个图及讨论'
main = pd.read_csv(os.path.join(D,'金属度_清洁样本_637973.csv'), low_memory=False)
sb1  = pd.read_csv(os.path.join(D,'RV变星_SB1候选_多历元.csv'), low_memory=False)
SB = set(sb1.uid)

def clean(df, snr_min=0, mherr=None):
    d = df[~df.uid.isin(SB)]
    for c in ['teff','logg','m_h','snru']:
        v = pd.to_numeric(d[c], errors='coerce'); d = d[v.notna() & (v!=-9999)]
    d = d[(d.teff>=2000)&(d.teff<=4500)&(d.logg>=3)&(d.logg<=6)&(d.m_h.abs()<1)]
    d = d[(d.snru>snr_min)&(d.snru<100)&(d.mh_ok==True)&(d.dist_pc>0)&(d.absz>0)&(d.absz<=400)]
    if mherr is not None: d = d[d.m_h_err<mherr]
    return d.copy()

d = clean(main)
d['active'] = ((d.ewha>=0.75)&(d.ewha>3*d.ewha_err)).astype(float)
def build(d, edges=(0,100,200,400), labels=('<100','100-200','200-400')):
    d = d.copy(); d['zb'] = pd.cut(d.absz, edges, labels=labels)
    DUM = pd.get_dummies(d.subclass, prefix='s', drop_first=True).astype(float)
    for c,nm in [('teff','F2'),('logg','F3'),('m_h','F4')]:
        v = pd.to_numeric(d[c]); d[nm] = v - v.mean()
    d['F2'] = d.F2/1000.0
    lv = np.log10(d.snru); d['F5'] = lv - lv.mean()
    ld = np.log10(d.dist_pc); d['F6'] = ld - ld.mean()
    X = pd.concat([DUM, d[['F2','F3','F4','F5','F6']]], axis=1)
    blocks = {'F1': list(DUM.columns), 'F2':['F2'], 'F3':['F3'], 'F4':['F4'], 'F5':['F5'], 'F6':['F6']}
    return d, X, blocks

d, X, blocks = build(d)
y = d.active.values
masks = {b:(d.zb.values==b) for b in ['<100','100-200','200-400']}
f = {b: 100*y[m].mean() for b,m in masks.items()}
OBS = {b: f['<100']-f[b] for b in ['100-200','200-400']}
print('bins (%%):', {k: round(v,2) for k,v in f.items()}, '| observed D:', {k: round(v,2) for k,v in OBS.items()}, '| n =', len(d))

# ---------- (a) two-channel alignment on the clean sample
rows=[]
for b in ['100-200','200-400']:
    a, c = d[d.zb=='<100'], d[d.zb==b]
    subs = sorted(set(a.subclass)|set(c.subclass))
    wa = a.subclass.value_counts(normalize=True).reindex(subs).fillna(0).values
    wc = c.subclass.value_counts(normalize=True).reindex(subs).fillna(0).values
    fa = a.groupby('subclass').active.mean().reindex(subs).fillna(0).values
    fc = c.groupby('subclass').active.mean().reindex(subs).fillna(0).values
    comp  = float((((fa+fc)/2)*(wa-wc)).sum()*100)
    within= float((((wa+wc)/2)*(fa-fc)).sum()*100)
    inter = float(((wa-wc)*(fa-fc)).sum()*100)
    rows.append(dict(bin=b, drop_pp=OBS[b], comp_pp_twochannel=comp+inter/2, within_pp_twochannel=within+inter/2,
                     interaction_pp=inter))
AL = pd.DataFrame(rows)
print('\n=== two-channel (clean sample) ===\n' + AL.round(2).to_string(index=False))
print('file 对照（obs_decomposition_within_vs_comp.csv）：100-200 内部 7.69 / 组成 3.21；200-400 内部 10.63 / 组成 5.40')

# ---------- main scheme (repeat, to attach phi)
def shapley_lpm(keys, X, blocks, y, masks, bins=('100-200','200-400'), ref='<100'):
    K=len(keys); cache={}
    def delta(S):
        cols=[c for k in S for c in blocks[k]]
        A=np.column_stack([np.ones(len(y))]+[X[c].values for c in cols]) if cols else np.ones((len(y),1))
        beta,*_=np.linalg.lstsq(A,y,rcond=None); pr=A@beta
        v={b:pr[m].mean() for b,m in masks.items()}
        return {b:100*(v[b]-v[ref]) for b in bins}
    for r in range(K+1):
        for S in itertools.combinations(keys,r): cache[frozenset(S)]=delta(S)
    phi={b:{k:0.0 for k in keys} for b in bins}
    for k in keys:
        others=[x for x in keys if x!=k]
        for r in range(len(others)+1):
            for S in itertools.combinations(others,r):
                w=math.factorial(len(S))*math.factorial(K-len(S)-1)/math.factorial(K)
                for b in bins: phi[b][k]+=w*(cache[frozenset(tuple(sorted(S+(k,))))][b]-cache[frozenset(S)][b])
    return phi, cache[frozenset(keys)]
phi, full = shapley_lpm(['F1','F2','F3','F4','F5','F6'], X, blocks, y, masks)
rows=[]
for b in ['100-200','200-400']:
    within_expl = sum(phi[b][k] for k in ['F2','F3','F4','F5','F6'])
    rows.append(dict(bin=b, drop_pp=OBS[b],
                     comp_pp_twochannel=float(AL.loc[AL.bin==b,'comp_pp_twochannel'].iloc[0]),
                     comp_pp_F1=phi[b]['F1'],
                     within_pp_twochannel=float(AL.loc[AL.bin==b,'within_pp_twochannel'].iloc[0]),
                     within_explained_pp=within_expl,
                     within_unexplained_pp=float(AL.loc[AL.bin==b,'within_pp_twochannel'].iloc[0])-within_expl,
                     model_total_pp=full[b], residual_pp=OBS[b]-full[b]))
AL2 = pd.DataFrame(rows).round(4)
AL2.to_csv(os.path.join(D,'多因素_渠道对齐.csv'), index=False, encoding='utf-8-sig')
print('\n=== 多因素_渠道对齐.csv ===\n' + AL2.to_string(index=False))

# ---------- (b) robustness
rob=[]
def add(tag, val): rob.append(dict(test=tag, **val))
add('R1_mergeF2F3', {'note':'合计不变（见 s631）：-3.03 / -5.60'})
add('R2_dropF6', {'note':'合计 -3.59 / -6.75；F1 升到 -2.09 / -3.39（共线性）'})
# R3 logit
def logit_fit(A, y, iters=60):
    b=np.zeros(A.shape[1]); b[0]=np.log(y.mean()/(1-y.mean()))
    for _ in range(iters):
        p=1/(1+np.exp(-(A@b))); W=p*(1-p)
        step=np.linalg.lstsq(A.T@(A*W[:,None])+1e-9*np.eye(len(b)), A.T@(y-p), rcond=None)[0]
        b=b+step
        if np.max(np.abs(step))<1e-9: break
    return b
def shapley_logit(keys, X, blocks, y, masks, bins=('100-200','200-400')):
    K=len(keys); cache={}
    def delta(S):
        cols=[c for k in S for c in blocks[k]]
        A=np.column_stack([np.ones(len(y))]+[X[c].values for c in cols]) if cols else np.ones((len(y),1))
        beta=logit_fit(A,y); pr=1/(1+np.exp(-(A@beta)))
        v={b:pr[m].mean() for b,m in masks.items()}
        return {b:100*(v[b]-v['<100']) for b in bins}
    for r in range(K+1):
        for S in itertools.combinations(keys,r): cache[frozenset(S)]=delta(S)
    phi={b:{k:0.0 for k in keys} for b in bins}
    for k in keys:
        others=[x for x in keys if x!=k]
        for r in range(len(others)+1):
            for S in itertools.combinations(others,r):
                w=math.factorial(len(S))*math.factorial(K-len(S)-1)/math.factorial(K)
                for b in bins: phi[b][k]+=w*(cache[frozenset(tuple(sorted(S+(k,))))][b]-cache[frozenset(S)][b])
    return phi, cache[frozenset(keys)]
phiL, fullL = shapley_logit(['F1','F2','F3','F4','F5','F6'], X, blocks, y, masks)
print('\n=== R3 logit ==='); 
for b in ['100-200','200-400']:
    print('  bin %s: model %+.2f | ' % (b, fullL[b]) + ', '.join('%s %+.2f' % (k, phiL[b][k]) for k in ['F1','F2','F3','F4','F5','F6']))
    diff = max(abs(phiL[b][k]-phi[b][k]) for k in ['F1','F2','F3','F4','F5','F6'])
    add('R3_logit_'+b, {'model_pp':round(fullL[b],3), 'max_abs_diff_vs_LPM_pp':round(diff,3),
                       **{k:round(phiL[b][k],3) for k in ['F1','F2','F3','F4','F5','F6']}})
# R5 alternative edges
d5, X5, b5 = build(clean(main), edges=(0,125,250,400), labels=('<125','125-250','250-400'))
y5 = d5.active.values; m5 = {b:(d5.zb.values==b) for b in ['<125','125-250','250-400']}
phi5, full5 = shapley_lpm(['F1','F2','F3','F4','F5','F6'], X5, b5, y5, m5, bins=('125-250','250-400'), ref='<125')
print('\n=== R5 edges 125/250 ==='); 
for b in ['125-250','250-400']:
    f5v = {k:100*y5[mm].mean() for k,mm in m5.items()}; obs5 = f5v['<125']-f5v[b]
    print('  bin %s: observed %.2f | model %+.2f | ' % (b, obs5, full5[b]) + ', '.join('%s %+.2f' % (k, phi5[b][k]) for k in ['F1','F2','F3','F4','F5','F6']))
    add('R5_edges_'+b, {'observed_pp':round(obs5,3), 'model_pp':round(full5[b],3), **{k:round(phi5[b][k],3) for k in ['F1','F2','F3','F4','F5','F6']}})
# R8 tightened
d8 = clean(main, snr_min=50, mherr=0.2)
print('\nR8 tightened sample:', len(d8))
if len(d8) > 20000:
    d8, X8, b8 = build(d8); y8=d8.active.values; m8={b:(d8.zb.values==b) for b in ['<100','100-200','200-400']}
    phi8, full8 = shapley_lpm(['F1','F2','F3','F4','F5','F6'], X8, b8, y8, m8)
    for b in ['100-200','200-400']:
        f8={k:100*y8[mm].mean() for k,mm in m8.items()}; obs8=f8['<100']-f8[b]
        print('  bin %s: observed %.2f | model %+.2f | ' % (b, obs8, full8[b]) + ', '.join('%s %+.2f' % (k, phi8[b][k]) for k in ['F1','F2','F3','F4','F5','F6']))
        add('R8_tight_'+b, {'n':len(d8), 'observed_pp':round(obs8,3), 'model_pp':round(full8[b],3), **{k:round(phi8[b][k],3) for k in ['F1','F2','F3','F4','F5','F6']}})
# R4 stratified by subtype (within-subtype, other factors only)
rows=[]
for st in ['dM1','dM2','dM3','dM4']:
    s = d[d.subclass==st]
    if len(s) < 5000: continue
    Xs = s[['F2','F3','F4','F5','F6']]; ys = s.active.values
    ms = {b:(s.zb.values==b) for b in ['<100','100-200','200-400']}
    phis, fulls = shapley_lpm(['F2','F3','F4','F5','F6'], Xs, {k:[k] for k in ['F2','F3','F4','F5','F6']}, ys, ms)
    fi = {k:100*ys[mm].mean() for k,mm in ms.items()}
    rows.append(dict(subtype=st, n=len(s), observed_pp=fi['<100']-fi['200-400'],
                     model_pp=fulls['200-400'], **{k:round(phis['200-400'][k],2) for k in ['F2','F3','F4','F5','F6']}))
R4 = pd.DataFrame(rows).round(3)
print('\n=== R4 within-subtype (200-400 pc) ===\n' + R4.to_string(index=False))
pd.DataFrame(rob).to_csv(os.path.join(D,'多因素_稳健性.csv'), index=False, encoding='utf-8-sig')
R4.to_csv(os.path.join(D,'多因素_R4_逐亚型.csv'), index=False, encoding='utf-8-sig')
print('\nwrote 多因素_稳健性.csv, 多因素_R4_逐亚型.csv')

# ---------- (c) figures
fig, axes = plt.subplots(1, 2, figsize=(11.5, 4.2))
for ax, b in zip(axes, ['100-200','200-400']):
    labels = ['F1 subtype', 'F2 Teff', 'F3 log g', 'F4 [Fe/H]', 'F5 log S/N', 'F6 log d', 'unexplained']
    vals = [phi[b][k] for k in ['F1','F2','F3','F4','F5','F6']] + [OBS[b]-full[b]]
    cum = 0.0; xs = np.arange(len(vals))
    for i, v in enumerate(vals):
        ax.bar(i, v, bottom=cum, color=('#c0392b' if i==6 else '#2c3e50'), width=0.62)
        ax.text(i, cum+v/2, '%+.2f' % v, ha='center', va='center', fontsize=6.5, color='white' if abs(v)>0.6 else 'black')
        cum += v
    ax.axhline(OBS[b], color='k', ls='--', lw=1.0)
    ax.set_xticks(xs); ax.set_xticklabels(labels, rotation=35, ha='right', fontsize=7)
    ax.set_ylabel('activity decline (pp)')
    ax.set_title('%s pc bin: observed %.2f pp' % (b, OBS[b]), fontsize=9)
plt.tight_layout(); plt.savefig(os.path.join(D,'多因素_瀑布图.png'), dpi=180); plt.close()
print('wrote 多因素_瀑布图.png')
