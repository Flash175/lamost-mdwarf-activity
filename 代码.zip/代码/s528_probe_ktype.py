
# -*- coding: utf-8 -*-
"""探测 LAMOST OpenAPI 里可用的星表（找 K 型），并测试 DR13 是否需要 token。"""
import io, os, sys, itertools
import requests
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
BASE = 'https://www.lamost.org/openapi'
token = ''
for p in ('extract/lamost_token.txt', 'extract/token.txt', 'data/lamost/token.txt'):
    if os.path.exists(p):
        token = open(p).read().strip(); print('token 文件:', p, '(长度 %d)' % len(token)); break
else:
    print('未找到 token 文件')

def sql(dr, sub, q, timeout=40):
    params = {'sql': q, 'output.fmt': 'csv'}
    if token: params['token'] = token
    try:
        r = requests.get(f'{BASE}/{dr}/{sub}/sql', params=params, timeout=timeout,
                         headers={'User-Agent': 'probe'})
        return r.status_code, r.text[:160].replace('\n', ' ')
    except Exception as e:
        return -1, type(e).__name__ + ': ' + str(e)[:80]

for dr, sub in (('dr13', 'v1.0'), ('dr12', 'v1.0'), ('dr11', 'v1.0'), ('dr10', 'v2.0')):
    for tbl in ('mstellar', 'stellar', 'lrs_stellar', 'catalogue', 'lrs'):
        q = "select count(*) as n from %s where subclass like 'K%%'" % tbl
        sc, txt = sql(dr, sub, q)
        print('%s/%s %-12s -> %s  %s' % (dr, sub, tbl, sc, txt[:90]))
