
# -*- coding: utf-8 -*-
"""s633：R8 修正（snru 需先转数值）并补跑"""
import os, sys, io, math, itertools
import numpy as np, pandas as pd
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
D = r'C:\Users\lingz\Desktop\复现老师工作\APJS\多个图及讨论'
main = pd.read_csv(os.path.join(D,'金属度_清洁样本_637973.csv'), low_memory=False)
for c in ['teff','logg','m_h','m_h_err','snru','dist_pc','absz','ewha','ewha_err']:
    main[c] = pd.to_numeric(main[c], errors='coerce')
sb1 = pd.read_csv(os.path.join(D,'RV变星_SB1候选_多历元.csv'), low_memory=False)
SB = set(sb1.uid)
print('snru>50 & <100 in main:', int(((main.snru>50)&(main.snru<100)).sum()),
      '| m_h_err<0.2:', int((main.m_h_err<0.2).sum()))
d = main[~main.uid.isin(SB)]
for c in ['teff','logg','m_h','snru']: d = d[d[c].notna() & (d[c]!=-9999)]
d = d[(d.teff>=2000)&(d.teff<=4500)&(d.logg>=3)&(d.logg<=6)&(d.m_h.abs()<1)]
d = d[(d.snru>50)&(d.snru<100)&(d.m_h_err<0.2)&(d.mh_ok==True)&(d.dist_pc>0)&(d.absz>0)&(d.absz<=400)].copy()
print('R8 sample:', len(d))
d['active'] = ((d.ewha>=0.75)&(d.ewha>3*d.ewha_err)).astype(float)
d['zb'] = pd.cut(d.absz,[0,100,200,400],labels=['<100','100-200','200-400'])
DUM = pd.get_dummies(d.subclass, prefix='s', drop_first=True).astype(float)
for c,nm in [('teff','F2'),('logg','F3'),('m_h','F4')]:
    v=d[c]; d[nm]=v-v.mean()
d['F2']=d.F2/1000.0
lv=np.log10(d.snru); d['F5']=lv-lv.mean()
ld=np.log10(d.dist_pc); d['F6']=ld-ld.mean()
X=pd.concat([DUM,d[['F2','F3','F4','F5','F6']]],axis=1)
blocks={'F1':list(DUM.columns),'F2':['F2'],'F3':['F3'],'F4':['F4'],'F5':['F5'],'F6':['F6']}
y=d.active.values; masks={b:(d.zb.values==b) for b in ['<100','100-200','200-400']}
def shapley(keys):
    K=len(keys); cache={}
    def delta(S):
        cols=[c for k in S for c in blocks[k]]
        A=np.column_stack([np.ones(len(y))]+[X[c].values for c in cols]) if cols else np.ones((len(y),1))
        beta,*_=np.linalg.lstsq(A,y,rcond=None); pr=A@beta
        v={b:pr[m].mean() for b,m in masks.items()}
        return {b:100*(v[b]-v['<100']) for b in ['100-200','200-400']}
    for r in range(K+1):
        for S in itertools.combinations(keys,r): cache[frozenset(S)]=delta(S)
    phi={b:{k:0.0 for k in keys} for b in ['100-200','200-400']}
    for k in keys:
        others=[x for x in keys if x!=k]
        for r in range(len(others)+1):
            for S in itertools.combinations(others,r):
                w=math.factorial(len(S))*math.factorial(K-len(S)-1)/math.factorial(K)
                for b in phi: phi[b][k]+=w*(cache[frozenset(tuple(sorted(S+(k,))))][b]-cache[frozenset(S)][b])
    return phi, cache[frozenset(keys)]
phi, full = shapley(['F1','F2','F3','F4','F5','F6'])
f={b:100*y[m].mean() for b,m in masks.items()}
print('\nbin rates (%):', {k:round(v,2) for k,v in f.items()})
rows=[]
for b in ['100-200','200-400']:
    obs=f['<100']-f[b]
    print('bin %-8s observed %.2f | model %+.2f | ' % (b, obs, full[b]) + ', '.join('%s %+.2f' % (k, phi[b][k]) for k in ['F1','F2','F3','F4','F5','F6']))
    rows.append(dict(bin=b, n=len(d), observed_pp=round(obs,3), model_pp=round(full[b],3), **{k:round(phi[b][k],3) for k in ['F1','F2','F3','F4','F5','F6']}))
pd.DataFrame(rows).to_csv(os.path.join(D,'多因素_R8_收紧.csv'), index=False, encoding='utf-8-sig')
print('wrote 多因素_R8_收紧.csv')
