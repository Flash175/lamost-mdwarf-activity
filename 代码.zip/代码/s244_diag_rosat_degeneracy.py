# -*- coding: utf-8 -*-
"""s244：`诊断_Ro_sat简并.png` 重绘（附录用）。

背景：该图由已丢失的脚本生成（文件时间 2026-10-22 12:06），图上有两处旧口径标注：
  ① 红点线 `reported 0.116` —— 已作废的**分面板自由断点**次支值（0.114–0.116），
     现行口径是**全体固定断点 0.135**，故红点线移到 0.135 并改标 `adopted`；
  ② 灰点线 `old grid edge 0.079` —— 指旧搜索网格起点 10^−1.1，属历史留痕，保留。
蓝点 0.047 / 0.050（= 两面板 ΔRSS 全局极小）与脚注所述平坦区 0.05–0.20 与现行口径一致，不动。

ΔRSS 定义（与正文/台账的分段模型一致，本脚本内自述）：
  断点 rs 以下 = 常数（坪），以上 = 直线；RSS(rs) = 下段常模型残差 + 上段直线残差；
  ΔRSS = RSS(rs) − min_rs RSS（**逐面板各减各的极小**，故左图 0.046 / 右图 0.050 处为 0）。

⚠ 与归档 PNG 的关系：归档脚本已丢失，无法逐像素复现其纵轴绝对值；本脚本按上定义重算，
  极小位置（0.046 / 0.050）、平坦区范围（≈0.05–0.20）与 β 漂移幅度（−0.38→−1.31 / −0.62→−3.14）
  均与归档图一致，仅 ΔRSS 绝对标度略有差异（同量级、同形状）。归档图已留为
  `图/旧版_诊断_Ro_sat简并_20261022_1206.png`。

数据源：数据/图5_逐星样本_严格3340行_⑤.csv（Ro 列是 −0.31 旧口径，本脚本按 M、P 以 −0.30 重算）
输出：图/诊断_Ro_sat简并.png

打印留痕（2026-10-23 加，不影响图面）：`branch_report()` 每个面板打一次
「两种 τ 口径（−0.30 / −0.31）× 两种网格（图域 400 点 / 宽域 1,101 点）× 上下两支」的
ΔRSS 相对极小、两点跨度、该断点下的 β。用途是把正文/台账里「Ro_sat 由 A 变到 B，RSS 只差 X」
这句话钉住，避免把「跨度」当「ΔRSS」用（M0–M3：跨度 0.81 vs ΔRSS 1.27；M4–M6：两者同为 7.64）。
"""
import io, os, sys
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
import numpy as np, pandas as pd
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import NullFormatter, FixedLocator, FixedFormatter

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
SAMPLE = os.path.join(ROOT, '数据', '图5_逐星样本_严格3340行_⑤.csv')
OUT = os.path.join(ROOT, '图', '诊断_Ro_sat简并.png')

BP = 0.135          # 现行：全体固定断点（台账 §2）
OLD_GRID = 0.079    # 旧搜索网格起点 10^-1.1（仅历史留痕）
TAU_C2 = -0.30      # Li et al. 2024 印刷式
TAU_C2_ALT = -0.31  # Wright et al. 2018 原式号（作对照）

PAN = [('M0–M3', ['dM0', 'dM1', 'dM2', 'dM3']),
       ('M4–M6', ['dM4', 'dM5', 'dM6'])]

# 两支留痕（2026-10-23）：每面板的自由断点 bootstrap 双支端点，用于把正文
# 「Ro_sat 由 A 变到 B，RSS 只差 X」这句话钉住。上支 = 次支（较高 Ro 那一支）。
BRANCH = {'M0–M3': (0.047, 0.116),   # 下支 / 上支（上支簇 0.114–0.116）
          'M4–M6': (0.050, 0.114)}
# 两种网格：图内横轴域 + s227/s228 的宽域（台账 §4 所述「宽域网格」）
DOMAINS = [('图域 0.020–0.400 (400点)', 0.02, 0.4, 400),
           ('宽域 0.004–0.500 (1101点)', 4e-3, 0.5, 1101)]


def branch_report(nm, q):
    """打印同一面板在 −0.30 / −0.31 两种 τ 口径、两种网格下的两支 ΔRSS 留痕。

    两个量必须分开报，混用会差 0.4 以上：
      ΔRSS(上支) = RSS(上支) − min_rs RSS   （与图纵轴同定义）
      跨度       = RSS(上支) − RSS(下支)     （上一轮报的 0.81 即此量）
    下支恰好落在极小上时（M4–M6 的 0.050）两者相等；M0–M3 的下支 0.047 比极小
    0.0457 高 2.8%，故跨度比 ΔRSS 小 0.46。
    """
    bp_lo, bp_up = BRANCH[nm]
    print('    [两支] 下支 %.3f ／ 上支 %.3f' % (bp_lo, bp_up))
    for c in (TAU_C2, TAU_C2_ALT):
        ro = q.P.values / 10 ** (2.33 - 1.50 * q.M.values + c * q.M.values ** 2)
        x, y = np.log10(ro), np.log10(q.RHa.values)
        for dn, lo, hi, n in DOMAINS:
            g = np.logspace(np.log10(lo), np.log10(hi), n)
            prof = [rss_beta(x, y, t) for t in np.log10(g)]
            r = np.array([p[0] for p in prof])
            i = int(np.argmin(r))
            rmin = r[i]
            r_up, b_up = rss_beta(x, y, np.log10(bp_up))
            r_lo, _ = rss_beta(x, y, np.log10(bp_lo))
            print('           τ%+0.2f %-22s 极小@%.4f  RSS=%.3f  '
                  'ΔRSS(%0.3f)=%+.2f = 跨度 %+.2f + [RSS(下)−min] %+.2f  β=%+.3f'
                  % (c, dn, g[i], rmin, bp_up, r_up - rmin,
                     r_up - r_lo, r_lo - rmin, b_up))


def rss_beta(x, y, rs, minseg=20):
    s, u = x <= rs, x > rs
    if s.sum() < minseg or u.sum() < minseg:
        return np.inf, np.nan
    r = ((y[s] - y[s].mean()) ** 2).sum()
    sl, ic = np.polyfit(x[u], y[u], 1)
    r += ((y[u] - (sl * x[u] + ic)) ** 2).sum()
    return r, sl


def main():
    d = pd.read_csv(SAMPLE)
    d = d[(d.Ro > 0) & (d.RHa > 0) & (d.P > 0) & (d.M > 0)].copy()
    d['Ro30'] = d.P / 10 ** (2.33 - 1.50 * d.M + TAU_C2 * d.M ** 2)

    fig, axes = plt.subplots(1, 2, figsize=(11.6, 5.6))
    for ax, (nm, sel) in zip(axes, PAN):
        q = d[d.spt.isin(sel)]
        assert len(q) == {'M0–M3': 2083, 'M4–M6': 1245}[nm], \
            '%s n=%d 与台账 2,083 / 1,245 不符' % (nm, len(q))
        x, y = np.log10(q.Ro30.values), np.log10(q.RHa.values)
        grid = np.logspace(np.log10(0.02), np.log10(0.4), 400)
        out = np.array([rss_beta(x, y, np.log10(g)) for g in grid])
        rss, beta = out[:, 0], out[:, 1]
        drss = rss - np.nanmin(rss)
        i = int(np.nanargmin(rss))
        print('%s n=%d  ΔRSS 极小 @ %.4f ；ΔRSS(0.135)=%.2f ；β(0.02)=%.2f β(0.135)=%.3f β(0.40)=%.2f'
              % (nm, len(q), grid[i], np.interp(np.log10(BP), np.log10(grid), drss),
                 beta[0], np.interp(np.log10(BP), np.log10(grid), beta), beta[-1]))
        branch_report(nm, q)

        # 蓝：ΔRSS（左轴）
        ax.plot(grid, drss, c='#1f4fd8', lw=1.2, label=u'ΔRSS')
        ax.set_xscale('log'); ax.set_xlim(0.02, 0.4)
        ax.set_ylim(bottom=-0.4)
        ax.xaxis.set_minor_formatter(NullFormatter())
        ax.xaxis.set_major_locator(FixedLocator([0.02, 0.05, 0.1, 0.2, 0.4]))
        ax.xaxis.set_major_formatter(FixedFormatter(['0.02', '0.05', '0.1', '0.2', '0.4']))
        ax.set_xlabel(u'$R_{\\rm o,sat}$', fontsize=10)
        ax.set_ylabel(u'ΔRSS', fontsize=10, color='#1f4fd8')
        ax.tick_params(axis='y', colors='#1f4fd8', direction='in', labelsize=8.5)
        ax.tick_params(axis='x', direction='in', top=True, labelsize=8.5)
        ax.set_title(u'%s (n=%d)' % (nm, len(q)), fontsize=10)
        ax.annotate(u'global min %.3f' % grid[i], xy=(grid[i], 0),
                    xytext=(5, 16), textcoords='offset points', fontsize=7.4, color='#1f4fd8',
                    bbox=dict(fc='white', ec='none', alpha=0.85, pad=0.8))

        # 橙：该断点下的上段斜率 β（右轴）
        ax2 = ax.twinx()
        ax2.plot(grid, beta, c='#c8721f', lw=1.4)
        ax2.set_ylabel(u'β at that $R_{\\rm o,sat}$', fontsize=9, color='#c8721f')
        ax2.tick_params(axis='y', colors='#c8721f', direction='in', labelsize=8.5)

        # 灰：旧搜索网格起点（历史留痕）
        ax.axvline(OLD_GRID, c='0.45', ls='--', lw=0.9, zorder=1)
        # 红：现行采纳值（全体固定断点）
        ax.axvline(BP, c='crimson', ls=':', lw=1.4, zorder=1)

    # ---- 留痕核对（2026-10-23）：钉住正文/记录里的两个 RSS 差数 ----
    def _flat(nm, c):
        sel = dict(PAN)[nm]
        q = d[d.spt.isin(sel)]
        ro = q.P.values / 10 ** (2.33 - 1.50 * q.M.values + c * q.M.values ** 2)
        x, y = np.log10(ro), np.log10(q.RHa.values)
        g = np.logspace(np.log10(0.02), np.log10(0.4), 400)
        r = np.array([rss_beta(x, y, t)[0] for t in np.log10(g)])
        i = int(np.argmin(r))
        bp_lo, bp_up = BRANCH[nm]
        return (g[i], r[i], rss_beta(x, y, np.log10(bp_up))[0],
                rss_beta(x, y, np.log10(bp_lo))[0])

    # 网格原子核对：区分「宽域网格才能取到的下支」与「两种网格共有的上支」
    g401 = np.linspace(-1.1, -0.4, 401)          # 旧网格：10^-1.1–10^-0.4 = 0.0794–0.3981
    g1101 = np.logspace(np.log10(4e-3), np.log10(0.5), 1101)
    print('    [网格] 旧 401 点网格端点 %.4f–%.4f；0.046/0.050 落在下界之外（旧网格取不到），'
          '0.116/0.114 两网格共有' % (10 ** g401[0], 10 ** g401[-1]))
    for bp in (0.046, 0.050, 0.116, 0.114):
        i4 = int(np.argmin(np.abs(g401 - np.log10(bp))))
        i11 = int(np.argmin(np.abs(np.log10(g1101) - np.log10(bp))))
        print('            %.3f：401 格最近原子 %.5f（在界内=%s）｜1101 格最近原子 %.5f'
              % (bp, 10 ** g401[i4], g401[0] <= np.log10(bp) <= g401[-1], g1101[i11]))

    for nm in ('M0–M3', 'M4–M6'):
        bp_lo, bp_up = BRANCH[nm]
        mn, rmin, r_up, r_lo = _flat(nm, TAU_C2)
        mn1, rmin1, r_up1, r_lo1 = _flat(nm, TAU_C2_ALT)
        print('    [核对] %s 上支 %.3f：ΔRSS(−0.30)=%.2f  ΔRSS(−0.31)=%.2f  '
              '跨度=%.2f / %.2f' % (nm, bp_up, r_up - rmin, r_up1 - rmin1,
                                    r_up - r_lo, r_up1 - r_lo1))
    print('    [核对] M4–M6 ΔRSS(0.114)=7.64 vs 声称 7.5 → 差 0.14（1.8%），成立；严格写 7.6')
    print('    [核对] M0–M3 0.047 落在旧 401 点网格下界 0.079 之外，'
          '故正文「旧 401 点网格下由 0.047 变到 0.116」这句本身不成立')

    from matplotlib.lines import Line2D
    handles = [Line2D([], [], c='crimson', ls=':', lw=1.4,
                      label=u'adopted $R_{\\rm o,sat}$ = %.3f (all-sample, fixed)' % BP),
               Line2D([], [], c='0.45', ls='--', lw=0.9,
                      label=u'old search-grid edge = %.3f (superseded)' % OLD_GRID)]
    fig.legend(handles=handles, loc='lower center', bbox_to_anchor=(0.5, 0.172),
               ncol=2, frameon=False, fontsize=7.8)

    foot = ('ΔRSS is relative to each panel minimum (rows below: constant plateau, above: power law). '
            'The surface is only weakly structured:\n'
            '    M0–M3: two shallow minima, Ro ≈ 0.046 and ≈ 0.115 (the second ΔRSS ≈ 1 above the first; '
            'ridge between them ΔRSS ≈ 6).\n'
            '    M4–M6: one minimum in this range, Ro ≈ 0.049; its second ΔRSS branch lies at Ro ≈ 0.014, '
            'left of the axis.\n'
            'The knee is therefore not identifiable from ΔRSS alone; β (orange) slides with the adopted breakpoint. '
            'Adopted all-sample %.3f (red);\n'
            '    earlier per-panel 0.116 (0.114–0.116) withdrawn; old grid edge %.3f (grey, superseded).'
            % (BP, OLD_GRID))
    fig.text(0.5, 0.010, foot, ha='center', va='bottom', fontsize=6.0, color='0.3', linespacing=1.8)
    assert foot.count('\n') == 4, '脚注应为 5 行，实际 %d 行' % (foot.count('\n') + 1)
    # 版式断言：脚注不得左右溢出画幅
    fig.canvas.draw(); _r = fig.canvas.get_renderer()
    _b = fig.texts[-1].get_window_extent(renderer=_r).transformed(fig.transFigure.inverted())
    assert _b.x0 > 0.004 and _b.x1 < 0.996, '脚注横向溢出：x0=%.4f x1=%.4f' % (_b.x0, _b.x1)
    fig.tight_layout(rect=(0, 0.255, 1, 1))
    fig.subplots_adjust(wspace=0.62)
    fig.savefig(OUT, dpi=200); plt.close(fig)
    print('已出图 -> %s' % OUT)


if __name__ == '__main__':
    main()
