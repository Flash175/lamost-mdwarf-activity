# -*- coding: utf-8 -*-
"""TESS 自转周期（修正过滤条件，用 dataURL 下载）"""
import io, os, sys, json, warnings, time
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
warnings.filterwarnings('ignore')
import numpy as np, pandas as pd, requests
from astropy.io import fits
from astropy.timeseries import LombScargle
W = 'https://mast.stsci.edu/api/v0/invoke'
os.makedirs('data/raw/tess_lc', exist_ok=True)
S = pd.read_csv('data/processed/dr13/ib2025_ztf_periods.csv')
Z = pd.read_csv('data/processed/dr13/ib2025_stars_with_prot.csv')
Z['key'] = Z.star.str.replace(' ', '').str.upper(); S['key'] = S.star.str.replace(' ', '').str.upper()
S = S.merge(Z[['key', 'P_rot']], on='key', how='left')
todo = S[S.P_rot.isna()].head(14)
print('本轮 %d 颗：%s' % (len(todo), ', '.join(todo.star)))
rows = []
for _, st in todo.iterrows():
    try:
        r = requests.post(W, data={'request': json.dumps({'service': 'Mast.Caom.Cone',
                'params': {'ra': float(st.ra), 'dec': float(st.dec), 'radius': 0.008}, 'format': 'json', 'pagesize': 100})}, timeout=90)
        data = r.json().get('data', [])
    except Exception as e:
        print('   %-10s MAST 查询异常 %s' % (st.star, type(e).__name__)); continue
    cand = [d for d in data if d.get('obs_collection') == 'TESS' and d.get('dataproduct_type') == 'timeseries'
            and str(d.get('dataURL', '')).endswith('lc.fits')]
    if not cand:
        print('   %-10s 无 TESS LC（timeseries %d 行）' % (st.star, sum(1 for d in data if d.get('dataproduct_type') == 'timeseries'))); continue
    cand.sort(key=lambda d: (-(d.get('t_exptime') or 0), -(d.get('t_max', 0) - d.get('t_min', 0) if d.get('t_max') else 0)))
    best = cand[0]
    fn = best['dataURL'].split('/')[-1]
    local = os.path.join('data/raw/tess_lc', fn)
    if not os.path.exists(local):
        try:
            rr = requests.get('https://mast.stsci.edu/api/v0.1/Download/file?uri=' + best['dataURL'], timeout=240)
            if rr.status_code != 200:
                print('   %-10s 下载 %s' % (st.star, rr.status_code)); continue
            open(local, 'wb').write(rr.content)
        except Exception as e:
            print('   %-10s 下载异常 %s' % (st.star, type(e).__name__)); continue
    try:
        d = fits.open(local)[1].data
        t = np.asarray(d['TIME'], float); f = np.asarray(d['PDCSAP_FLUX'], float)
        q = np.asarray(d['QUALITY'], int) if 'QUALITY' in d.names else np.zeros(len(t), int)
        g = np.isfinite(t) & np.isfinite(f) & (q == 0); t, f = t[g], f[g]
        if len(t) < 200:
            print('   %-10s 有效点 %d 太少' % (st.star, len(t))); continue
        f = f/np.median(f) - 1.0
        f = f - np.polyval(np.polyfit(t, f, 2), t)
        freq = np.linspace(1/100.0, 1/0.2, 60000)
        ls = LombScargle(t, f)
        p = ls.power(2*np.pi*freq); i = int(np.argmax(p))
        P, pk = 1/freq[i], float(p[i])
        fap = float(ls.false_alarm_probability(pk, method='baluev'))
        rows.append(dict(star=st.star, P_tess=round(P, 4), power=round(pk, 3), FAP=fap, N=len(t), file=fn))
        print('   %-10s P=%.3f d power=%.3f FAP=%.2g N=%d  %s' % (st.star, P, pk, fap, len(t), fn[:38]))
    except Exception as e:
        print('   %-10s 解析异常 %s' % (st.star, type(e).__name__))
T = pd.DataFrame(rows)
T.to_csv('data/processed/dr13/ib2025_tess_prot_selfcomputed.csv', index=False)
print('\n成功 %d 颗；FAP<0.01: %d' % (len(T), int((T.FAP < 0.01).sum()) if len(T) else 0))
