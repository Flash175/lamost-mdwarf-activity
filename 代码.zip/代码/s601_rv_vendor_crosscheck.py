# -*- coding: utf-8 -*-
"""s601：LAMOST RV 与 Gaia RV 的「同一批星」交叉检验

s600 用 LAMOST RV 把样本从 8.25 万扩到 61.1 万，得到「活动星更冷」延伸到 125 pc、且 200 pc 以外两种估计量都翻正。
但 LAMOST RV 来自模板互相关，发射线（活动星）可能使 CCF 系统性偏移。本脚本在**同一批同时有两种 RV 的星**上
分别用 Gaia RV 与 LAMOST RV 重做同一分片比较，检验结论是否由 RV 系统差造成。

输出：多个图及讨论/rv_vendor_crosscheck.csv
"""
import io, sys, os
import numpy as np, pandas as pd
from astropy.coordinates import SkyCoord, Galactocentric
import astropy.units as un

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
BASE = r'C:\Users\lingz\OneDrive\Desktop\复现老师工作'
OUT = r'C:\Users\lingz\Desktop\复现老师工作\APJS\多个图及讨论'
C_KMS = 299792.458

cat = pd.read_csv(os.path.join(BASE,'data','lamost','dr13','dr13_mstellar_dM.csv'), low_memory=False,
                  usecols=['obsid','uid','subclass','ewha','ewha_err','snrr','z','z_err',
                           'ra','dec','gaia_source_id','gaia_g_mean_mag'])
cat = cat[(cat.ewha > -20) & (cat.ewha <= 50) & (cat.ewha_err > 0) & (cat.ewha_err <= 5)].copy()
cat['active'] = (cat.ewha >= 0.75) & (cat.ewha > 3*cat.ewha_err)
cat['gaia_source_id'] = pd.to_numeric(cat.gaia_source_id, errors='coerce')
g = pd.read_csv(os.path.join(BASE,'data','gaia','gaia_dr3_mstars.csv'), low_memory=False,
                usecols=['source_id','parallax','parallax_error','pmra','pmdec','ruwe','radial_velocity'])
m = cat.merge(g, left_on='gaia_source_id', right_on='source_id', how='inner')
m = m[(m.parallax > 0.2) & (m.parallax/m.parallax_error > 5) & (m.ruwe < 1.4)].copy()
u = m.sort_values('ewha', ascending=False).drop_duplicates('uid').copy()
u['MG'] = u.gaia_g_mean_mag.values - 5*np.log10(np.clip(1000.0/u.parallax.values, 1, None)) + 5
u = u[u.MG >= 6].copy()
u['rv_lam'] = C_KMS*u.z; u['sig_lam'] = C_KMS*u.z_err.abs()
both = u[(u.radial_velocity.notna()) & (u.z != 0) & (u.z_err > 0) & (u.sig_lam < 20)
         & (u.rv_lam.abs() < 500) & (u.radial_velocity.abs() < 500)].copy()
print('同时有两种 RV 的星：%d' % len(both))
d_pc = 1000.0/both.parallax.values
def vz_of(rv):
    sc = SkyCoord(ra=both.ra.values*un.deg, dec=both.dec.values*un.deg, distance=(d_pc/1000.)*un.kpc,
                  pm_ra_cosdec=both.pmra.values*un.mas/un.yr, pm_dec=both.pmdec.values*un.mas/un.yr,
                  radial_velocity=rv*un.km/un.s, frame='icrs')
    gc = sc.transform_to(Galactocentric())
    return gc.velocity.d_z.to(un.km/un.s).value
both['vz_gaia'] = vz_of(both.radial_velocity.values)
both['vz_lam'] = vz_of(both.rv_lam.values)
both['absz'] = np.abs(d_pc*np.sin(np.deg2rad(SkyCoord(ra=both.ra.values*un.deg, dec=both.dec.values*un.deg,
                  distance=(d_pc/1000.)*un.kpc, frame='icrs').galactic.b.deg)))
def stats(v):
    n = len(v)
    if n < 30: return np.nan, np.nan, np.nan
    s = np.std(v, ddof=1); mad = 1.4826*np.median(np.abs(v - np.median(v)))
    return s, mad, np.sqrt(2.0/(n-1))*s
rows = []
for lo in range(0, 401, 25):
    hi = lo + 25
    s = both[(both.absz >= lo) & (both.absz < hi)]
    a = s[s.active]; i = s[~s.active]
    if len(a) < 40 or len(i) < 40: continue
    out = dict(z_lo=lo, n=len(s), n_act=len(a), n_inact=len(i))
    for tag, col in [('gaia','vz_gaia'), ('lam','vz_lam')]:
        sa, ma, sea = stats(a[col].values); si, mi, sei = stats(i[col].values)
        se = np.sqrt(sea**2 + sei**2)
        out['d_std_%s' % tag] = sa - si; out['sig_std_%s' % tag] = (sa - si)/se if se else np.nan
        out['d_mad_%s' % tag] = ma - mi
    rows.append(out)
T = pd.DataFrame(rows)
print('\n同一批星、两种 RV 的分片差分（d_std：活动 − 非活动，负=活动更冷）')
print(T[['z_lo','n','d_std_gaia','sig_std_gaia','d_std_lam','sig_std_lam','d_mad_gaia','d_mad_lam']]
      .to_string(index=False, float_format=lambda x: '%.2f' % x))
fp = os.path.join(OUT, 'rv_vendor_crosscheck.csv')
T.to_csv(fp, index=False, encoding='utf-8')
txt = open(fp, encoding='utf-8').read()
hdr = ('# s601：同一批（同时有 Gaia RV 与 LAMOST RV 的）星，用两种 RV 各做一次 σ(vz) 差分\n'
       '# d_std_* / d_mad_* = σ_act − σ_inact；负值=活动星更冷。若两种 RV 给的 d 一致，说明 LAMOST RV 无活动相关系统差\n'
       '# 生成脚本：代码/s601_rv_vendor_crosscheck.py\n')
open(fp, 'w', encoding='utf-8-sig').write(hdr + txt)
print('\n写出 rv_vendor_crosscheck.csv（%d 行）' % len(T))
