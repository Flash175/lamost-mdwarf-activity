# -*- coding: utf-8 -*-
"""s614：内盘三档（<100 / 100–200 / 200–400 pc）重算 f、n、z 中位，并做未加权与二项加权指数拟合。

目的：正文 §2.9 的两个手工常数（未加权 a = −1.2262、b = −0.004920 /pc；二项加权 b = −0.005198 /pc，
H = 192.4 pc）此前只存在于文字里。本脚本从 637,973 颗 2D 样本直接重算，落盘 lnf_binfit.csv。
"""
import io
import os
import sys

import numpy as np
import pandas as pd
from astropy import units as un
from astropy.coordinates import SkyCoord

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

BASE = r"C:\Users\lingz\OneDrive\Desktop\复现老师工作"
DATA = r"C:\Users\lingz\Desktop\复现老师工作\APJS\多个图及讨论"

cat = pd.read_csv(os.path.join(BASE, "data", "lamost", "dr13", "dr13_mstellar_dM.csv"), low_memory=False,
                  usecols=["uid", "subclass", "ewha", "ewha_err", "ra", "dec", "gaia_source_id", "gaia_g_mean_mag"])
cat = cat[(cat.ewha > -20) & (cat.ewha <= 50) & (cat.ewha_err > 0) & (cat.ewha_err <= 5)].copy()
cat["active"] = (cat.ewha >= 0.75) & (cat.ewha > 3 * cat.ewha_err)
cat["gaia_source_id"] = pd.to_numeric(cat.gaia_source_id, errors="coerce")
g = pd.read_csv(os.path.join(BASE, "data", "gaia", "gaia_dr3_mstars.csv"), low_memory=False,
                usecols=["source_id", "parallax", "parallax_error", "pmra", "pmdec", "ruwe"])
m = cat.merge(g, left_on="gaia_source_id", right_on="source_id", how="inner")
m = m[(m.parallax > 0.2) & (m.parallax / m.parallax_error > 5) & (m.ruwe < 1.4)].copy()
u = m.sort_values("ewha", ascending=False).drop_duplicates("uid").copy()
u["MG"] = u.gaia_g_mean_mag.values - 5 * np.log10(np.clip(1000.0 / u.parallax.values, 1, None)) + 5
u = u[u.MG >= 6].copy()
print("2D 样本 %d 颗，活动 %.3f%%" % (len(u), 100 * u.active.mean()))

d_pc = 1000.0 / u.parallax.values
sc = SkyCoord(ra=u.ra.values * un.deg, dec=u.dec.values * un.deg, distance=(d_pc / 1000.0) * un.kpc,
              pm_ra_cosdec=u.pmra.values * un.mas / un.yr, pm_dec=u.pmdec.values * un.mas / un.yr,
              frame="icrs")
b = np.deg2rad(sc.galactic.b.deg)
u["absz"] = np.abs(d_pc * np.sin(b))

edges = [(0, 100), (100, 200), (200, 400)]
rows = []
for lo, hi in edges:
    s = u[(u.absz >= lo) & (u.absz < hi)]
    n = len(s); k = int(s.active.sum()); p = k / n
    sig = np.sqrt((1 - p) / (n * p))
    rows.append(dict(zbin="%d-%d" % (lo, hi), lo=lo, hi=hi, n=n, k=k, frac=100 * p,
                     zmed=float(np.median(s.absz)), zmean=float(s.absz.mean()),
                     sig_lnf=float(sig)))
    print("%-9s n=%7d k=%6d f=%.2f%%  z_med=%.1f  sigma(ln f)=%.4f" % (rows[-1]["zbin"], n, k, 100 * p, rows[-1]["zmed"], sig))

df = pd.DataFrame(rows)

def wls(z, y, w):
    X = np.column_stack([np.ones_like(z), z])
    W = np.diag(w)
    beta = np.linalg.solve(X.T @ W @ X, X.T @ W @ y)
    cov = np.linalg.inv(X.T @ W @ X)
    se = np.sqrt(np.diag(cov))
    chi2 = float(((y - X @ beta) ** 2 * w).sum())
    return beta, se, chi2

y = np.log(df.frac.values / 100.0)
out = []
for label, z in [("unweighted@zmed", df.zmed.values), ("unweighted@zmean", df.zmean.values),
                 ("binomial@zmed", df.zmed.values), ("binomial@zmean", df.zmean.values)]:
    w = np.ones_like(z) if label.startswith("unweighted") else 1.0 / df.sig_lnf.values ** 2
    beta, se, chi2 = wls(z, y, w)
    H = -1.0 / beta[1]; Hse = abs(se[1] / beta[1] ** 2)  # z 以 pc 为单位，故 H 直接是 pc
    out.append(dict(fit=label, a=beta[0], a_se=se[0], b_per_kpc=beta[1], b_se=se[1], H_pc=H, H_se=Hse, chi2=chi2))
    print("%-18s a=%+.6f b=%+.6f±%.6f /kpc  H=%.1f±%.1f pc  chi2=%.1f" % (label, beta[0], beta[1], se[1], H, Hse, chi2))

path = os.path.join(DATA, "lnf_binfit.csv")
with open(path, "w", encoding="utf-8") as f:
    f.write("# s614：内盘三档（<100/100-200/200-400 pc）的 f、n、z 中位与两种指数拟合（正文 §2.9 常数复算）\n")
    f.write("# 样本 = 2D 样本 637,973 颗（视差质量 + 每 uid 取 EW 最大 + 去巨星 M_G>=6），|Z| = d*sin(b_gal)\n")
    f.write("# sigma(ln f) = sqrt((1-p)/(n*p))；binomial 权重 = 1/sigma^2\n")
    f.write("# 生成脚本：代码/s614_binfit_recompute.py\n")
    f.write("section,zbin,n,k,frac_pct,zmed_pc,zmean_pc,sig_lnf\n")
    for r in rows:
        f.write("bins,%s,%d,%d,%.6f,%.4f,%.4f,%.8f\n" % (r["zbin"], r["n"], r["k"], r["frac"], r["zmed"], r["zmean"], r["sig_lnf"]))
    f.write("section,fit,a,a_se,b_per_kpc,b_se,H_pc,H_se,chi2\n")
    for r in out:
        f.write("fits,%s,%.8f,%.8f,%.8f,%.8f,%.2f,%.2f,%.2f\n" % (r["fit"], r["a"], r["a_se"], r["b_per_kpc"], r["b_se"], r["H_pc"], r["H_se"], r["chi2"]))
print("写出", path, os.path.getsize(path), "B")
