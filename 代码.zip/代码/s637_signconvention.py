
# -*- coding: utf-8 -*-
"""s637：符号口径修正 —— 统一用「对降幅的贡献」（正=贡献于观测下降），重出表与图。
之前把 Δ(F)（负）直接与观测降幅（正）相减，导致残余 14.3/22.2 pp 的错误（应为 7.5/9.9 pp）。
"""
import os, math, itertools, numpy as np, pandas as pd
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
D = r'C:\Users\lingz\Desktop\复现老师工作\APJS\多个图及讨论'
d = pd.read_csv(os.path.join(D,'分解样本_snrr_470548.csv'), low_memory=False)
d['zb'] = pd.cut(d.absz,[0,100,200,400],labels=['<100','100-200','200-400'])
DUM = pd.get_dummies(d.subclass, prefix='s', drop_first=True).astype(float)
for c,nm in [('teff','F2'),('logg','F3'),('m_h','F4')]:
    v=d[c]; d[nm]=v-v.mean()
d['F2']=d.F2/1000.0
lv=np.log10(d.snrr); d['F5']=lv-lv.mean()
ld=np.log10(d.dist_pc); d['F6']=ld-ld.mean()
X=pd.concat([DUM,d[['F2','F3','F4','F5','F6']]],axis=1)
blocks={'F1':list(DUM.columns),'F2':['F2'],'F3':['F3'],'F4':['F4'],'F5':['F5'],'F6':['F6']}
y=d.active.values; masks={b:(d.zb.values==b) for b in ['<100','100-200','200-400']}
keys=['F1','F2','F3','F4','F5','F6']; K=6; cache={}
def delta(S):
    cols=[c for k in S for c in blocks[k]]
    A=np.column_stack([np.ones(len(y))]+[X[c].values for c in cols]) if cols else np.ones((len(y),1))
    beta,*_=np.linalg.lstsq(A,y,rcond=None); pr=A@beta
    v={b:pr[m].mean() for b,m in masks.items()}
    return {b:100*(v[b]-v['<100']) for b in ['100-200','200-400']}
for r in range(K+1):
    for S in itertools.combinations(keys,r): cache[frozenset(S)]=delta(S)
phi={b:{k:0.0 for k in keys} for b in ['100-200','200-400']}
for k in keys:
    o=[x for x in keys if x!=k]
    for r in range(len(o)+1):
        for S in itertools.combinations(o,r):
            w=math.factorial(len(S))*math.factorial(K-len(S)-1)/math.factorial(K)
            for b in phi: phi[b][k]+=w*(cache[frozenset(tuple(sorted(S+(k,))))][b]-cache[frozenset(S)][b])
full=cache[frozenset(keys)]
f={b:100*y[masks[b]].mean() for b in ['<100','100-200','200-400']}
OBS={b:f['<100']-f[b] for b in ['100-200','200-400']}
rows=[]
for b in ['100-200','200-400']:
    expl = -full[b]                      # 降幅口径（正）
    for k in keys:
        rows.append(dict(bin=b, factor=k, contribution_to_decline_pp=round(-phi[b][k],4),
                         share_of_observed_pct=round(100*(-phi[b][k])/OBS[b],2),
                         share_of_explained_pct=round(100*(-phi[b][k])/expl,2)))
    merged = -(phi[b]['F5']+phi[b]['F6'])
    rows.append(dict(bin=b, factor='MEAS(F5+F6)', contribution_to_decline_pp=round(merged,4),
                     share_of_observed_pct=round(100*merged/OBS[b],2), share_of_explained_pct=round(100*merged/expl,2)))
    rows.append(dict(bin=b, factor='OBSERVED_DECLINE', contribution_to_decline_pp=round(OBS[b],4), share_of_observed_pct=100.0, share_of_explained_pct=np.nan))
    rows.append(dict(bin=b, factor='EXPLAINED_SUM', contribution_to_decline_pp=round(expl,4), share_of_observed_pct=round(100*expl/OBS[b],2), share_of_explained_pct=100.0))
    rows.append(dict(bin=b, factor='UNEXPLAINED', contribution_to_decline_pp=round(OBS[b]-expl,4), share_of_observed_pct=round(100*(OBS[b]-expl)/OBS[b],2), share_of_explained_pct=np.nan))
T=pd.DataFrame(rows); T.to_csv(os.path.join(D,'多因素_六因素贡献_snrr版_降幅口径.csv'), index=False, encoding='utf-8-sig')
print(T.to_string(index=False))
print('\n观测 %.2f / %.2f pp；六因素解释 %.2f / %.2f pp（%.1f%% / %.1f%%）；未解释 %.2f / %.2f pp（%.1f%% / %.1f%%）' % (
    OBS['100-200'], OBS['200-400'], -full['100-200'], -full['200-400'],
    100*(-full['100-200'])/OBS['100-200'], 100*(-full['200-400'])/OBS['200-400'],
    OBS['100-200']+full['100-200'], OBS['200-400']+full['200-400'],
    100*(OBS['100-200']+full['100-200'])/OBS['100-200'], 100*(OBS['200-400']+full['200-400'])/OBS['200-400']))
# 对齐表（降幅口径）
al=[]
for b in ['100-200','200-400']:
    a, c = d[d.zb=='<100'], d[d.zb==b]
    subs=sorted(set(a.subclass)|set(c.subclass))
    wa=a.subclass.value_counts(normalize=True).reindex(subs).fillna(0).values
    wc=c.subclass.value_counts(normalize=True).reindex(subs).fillna(0).values
    fa=a.groupby('subclass').active.mean().reindex(subs).fillna(0).values
    fc=c.groupby('subclass').active.mean().reindex(subs).fillna(0).values
    comp=float((((fa+fc)/2)*(wa-wc)).sum()*100); inter=float(((wa-wc)*(fa-fc)).sum()*100)
    within=float((((wa+wc)/2)*(fa-fc)).sum()*100)
    we = -(phi[b]['F2']+phi[b]['F3']+phi[b]['F4']+phi[b]['F5']+phi[b]['F6'])
    al.append(dict(bin=b, drop_pp=OBS[b], comp_twochannel=comp, comp_F1=-phi[b]['F1'],
                   within_twochannel=within, within_explained=we,
                   within_unexplained=within-we, explained_total=-full[b], unexplained=OBS[b]+full[b],
                   interaction_pp=inter))
A=pd.DataFrame(al).round(3); A.to_csv(os.path.join(D,'多因素_渠道对齐_snrr版_降幅口径.csv'), index=False, encoding='utf-8-sig')
print('\n' + A.to_string(index=False))
# 图（降幅口径）
fig, axes = plt.subplots(1,2, figsize=(11.8,4.3))
for ax,b in zip(axes,['100-200','200-400']):
    labs=['F1 subtype','F2 T$_{eff}$','F3 log g','F4 [Fe/H]','F5 log S/N','F6 log d','unexplained']
    vals=[-phi[b][k] for k in keys]+[OBS[b]+full[b]]
    cum=0.0
    for i,v in enumerate(vals):
        ax.bar(i, v, bottom=cum, color=('#c0392b' if i==6 else '#2c3e50'), width=0.62)
        ax.text(i, cum+v/2, '%+.2f'%v, ha='center', va='center', fontsize=6.8, color='white' if abs(v)>0.9 else 'black')
        cum+=v
    ax.axhline(OBS[b], color='k', ls='--', lw=1.0)
    ax.set_xticks(range(len(vals))); ax.set_xticklabels(labs, rotation=32, ha='right', fontsize=7.5)
    ax.set_ylabel('contribution to the decline (pp)')
    ax.set_title('%s pc: observed %.2f pp = explained %.3f + unexplained %.3f' % (b, OBS[b], -full[b], OBS[b]+full[b]), fontsize=9)
    ax.grid(axis='y', ls=':', lw=0.4, alpha=0.6)
plt.tight_layout(); plt.savefig(os.path.join(D,'多因素_瀑布图_snrr版_降幅口径.png'), dpi=180); plt.close()
print('\nfigure written (decline convention)')
