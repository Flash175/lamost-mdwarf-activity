# -*- coding: utf-8 -*-
"""s612：复核 s600 的 LAMOST-RV 样本链，并把整条链落成 CSV（此前 611,094 只在脚本打印里）。

口径与 代码/s600_kinematics_lamost_rv.py 第 19–35 行逐字一致：
  EW 闸门 (ewha in (-20,50], ewha_err in (0,5]) → 并 Gaia → 视差质量(>0.2, plx/err>5, ruwe<1.4)
  → 每 uid 取 EW 最大的一条 → 去巨星 M_G >= 6 → RV 有效(z!=0, z_err>0, σ_rv<20, |RV|<500)
"""
import io
import os
import sys

import numpy as np
import pandas as pd

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

BASE = r"C:\Users\lingz\OneDrive\Desktop\复现老师工作"
DATA = r"C:\Users\lingz\Desktop\复现老师工作\APJS\多个图及讨论"
C_KMS = 299792.458

cat0 = pd.read_csv(os.path.join(BASE, "data", "lamost", "dr13", "dr13_mstellar_dM.csv"), low_memory=False,
                   usecols=["obsid", "uid", "subclass", "ewha", "ewha_err", "snrr", "z", "z_err",
                            "ra", "dec", "gaia_source_id", "gaia_g_mean_mag"])
rows = [("目录", len(cat0), cat0.uid.nunique(), "dr13_mstellar_dM.csv 全表")]

cat = cat0[(cat0.ewha > -20) & (cat0.ewha <= 50) & (cat0.ewha_err > 0) & (cat0.ewha_err <= 5)].copy()
cat["active"] = (cat.ewha >= 0.75) & (cat.ewha > 3 * cat.ewha_err)
cat["gaia_source_id"] = pd.to_numeric(cat.gaia_source_id, errors="coerce")
rows.append(("EW 闸门", len(cat), cat.uid.nunique(), "ewha in (-20,50], ewha_err in (0,5]"))

g = pd.read_csv(os.path.join(BASE, "data", "gaia", "gaia_dr3_mstars.csv"), low_memory=False,
                usecols=["source_id", "parallax", "parallax_error", "pmra", "pmdec", "ruwe"])
m0 = cat.merge(g, left_on="gaia_source_id", right_on="source_id", how="inner")
rows.append(("并 Gaia", len(m0), m0.uid.nunique(), "内连接 gaia_dr3_mstars"))

m = m0[(m0.parallax > 0.2) & (m0.parallax / m0.parallax_error > 5) & (m0.ruwe < 1.4)].copy()
u0 = m.sort_values("ewha", ascending=False).drop_duplicates("uid").copy()
rows.append(("视差质量+去重", len(u0), len(u0), "parallax>0.2, plx/err>5, ruwe<1.4, 每 uid 取 EW 最大的一条"))

u0["MG"] = u0.gaia_g_mean_mag.values - 5 * np.log10(np.clip(1000.0 / u0.parallax.values, 1, None)) + 5
u1 = u0[u0.MG >= 6].copy()
rows.append(("去巨星", len(u1), len(u1), "M_G >= 6"))

u1["rv"] = C_KMS * u1.z
u1["sig_rv"] = C_KMS * u1.z_err.abs()
u = u1[(u1.z != 0) & (u1.z_err > 0) & np.isfinite(u1.rv) & (u1.sig_rv < 20) & (u1.rv.abs() < 500)].copy()
rows.append(("LAMOST-RV", len(u), len(u), "z!=0, z_err>0, sigma_rv<20, |RV|<500"))

for r in rows:
    print("%-14s %9d  %9d  %s" % r)

out = os.path.join(DATA, "rv_sample_count.csv")
with open(out, "w", encoding="utf-8") as f:
    f.write("# s612：LAMOST-RV 样本链复核（与 s600 同口径），2026-11-03\n")
    f.write("# 生成脚本：代码/s612_rv_sample_count.py\n")
    f.write("step,n_rows,n_uid,note\n")
    for r in rows:
        f.write("%s,%d,%d,%s\n" % r)
print("写出", out, os.path.getsize(out), "B")
