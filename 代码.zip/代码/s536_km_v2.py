
# -*- coding: utf-8 -*-
"""K/M 联合图 v2：K 侧全样本 + S/N 匹配；输出 v2 并替换正式文件名。"""
import io, os, sys
import numpy as np, pandas as pd
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
OUT = r'C:\Users\lingz\Desktop\复现老师工作\APJS\多个图及讨论'
K = pd.read_csv('data/processed/dr13/ktype_pilot_ew.csv')
cat = pd.read_csv('data/lamost/dr13/dr13_mstellar_dM.csv', low_memory=False,
                  usecols=['subclass','ewha','ewha_err','snrr'])
cat = cat[(cat.ewha > -20) & (cat.ewha <= 50) & (cat.ewha_err > 0) & (cat.ewha_err <= 5)].copy()
cat['active'] = (cat.ewha >= 0.75) & (cat.ewha > 3*cat.ewha_err)

def frac(df, sp, lo=None, hi=None):
    s = df[df.subclass == sp]
    if lo is not None: s = s[(s.snrr >= lo) & (s.snrr <= hi)]
    return (len(s), 100*s.active.mean() if len(s) >= 20 else np.nan)

rows = []
for sp in ['K0','K1','K2','K3','K4','K5','K6','K7']:
    n1, f1 = frac(K, sp); n2, f2 = frac(K, sp, 6, 20)
    if n1 >= 20: rows.append(dict(spt=sp, kind='K', n=n1, frac=f1, n_sn=n2, frac_sn=f2))
for sp in ['dM0','dM1','dM2','dM3','dM4','dM5','dM6','dM7','dM8']:
    n1, f1 = frac(cat, sp); n2, f2 = frac(cat, sp, 6, 20)
    if n1 >= 50: rows.append(dict(spt=sp, kind='M', n=n1, frac=f1, n_sn=n2, frac_sn=f2))
T = pd.DataFrame(rows)
for nm in ('新图3_K与M活动比例_v2.csv', '新图3_K与M活动比例.csv'):
    T.to_csv(os.path.join(OUT, nm), index=False, encoding='utf-8-sig')
print(T.round(2).to_string(index=False))
print('\nK 侧合计 %d 颗（S/N 6-20: %d 颗）' % (T[T.kind=='K'].n.sum(), T[T.kind=='K'].n_sn.sum()))

xs = np.arange(len(T))
fig, ax = plt.subplots(figsize=(9.4, 4.8))
ax.plot(xs, T.frac, 'o-', color='#2c3e50', lw=1.6, ms=6, label='all spectra')
ax.plot(xs, T.frac_sn, 's--', color='#2980b9', lw=1.2, ms=5, label='S/N 6-20 (matched)')
for xi, k in enumerate(T.kind):
    ax.plot(xi, T.frac[xi], 'o', color='#8e44ad' if k == 'K' else '#c0392b', ms=8, zorder=4)
for xi, n in enumerate(T.n):
    y = np.nanmax([T.frac[xi], T.frac_sn[xi] if np.isfinite(T.frac_sn[xi]) else -np.inf])
    ax.annotate('%d' % n, xy=(xi, -0.115), xycoords=('data', 'axes fraction'),
                ha='center', va='top', fontsize=6.5, color='#555')
ax.set_xticks(xs); ax.set_xticklabels(T.spt, rotation=0, fontsize=8)
ax.set_ylabel('Active fraction (%)'); ax.set_xlabel('Spectral subtype')
ax.set_title('Active fraction across the K/M transition (numbers = stars per bin)')
ax.axvline(sum(T.kind == 'K')-0.5, color='#999', ls='--', lw=1)
ax.legend(fontsize=8)
plt.subplots_adjust(bottom=0.22)
plt.tight_layout()
for nm in ('新图3_K与M活动比例_v2.png', '新图3_K与M活动比例.png'):
    plt.savefig(os.path.join(OUT, nm), dpi=200)
plt.close()
print('v2 已写入并替换正式文件名')
