
# -*- coding: utf-8 -*-
"""s624：径向控制——固定 |Z| 时活动率是否随银心柱半径 R 变化（论文口径重建样本）
输出：多个图及讨论/径向控制_活动率.csv、径向控制_斜率.csv、第一篇APJS/figures/fig_radial.png
"""
import os, sys, io, json
import numpy as np, pandas as pd
from scipy import stats
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
from astropy.coordinates import SkyCoord
import astropy.units as u
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
OD  = r'C:\Users\lingz\OneDrive\Desktop\复现老师工作\data'
OUTD= r'C:\Users\lingz\Desktop\复现老师工作\APJS\多个图及讨论'
FIG = r'C:\Users\lingz\Desktop\第一篇APJS\figures\fig_radial.png'
lam = ['uid','subclass','teff','ewha','ewha_err','gaia_source_id','gaia_g_mean_mag','ra','dec']
d = pd.read_csv(os.path.join(OD,'lamost','dr13','dr13_mstellar_dM.csv'), usecols=lam, low_memory=False)
d = d[(d.ewha>-20)&(d.ewha<=50)&(d.ewha_err>0)&(d.ewha_err<=5)]
g = pd.read_csv(os.path.join(OD,'gaia','gaia_dr3_mstars.csv'),
                usecols=['source_id','parallax','parallax_error','ruwe','phot_g_mean_mag'], low_memory=False)
d = d.merge(g, left_on='gaia_source_id', right_on='source_id', how='inner')
d = d[(d.parallax>0.2)&(d.parallax/d.parallax_error>5)&(d.ruwe<1.4)]
d = d.sort_values('ewha', ascending=False).drop_duplicates('uid')
d['MG'] = d.gaia_g_mean_mag.values - 5*np.log10(np.clip(1000.0/d.parallax.values,1,None)) + 5
d = d[d.MG>=6]
d['dist_pc'] = 1000.0/d.parallax.values
sc = SkyCoord(ra=d.ra.values*u.deg, dec=d.dec.values*u.deg, distance=d.dist_pc.values*u.pc, frame='icrs')
d['absz'] = np.abs(d.dist_pc.values*np.sin(np.deg2rad(sc.galactic.b.deg)))
d = d[(d.absz>0)&(d.absz<=3000)]
gc = sc.galactocentric
x, y, z = gc.x.to_value(u.kpc), gc.y.to_value(u.kpc), gc.z.to_value(u.kpc)
d['R_gc'] = np.hypot(x, y); d['z_gc'] = z
d['active'] = ((d.ewha>=0.75)&(d.ewha>3*d.ewha_err)).astype(int)
d = d[d.subclass.isin(['dM0','dM1','dM2','dM3','dM4','dM5','dM6'])]
print('sample', len(d), '| active', int(d.active.sum()), '| R range %.2f-%.2f' % (d.R_gc.min(), d.R_gc.max()))
E=[0,100,200,400,600,1000,3000]; L=['<100','100-200','200-400','400-600','600-1000','>1000']
d['zb'] = pd.cut(d.absz, E, labels=L)
RE = np.arange(7.0, 11.75, 0.5)
def binR(v): return pd.cut(v, RE)
rows=[]
for lb in ['<100','100-200','200-400']:
    s = d[d.zb==lb]
    rb = binR(s.R_gc)
    for b in rb.cat.categories:
        t = s[rb==b]
        if len(t) < 100: continue
        p = t.active.mean(); n=len(t); k=int(t.active.sum())
        w = 1.96*np.sqrt(p*(1-p)/n)
        rows.append(dict(zbin=lb, R_bin='%.1f-%.1f'%(b.left,b.right), R_med=float(t.R_gc.median()), n=n, n_act=k,
                         frac_pct=100*p, lo=100*max(0,p-w), hi=100*min(1,p+w), teff_med=float(t.teff.median())))
A = pd.DataFrame(rows); A.to_csv(os.path.join(OUTD,'径向控制_活动率.csv'), index=False, encoding='utf-8-sig')
print('\n=== activity vs R at fixed |Z| ===\n' + A.round(2).to_string(index=False))

def logit(X, y, ridge=1e-8, it=200):
    b = np.zeros(X.shape[1]); b[0]=np.log(y.mean()/(1-y.mean()))
    for _ in range(it):
        p = 1/(1+np.exp(-(X@b))); W=p*(1-p)
        step = np.linalg.lstsq(X.T@(X*W[:,None]) + ridge*np.eye(len(b)), X.T@(y-p), rcond=None)[0]
        b += step
        if np.max(np.abs(step))<1e-12: break
    p = 1/(1+np.exp(-(X@b))); cov = np.linalg.pinv(X.T@(X*(p*(1-p))[:,None]))
    return b, np.sqrt(np.diag(cov))
rows=[]
for lb in ['<100','100-200','200-400']:
    s = d[d.zb==lb]
    X = np.column_stack([np.ones(len(s)), s.R_gc.values, pd.get_dummies(s.subclass, drop_first=True).astype(float).values])
    b, se = logit(X, s.active.values.astype(float))
    rows.append(dict(zbin=lb, n=len(s), b_R_per_kpc=b[1], se=se[1], z=b[1]/se[1]))
    print('%-9s n=%6d  dlogit/dR = %+.3f +/- %.3f /kpc (z=%+.1f)' % (lb, len(s), b[1], se[1], b[1]/se[1]))
S = pd.DataFrame(rows).round(4); S.to_csv(os.path.join(OUTD,'径向控制_斜率.csv'), index=False, encoding='utf-8-sig')

# figure: (a) mixed by |Z|, (b) dM4 only, (c) slope summary
fig, ax = plt.subplots(1, 3, figsize=(13.2, 4.0))
for lb, c in zip(['<100','100-200','200-400'], ['#c0392b','#e08a7f','#95a5a6']):
    t = A[A.zbin==lb]
    ax[0].errorbar(t.R_med, t.frac_pct, yerr=[t.frac_pct-t.lo, t.hi-t.frac_pct], fmt='o-', color=c, ms=4, lw=1.1, capsize=2, label=lb)
ax[0].set_xlabel('$R_{\\rm gc}$  (kpc)'); ax[0].set_ylabel('Active fraction (%)')
ax[0].set_title('All subtypes mixed', fontsize=9); ax[0].legend(fontsize=7, title='$|Z|$ (pc)', title_fontsize=7)
for st, c in zip(['dM0','dM2','dM4'], ['#2c3e50','#27ae60','#8e44ad']):
    s = d[(d.subclass==st)&(d.absz<=400)]
    rb = binR(s.R_gc)
    xs=[]; ys=[]; es=[]
    for b in rb.cat.categories:
        t = s[rb==b]
        if len(t)<100: continue
        p=t.active.mean(); n=len(t); w=1.96*np.sqrt(p*(1-p)/n)
        xs.append(float(t.R_gc.median())); ys.append(100*p); es.append(100*w)
    ax[1].errorbar(xs, ys, yerr=es, fmt='o-', color=c, ms=4, lw=1.1, capsize=2, label=st)
ax[1].set_xlabel('$R_{\\rm gc}$  (kpc)'); ax[1].set_ylabel('Active fraction (%)')
ax[1].set_title('Per subtype, $|Z|\\leq400$ pc', fontsize=9); ax[1].legend(fontsize=7)
ax[2].bar(np.arange(len(S)), S.b_R_per_kpc, yerr=1.96*S.se, color=['#c0392b','#e08a7f','#95a5a6'], width=0.55, capsize=3)
ax[2].axhline(0, color='k', lw=0.8)
for i, r in S.iterrows(): ax[2].text(i, r.b_R_per_kpc + (0.02 if r.b_R_per_kpc>=0 else -0.05), '%+.3f'%r.b_R_per_kpc, ha='center', fontsize=7)
ax[2].set_xticks(np.arange(len(S))); ax[2].set_xticklabels(S.zbin, fontsize=8)
ax[2].set_ylabel('$\\partial\\ln[f/(1-f)]/\\partial R_{\\rm gc}$  (kpc$^{-1}$)')
ax[2].set_title('Fixed $|Z|$, subtype-controlled', fontsize=9)
plt.tight_layout(); plt.savefig(FIG, dpi=200); plt.close()
print('\nfigure written', os.path.getsize(FIG), 'bytes')
print('R_gc median %.2f kpc; 5-95%% %.2f-%.2f' % (d.R_gc.median(), d.R_gc.quantile(.05), d.R_gc.quantile(.95)))
