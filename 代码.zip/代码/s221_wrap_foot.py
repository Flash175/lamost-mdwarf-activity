# -*- coding: utf-8 -*-
"""脚注按宽度自动换行，避免两侧被裁"""
import io, sys
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
P = 'repro/src/s189_fig5_official_v4.py'
s = open(P, encoding='utf-8').read()
ANCH = "fig, axes = plt.subplots(1, 2, figsize=(10.6, 4.7))"
WRAP = "FOOT = textwrap.fill(FOOT.replace('\\n', ' '), 152)\n"
if 'textwrap.fill(FOOT.replace' not in s:
    s = s.replace(ANCH, WRAP + ANCH, 1)
    s = s.replace("fig.tight_layout(rect=(0, 0.075, 1, 0.885))", "fig.tight_layout(rect=(0, 0.105, 1, 0.885))")
    open(P, 'w', encoding='utf-8').write(s); print('  已加脚注自动换行')
else: print('  已有换行处理')
