# -*- coding: utf-8 -*-
"""扩展 P_cyc–P_rot：加 5" 匹配与图例位置修正，并把结果写进文档"""
import io, os, shutil, sys
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
import numpy as np, pandas as pd
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
W = r'C:\Users\lingz\OneDrive\Desktop\复现老师工作'
D = r'C:\Users\lingz\Desktop\复现老师工作'
A = r'C:\Users\lingz\Desktop\APJS\图五及相关数据'
g = lambda *a: os.path.join(W, *a)
P = pd.read_csv(g('data', 'processed', 'dr13', 'ib2025_periodogram_selfcomputed.csv')).rename(columns={'star': 'star_ib'})
R = pd.read_csv(g('data', 'processed', 'dr13', 'ib2025_stars_with_prot.csv')).rename(columns={'star': 'star_src'})
P['key'] = P.star_ib.str.replace(' ', '').str.upper(); R['key'] = R.star_src.str.replace(' ', '').str.upper()
R['P_rot'] = np.where(R.sep_as < 5, R.P_rot, np.nan)          # 只认 5 角秒内
M = P.merge(R[['key', 'P_rot', 'vsx_type', 'vsx_name', 'sep_as']], on='key', how='left')
M['usable'] = M.P_rot.notna() & (M.FAP < 0.05) & (M.P_yr <= 0.95*M.baseline_yr) & (M.P_yr <= 24.0)
use = M[M.usable].sort_values('P_yr').copy()
print('可用 %d 点：' % len(use)); print(use[['star_ib','P_rot','vsx_type','P_yr','FAP','baseline_yr']].round(3).to_string(index=False))
out = use[['star_ib', 'P_rot', 'vsx_type', 'vsx_name', 'P_yr', 'P2_yr', 'power', 'FAP', 'N', 'baseline_yr']].rename(columns={'star_ib': 'star'})
out.to_csv(g('data', 'processed', 'dr13', 'pcyc_vs_prot_expanded.csv'), index=False)
lit = pd.read_csv(g('data', 'raw', 'activity_cycle_data_complete.csv'))
lit['P_cyc'] = pd.to_numeric(lit.P_cyc_yr, errors='coerce'); lit['ProT'] = pd.to_numeric(lit.P_rot_days, errors='coerce')
ok = lit.dropna(subset=['P_cyc', 'ProT'])
fig, ax = plt.subplots(figsize=(6.8, 5.2))
ax.errorbar(ok.ProT, ok.P_cyc, yerr=pd.to_numeric(ok.P_cyc_err_yr, errors='coerce'),
            xerr=pd.to_numeric(ok.P_rot_err_days, errors='coerce'), fmt='none', ecolor='0.75', lw=0.7, zorder=2)
ax.scatter(ok.ProT, ok.P_cyc, s=34, c='#1f4fd8', label='literature table (N=%d)' % len(ok), zorder=3)
ax.scatter(use.P_rot, use.P_yr, s=48, facecolors='none', edgecolors='#d95f02', lw=1.4,
           label='this work: LS(IB2025 B1) x VSX P$_{rot}$ (N=%d)' % len(use), zorder=4)
for _, r in use.iterrows():
    ax.annotate(str(r.star_ib), (r.P_rot, r.P_yr), textcoords='offset points', xytext=(6, 3), fontsize=6.4, color='#8c3b00')
for _, r in ok.iterrows():
    ax.annotate(str(r.Star), (r.ProT, r.P_cyc), textcoords='offset points', xytext=(5, -9), fontsize=6.0, color='0.4')
ax.scatter([25.4], [11.0], marker='*', s=220, color='goldenrod', edgecolor='k', lw=0.6, zorder=5)
ax.annotate('Sun', (25.4, 11.0), xytext=(7, -9), textcoords='offset points', fontsize=7)
ax.set_xscale('log'); ax.set_yscale('log')
ax.set_xlabel('P$_{rot}$ (days)', fontsize=11); ax.set_ylabel('P$_{cyc}$ (years)', fontsize=11)
ax.set_xlim(1.5, 330); ax.set_ylim(1.5, 34)
ax.grid(alpha=0.25, which='both', lw=0.4)
ax.tick_params(direction='in', top=True, right=True, labelsize=9)
ax.legend(fontsize=7.4, loc='upper left', framealpha=0.95)
ax.set_title('Activity cycle vs rotation period: %d literature + %d recomputed points' % (len(ok), len(use)), fontsize=10)
fig.text(0.5, 0.012, 'P$_{rot}$ from VSX (BY/ROT = spot modulation, 5 arcsec match); P$_{cyc}$ from our Lomb-Scargle analysis of the Ibanez Bustos et al. (2025) Table B1\n'
                     '(2-25 yr, baseline >= 8 yr). Excluded: FAP > 0.05, P$_{cyc}$ > 0.95 x baseline, or at the 25-yr search edge.', ha='center', fontsize=6.3, color='0.3', linespacing=1.5)
fig.tight_layout(rect=(0, 0.07, 1, 1))
o = g('figures', 'dr13_figPcyc_Prot_expanded.png'); fig.savefig(o, dpi=180); plt.close(fig)
for s, t in [(o, os.path.join(D, '图', '对照与备选', '附_Pcyc_vs_Prot_扩展_自算.png')), (o, os.path.join(A, '图', '附_Pcyc_vs_Prot_扩展_自算.png')),
             (g('data', 'processed', 'dr13', 'pcyc_vs_prot_expanded.csv'), os.path.join(D, '数据', 'Pcyc与Prot_扩展样本.csv')),
             (g('data', 'processed', 'dr13', 'pcyc_vs_prot_expanded.csv'), os.path.join(A, '数据', 'Pcyc与Prot_扩展样本.csv'))]:
    shutil.copy2(s, t)
print('  图/表已同步')
SEC = """
## 九、扩展 P_cyc–P_rot 样本（本工作复算 × VSX 自转周期，2026-10-21）

做法：IB2025 的 35 颗星按 5″ 匹配本地 VSX（29 颗有对应，11 颗带周期），再与我们对 Table B1 的 LS 复算结果交叉，剔除 FAP>0.05、P_cyc > 0.95×基线、以及卡在 25 yr 搜索边界的点，最终得到 **4 个可用新点**：

| 星 | P_rot (d, VSX) | P_cyc (yr, 自算) | FAP | 基线 (yr) |
|---|---|---|---|---|
| GJ 876 | 16.86 (BY) | 3.32 | 3×10⁻⁷ | 8.9 |
| GJ 699 | 130.0 (BY) | 8.76 | 3×10⁻³ | 16.0 |
| GJ 674 | 33.29 (BY) | 13.46 | 1×10⁻³ | 15.0 |
| GJ 205 | 33.61 (BY) | 14.74 | 3×10⁻¹⁰ | 21.0 |

连同文献表 8 点，图上共 **12 点**（图：附_Pcyc_vs_Prot_扩展_自算.png；表：Pcyc与Prot_扩展样本.csv）。

限制（必须写进正文或脚注）：
1. VSX 的 BY 型周期是**星斑调制**，一般等于 P_rot，但也可能是双星轨道周期，无法逐一剔除；ROT 型更可靠，本批仅 GJ 229 匹配到一条 0.64 d 的 ROT，因其与 Gaia 随机目标相距 0.96″、明显不可信，已剔除。
2. 4 个新点的 P_cyc 均来自我们对原始时间序列的复算，**不是** IB2025 发表值；若作者发表值不同，应以他们为准。
3. 12 点的散布仍不支持任何 P_cyc–P_rot 定量关系（r ≈ −0.3，样本太小），图中仅作存在性展示。
"""
for p in (os.path.join(D, '文档', '图05_Methods文字_中英文.md'), os.path.join(A, '方法说明', '图05_Methods文字_中英文.md')):
    s = open(p, encoding='utf-8').read()
    if '九、扩展 P_cyc–P_rot 样本' in s: print('  已有第九节'); continue
    open(p, 'w', encoding='utf-8').write(s.rstrip() + '\n' + SEC); print('  已追加第九节:', p.split('\\')[-3:])
