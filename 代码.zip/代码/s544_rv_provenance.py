
# -*- coding: utf-8 -*-
"""核对 RV 来源 + 按亚型分层的 f_act(|Z|)（不依赖 RV 的全样本）。"""
import io, sys
import numpy as np, pandas as pd
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')

g = pd.read_csv('data/gaia/gaia_dr3_mstars.csv', low_memory=False,
                usecols=['source_id','phot_g_mean_mag','radial_velocity','parallax','parallax_error','ruwe'])
print('gaia_dr3_mstars.csv: n=%d' % len(g))
rv = g.radial_velocity
print('RV 非空: %d (%.1f%%)' % (rv.notna().sum(), 100*rv.notna().mean()))
for lo, hi in ((0,12),(12,14),(14,16),(16,18),(18,21)):
    s = g[(g.phot_g_mean_mag >= lo) & (g.phot_g_mean_mag < hi)]
    if len(s): print('  G∈[%d,%d): n=%6d, RV 非空 %6d (%.1f%%)' % (lo, hi, len(s), s.radial_velocity.notna().sum(), 100*s.radial_velocity.notna().mean()))
print('  → 若 RV 来自 Gaia DR3，G>14 应几乎为空（G_RVS≲14）')
