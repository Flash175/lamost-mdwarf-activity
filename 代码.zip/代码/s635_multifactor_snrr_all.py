
# -*- coding: utf-8 -*-
"""s635：snrr 版全套输出（主表已出，这里补齐：对齐表、R4/R5/R8、存档样本、瀑布图）"""
import os, sys, io, math, itertools
import numpy as np, pandas as pd
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy.special import expit
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
OD = r'C:\Users\lingz\OneDrive\Desktop\复现老师工作\data'
D  = r'C:\Users\lingz\Desktop\复现老师工作\APJS\多个图及讨论'
lam = ['uid','subclass','teff','logg','m_h','m_h_err','ewha','ewha_err','snrr','gaia_source_id','gaia_g_mean_mag','ra','dec']
d = pd.read_csv(os.path.join(OD,'lamost','dr13','dr13_mstellar_dM.csv'), usecols=lam, low_memory=False)
d = d[(d.ewha>-20)&(d.ewha<=50)&(d.ewha_err>0)&(d.ewha_err<=5)]
g = pd.read_csv(os.path.join(OD,'gaia','gaia_dr3_mstars.csv'), usecols=['source_id','parallax','parallax_error','ruwe','phot_g_mean_mag'], low_memory=False)
d = d.merge(g, left_on='gaia_source_id', right_on='source_id', how='inner')
d = d[(d.parallax>0.2)&(d.parallax/d.parallax_error>5)&(d.ruwe<1.4)]
d = d.sort_values('ewha', ascending=False).drop_duplicates('uid')
d['MG'] = d.gaia_g_mean_mag.values - 5*np.log10(np.clip(1000.0/d.parallax.values,1,None)) + 5
d = d[d.MG>=6].copy(); d['dist_pc']=1000.0/d.parallax.values
from astropy.coordinates import SkyCoord
import astropy.units as u
sc = SkyCoord(ra=d.ra.values*u.deg, dec=d.dec.values*u.deg, distance=d.dist_pc.values*u.pc, frame='icrs')
d['absz'] = np.abs(d.dist_pc.values*np.sin(np.deg2rad(sc.galactic.b.deg)))
d = d[(d.absz>0)&(d.absz<=400)].copy()
d['active'] = ((d.ewha>=0.75)&(d.ewha>3*d.ewha_err)).astype(float)
sb1 = pd.read_csv(os.path.join(D,'RV变星_SB1候选_多历元.csv'), low_memory=False)
d = d[~d.uid.isin(set(sb1.uid))]
for c in ['teff','logg','m_h','snrr']: d = d[d[c].notna() & (d[c]!=-9999)]
d = d[(d.teff>=2000)&(d.teff<=4500)&(d.logg>=3)&(d.logg<=6)&(d.m_h.abs()<1)&(d.snrr>0)&(d.m_h_err.notna())&(d.dist_pc>0)].copy()
d[['uid','subclass','teff','logg','m_h','m_h_err','ewha','ewha_err','snrr','dist_pc','absz','active','MG']].to_csv(
    os.path.join(D,'分解样本_snrr_470548.csv'), index=False, encoding='utf-8-sig')
print('sample saved:', len(d))

def prep(df, edges=(0,100,200,400), labels=('<100','100-200','200-400')):
    x = df.copy(); x['zb'] = pd.cut(x.absz, edges, labels=labels)
    DUM = pd.get_dummies(x.subclass, prefix='s', drop_first=True).astype(float)
    for c,nm in [('teff','F2'),('logg','F3'),('m_h','F4')]:
        v=x[c]; x[nm]=v-v.mean()
    x['F2']=x.F2/1000.0
    lv=np.log10(x.snrr); x['F5']=lv-lv.mean()
    ld=np.log10(x.dist_pc); x['F6']=ld-ld.mean()
    X=pd.concat([DUM,x[['F2','F3','F4','F5','F6']]],axis=1)
    return x, X, {'F1':list(DUM.columns),'F2':['F2'],'F3':['F3'],'F4':['F4'],'F5':['F5'],'F6':['F6']}
def shapley(x, X, blocks, keys, ref='<100', bins=('100-200','200-400'), logit=False):
    y=x.active.values; masks={b:(x.zb.values==b) for b in [ref]+list(bins)}
    K=len(keys); cache={}
    def delta(S):
        cols=[c for k in S for c in blocks[k]]
        A=np.column_stack([np.ones(len(y))]+[X[c].values for c in cols]) if cols else np.ones((len(y),1))
        if logit:
            b=np.zeros(A.shape[1]); b[0]=np.log(y.mean()/(1-y.mean()))
            for _ in range(60):
                p=expit(A@b); W=p*(1-p)
                st=np.linalg.lstsq(A.T@(A*W[:,None])+1e-8*np.eye(len(b)), A.T@(y-p), rcond=None)[0]; b=b+st
                if np.max(np.abs(st))<1e-8: break
            pr=expit(A@b)
        else:
            beta,*_=np.linalg.lstsq(A,y,rcond=None); pr=A@beta
        v={bb:pr[mm].mean() for bb,mm in masks.items()}
        return {bb:100*(v[bb]-v[ref]) for bb in bins}
    for r in range(K+1):
        for S in itertools.combinations(keys,r): cache[frozenset(S)]=delta(S)
    phi={bb:{k:0.0 for k in keys} for bb in bins}
    for k in keys:
        others=[v for v in keys if v!=k]
        for r in range(len(others)+1):
            for S in itertools.combinations(others,r):
                w=math.factorial(len(S))*math.factorial(K-len(S)-1)/math.factorial(K)
                for bb in phi: phi[bb][k]+=w*(cache[frozenset(tuple(sorted(S+(k,))))][bb]-cache[frozenset(S)][bb])
    return phi, cache[frozenset(keys)]
x, X, blocks = prep(d)
phi, full = shapley(x, X, blocks, ['F1','F2','F3','F4','F5','F6'])
f = {b:100*x.active[x.zb==b].mean() for b in ['<100','100-200','200-400']}
OBS = {b: f['<100']-f[b] for b in ['100-200','200-400']}
# alignment
rows=[]
for b in ['100-200','200-400']:
    a, c = x[x.zb=='<100'], x[x.zb==b]
    subs = sorted(set(a.subclass)|set(c.subclass))
    wa=a.subclass.value_counts(normalize=True).reindex(subs).fillna(0).values
    wc=c.subclass.value_counts(normalize=True).reindex(subs).fillna(0).values
    fa=a.groupby('subclass').active.mean().reindex(subs).fillna(0).values
    fc=c.groupby('subclass').active.mean().reindex(subs).fillna(0).values
    comp=float((((fa+fc)/2)*(wa-wc)).sum()*100); inter=float(((wa-wc)*(fa-fc)).sum()*100)
    within=float((((wa+wc)/2)*(fa-fc)).sum()*100)
    we = phi[b]['F2']+phi[b]['F3']+phi[b]['F4']+phi[b]['F5']+phi[b]['F6']
    rows.append(dict(bin=b, drop_pp=OBS[b], comp_pp_twochannel=comp+inter/2, comp_pp_F1=phi[b]['F1'],
                     within_pp_twochannel=within+inter/2, within_explained_pp=we,
                     within_unexplained_pp=within+inter/2-we, model_total_pp=full[b], residual_pp=OBS[b]-full[b]))
AL = pd.DataFrame(rows).round(3)
AL.to_csv(os.path.join(D,'多因素_渠道对齐_snrr版.csv'), index=False, encoding='utf-8-sig')
print('\n=== alignment (snrr) ===\n' + AL.to_string(index=False))
# R5 edges
x5, X5, b5 = prep(d, edges=(0,125,250,400), labels=('<125','125-250','250-400'))
phi5, full5 = shapley(x5, X5, b5, ['F1','F2','F3','F4','F5','F6'], ref='<125', bins=('125-250','250-400'))
print('\n=== R5 edges ===')
for b in ['125-250','250-400']:
    obs = 100*x5.active[x5.zb=='<125'].mean() - 100*x5.active[x5.zb==b].mean()
    print('  %-8s observed %6.2f | model %+6.2f | ' % (b, obs, full5[b]) + ', '.join('%s %+.2f' % (k, phi5[b][k]) for k in ['F1','F2','F3','F4','F5','F6']))
# R8
x8, X8, b8 = prep(d[(d.snrr>50)&(d.m_h_err<0.2)])
phi8, full8 = shapley(x8, X8, b8, ['F1','F2','F3','F4','F5','F6'])
print('\n=== R8 tightened (n=%d) ===' % len(x8))
for b in ['100-200','200-400']:
    obs = 100*x8.active[x8.zb=='<100'].mean() - 100*x8.active[x8.zb==b].mean()
    print('  %-8s observed %6.2f | model %+6.2f | ' % (b, obs, full8[b]) + ', '.join('%s %+.2f' % (k, phi8[b][k]) for k in ['F1','F2','F3','F4','F5','F6']))
# R4 stratified
rows=[]
for st in ['dM1','dM2','dM3','dM4']:
    s = d[d.subclass==st]
    xs, Xs, bs = prep(s)
    ph, fu = shapley(xs, Xs, bs, ['F2','F3','F4','F5','F6'])
    obs = 100*xs.active[xs.zb=='<100'].mean() - 100*xs.active[xs.zb=='200-400'].mean()
    rows.append(dict(subtype=st, n=len(xs), observed_pp=round(obs,2), model_pp=round(fu['200-400'],2),
                     **{k:round(ph['200-400'][k],2) for k in ['F2','F3','F4','F5','F6']}))
R4=pd.DataFrame(rows); R4.to_csv(os.path.join(D,'多因素_R4_逐亚型_snrr版.csv'), index=False, encoding='utf-8-sig')
print('\n=== R4 within-subtype (200-400) ===\n' + R4.to_string(index=False))
# waterfall
fig, axes = plt.subplots(1,2, figsize=(11.5,4.2))
for ax,b in zip(axes,['100-200','200-400']):
    labs=['F1 亚型','F2 Teff','F3 log g','F4 [Fe/H]','F5 log S/N','F6 log d','未解释']
    vals=[phi[b][k] for k in ['F1','F2','F3','F4','F5','F6']]+[OBS[b]-full[b]]
    cum=0.0
    for i,v in enumerate(vals):
        ax.bar(i, v, bottom=cum, color=('#c0392b' if i==6 else '#2c3e50'), width=0.62)
        ax.text(i, cum+v/2, '%+.2f'%v, ha='center', va='center', fontsize=6.5, color='white' if abs(v)>0.8 else 'black')
        cum+=v
    ax.axhline(OBS[b], color='k', ls='--', lw=1.0)
    ax.set_xticks(range(len(vals))); ax.set_xticklabels(labs, rotation=35, ha='right', fontsize=7)
    ax.set_ylabel('activity decline (pp)'); ax.set_title('%s pc: observed %.2f pp, explained %+.2f pp'%(b,OBS[b],full[b]), fontsize=9)
plt.tight_layout(); plt.savefig(os.path.join(D,'多因素_瀑布图_snrr版.png'), dpi=180); plt.close()
print('\nwrote 多因素_瀑布图_snrr版.png')
