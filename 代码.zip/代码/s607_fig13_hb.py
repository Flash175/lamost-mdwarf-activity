
import io, sys, os
import numpy as np, pandas as pd
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
MD = "C:/Users/lingz/Desktop/复现老师工作/APJS/多个图及讨论"
OUT = "C:/Users/lingz/Desktop/复现老师工作/APJS/图五及相关数据/图_20261103/新图"

# --- 1) 清单登记 ---
def ed(path, old, new, label):
    s = open(path, encoding='utf-8').read()
    if old not in s: print('  [跳过] ' + label); return
    open(path, 'wb').write(s.replace(old, new, 1).encode('utf-8'))
    print('  [完成] %-22s %d B' % (label, os.path.getsize(path)))
p1 = MD + "/新一节_银盘示踪_中文草稿.md"
ed(p1, "rv_vendor_crosscheck.csv（两种 RV 同批星交叉检验）；",
   "rv_vendor_crosscheck.csv（两种 RV 同批星交叉检验）、criterion3_figure_data.csv（第三判据分档图数据）、"
   "hbeta30k_by_zbin.csv（Hβ 30,224 条分层六档汇总）、hbeta30k_per_spectrum.csv（逐谱三判据）；图：新图_第三判据分档曲线.png、新图_三判据活动比例.png；", "CN 清单")
ed(p1, "**s599/s600/s601**（LAMOST RV 覆盖、运动学扩样本、双 RV 交叉检验）。",
   "**s599/s600/s601**（LAMOST RV 覆盖、运动学扩样本、双 RV 交叉检验）、**s602/s603**（第三判据全量谱与分档图）、"
   "**s605/s606**（Hβ 3 万条抽样与三判据图）。", "CN 脚本")
p2 = MD + "/新一节_银盘示踪_中文稿_v5_重写.md"
ed(p2, "rv_vendor_crosscheck.csv；脚本 **s584–s601**",
   "rv_vendor_crosscheck.csv、criterion3_figure_data.csv、hbeta30k_by_zbin.csv、hbeta30k_per_spectrum.csv；脚本 **s584–s606**", "v5 清单")
p3 = MD + "/新一节_银盘示踪_英文草稿.tex"
ed(p3, "rv_vendor_crosscheck.csv (s599--s601).",
   "rv_vendor_crosscheck.csv (s599--s601), criterion3_figure_data.csv, hbeta30k_by_zbin.csv and hbeta30k_per_spectrum.csv "
   "(s602, s603, s605, s606), with Figures 新图_第三判据分档曲线.png and 新图_三判据活动比例.png.", "EN 清单")

# --- 2) 图13 的 Hβ 版：按亚型的 Hβ vs Hα 活动比例 ---
T = pd.read_csv(MD + "/hbeta30k_per_spectrum.csv", low_memory=False)
T = T[T.absz <= 600]
subs = ['dM0','dM1','dM2','dM3','dM4','dM5']
rows = []
for sp in subs:
    q = T[T.subclass == sp]
    if len(q) < 100: continue
    rows.append(dict(sub=sp, n=len(q), ha=100*q.act_ha.mean(), hb=100*q.act_hb.mean(),
                     cat=100*q.act_cat.mean()))
D = pd.DataFrame(rows)
print(D.to_string(index=False, float_format=lambda x: '%.1f' % x))
x = np.arange(len(D)); w = 0.27
fig, ax = plt.subplots(figsize=(7.6, 4.4))
ax.bar(x-w, D.cat, w, label='catalogue H$\\alpha$', color='0.35')
ax.bar(x,   D.ha,  w, label='local H$\\alpha$', color='tab:red')
ax.bar(x+w, D.hb,  w, label='local H$\\beta$', color='tab:blue')
ax.set_xticks(x); ax.set_xticklabels(['%s\n(n=%d)' % (r.sub, r.n) for r in D.itertuples()], fontsize=8)
ax.set_ylabel('active fraction  (%)'); ax.set_xlabel('subtype  (|Z| $\\leq$ 600 pc)')
ax.set_title('Figure 13 analogue: activity fraction by subtype from H$\\alpha$ and H$\\beta$', fontsize=10)
ax.legend(fontsize=8.5, frameon=False); ax.grid(axis='y', alpha=.25); ax.tick_params(labelsize=8.5)
fig.tight_layout()
fp = OUT + "/新图_图13_子型Hβ对照.png"
fig.savefig(fp, dpi=180); plt.close(fig)
print('\n写出 %s（%d B）' % (fp, os.path.getsize(fp)))
D.to_csv(MD + "/fig13_hb_by_subtype.csv", index=False, encoding='utf-8')
print('写出 fig13_hb_by_subtype.csv（%d 行）' % len(D))
