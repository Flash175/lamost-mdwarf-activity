# -*- coding: utf-8 -*-
"""s235_readme_audit.py —— README「一、口径与关键数字」四处疑值的溯源审计。

回答四个问题（P1 / P2-1 / P2-2 / P2-3）：
  Q1 全体固定断点 0.135 的 β(ML) 是 −0.855 还是 −0.856？
     （README §二 表「⑤ 终版」行 ML 列 vs §一「整体斜率」句 —— 一律用节锚点，勿写行号）
  Q2 面板 β(ML) 有出处吗？−0.780 / −0.872 各属哪个口径（自由断点 / 固定 0.135）？
  Q3 Ro_sat(WLS) = 0.127 能否复现？
  Q4 面板固定 0.135 的 OLS/ML 现值（确认红线口径 0.135 下的面板值）

口径：τ = 2.33 − 1.50M − 0.30M²（Li 2024 印刷式，COEF=−0.30）；
      自由断点搜索 bp ∈ [4e-3, 0.5]（1,101 点宽域，避开旧 401 点网格 0.079 截断）。
"""
import sys

import numpy as np
import pandas as pd
from scipy.optimize import minimize

D = "C:/Users/lingz/Desktop/APJS/图五及相关数据/数据/"
COEF, A1, A2 = -0.30, 1.50, 2.33
BP_GRID = np.linspace(-2.4, -0.3, 1101)
BP_FIX = 0.135
SEED = 20261022
TRACE_ML = True   # 打印 ML 多初值的收敛轨迹（P3-3：让"多初值真的生效"可见）


def ro(m, p):
    return p / 10 ** (A2 - A1 * m + COEF * m ** 2)


def free_bp_ols(x, y):
    best = None
    for rs in BP_GRID:
        s, u = x <= rs, x > rs
        if s.sum() < 20 or u.sum() < 20:
            continue
        rss = ((y[s] - y[s].mean()) ** 2).sum()
        sl, ic = np.polyfit(x[u], y[u], 1)
        rss += ((y[u] - (sl * x[u] + ic)) ** 2).sum()
        if best is None or rss < best[0]:
            best = (rss, 10 ** rs, sl)
    return best[1], best[2]


def free_bp_wls(x, y, sy):
    w = 1 / np.maximum(sy / np.log(10), 1e-3) ** 2
    best = None
    for rs in BP_GRID:
        s, u = x <= rs, x > rs
        if s.sum() < 20 or u.sum() < 20:
            continue
        rss = (w[s] * (y[s] - np.average(y[s], weights=w[s])) ** 2).sum()
        M2 = np.vstack([np.ones_like(x[u]), x[u]]).T
        W = np.diag(w[u])
        b = np.linalg.lstsq(M2.T @ W @ M2, M2.T @ W @ y[u], rcond=None)[0]
        rss += (w[u] * (y[u] - M2 @ b) ** 2).sum()
        if best is None or rss < best[0]:
            best = (rss, 10 ** rs, b[1])
    return best[1], best[2]


def dexp(sy, y):
    """绝对误 → dex。与 s227.ml_fit 内部换算一致。"""
    return np.maximum(sy / np.maximum(10 ** y, 1e-12) / np.log(10), 0.02)


def ml_fit(x, y, sy, bp=None, tag=""):
    """bp=None 自由断点；bp 给定则锁定断点（与 s227 的衔接模型同式）。"""
    sd = dexp(sy, y)

    def nll(p):
        if bp is None:
            lrs, beta, c, lsi = p
        else:
            beta, c, lsi = p
            lrs = np.log10(bp)
        si = np.exp(lsi)
        m = np.where(x <= lrs, c, c + beta * (x - lrs))
        v = sd ** 2 + si ** 2
        return 0.5 * np.sum((y - m) ** 2 / v + np.log(v))

    best = None
    trials = []
    inits = (-1.0, -0.85, -0.7) if bp is None else (None,)
    for l0 in inits:
        x0 = ([l0, -0.7, np.median(y), np.log(0.3)] if bp is None
              else [-0.7, np.median(y), np.log(0.3)])
        bnd = ([(-1.30, -0.50), (-1.60, 0.10), (-9.0, 0.0), (-4.0, 0.0)] if bp is None
               else [(-1.60, 0.10), (-9.0, 0.0), (-4.0, 0.0)])
        r = minimize(nll, x0, method="Nelder-Mead", bounds=bnd,
                     options={"maxiter": 8000, "xatol": 1e-5, "fatol": 1e-7})
        trials.append((l0, r.fun, 10 ** r.x[0] if bp is None else bp,
                       r.x[1] if bp is None else r.x[0]))
        if best is None or r.fun < best.fun:
            best = r
    if bp is None and TRACE_ML:
        win = min(trials, key=lambda t: t[1])
        print("      [ML 多初值 %s] " % (tag or "-") + " | ".join(
            "l0=%.2f→NLL=%.2f@%.4f(β=%.4f)" % t for t in trials) +
            "  ⇒ 取最小: l0=%.2f" % win[0])
    if bp is None:
        return 10 ** best.x[0], best.x[1], np.exp(best.x[3])
    return bp, best.x[0], np.exp(best.x[2])


def fixed_ols(x, y, bp=BP_FIX):
    u = x > np.log10(bp)
    return np.polyfit(x[u], y[u], 1)[0]


SAMPLE_CSV = "图5_逐星样本_严格3340行_⑤.csv"
d = pd.read_csv(D + SAMPLE_CSV)
print("样本表 %s 列：%s" % (SAMPLE_CSV, ", ".join(map(str, d.columns))))
REQ = {"RHa", "P", "M", "spt", "sRHa"}
lack = REQ - set(d.columns)
if lack:
    print("  ✗ 缺列：%s" % ", ".join(sorted(lack)))
    print("  说明：sRHa 为 R′Hα 的 1σ 绝对误差列；若样本表改用别的列名，请在此映射后重跑。")
    sys.exit(3)
print("  ✓ 必需列齐全（RHa / P / M / spt / sRHa）")
d = d[(d.RHa > 0) & (d.P > 0) & (d.M > 0)].copy()
d["Ro"] = ro(d.M.values, d.P.values)
d["pan"] = np.where(d.spt.isin(["dM0", "dM1", "dM2", "dM3"]), "M0M3",
                    np.where(d.spt.isin(["dM4", "dM5", "dM6"]), "M4M6", "late"))

print("=" * 84)
print("Q1  全体 3,340：固定断点 0.135 下 OLS / ML")
x, y = np.log10(d.Ro.values), np.log10(d.RHa.values)
print("    β(OLS, 固定0.135) = %.4f      ← README §二 表「⑤ 终版」OLS 列（主结果；正文报 −0.855，末位待拍板见状态文件 U4）" % fixed_ols(x, y))
r_f = ml_fit(x, y, d.sRHa.values, bp=BP_FIX)
print("    β(ML , 固定0.135) = %.4f  σ_int=%.3f   ← 同表 ML 列应为此值（≠ −0.855）" % (r_f[1], r_f[2]))
r_free = ml_fit(x, y, d.sRHa.values, tag="全体")
print("    β(ML , 自由断点)  = %.4f  @ Ro_sat=%.4f σ_int=%.3f  ← README §一「整体斜率」句 / 台账 §2 ML 行的 −0.856" %
      (r_free[1], r_free[0], r_free[2]))

print("\n" + "=" * 84)
print("Q2  两面板：四个口径全列（认领 README §一 面板条目原有的两个 ML 值）")
rows = []
for k, q in d.groupby("pan"):
    if k == "late":
        continue
    xp, yp, sp = np.log10(q.Ro.values), np.log10(q.RHa.values), q.sRHa.values
    fo, bfo = free_bp_ols(xp, yp)
    fm = ml_fit(xp, yp, sp, tag=k)
    bo135 = fixed_ols(xp, yp)
    bm135 = ml_fit(xp, yp, sp, bp=BP_FIX)[1]
    rows.append((k, len(q), fo, bfo, fm[0], fm[1], bo135, bm135))
    print("  %-6s n=%4d" % (k, len(q)))
    print("      自由断点  OLS β=%.4f @%.4f   ML β=%.4f @%.4f" % (bfo, fo, fm[1], fm[0]))
    print("      固定 0.135 OLS β=%.4f             ML β=%.4f" % (bo135, bm135))

print("\n  → README 面板条目 M0–M3 的 β(ML)=−0.872：与上表四值比对")
print("  → README 面板条目 M4–M6 的 β(ML)=−0.780：与上表四值比对")

print("\n" + "=" * 84)
print("Q3  全体 Ro_sat(WLS)：自由断点复算（README §一 饱和点句写 0.127）")
# 注意：s227 的调用是 free_bp_wls(x, y, sy / RHa)，传**相对误**；函数内部再 /log(10) 转 dex。
rw, bw = free_bp_wls(x, y, d.sRHa.values / d.RHa.values)
print("    Ro_sat(WLS) = %.4f   β(WLS) = %.4f   ← 台账只登 β=−0.767，未登断点" % (rw, bw))
print("    （β 应落在 −0.767 附近，用于自检传参是否正确）")

print("\n" + "=" * 84)
print("Q4  红线口径确认：图 5 红线 = 全体固定 0.135 OLS")
print("    β=%.4f @ Ro_sat=%.2f；ML 的 Ro_sat 仅作对照（台账「固定断点口径」与「引用约束」两段）" %
      (fixed_ols(x, y), BP_FIX))

print("\n" + "=" * 84)
print("与 v4 CSV 对照（数据/面板拟合_v4.csv 的 beta_ml 列）")
v4 = pd.read_csv(D + "面板拟合_v4.csv")
print("  v4 表头：%s" % ", ".join(map(str, v4.columns)))
REQ_V4 = {"panel", "beta_ols", "beta_ml", "panel_ro_sat_ols", "panel_ro_sat_ml"}
lackv = REQ_V4 - set(v4.columns)
if lackv:
    print("  ✗ v4 缺列：%s —— 下方对照跳过" % ", ".join(sorted(lackv)))
    v4 = v4.iloc[0:0]
else:
    print("  ✓ v4 列名与脚本假定一致；注意本表为 τ=−0.31 旧口径，与现口径分别差 0.0013（M0–M3）/ 0.0016（M4–M6）")
for _, r in v4.iterrows():
    print("  %-6s v4: beta_ols=%.4f  beta_ml=%.4f  ro_sat_ols=%.4f  ro_sat_ml=%.4f（该列 ML 自带断点）" %
          (r["panel"], r["beta_ols"], r["beta_ml"], r["panel_ro_sat_ols"], r["panel_ro_sat_ml"]))
