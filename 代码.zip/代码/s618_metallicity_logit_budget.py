
# -*- coding: utf-8 -*-
"""s618：固定效应 logit 与金属度通道预算（在已保存的清洁样本上重算，含稳健求解）"""
import io, sys, os, json
import numpy as np, pandas as pd
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
OUTD = r'C:\Users\lingz\Desktop\复现老师工作\APJS\多个图及讨论'
d = pd.read_csv(os.path.join(OUTD,'金属度_清洁样本_637973.csv'), low_memory=False)
sub = d[d.mh_ok & d.subclass.isin(['dM0','dM1','dM2','dM3','dM4','dM5','dM6']) & (d.absz<=400)].copy()
sub['zb'] = pd.Categorical(sub.zb, categories=['<100','100-200','200-400'])
print('n(|Z|<=400, usable m_h) =', len(sub), '| frac active %.3f' % sub.active.mean())

def logit_fit(X, y, ridge=1e-6, iters=200):
    b = np.zeros(X.shape[1]); b[0] = np.log(y.mean()/(1-y.mean()))
    for _ in range(iters):
        eta = X@b; p = 1/(1+np.exp(-eta)); W = p*(1-p)
        H = X.T@(X*W[:,None]) + ridge*np.eye(X.shape[1]); g = X.T@(y-p)
        step = np.linalg.lstsq(H, g, rcond=None)[0]
        b = b + step
        if np.max(np.abs(step)) < 1e-12: break
    p = 1/(1+np.exp(-(X@b)))
    cov = np.linalg.pinv(X.T@(X*(p*(1-p))[:,None]))
    return b, np.sqrt(np.diag(cov)), p

y = sub.active.values.astype(float)
mh = sub.m_h.values
Z1 = pd.get_dummies(sub.zb, drop_first=True).astype(float).values
S1 = pd.get_dummies(sub.subclass, drop_first=True).astype(float).values
res = {}
for tag, X in [('global(|Z| fixed)', np.column_stack([np.ones(len(sub)), mh, Z1])),
               ('fixed effect(subtype+|Z|)', np.column_stack([np.ones(len(sub)), mh, S1, Z1]))]:
    b, se, p = logit_fit(X, y)
    res[tag] = dict(b_mh=float(b[1]), se=float(se[1]), z=float(b[1]/se[1]))
    print('%-28s b_mh = %+.4f +/- %.4f (z = %+.1f)' % (tag, b[1], se[1], b[1]/se[1]))
b_fx, se_fx, p_fx = logit_fit(np.column_stack([np.ones(len(sub)), mh, S1, Z1]), y)

# per-subtype slope
rows=[]
for st in ['dM0','dM1','dM2','dM3','dM4','dM5','dM6']:
    s = sub[sub.subclass==st]
    if len(s) < 500: continue
    X = np.column_stack([np.ones(len(s)), s.m_h.values, pd.get_dummies(s.zb, drop_first=True).astype(float).values])
    b, se, _ = logit_fit(X, s.active.values.astype(float))
    rows.append(dict(subtype=st, n=len(s), b_mh=float(b[1]), se=float(se[1]), z=float(b[1]/se[1]),
                     frac_pct=100*float(s.active.mean())))
per = pd.DataFrame(rows).round(4)
print('\nper-subtype logit slope\n' + per.to_string())
per.to_csv(os.path.join(OUTD,'金属度_逐亚型斜率.csv'), index=False, encoding='utf-8-sig')

# budget: <100 -> 200-400 pc, using median m_h per bin
med = {lb: float(sub[sub.zb==lb].m_h.median()) for lb in ['<100','100-200','200-400']}
dmh = med['200-400'] - med['<100']
fbar = float(sub.active.mean())
rows=[]
for tag, b, se in [('global(|Z| fixed)', res['global(|Z| fixed)']['b_mh'], res['global(|Z| fixed)']['se']),
                   ('fixed effect(subtype+|Z|)', b_fx[1], se_fx[1])]:
    dpp = 100*dmh*b*fbar*(1-fbar)
    rows.append(dict(caliber=tag, b_mh=b, b_se=se, dm_h_dex=dmh, delta_pp=dpp,
                     f_mean_pct=100*fbar))
bud = pd.DataFrame(rows).round(4)
print('\nbudget (m_h: %.3f -> %.3f dex, dm_h = %+.3f)' % (med['<100'], med['200-400'], dmh))
print(bud.to_string(index=False))
bud.to_csv(os.path.join(OUTD,'金属度_通道预算.csv'), index=False, encoding='utf-8-sig')

obs = 100*(sub[sub.zb=='<100'].active.mean() - sub[sub.zb=='200-400'].active.mean())
print('\nobserved decline <100 -> 200-400 pc = %.2f pp' % obs)
summary = dict(n_sample=int(len(d)), n_mh=int(d.mh_ok.sum()), n_fit=int(len(sub)),
               mh_med_inner=med['<100'], mh_med_outer=med['200-400'], dm_h_dex=dmh,
               observed_decline_pp=float(obs), fixed_effect=res['fixed effect(subtype+|Z|)'],
               global_only=res['global(|Z| fixed)'],
               budget_global_pp=float(bud.delta_pp.iloc[0]), budget_fixed_pp=float(bud.delta_pp.iloc[1]))
json.dump(summary, open(os.path.join(OUTD,'金属度_结论摘要.json'),'w',encoding='utf-8'), ensure_ascii=False, indent=2)
print('\nsaved 金属度_结论摘要.json')
