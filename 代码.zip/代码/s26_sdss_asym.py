# -*- coding: utf-8 -*-
"""找 SDSS 样本里的左右不对称特征，用来判定论文右板的经度方向。"""
import io, sys
import numpy as np
import pandas as pd
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")
df = pd.read_csv("data/vizier/aj141_97_sdss_dwarfs.csv", low_memory=False,
                 usecols=lambda c: c in {"RAJ2000", "DEJ2000"})
ra = df["RAJ2000"].to_numpy(float); de = df["DEJ2000"].to_numpy(float)

for lo, hi in [(65, 90), (55, 90), (-15, -3)]:
    m = (de > lo) & (de <= hi) if lo > 0 else (de > lo) & (de < hi)
    if m.sum() == 0:
        print(f"Dec {lo}..{hi}: 0 行"); continue
    print(f"Dec {lo}..{hi}: {int(m.sum())} 行，RA 范围 {ra[m].min():.1f}..{ra[m].max():.1f}，"
          f"RA 直方(30°一格):", np.histogram(ra[m], bins=np.arange(0, 361, 30))[0].tolist())
print()
print("全样本 Dec 直方(-30..90, 10°一格):",
      np.histogram(de, bins=np.arange(-30, 91, 10))[0].tolist())
