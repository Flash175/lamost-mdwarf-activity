# -*- coding: utf-8 -*-
"""s562：回应审稿意见 4/6/7——
 (A) M 侧逐谱 vs 逐星 vs 2D 三种口径的活动率（拆解 58.0/69.9 与 56.8/73.3 的差）
 (B) Δσ(vz) 的标准误与显著性（每个细片、std 与 MAD 两种估计量）
 (C) 按亚型分层（早型 dM0–dM2 / 晚型 dM3–dM5）后，活动/非活动的 σ(vz) 差
"""
import io, sys, os
import numpy as np, pandas as pd
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
from astropy.coordinates import SkyCoord
import astropy.units as un
OUT = r'C:\Users\lingz\Desktop\复现老师工作\APJS\多个图及讨论'

def save(df, name, comments):
    fp = os.path.join(OUT, name); df.to_csv(fp, index=False, encoding='utf-8')
    txt = open(fp, encoding='utf-8').read()
    with open(fp, 'w', encoding='utf-8-sig') as f:
        f.write('\n'.join('# ' + c for c in comments) + '\n' + txt)

def mad(x):
    x = np.asarray(x, float); x = x[np.isfinite(x)]
    return 1.4826*np.median(np.abs(x-np.median(x))) if len(x) > 10 else np.nan

cat = pd.read_csv('data/lamost/dr13/dr13_mstellar_dM.csv', low_memory=False,
                  usecols=['uid','subclass','teff','ewha','ewha_err','snrr','ra','dec','gaia_g_mean_mag',
                           'gaia_source_id'])
cat = cat[(cat.ewha > -20) & (cat.ewha <= 50) & (cat.ewha_err > 0) & (cat.ewha_err <= 5)].copy()
cat['active'] = (cat.ewha >= 0.75) & (cat.ewha > 3*cat.ewha_err)

# (A) 三种口径
print('=== (A) M 侧活动率的三种口径 ===')
print('  亚型   逐谱(全表)  逐星(目录去重)  逐星+Gaia裁剪(2D)')
g = pd.read_csv('data/gaia/gaia_dr3_mstars.csv', low_memory=False,
                usecols=['source_id','parallax','parallax_error','pmra','pmdec','radial_velocity','ruwe'])
cat['gaia_source_id'] = pd.to_numeric(cat.gaia_source_id, errors='coerce')
m = cat.merge(g, left_on='gaia_source_id', right_on='source_id', how='inner')
m2 = m[(m.parallax > 0.2) & (m.parallax/m.parallax_error > 5) & (m.ruwe < 1.4)]
star_cat = cat.sort_values('ewha', ascending=False).drop_duplicates('uid')
star_2d = m2.sort_values('ewha', ascending=False).drop_duplicates('uid')
rows = []
for sp in ['dM0','dM1','dM2','dM3','dM4','dM5','dM6','dM7','dM8']:
    a = cat[cat.subclass == sp]; b = star_cat[star_cat.subclass == sp]; c2 = star_2d[star_2d.subclass == sp]
    print('  %-4s  %5.1f%%(n=%6d)  %5.1f%%(n=%6d)  %5.1f%%(n=%6d)'
          % (sp, 100*a.active.mean(), len(a), 100*b.active.mean(), len(b), 100*c2.active.mean(), len(c2)))
    rows.append(dict(subtype=sp, n_spec=len(a), f_spec=100*a.active.mean(),
                     n_star=len(b), f_star=100*b.active.mean(),
                     n_2d=len(c2), f_2d=100*c2.active.mean()))
save(pd.DataFrame(rows), 'm_side_three_units.csv', [
    'M 侧三种口径：逐谱（全表）/ 逐星（目录去重）/ 逐星+Gaia 裁剪（=§1、§3 的 2D 样本）',
    '用途：拆解 §9 的 58.0/69.9 与 §3 的 56.8/73.3 之差是「谱→星」还是「全样本→2D 裁剪」',
    '生成脚本：代码/s562_kinematic_errors_and_strata.py'])

# (B)(C) 运动学
six = m2.sort_values('ewha', ascending=False).drop_duplicates('uid').copy()
# [giant-cut]
six['MG'] = six.gaia_g_mean_mag.values - 5*np.log10(np.clip(1000.0/six.parallax.values, 1, None)) + 5
six = six[six.MG >= 6].copy()
six = six[np.isfinite(six.radial_velocity) & (np.abs(six.radial_velocity) < 500)].copy()
c6 = SkyCoord(ra=six.ra.values*un.deg, dec=six.dec.values*un.deg,
              distance=(1000.0/six.parallax.values)*un.pc,
              pm_ra_cosdec=six.pmra.values*un.mas/un.yr, pm_dec=six.pmdec.values*un.mas/un.yr,
              radial_velocity=six.radial_velocity.values*un.km/un.s, frame='icrs')
gc = c6.transform_to('galactocentric')
v = gc.velocity.d_xyz.to(un.km/un.s).value
six = six.assign(vx=v[0], vy=v[1], vz=v[2], zgc=np.abs(gc.z.to(un.kpc).value)*1000)
six = six[six.zgc <= 3000]

def se_diff(sa, na, si, ni):
    return np.sqrt(sa**2/(2*max(na-1,1)) + si**2/(2*max(ni-1,1)))
def se_mad(sa, na, si, ni):
    return np.sqrt((1.858*sa)**2/max(na,1) + (1.858*si)**2/max(ni,1))

print('\n=== (B) Δσ(vz) 的标准误与显著性 ===')
rows = []
for lo, hi in [(0,25),(25,50),(50,75),(75,100),(100,150),(150,200),(40,80)]:
    s = six[(six.zgc >= lo) & (six.zgc < hi)]
    a, i = s[s.active], s[~s.active]
    if len(a) < 30 or len(i) < 30: continue
    d = a.vz.std()-i.vz.std(); se = se_diff(a.vz.std(), len(a), i.vz.std(), len(i))
    dm = mad(a.vz)-mad(i.vz); sem = se_mad(a.vz.std(), len(a), i.vz.std(), len(i))
    print('  %3d–%3d pc  n=%5d/%5d  Δstd=%+6.2f ± %.2f (%.1fσ)   ΔMAD=%+6.2f ± %.2f (%.1fσ)'
          % (lo, hi, len(a), len(i), d, se, d/se, dm, sem, dm/sem))
    rows.append(dict(slice='%d-%d' % (lo,hi), n_act=len(a), n_inact=len(i),
                     d_std=d, se_std=se, z_std=d/se, d_mad=dm, se_mad=sem, z_mad=dm/sem))
save(pd.DataFrame(rows), 'kinematic_diff_errors.csv', [
    'Δσ(vz) 的标准误与显著性：SE(std)=sqrt(σa²/(2(na−1))+σi²/(2(ni−1)))；SE(MAD)≈sqrt((1.858σa)²/na+(1.858σi)²/ni)',
    'z = Δ/SE；用于说明「两种估计量同号为负」的区间及其显著程度',
    '生成脚本：代码/s562_kinematic_errors_and_strata.py'])

print('\n=== (C) 按亚型分层后的 Δσ(vz) ===')
EARLY, LATE = ['dM0','dM1','dM2'], ['dM3','dM4','dM5']
rows = []
for grp, sps in (('dM0-dM2', EARLY), ('dM3-dM5', LATE)):
    for lo, hi in [(0,25),(25,50),(50,75),(40,80)]:
        s = six[(six.zgc >= lo) & (six.zgc < hi) & (six.subclass.isin(sps))]
        a, i = s[s.active], s[~s.active]
        if len(a) < 30 or len(i) < 30: continue
        d = a.vz.std()-i.vz.std(); se = se_diff(a.vz.std(), len(a), i.vz.std(), len(i))
        print('  %-7s %3d–%3d pc  n=%4d/%5d  Δstd=%+6.2f ± %.2f (%.1fσ)  ΔMAD=%+6.2f'
              % (grp, lo, hi, len(a), len(i), d, se, d/se, mad(a.vz)-mad(i.vz)))
        rows.append(dict(group=grp, slice='%d-%d' % (lo,hi), n_act=len(a), n_inact=len(i),
                         d_std=d, se_std=se, z_std=d/se, d_mad=mad(a.vz)-mad(i.vz)))
save(pd.DataFrame(rows), 'kinematic_diff_by_subtype.csv', [
    '按亚型分层后的 Δσ(vz)：早型 dM0–dM2 与晚型 dM3–dM5（检验「活动星更冷」是否只是「活动星更晚型」）',
    'd_std / z_std 为 std 估计量的差与显著性；d_mad 为 MAD 差',
    '生成脚本：代码/s562_kinematic_errors_and_strata.py'])
print('s562 完成')
