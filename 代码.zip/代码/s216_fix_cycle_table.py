# -*- coding: utf-8 -*-
"""修正文献周期表：Proxima 降级为争议、Gl 273 标为未证实、GJ 740 注明出处；重建 P_cyc 图"""
import io, os, shutil, sys
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
import pandas as pd
W = r'C:\Users\lingz\OneDrive\Desktop\复现老师工作'
D = r'C:\Users\lingz\Desktop\复现老师工作'
A = r'C:\Users\lingz\Desktop\APJS\图五及相关数据'
src = os.path.join(W, 'data', 'raw', 'activity_cycle_data_complete.csv')
d = pd.read_csv(src)
def setrow(star, pcyc=None, notes=None):
    m = d.Star.astype(str).str.strip() == star
    if not m.any(): print('   !! 未找到', star); return
    if pcyc is not None: d.loc[m, 'P_cyc_yr'] = pcyc
    if notes is not None: d.loc[m, 'Notes'] = notes
    print('   已更新 %-10s -> P_cyc=%-6s %s' % (star, d.loc[m, 'P_cyc_yr'].iloc[0], d.loc[m, 'Notes'].iloc[0]))
setrow('GJ 551', '', 'SM2016 报 6.8 yr；SM2020 未检出、Ibañez Bustos 2025 给 11.3 yr —— 争议个例，不入图')
setrow('Gl 273', '', 'GomesdaSilva2012 曾报 3.5 yr；后续 GdS2012 复核与 SM2016、IB2025 均未证实 —— 按未检出处理')
setrow('GJ 740', None, 'HADES VII 表 A.2：P_rot=36.3 d（旧版误记 38.3 d），周期 5.6 yr 取自正文')
d.to_csv(src, index=False, encoding='utf-8')
print('  源表已写回:', src)
for tgt in (os.path.join(D, '数据', '文献活动周周期_20颗.csv'), os.path.join(A, '数据', '文献活动周周期_20颗.csv')):
    shutil.copy2(src, tgt); print('  同步 ->', tgt.split('\\')[-2] + '/' + tgt.split('\\')[-1])
