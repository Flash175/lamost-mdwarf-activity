# -*- coding: utf-8 -*-
# 独立审计 part2：全体 RSS 面、+0.31 口径、2×2 四格、历元统计（纯 Python）
import csv, math, random

BASE = 'C:/Users/lingz/Desktop/复现老师工作/APJS/图五及相关数据'
FN = BASE + '/数据/图5_逐星样本_严格3340行_⑤_tau030.csv'
rows = []
with open(FN, encoding='utf-8-sig') as f:
    for row in csv.DictReader(f):
        rows.append(row)

def panel_of(s):
    if s in ('dM0','dM1','dM2','dM3'): return 'M0-M3'
    if s in ('dM4','dM5','dM6'): return 'M4-M6'
    return 'OTHER'

data = []
for r in rows:
    M = float(r['M']); P = float(r['P'])
    Ro30 = P / 10 ** (2.33 - 1.50 * M - 0.30 * M * M)
    Ro31 = P / 10 ** (2.33 - 1.50 * M + 0.31 * M * M)
    data.append(dict(uid=r['uid'], spt=r['spt'], panel=panel_of(r['spt']),
                     Ro30=Ro30, Ro31=Ro31,
                     logRo30=math.log10(Ro30), logRo31=math.log10(Ro31),
                     logRHa=math.log10(float(r['RHa'])), snrr=float(r['snrr'])))

def ols(xs, ys):
    n = len(xs); xm = sum(xs)/n; ym = sum(ys)/n
    sxx = sum((x-xm)**2 for x in xs); sxy = sum((x-xm)*(y-ym) for x,y in zip(xs,ys))
    b = sxy/sxx; a = ym - b*xm
    rss = sum((y-a-b*x)**2 for x,y in zip(xs,ys))
    return a,b,rss

def rss_at(ds, key, bp):
    lbp = math.log10(bp)
    lo = [d['logRHa'] for d in ds if d[key] <= lbp]
    hi = [(d[key], d['logRHa']) for d in ds if d[key] > lbp]
    if len(lo) < 3 or len(hi) < 5:
        return float('inf')
    c = sum(lo)/len(lo)
    rss = sum((y-c)**2 for y in lo)
    xs=[x for x,_ in hi]; ys=[y for _,y in hi]
    _,_,r2 = ols(xs,ys)
    return rss+r2

# linspace(-2.4,-0.3,1101) 纯 python
grid = [-2.4 + i*2.1/1100 for i in range(1101)]
bp_lin = [10**g for g in grid]

print('【C3】全体 RSS 面（linspace 1101, -0.30 口径）')
rp = [rss_at(data,'logRo30',bp) for bp in bp_lin]
imin = min(range(len(rp)), key=lambda i: rp[i])
print(f'  RSS_min = {min(rp):.3f} @ Ro = {bp_lin[imin]:.4f}   (台账2026-10-24: 1132.20 @ 0.1352; 讨论体: 1132.20)')
for tag, q in (('0.05',0.05), ('0.132',0.132), ('0.20',0.20),
               ('0.1543',0.1543), ('0.1577',0.1577), ('0.1598',0.1598)):
    i = min(range(len(bp_lin)), key=lambda i: abs(bp_lin[i]-q))
    print(f'  ΔRSS({tag}) = {rp[i]-min(rp):.3f} @格点{bp_lin[i]:.5f}   (台账: 9.74 / 0.02~0.04 / 5.13 / 1.031 / 1.241 / 0.997)')
# logspace 参数化（端点 4e-3 - 0.5）
import math as _m
lg = [10**(_m.log10(4e-3) + i*( _m.log10(0.5)-_m.log10(4e-3))/1100) for i in range(1101)]
rp2 = [rss_at(data,'logRo30',bp) for bp in lg]
imin2 = min(range(len(rp2)), key=lambda i: rp2[i])
print(f'  logspace(4e-3,0.5,1101): RSS_min = {min(rp2):.3f} @ {lg[imin2]:.4f}   (台账: 1132.22 @ 0.1322)')
gap = [d for d in data if 0.155 < d['Ro30'] <= 0.160]
print(f'  缺口(0.155,0.160]: {len(gap)} 颗 (台账29);  [0.150,0.166]: {sum(1 for d in data if 0.150<=d["Ro30"]<=0.166)} 颗 (台账73)')
print()

print('【C6】+0.31 口径')
rp31 = [rss_at(data,'logRo31',bp) for bp in bp_lin]
imin31 = min(range(len(rp31)), key=lambda i: rp31[i])
print(f'  全体自由断点: {min(rp31):.2f} @ {bp_lin[imin31]:.4f}   (台账: 0.069; 讨论体: 0.069)')
s = [d for d in data if d['logRo31'] > math.log10(0.069)]
_,b,_ = ols([d['logRo31'] for d in s],[d['logRHa'] for d in s])
print(f'  全体 β(自由断点/固定0.069) = {b:.4f}   (台账5b: -0.913; 讨论体 -0.853→-0.913)')
s = [d for d in data if d['logRo31'] > math.log10(0.132)]
_,b132_31,_ = ols([d['logRo31'] for d in s],[d['logRHa'] for d in s])
print(f'  全体 β(固定0.132, +0.31) = {b132_31:.4f}   (-0.30口径: -0.857, 位移 {abs(b132_31)-0.857:.3f})')
for p in ('M0-M3','M4-M6'):
    dp = [d for d in data if d['panel']==p]
    s1 = [d for d in dp if d['logRo31'] > math.log10(0.132)]
    _,bf,_ = ols([d['logRo31'] for d in s1],[d['logRHa'] for d in s1])
    rpp = [rss_at(dp,'logRo31',bp) for bp in bp_lin]
    ib = min(range(len(rpp)), key=lambda i: rpp[i])
    s2 = [d for d in dp if d['logRo31'] > math.log10(bp_lin[ib])]
    _,bg,_ = ols([d['logRo31'] for d in s2],[d['logRHa'] for d in s2])
    print(f'  {p}: 固定0.132 β={bf:.4f} (Δ={bf-(-0.8901 if p=="M0-M3" else -0.8225):+.3f})   自由({bp_lin[ib]:.4f}) β={bg:.4f}')
print('  讨论体C6: 固定 M0-M3 -0.890→-1.021 (Δ0.13); M4-M6 -0.822→-0.679 (Δ0.14)')
print('           自由 M0-M3 -0.642→-0.931 (Δ0.30); M4-M6 Δ约0.02')
print()

print('【C1】2×2 四格对照')
dA = [d for d in data if d['panel']=='M0-M3']
dB = [d for d in data if d['panel']=='M4-M6']
BP = 0.132; lbp = math.log10(BP)

def solve3(A, y):
    # 3x3 高斯消元
    n = 3
    M = [row[:] + [yy] for row, yy in zip(A, y)]
    for c in range(n):
        p = max(range(c, n), key=lambda r: abs(M[r][c]))
        M[c], M[p] = M[p], M[c]
        for r in range(c+1, n):
            f = M[r][c]/M[c][c]
            for k in range(c, n+1):
                M[r][k] -= f*M[c][k]
    x = [0]*n
    for r in range(n-1, -1, -1):
        x[r] = (M[r][n] - sum(M[r][k]*x[k] for k in range(r+1, n)))/M[r][r]
    return x

def anchored(d1, d2, key, bp, nboot=0):
    l = math.log10(bp)
    s1 = [(d[key], d['logRHa']) for d in d1 if d[key] > l]
    s2 = [(d[key], d['logRHa']) for d in d2 if d[key] > l]
    A = [[0.0]*3 for _ in range(3)]; Y = [0.0]*3
    for x, y in s1:
        v = [1.0, x-l, 0.0]
        for i in range(3):
            for j in range(3):
                A[i][j] += v[i]*v[j]
            Y[i] += v[i]*y
    for x, y in s2:
        v = [1.0, 0.0, x-l]
        for i in range(3):
            for j in range(3):
                A[i][j] += v[i]*v[j]
            Y[i] += v[i]*y
    sol = solve3(A, Y)
    rss = 0.0
    for x, y in s1:
        rss += (y - (sol[0] + sol[1]*(x-l)))**2
    for x, y in s2:
        rss += (y - (sol[0] + sol[2]*(x-l)))**2
    return sol[1], sol[2], rss

# 格1 自由截距+固定0.132
hA = [d for d in dA if d['logRo30'] > lbp]; hB = [d for d in dB if d['logRo30'] > lbp]
_,bA,_ = ols([d['logRo30'] for d in hA],[d['logRHa'] for d in hA])
_,bB,_ = ols([d['logRo30'] for d in hB],[d['logRHa'] for d in hB])
print(f'  格1 自由截距+固定0.132: Δβ={bA-bB:+.4f}')
# 格2 锚定连续+固定0.132
b1,b2,_ = anchored(dA,dB,'logRo30',BP)
print(f'  格2 锚定连续+固定0.132: Δβ={b1-b2:+.4f}   (台账8b: -0.63 4.3σ; 讨论体: 4.1σ)')
# 格3 自由截距+自由断点
rA = [rss_at(dA,'logRo30',bp) for bp in bp_lin]
rB = [rss_at(dB,'logRo30',bp) for bp in bp_lin]
iA = min(range(len(rA)), key=lambda i: rA[i]); iB = min(range(len(rB)), key=lambda i: rB[i])
sA = [d for d in dA if d['logRo30'] > math.log10(bp_lin[iA])]
sB = [d for d in dB if d['logRo30'] > math.log10(bp_lin[iB])]
_,bA3,_ = ols([d['logRo30'] for d in sA],[d['logRHa'] for d in sA])
_,bB3,_ = ols([d['logRo30'] for d in sB],[d['logRHa'] for d in sB])
print(f'  格3 自由截距+自由断点: Δβ={bA3-bB3:+.4f}  (bpA={bp_lin[iA]:.4f}, bpB={bp_lin[iB]:.4f})')
# 格4 锚定连续+自由断点
best = None
for bp in bp_lin:
    try:
        b1,b2,r = anchored(dA,dB,'logRo30',bp)
        if best is None or r < best[0]:
            best = (r, b1, b2, bp)
    except Exception:
        pass
print(f'  格4 锚定连续+自由断点: Δβ={best[1]-best[2]:+.4f} @bp={best[3]:.4f}   (台账8b: ≈1σ)')
print()

print('【历元】n_ep 分布')
n_eps = []
with open(BASE + '/数据/图5_历元峰值与平均.csv', encoding='utf-8-sig') as f:
    rd = csv.reader(f); hdr = None
    for row in rd:
        if not row: continue
        if row[0] == 'uid':
            hdr = row; continue
        if hdr:
            try: n_eps.append(int(float(row[hdr.index('n_ep')])))
            except Exception: pass
n_eps.sort(); nn = len(n_eps)
import statistics
print(f'  N={nn}  中位={n_eps[nn//2]}  均值={sum(n_eps)/nn:.2f}  90%分位( nearest-rank )={n_eps[min(nn-1, math.ceil(0.9*nn))]}  (讨论体: 中位1, 90%分位3)')
from collections import Counter
print('  n_ep 分布前6:', dict(sorted(Counter(n_eps).items())[:6]))
