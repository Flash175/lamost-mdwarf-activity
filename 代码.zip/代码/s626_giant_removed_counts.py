
import pandas as pd, numpy as np
OD = r'C:\Users\lingz\OneDrive\Desktop\复现老师工作\data'
lam = ['uid','designation','subclass','ewha','ewha_err','teff','gaia_source_id','gaia_g_mean_mag']
d = pd.read_csv(OD + r'\lamost\dr13\dr13_mstellar_dM.csv', usecols=lam, low_memory=False)
print('catalogue rows', len(d), '| uid', d.uid.nunique(), '| designation', d.designation.nunique())
g = pd.read_csv(OD + r'\gaia\gaia_dr3_mstars.csv', usecols=['source_id','parallax','parallax_error','ruwe','phot_g_mean_mag'], low_memory=False)
d['gaia_source_id'] = pd.to_numeric(d.gaia_source_id, errors='coerce')
m = d.merge(g, left_on='gaia_source_id', right_on='source_id', how='left')
m['MG'] = m.phot_g_mean_mag - 5*np.log10(np.clip(1000.0/m.parallax, 1, None)) + 5
print('with Gaia parallax:', int(m.MG.notna().sum()))
def show(tag, s):
    print('%-42s spectra %8d | uid %7d | designation %7d' % (tag, len(s), s.uid.nunique(), s.designation.nunique()))
show('all', m)
show('M_G >= 6 (giant-removed)', m[m.MG >= 6])
show('M_G >= 6 & EW gate', m[(m.MG >= 6) & (m.ewha > -20) & (m.ewha <= 50) & (m.ewha_err > 0) & (m.ewha_err <= 5)])
show('M_G >= 6 & finite teff', m[(m.MG >= 6) & m.teff.notna()])
show('no Gaia (NaN) rows', m[m.MG.isna()])
# how many giants are in the catalogue at all
print('\nM_G < 6:', int((m.MG < 6).sum()), '| of which M_G<4:', int((m.MG < 4).sum()))
