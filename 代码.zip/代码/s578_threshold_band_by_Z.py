# -*- coding: utf-8 -*-
"""s578: 「压线带」比例随 |Z| 的变化——压线误杀能否造成档间差异？
用与 s551 相同的 2D 样本链（EW 闸门 → Gaia 质量 → 去重 → |Z|<=3 kpc → 去巨星），
保留 ewha 与 |Z|，统计各档 EW 落在 0.70-0.80 / 0.65-0.85 / 0.50-1.00 A 的比例，
并按「压线星半数误杀」换算成对活动比例的影响上限。"""
import io, sys, os
import numpy as np, pandas as pd
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
OUT = r'C:\Users\lingz\Desktop\复现老师工作\APJS\多个图及讨论'
cat = pd.read_csv('data/lamost/dr13/dr13_mstellar_dM.csv', low_memory=False,
                  usecols=['uid','subclass','ewha','ewha_err','snrr','ra','dec','gaia_g_mean_mag','gaia_source_id'])
cat = cat[(cat.ewha > -20) & (cat.ewha <= 50) & (cat.ewha_err > 0) & (cat.ewha_err <= 5)].copy()
print('EW 闸门后 %d 条' % len(cat))
cat['gaia_source_id'] = pd.to_numeric(cat.gaia_source_id, errors='coerce')
g = pd.read_csv('data/gaia/gaia_dr3_mstars.csv', low_memory=False,
                usecols=['source_id','parallax','parallax_error','ruwe'])
m = cat.merge(g, left_on='gaia_source_id', right_on='source_id', how='inner')
m = m[(m.parallax > 0.2) & (m.parallax/m.parallax_error > 5) & (m.ruwe < 1.4)].copy()
u = m.sort_values('ewha', ascending=False).drop_duplicates('uid').copy()
dpc = 1000.0/u.parallax.values
u['MG'] = u.gaia_g_mean_mag.values - 5*np.log10(np.clip(dpc, 1, None)) + 5
u = u[u.MG >= 6].copy()
sinb = np.sin(np.deg2rad(np.arcsin(np.clip((u.dec.values - 0)/1, -1, 1))))  # placeholder, replaced below
from astropy.coordinates import SkyCoord
import astropy.units as un
sc = SkyCoord(ra=u.ra.values*un.deg, dec=u.dec.values*un.deg, distance=dpc[u.index.isin(u.index)]*un.pc if False else (1000.0/u.parallax.values)*un.pc, frame='icrs')
u['absz'] = np.abs((1000.0/u.parallax.values)*np.sin(np.deg2rad(sc.galactic.b.deg)))
u = u[u.absz <= 3000].copy()
print('2D 样本 %d 颗（应接近 637,973）' % len(u))
bins = [(0,100,'<100'),(100,200,'100-200'),(200,400,'200-400'),(400,600,'400-600'),(600,1000,'600-1000'),(1000,3000,'>1000')]
rows=[]
for a,b,lb in bins:
    q = u[(u.absz>=a)&(u.absz<b)]
    n = len(q)
    if n == 0: continue
    f1 = 100*((q.ewha>=0.70)&(q.ewha<0.80)).mean()
    f2 = 100*((q.ewha>=0.65)&(q.ewha<0.85)).mean()
    f3 = 100*((q.ewha>=0.50)&(q.ewha<1.00)).mean()
    act = 100*((q.ewha>=0.75)&(q.ewha>3*q.ewha_err)).mean()
    rows.append(dict(zbin=lb, n=n, act_pct=act, band_070_080=f1, band_065_085=f2, band_050_100=f3,
                     bias_max_pp=0.5*f1, bias_wide_pp=0.5*f3))
    print('  %-9s n=%7d  活动 %5.2f%%  EW 0.70-0.80 %4.2f%%  0.65-0.85 %4.2f%%  0.50-1.00 %4.2f%%  半数误杀影响 %4.2f pp'
          % (lb, n, act, f1, f2, f3, 0.5*f1))
T = pd.DataFrame(rows)
fp = os.path.join(OUT,'threshold_band_by_Z.csv')
T.to_csv(fp, index=False, encoding='utf-8')
txt = open(fp, encoding='utf-8').read()
open(fp,'w',encoding='utf-8-sig').write(
    '# 压线带（EW 在 0.75 A 附近）比例随 |Z| 的变化，及其对活动比例的影响上限\n'
    '# 样本链与 s551 相同（ewha 闸门 → Gaia 质量 → 每星最大 EW 去重 → |Z|<=3 kpc → M_G>=6）\n'
    '# bias_max_pp = 0.5 x band_070_080（按「压线星半数误杀」的上限）；bias_wide_pp 用 0.50-1.00 A 的宽带\n'
    '# 生成脚本：代码/s578_threshold_band_by_Z.py' + chr(10) + txt)
print('\n写出 threshold_band_by_Z.csv')
