# -*- coding: utf-8 -*-
"""s608：按正文口径重画图01（子型计数）：EW 闸门后 1,016,104 条谱 / 759,607 颗 uid"""
import io, sys, os, shutil
import pandas as pd, numpy as np
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
BASE = "C:/Users/lingz/OneDrive/Desktop/复现老师工作"
FIG = "C:/Users/lingz/Desktop/复现老师工作/APJS/图五及相关数据"
d = pd.read_csv(BASE + "/data/lamost/dr13/dr13_mstellar_dM.csv", low_memory=False,
                usecols=['uid','designation','subclass','ewha','ewha_err'])
g = d[(d.ewha > -20) & (d.ewha <= 50) & (d.ewha_err > 0) & (d.ewha_err <= 5)].copy()
g['spt'] = g.subclass.astype(str).str.strip()
order = ['dM%d' % i for i in range(10)]
spec = g.spt.value_counts().reindex(order).fillna(0).astype(int)
stars = g.drop_duplicates('uid').spt.value_counts().reindex(order).fillna(0).astype(int)
print('谱合计 %d（应 1,016,104）；uid 合计 %d（应 759,607）' % (spec.sum(), stars.sum()))
print(pd.DataFrame({'spectra': spec.values, 'uid': stars.values}, index=[o.replace('dM','M') for o in order]).T.to_string())

lab = [o.replace('dM', 'M') for o in order]
fig, ax = plt.subplots(1, 2, figsize=(12.4, 4.6))
for a, vals, ttl, tot in [(ax[0], stars.values, 'stars (unique uid)', stars.sum()),
                          (ax[1], spec.values, 'spectra', spec.sum())]:
    b = a.bar(lab, vals, color='#2ca02c', edgecolor='#c00000', linewidth=0.8)
    a.set_title('(a) LAMOST M dwarfs: %s, M0-M9 (total %s)' % (ttl, format(int(tot), ',')) if ttl.startswith('stars')
                else '(b) LAMOST M dwarfs: %s, M0-M9 (total %s)' % (ttl, format(int(tot), ',')), fontsize=10)
    a.set_xlabel('Spectral type'); a.set_ylabel('Number'); a.grid(axis='y', alpha=.25)
    for r, v in zip(b, vals):
        a.text(r.get_x()+r.get_width()/2, v, format(int(v), ','), ha='center', va='bottom', fontsize=8)
fig.suptitle('EW-gated catalogue: 1,016,104 spectra / 759,607 stars (uid), same as Section 1', fontsize=9.5)
fig.tight_layout(rect=[0, 0, 1, 0.93])
out1 = FIG + "/图_20261103/新图/新图_图01_子型计数_正文口径.png"
fig.savefig(out1, dpi=180); plt.close(fig)
print('写出 %s（%d B）' % (out1, os.path.getsize(out1)))
# 替换交付版图01（旧版入 _旧版）
dst = FIG + "/图/图01_子型计数_paperA_fig1_subtype_counts.png"
if os.path.exists(dst):
    old = FIG + "/图/_旧版"; os.makedirs(old, exist_ok=True)
    shutil.move(dst, os.path.join(old, "图01_旧口径_%d.png" % int(os.path.getmtime(dst))))
shutil.copy2(out1, dst)
print('交付版图01 已替换：%d B' % os.path.getsize(dst))
