# -*- coding: utf-8 -*-
"""s552：找出 §1 的 2D 样本 (637,674/637,683 颗) 究竟多加了哪道筛选。"""
import io, sys
import numpy as np, pandas as pd
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
from astropy.coordinates import SkyCoord
import astropy.units as un

cat = pd.read_csv('data/lamost/dr13/dr13_mstellar_dM.csv', low_memory=False,
                  usecols=['uid','subclass','teff','logg','ewha','ewha_err','snrr','ra','dec',
                           'gaia_source_id','gaia_g_mean_mag','class'])
cat = cat[(cat.ewha > -20) & (cat.ewha <= 50) & (cat.ewha_err > 0) & (cat.ewha_err <= 5)].copy()
cat['active'] = (cat.ewha >= 0.75) & (cat.ewha > 3*cat.ewha_err)
cat['gaia_source_id'] = pd.to_numeric(cat.gaia_source_id, errors='coerce')
g = pd.read_csv('data/gaia/gaia_dr3_mstars.csv', low_memory=False,
                usecols=['source_id','parallax','parallax_error','ruwe'])
m = cat.merge(g, left_on='gaia_source_id', right_on='source_id', how='inner')
m = m[(m.parallax > 0.2) & (m.parallax/m.parallax_error > 5) & (m.ruwe < 1.4)].copy()
base = m.sort_values('ewha', ascending=False).drop_duplicates('uid').copy()
d = 1000.0/base.parallax.values
sc = SkyCoord(ra=base.ra.values*un.deg, dec=base.dec.values*un.deg, distance=d*un.pc, frame='icrs')
base['absz_pc'] = np.abs(d*np.sin(np.deg2rad(sc.galactic.b.deg)))
base = base[base.absz_pc <= 3000]

def rep(tag, df):
    b = pd.cut(df.absz_pc, [0,100,200,400,1e9], labels=['<100','100-200','200-400','>400'])
    v = df.groupby(b).size()
    print('%-28s 总 %6d | %s | 合计 %d' % (tag, len(df),
          ' '.join('%s=%d' % (k, v.get(k, 0)) for k in ['<100','100-200','200-400','>400']),
          int(v.sum())))

rep('基准（当前 s551）', base)
for tag, sub in [
    ('snrr>0', base[base.snrr > 0]),
    ('snrr>=3', base[base.snrr >= 3]),
    ('snrr>=5', base[base.snrr >= 5]),
    ('ewha_err<=1.0', base[base.ewha_err <= 1.0]),
    ('ewha_err<=0.5', base[base.ewha_err <= 0.5]),
    ('class==STAR', base[base['class'].astype(str).str.upper() == 'STAR']),
    ('logg>0', base[base.logg > 0]),
    ('teff>0', base[base.teff > 0]),
    ('snrr>0 且 logg>0', base[(base.snrr > 0) & (base.logg > 0)]),
    ('gaia_g 非空', base[base.gaia_g_mean_mag.notna()]),
]:
    rep(tag, sub)
print('\n目标：总 637,674（四档之和）或 637,683')
