# -*- coding: utf-8 -*-
"""s581：把「去巨星」后的新数字写回中文稿（表格整体重生成 + 关键常量替换）。"""
import io, sys, os, re, shutil
import numpy as np, pandas as pd
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
OUT = r'C:\Users\lingz\Desktop\复现老师工作\APJS\多个图及讨论'
D = os.path.join(OUT, '新一节_银盘示踪_中文草稿.md')
shutil.copyfile(D, D.replace('.md', '_备份_去巨星前.md'))
lines = open(D, encoding='utf-8').read().split('\n')
A = pd.read_csv(os.path.join(OUT,'far400_2d_audit.csv'), comment='#').set_index('zbin')
S = pd.read_csv(os.path.join(OUT,'far400_subtype_table.csv'), comment='#')
R = pd.read_csv(os.path.join(OUT,'subtype_decline_ratio.csv'), comment='#').set_index('subtype')
W = pd.read_csv(os.path.join(OUT,'reweight_by_bin.csv'), comment='#').set_index('zbin')
K = pd.read_csv(os.path.join(OUT,'kinematic_diff_errors.csv'), comment='#')
C = pd.read_csv(os.path.join(OUT,'coolend_sn_cuts_with_n.csv'), comment='#')
H = pd.read_csv(os.path.join(OUT,'holdout_prediction.csv'), comment='#')
G = pd.read_csv(os.path.join(OUT,'highsn_far_bins.csv'), comment='#').set_index('zbin')

def replace_table(header_sub, new_rows):
    global lines
    for i, l in enumerate(lines):
        if header_sub in l:
            j = i + 2
            while j < len(lines) and lines[j].startswith('|'):
                j += 1
            lines = lines[:i+2] + new_rows + lines[j:]
            return True
    print('  未找到表头:', header_sub[:40]); return False

def fmt(x, nd=2, pct=False):
    s = ('%.'+str(nd)+'f') % x
    return s + ('%' if pct else '')

# §1 主表
rows = []
for lb in ['<100','100-200','200-400','400-600','600-1000','>1000']:
    if lb not in A.index: continue
    q = A.loc[lb]
    star = ' †' if lb == '>1000' else ''
    rows.append('| %s%s | %s | %s | %s | %s–%s | %d | %s |' % (
        lb.replace('-','–'), star, format(int(q['n']), ','), format(int(q['n_act']), ','),
        fmt(q['frac'],2,True), fmt(q['lo'],2), fmt(q['hi'],2), int(round(q['absz_med'])), fmt(q['dm0_share'],1,True)))
replace_table('| 星数 | 活动星数 | 活动比例 |', rows)

# §1 分层表
rows = []
for sp in ['dM0','dM1','dM2','dM3','dM4','dM5','dM6']:
    cells = []
    for b in ['<100','100-200','200-400']:
        q = S[(S.subtype==sp)&(S.zbin==b)]
        cells.append('%s（%s）' % (fmt(q.frac.iloc[0],1,True), format(int(q.n.iloc[0]),',')) if len(q) else '—')
    ratio = fmt(R.loc[sp,'ratio'],2)+'×' if sp in R.index else '—'
    rows.append('| %s | %s | %s | %s | %s |' % (sp, cells[0], cells[1], cells[2], ratio))
replace_table('| 亚型 | < 100 pc | 100–200 pc | 200–400 pc | 降幅 |', rows)

# §1 重加权表
rows = []
for lb in ['200-400','400-600','600-1000','>1000','>400']:
    if lb not in W.index: continue
    q = W.loc[lb]
    rows.append('| %s | %s | %s | **%s** | %s–%s | %s | %s |' % (
        lb.replace('-','–'), format(int(q['n']),','), fmt(q['frac_raw'],2,True), fmt(q['frac_rw'],2,True),
        fmt(q['rw_lo'],2), fmt(q['rw_hi'],2), format(int(round(q['kish_neff'])),','), format(int(round(q['binom_neff'])),',')))
replace_table('| 档 (pc) | n | 实测合并 |', rows)

# §2 细片表
rows = []
for sl in ['0-25','25-50','50-75','75-100','100-150','150-200','200-400']:
    q = K[K.slice==sl]
    if len(q)==0: continue
    q = q.iloc[0]
    def sig(z):
        return ('**%+.1fσ**' % z) if abs(z) >= 2 else ('%+.1fσ（与 0 相容）' % z if abs(z) < 2 and sl not in ('150-200',) else '%+.1fσ（不显著）' % z)
    rows.append('| %s | %s / %s | **%+.2f** | %.2f | %s | **%+.2f** | %.2f | %s |' % (
        sl.replace('-','–'), format(int(q.n_act),','), format(int(q.n_inact),','),
        q.d_std, q.se_std, sig(q.z_std), q.d_mad, q.se_mad, sig(q.z_mad)))
replace_table('| 细片 (pc) | n(活动/非活动) |', rows)

# §3 冷端表
rows = []
for sp in ['dM5','dM6','dM7','dM8']:
    q = C[(C.subtype==sp)]
    if len(q)==0: continue
    def fc(cut):
        r = q[q.cut==cut]
        return ('%s%%（%s）' % (fmt(r.frac.iloc[0],1), format(int(r.n.iloc[0]),','))) if len(r) else '—'
    det = q[q.cut=='all'].iloc[0]
    rows.append('| %s | %s | %s | %s–%s | %s | %s | %s | %s |' % (
        sp, format(int(det.n),','), fmt(det.frac,1,True), fmt(det.lo,1), fmt(det.hi,1),
        fmt(det.detect_pct,1,True), fc('sn36'), fc('sn612'), fc('sn620')))
replace_table('| 亚型 | 星数 | 全样本活动率 |', rows)

# 附录 A.1
rows = []
for lb in ['400-600','600-1000']:
    q = H[(H.kind=='merged')&(H.zbin==lb)]
    if len(q)==0: continue
    q = q.iloc[0]
    rows.append('| %s | %s | %s（%s–%s） | %s |' % (lb.replace('-','–'), fmt(q.pred,2,True), fmt(q.meas,2,True), fmt(q.lo,2), fmt(q.hi,2), fmt(q.ratio,2)))
replace_table('| 档 (pc) | 外推预测 | 实测（Wilson 95%） |', rows)

# 附录 A.3
rows = []
for lb in ['<100','200-400','400-600','600-1000']:
    if lb not in G.index: continue
    q = G.loc[lb]
    rows.append('| %s | %s | %s | %+d%% | %s |' % (lb.replace('-','–'), fmt(q.rw_all,2,True), fmt(q.rw_hi,2,True),
        int(round(100*(q.rw_hi-q.rw_all)/q.rw_all)), fmt(q.rw_hi/q.pred,1,False)+'×' if 'pred' in G.columns else '—'))
replace_table('| 档 (pc) | 全样本重加权 | S/N ≥ 15 重加权 |', rows)

txt = '\n'.join(lines)
# 关键常量替换
subs = [('639,702', '637,973'), ('83,270', '82,518'), ('640,000', '637,973')]
for a, b in subs:
    n = txt.count(a); txt = txt.replace(a, b); print('  替换 %s → %s : %d 处' % (a, b, n))
open(D, 'w', encoding='utf-8').write(txt)
print('写出', D, len(txt.encode('utf-8')), 'bytes')
