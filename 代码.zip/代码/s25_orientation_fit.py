# -*- coding: utf-8 -*-
"""定出论文 Fig2 两板的地图取向：把本地样本按不同 (L0, mirror) 渲染，与论文板的彩色像素密度图
（各自裁到点云包围盒后归一化）比直方图交集。"""
import io, sys
import numpy as np
import pandas as pd
from PIL import Image
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

GW, GH = 480, 240        # 统一比较网格

def paper_density(path):
    a = np.asarray(Image.open(path).convert("RGB")).astype(int)
    m = (a.max(2) - a.min(2) > 40) & (a.min(2) < 240)
    ys, xs = np.where(m)
    m = m[ys.min():ys.max() + 1, xs.min():xs.max() + 1]
    d = np.asarray(Image.fromarray((m * 255).astype(np.uint8)).resize((GW, GH), Image.BILINEAR), float) / 255
    return d / d.sum()

def render_density(ra, dec, l0, mirror):
    W, H = GW * 4, GH * 4
    fig = plt.figure(figsize=(W / 100, H / 100), dpi=100)
    ax = fig.add_axes([0, 0, 1, 1], projection="mollweide")
    lon = np.radians(((ra - l0 + 180) % 360) - 180) * (1.0 if mirror > 0 else -1.0)
    try:
        ax.scatter(lon, np.radians(dec), s=1.0, c="k", lw=0, marker="s")
        ax.set_axis_off()
        fig.canvas.draw()
        buf = np.asarray(fig.canvas.buffer_rgba())[:, :, 0].astype(float)
    finally:
        plt.close(fig)
    m = buf > 20
    ys, xs = np.where(m)
    if len(ys) == 0:
        return None
    m = m[ys.min():ys.max() + 1, xs.min():xs.max() + 1]
    d = np.asarray(Image.fromarray((m * 255).astype(np.uint8)).resize((GW, GH), Image.BILINEAR), float) / 255
    return d / max(d.sum(), 1e-9)

lam = pd.read_csv("data/vizier/apjs274_36_mdwarfs.csv", low_memory=False,
                  usecols=lambda c: c in {"LAMOST", "RAJ2000", "DEJ2000", "EWHa"})
lam = lam.dropna(subset=["RAJ2000", "DEJ2000"]).sort_values("EWHa", ascending=False).drop_duplicates("LAMOST")
sdss = pd.read_csv("data/vizier/aj141_97_sdss_dwarfs.csv", low_memory=False,
                   usecols=lambda c: c in {"RAJ2000", "DEJ2000"})
jobs = [("LAMOST", "extract/pdf_images/fig2_LAMOST_zoom.png", lam["RAJ2000"].to_numpy(float), lam["DEJ2000"].to_numpy(float)),
        ("SDSS", "extract/pdf_images/fig2_SDSS_zoom.png", sdss["RAJ2000"].to_numpy(float), sdss["DEJ2000"].to_numpy(float))]

for name, path, ra, dec in jobs:
    tgt = paper_density(path)
    res = []
    for l0 in range(0, 360, 15):
        for mir in (1, -1):
            d = render_density(ra, dec, l0, mir)
            if d is None:
                continue
            res.append((float(np.minimum(tgt, d).sum()), l0, mir))
    res.sort(reverse=True)
    print(f"=== {name} 最佳取向:")
    for s, l0, mir in res[:5]:
        print(f"   score={s:.4f}  L0={l0:3d}°  mirror={mir:+d}")
    print(f"   （最差 score={res[-1][0]:.4f}  L0={res[-1][1]:3d}° mirror={res[-1][2]:+d}）", flush=True)
