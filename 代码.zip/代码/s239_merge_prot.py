# -*- coding: utf-8 -*-
"""合并 VSX + 自算 TESS 的 P_rot，重建扩展 P_cyc–P_rot 图（含质量筛选）"""
import io, os, shutil, sys
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
import numpy as np, pandas as pd
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
W = r'C:\Users\lingz\OneDrive\Desktop\复现老师工作'; D = r'C:\Users\lingz\Desktop\复现老师工作'; A = r'C:\Users\lingz\Desktop\APJS\图五及相关数据'
g = lambda *a: os.path.join(W, *a)
cyc = pd.read_csv(g('data', 'processed', 'dr13', 'ib2025_periodogram_selfcomputed.csv')).rename(columns={'star': 'star'})
vsx = pd.read_csv(g('data', 'processed', 'dr13', 'ib2025_stars_with_prot.csv'))
vsx['key'] = vsx.star.str.replace(' ', '').str.upper()
vsx['P_vsx'] = np.where(vsx.sep_as < 5, vsx.P_rot, np.nan)
tes = pd.read_csv(g('data', 'processed', 'dr13', 'ib2025_tess_prot_selfcomputed.csv'))
tes['key'] = tes.star.str.replace(' ', '').str.upper()
tes['P_tess_ok'] = np.where((tes.power >= 0.10) & (tes.P_tess < 90) & (tes.P_tess > 0.25), tes.P_tess, np.nan)
print('TESS 通过质量筛选（power>=0.10 且 0.25<P<90 d）：')
print(tes[tes.P_tess_ok.notna()][['star','P_tess','power','FAP','N']].to_string(index=False))
cyc['key'] = cyc.star.str.replace(' ', '').str.upper()
M = cyc.merge(vsx[['key','P_vsx']], on='key', how='left').merge(tes[['key','P_tess_ok','power']], on='key', how='left')
M['P_rot'] = M.P_vsx.fillna(M.P_tess_ok)
M['src'] = np.where(M.P_vsx.notna(), 'VSX', np.where(M.P_tess_ok.notna(), 'TESS(ours)', ''))
use = M[M.P_rot.notna() & (M.FAP < 0.05) & (M.P_yr <= 0.95*M.baseline_yr) & (M.P_yr <= 24)].copy()
use['flag'] = np.where(use.P_yr > 18, 'boundary', 'ok')
out = use[['star','P_rot','src','P_yr','P2_yr','power_x' if 'power_x' in use else 'power','FAP','N_x' if 'N_x' in use else 'N','baseline_yr','flag']]
out = out.rename(columns={out.columns[5]: 'cycle_power', out.columns[7]: 'N_obs'})
out.to_csv(g('data','processed','dr13','pcyc_vs_prot_expanded.csv'), index=False)
print('\n最终可用 %d 点：' % len(out)); print(out.round(3).to_string(index=False))
lit = pd.read_csv(g('data','raw','activity_cycle_data_complete.csv'))
lit['P_cyc'] = pd.to_numeric(lit.P_cyc_yr, errors='coerce'); lit['ProT'] = pd.to_numeric(lit.P_rot_days, errors='coerce')
ok = lit.dropna(subset=['P_cyc','ProT'])
fig, ax = plt.subplots(figsize=(6.8, 5.2))
ax.errorbar(ok.ProT, ok.P_cyc, yerr=pd.to_numeric(ok.P_cyc_err_yr, errors='coerce'),
            xerr=pd.to_numeric(ok.P_rot_err_days, errors='coerce'), fmt='none', ecolor='0.78', lw=0.7, zorder=2)
ax.scatter(ok.ProT, ok.P_cyc, s=34, c='#1f4fd8', label='literature table (N=%d)' % len(ok), zorder=3)
mk = {'VSX': ('o', '#d95f02'), 'TESS(ours)': ('^', '#2e8b57')}
for s, (m, c) in mk.items():
    q = use[use.src == s]
    if len(q): ax.scatter(q.P_rot, q.P_yr, s=52, marker=m, facecolors='none', edgecolors=c, lw=1.4,
                          label='recomputed, P$_{rot}$ from %s (N=%d)' % (s, len(q)), zorder=4)
for _, r in use.iterrows():
    ax.annotate(str(r.star), (r.P_rot, r.P_yr), textcoords='offset points', xytext=(6, 3), fontsize=6.2,
                color='#2e8b57' if r.src.startswith('TESS') else '#8c3b00')
for _, r in ok.iterrows():
    ax.annotate(str(r.Star), (r.ProT, r.P_cyc), textcoords='offset points', xytext=(5, -9), fontsize=5.9, color='0.4')
ax.scatter([25.4], [11.0], marker='*', s=220, color='goldenrod', edgecolor='k', lw=0.6, zorder=5)
ax.annotate('Sun', (25.4, 11.0), xytext=(7, -9), textcoords='offset points', fontsize=7)
ax.set_xscale('log'); ax.set_yscale('log'); ax.set_xlabel('P$_{rot}$ (days)', fontsize=11); ax.set_ylabel('P$_{cyc}$ (years)', fontsize=11)
ax.set_xlim(1.5, 330); ax.set_ylim(1.5, 34); ax.grid(alpha=0.25, which='both', lw=0.4)
ax.tick_params(direction='in', top=True, right=True, labelsize=9)
ax.legend(fontsize=6.8, loc='upper left', framealpha=0.95)
ax.set_title('Activity cycle vs rotation period: %d literature + %d recomputed points' % (len(ok), len(use)), fontsize=10)
fig.text(0.5, 0.012, 'circles: P$_{rot}$ from VSX (BY/ROT spot modulation, 5 arcsec); triangles: our Lomb-Scargle P$_{rot}$ from TESS SPOC light curves (peak power >= 0.10, 0.25 < P < 90 d).\n'
                     'P$_{cyc}$: our Lomb-Scargle on the Ibanez Bustos et al. (2025) Table B1 (FAP < 0.05, P$_{cyc}$ <= 0.95 x baseline).', ha='center', fontsize=6.1, color='0.3', linespacing=1.5)
fig.tight_layout(rect=(0, 0.075, 1, 1))
o = g('figures','dr13_figPcyc_Prot_expanded.png'); fig.savefig(o, dpi=180); plt.close(fig)
for s, t in [(o, os.path.join(D,'图','对照与备选','附_Pcyc_vs_Prot_扩展_自算.png')), (o, os.path.join(A,'图','附_Pcyc_vs_Prot_扩展_自算.png')),
             (g('data','processed','dr13','pcyc_vs_prot_expanded.csv'), os.path.join(D,'数据','Pcyc与Prot_扩展样本.csv')),
             (g('data','processed','dr13','pcyc_vs_prot_expanded.csv'), os.path.join(A,'数据','Pcyc与Prot_扩展样本.csv')),
             (g('data','processed','dr13','ib2025_tess_prot_selfcomputed.csv'), os.path.join(A,'数据','IB2025_TESS自算自转周期.csv')),
             (g('data','processed','dr13','ib2025_ztf_periods.csv'), os.path.join(A,'数据','IB2025_ZTF周期查询_35星.csv'))]:
    shutil.copy2(s, t)
print('\n图/表已同步')
