# -*- coding: utf-8 -*-
import csv, os, numpy as np
D = r"C:\Users\lingz\OneDrive\Desktop\复现老师工作\data\processed\dr13"
rows = list(csv.DictReader(open(os.path.join(D, "fig5_sample_strict_v4.csv"), newline="", encoding="utf-8-sig")))
ro = np.array([float(r["Ro"]) for r in rows]); rh = np.array([float(r["RHa"]) for r in rows])
m = np.isfinite(ro)&np.isfinite(rh)&(ro>0)&(rh>0); ro, rh = ro[m], rh[m]
x, y = np.log10(ro), np.log10(rh); n = x.size
o = np.argsort(x); xs, ys = x[o], y[o]
Px = np.concatenate(([0], np.cumsum(xs))); Pxx = np.concatenate(([0], np.cumsum(xs**2)))
Py = np.concatenate(([0], np.cumsum(ys))); Pyy = np.concatenate(([0], np.cumsum(ys**2))); Pxy = np.concatenate(([0], np.cumsum(xs*ys)))
grid = np.linspace(np.log10(0.004), np.log10(0.5), 1101); ks = np.searchsorted(xs, grid, side="right")
recs = []
for rs, k in zip(10**grid, ks):
    if k < 10 or n-k < 10: continue
    s1 = Pyy[k] - Py[k]**2/k; n2 = n-k
    sxx = Pxx[n]-Pxx[k]-(Px[n]-Px[k])**2/n2
    sxy = Pxy[n]-Pxy[k]-(Px[n]-Px[k])*(Py[n]-Py[k])/n2
    syy = Pyy[n]-Pyy[k]-(Py[n]-Py[k])**2/n2
    # slope of the unsaturated branch at this break
    slope = sxy/sxx
    recs.append((rs, s1+syy-sxy**2/sxx, slope, k))
out = os.path.join(D, "fig5_rss_profile_all.csv")
with open(out, "w", newline="", encoding="utf-8") as f:
    w = csv.writer(f); w.writerow(["Ro_sat", "RSS", "beta_unsat", "n_flat"])
    for r in recs: w.writerow(["%.6f" % r[0], "%.6f" % r[1], "%.6f" % r[2], r[3]])
mn = min(r[1] for r in recs)
print("wrote", out, "rows", len(recs), "RSS_min %.2f at %.4f" % (mn, min(recs, key=lambda r: r[1])[0]))
