# -*- coding: utf-8 -*-
"""s610：按当前目录重画图07（曝光次数 + HJD 间隔），版式完全沿用 repro/src/s71_dr13_fig7.py。

相对 s71 只改三处：① 数据路径写绝对；② 输出落到 APJS 图包；③ 替换交付副本（旧版入 _旧版）。
统计口径一字未改：按 uid 分组、左板 1..min(max,35)、内嵌累计分母 = ≥2 次曝光的星、
右板 100 天分箱（0..2900）、dt>0。
"""
from __future__ import annotations

import io
import os
import shutil
import sys

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

BASE = "C:/Users/lingz/OneDrive/Desktop/复现老师工作"
FIG = "C:/Users/lingz/Desktop/复现老师工作/APJS/图五及相关数据"


def main():
    d = pd.read_csv(BASE + "/data/lamost/dr13/dr13_mstellar_dM.csv", low_memory=False,
                    usecols=["designation", "uid", "lmjd"])
    d = d.dropna(subset=["designation", "lmjd"])
    d = d.sort_values(["uid", "lmjd"])
    n_exp = d.groupby("uid").size()
    n_des = d.groupby("designation").size()
    print("按 designation 分组：%s 星，>=2 次 %s，恰好2次占 %.1f%%" % (format(len(n_des), ","), format(int((n_des >= 2).sum()), ","), 100 * (n_des == 2).sum() / max((n_des >= 2).sum(), 1)))
    print("DR13 M 矮星 %s 颗，曝光 %s 次" % (format(len(n_exp), ","), format(len(d), ",")))
    ge2 = n_exp[n_exp >= 2]
    print(">=2 次曝光: %s 颗（论文 130,084）" % format(len(ge2), ","))
    print("恰好 2 次: %s = 占>=2次的 %.1f%%（论文 73%%）" % (format(int((n_exp == 2).sum()), ","), 100 * (n_exp == 2).sum() / len(ge2)))
    lmjd = d.lmjd.to_numpy(float)
    des = d.uid.to_numpy()
    same = des[1:] == des[:-1]
    dt = np.diff(lmjd)[same]
    dt = dt[np.isfinite(dt) & (dt > 0)]
    print("相邻观测间隔 %s 个，中位 %.1f 天，>2800 天 %s 个" % (format(len(dt), ","), np.median(dt), format(int((dt > 2800).sum()), ",")))

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(13.5, 4.6))
    nmax = int(min(n_exp.max(), 35))
    counts = np.array([int((n_exp == k).sum()) for k in range(1, nmax + 1)])
    print("n=1..6:", counts[:6].tolist(), "| n=1 占比 %.1f%%" % (100.0 * counts[0] / counts.sum()))
    ax1.bar(np.arange(1, nmax + 1), counts, color="tab:blue", width=0.8)
    ax1.set_yscale("log")
    ax1.set_xlabel("Number of Exposures", fontsize=10)
    ax1.set_ylabel("Number of M-type Stars", fontsize=10)
    ax1.set_xlim(0.5, nmax + 0.5)
    ax1.tick_params(labelsize=8)
    ins = ax1.inset_axes([0.42, 0.42, 0.55, 0.55])
    k2 = np.arange(2, nmax + 1)
    cnt2 = counts[1:]
    cum = np.cumsum(cnt2) / cnt2.sum() * 100
    ins.bar(k2, cum, color="0.6", width=0.8)
    print("内嵌累计（分母= >=2 次的 %s 颗）：2 次 %.1f%% -> 16 次 %.1f%%" % (format(int(cnt2.sum()), ","), cum[0], cum[k2.tolist().index(16)] if 16 in k2.tolist() else cum[-1]))
    ins.set_ylim(0, 100); ins.set_xlim(1.6, 16.5)
    ins.set_xticks([5, 10, 15]); ins.set_yticks([0, 20, 40, 60, 80, 100])
    ins.set_yticklabels(["0%", "20%", "40%", "60%", "80%", "100%"], fontsize=6)
    ins.tick_params(labelsize=6)
    ins.set_xlabel("Number of Exposures", fontsize=7)
    ins.set_ylabel("Cumulative", fontsize=7)
    bins = np.arange(0, 2900, 100)
    h, edges = np.histogram(dt, bins=bins)
    ax2.bar(edges[:-1] + 50, h, width=90, color="tab:green")
    print("右板 29 箱合计 %s；0-100 天箱 %s" % (format(int(h.sum()), ","), format(int(h[0]), ",")))
    ax2.set_xlabel("HJD Interval (days)", fontsize=10)
    ax2.set_ylabel("Number", fontsize=10)
    ax2.tick_params(labelsize=8)
    for c, e in zip(h, edges[:-1]):
        if c > 0:
            ax2.text(e + 50, c, str(c), ha="center", va="bottom", fontsize=6, rotation=0)
    ax2.set_xlim(-50, 2800)
    ax2.set_title("Histogram of HJD Intervals", fontsize=10)
    ax2.tick_params(axis="x", rotation=60, labelsize=7)
    fig.tight_layout()

    out = FIG + "/图_20261103/新图/新图_图07_正文口径_uid分组.png"
    fig.savefig(out, dpi=170); plt.close(fig)
    print("写出 %s（%d B）" % (out, os.path.getsize(out)))
    for dst in [FIG + "/图_20261103/图/图07_曝光次数_dr13_fig7_exposures.png",
                FIG + "/图_20261104/图/图07_曝光次数_dr13_fig7_exposures.png"]:
        if os.path.exists(dst):
            old = os.path.join(os.path.dirname(dst), "_旧版")
            os.makedirs(old, exist_ok=True)
            shutil.move(dst, os.path.join(old, "图07_旧口径_%d.png" % int(os.path.getmtime(dst))))
            shutil.copy2(out, dst)
            print("替换 %s（现 %d B）" % (dst, os.path.getsize(dst)))


if __name__ == "__main__":
    main()
