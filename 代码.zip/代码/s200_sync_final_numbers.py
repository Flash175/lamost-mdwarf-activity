# -*- coding: utf-8 -*-
"""别名修正+细网格后的终版数字，全面同步：图/表/逐星样本/文档"""
import io, glob, os, shutil, sys
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
import pandas as pd
W = r'C:\Users\lingz\OneDrive\Desktop\复现老师工作'
D = r'C:\Users\lingz\Desktop\复现老师工作'
A = r'C:\Users\lingz\Desktop\APJS\图五及相关数据'
g = lambda *a: os.path.join(W, *a)
FILES = [(g('figures', 'dr13_fig5_rha_rossby.png'), os.path.join(D, '图', '图05_Rossby_dr13_fig5_rha_rossby.png'), '图'),
         (g('figures', 'dr13_fig5_rha_rossby_strict.png'), os.path.join(D, '图', '对照与备选', 'dr13_fig5_rha_rossby_strict_single.png'), '图'),
         (g('data', 'processed', 'dr13', 'fig5_robustness_v4.csv'), os.path.join(D, '数据', '图5_稳健性表_v4.csv'), '表'),
         (g('data', 'processed', 'dr13', 'fig5_panel_fits_v4.csv'), os.path.join(D, '数据', '图5_面板拟合_v4.csv'), '表'),
         (g('data', 'processed', 'dr13', 'fig5_sample_strict_v4.csv'), os.path.join(D, '数据', '图5_逐星样本_严格3340行_⑤.csv'), '样本'),
         (g('data', 'processed', 'dr13', 'fig5_sample_relaxed_v4.csv'), os.path.join(D, '数据', '图5_逐星样本_对照4114行_⑤′.csv'), '样本'),
         (g('data', 'processed', 'dr13', 'fig5_sample_period_v4.csv'), os.path.join(D, '数据', '图5_逐星样本_周期4612行_①.csv'), '样本')]
for s, d, _ in FILES:
    shutil.copy2(s, d)
for s, d, k in FILES:
    tgt = {'图': os.path.join(A, '图'), '表': os.path.join(A, '数据'), '样本': os.path.join(A, '数据')}[k]
    tgt = os.path.join(tgt, {'图': {'dr13_fig5_rha_rossby.png': '图5_两面板_终版.png', 'dr13_fig5_rha_rossby_strict.png': '图5_单面板_变体.png'},
                             '表': {'fig5_robustness_v4.csv': '稳健性表_v4_逐级筛选.csv', 'fig5_panel_fits_v4.csv': '面板拟合_v4.csv'},
                             '样本': {'fig5_sample_strict_v4.csv': '图5_逐星样本_严格3340行_⑤.csv',
                                      'fig5_sample_relaxed_v4.csv': '图5_逐星样本_对照4114行_⑤′.csv',
                                      'fig5_sample_period_v4.csv': '图5_逐星样本_周期4612行_①.csv'}}[k][os.path.basename(s)])
    shutil.copy2(s, tgt)
print('   已同步 图2 + 表2 + 逐星样本3 到交付包与 APJS')

TOK = [('−0.870', '−0.851'), ('-0.870', '-0.851'), ('−0.863', '−0.855'), ('-0.863', '-0.855'),
       ('−0.832', '−0.817'), ('-0.832', '-0.817'), ('−0.846', '−0.842'), ('-0.846', '-0.842'),
       ('3,361', '3,340'), ('4,140', '4,114'), ('2,096', '2,083'), ('1,253', '1,245'),
       ('−0.930', '−0.935'), ('-0.930', '-0.935'), ('−0.735', '−0.702'), ('-0.735', '-0.702'),
       ('±0.145', '±0.085'), ('± 0.145', '± 0.085'), ('±0.189', '±0.204'), ('± 0.189', '± 0.204'),
       ('Ro_sat=0.132', 'Ro_sat=0.137'), ('Ro_sat = 0.132', 'Ro_sat = 0.137'), ('σ_int=0.49', 'σ_int=0.49')]
docs = [p for pat in ('%s\\*.md' % os.path.join(D), '%s\\文档\\*.md' % D, '%s\\方法说明\\*.md' % A,
                      '%s\\README.md' % A, '%s\\说明.md' % D) for p in glob.glob(pat)]
# 稳健性表整块用 CSV 重生成
tab = pd.read_csv(g('data', 'processed', 'dr13', 'fig5_robustness_v4.csv'))
lines = ['| 逐级筛选 | N | β (OLS) | β (WLS) | β (ML) | Ro_sat | σ_int (dex) |', '|---|---|---|---|---|---|---|']
for _, r in tab.iterrows():
    nm = str(r['样本']).replace('(双星/别名/M3-M4边界)', '（含别名/双星/边界）')
    lines.append('| %s | %s | %.3f | %.3f | %.3f | %.3f | %.2f |' % (nm, format(int(r.n), ','), r['β OLS'], r['β WLS'], r['β ML'], r['Ro_sat OLS'], r['σ_int']))
NEWTAB = '\n'.join(lines)
for p in docs:
    s = open(p, encoding='utf-8').read(); o = s; ch = []
    for a, b in TOK:
        if a in s and a != b: s = s.replace(a, b); ch.append(a + '->' + b)
    if '| 逐级筛选 | N | β (OLS)' in s:
        i, j = s.index('| 逐级筛选 | N | β (OLS)'), s.index('\n', s.rindex('| **'))
        s = s[:i] + NEWTAB + s[j:]; ch.append('稳健性表重生成')
    if s != o: open(p, 'w', encoding='utf-8').write(s)
    print('   %-42s %s' % (os.path.basename(p), '; '.join(ch) or '-'))
print('\n=== 复检旧数字残留 ===')
bad = 0
for p in docs:
    s = open(p, encoding='utf-8').read()
    for t in ('0.870', '0.863', '0.832', '0.846', '3,361', '4,140', '2,096', '1,253', '0.145', '0.189'):
        if t in s: print('  !!', os.path.basename(p), '含', t); bad += 1
print('   残留 %d 处' % bad)
