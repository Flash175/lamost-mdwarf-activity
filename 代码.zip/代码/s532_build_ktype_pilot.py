
# -*- coding: utf-8 -*-
"""取 K 型矮星试点样本（随机 1/60），存 obsid 清单与元数据。"""
import io, os, sys, requests, pandas as pd, numpy as np
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
BASE='https://www.lamost.org/openapi'; token=open('extract/lamost_token.txt').read().strip()
def q(sql, timeout=180):
    r = requests.get(f'{BASE}/dr13/v1.0/sql', params={'sql': sql, 'output.fmt':'csv','token':token}, timeout=timeout)
    if r.text.lstrip().startswith('{'):
        raise RuntimeError(r.text[:120])
    return pd.read_csv(io.StringIO(r.text.lstrip('\ufeff')))

cnt = q("select count(*) as n from stellar where subclass like 'K%' and logg > 3.8 and teff between 3900 and 5500")
print('K 型矮星（logg>3.8, 3900<T<5500）总数:', int(cnt.n[0]))
sql = ("select obsid, uid, subclass, teff, logg, snrr, gaia_g_mean_mag, z from stellar "
       "where subclass like 'K%' and logg > 3.8 and teff between 3900 and 5500 "
       "and obsid % 60 = 13 and snrr between 4 and 30 and gaia_g_mean_mag between 14.0 and 18.0 "
       "order by obsid limit 30000")
d = q(sql)
print('取到', len(d), '条；亚型分布：')
print(d.subclass.value_counts().head(10).to_string())
d['uid'] = d.uid.astype(str)
one = d.sort_values('snrr', ascending=False).drop_duplicates('uid')
print('\n每星一条后', len(one), '颗；G 中位 %.1f；S/N 中位 %.1f' % (one.gaia_g_mean_mag.median(), one.snrr.median()))
os.makedirs('data/processed/dr13', exist_ok=True)
one.to_csv('data/processed/dr13/ktype_pilot_meta.csv', index=False, encoding='utf-8-sig')
with open('data/processed/dr13/ktype_pilot_obsids.txt', 'w') as fh:
    fh.write('\n'.join(str(int(o)) for o in one.obsid) + '\n')
print('已写 obsid 清单:', len(one), '条 → data/processed/dr13/ktype_pilot_obsids.txt')
print('对比 M 样本：G 中位 16.6、S/N 中位约 15（mstellar 全表）')
