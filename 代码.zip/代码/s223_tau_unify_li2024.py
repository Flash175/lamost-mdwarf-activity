# -*- coding: utf-8 -*-
"""s223：τ 标定统一为 Li et al. (2024) 印刷式 log τ = 2.33 − 1.50M − 0.30M²

背景
----
Li et al. (2024, ApJS 274, 36) 正文印为 `log τ = 2.33 - 1.50 (M/Msun) - 0.3 (M/Msun)^2`
并注明引自 N. J. Wright et al. (2018)。Wright et al. (2018, MNRAS 479, 2351) 式(6)
的原始系数为 −0.31（两位小数），Li 等人印出的 −0.3 是末位取整。

本脚本把"采用系数"从 0.31 切到 0.30（单一约定），并重算全部下游统计量，
列出两位小数差异对每个数值的实际影响，供正文/图注/台账同步。

用法：python s223_tau_unify_li2024.py
输出：data/processed/dr13/tau统一口径_Li2024_vs_Wright2018.csv
"""
import io, os, sys
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
import numpy as np, pandas as pd
from scipy.optimize import minimize

SAMPLE = '../数据/图5_逐星样本_严格3340行_⑤.csv'
OUT = '../数据/tau统一口径_Li2024_vs_Wright2018.csv'
BP = 0.135          # 正文固定断点
SNR_CUT = 23.5      # least-biased 高 S/N 半样本阈值
NB = 2000           # bootstrap 次数

d = pd.read_csv(SAMPLE)
d = d[(d.RHa > 0) & (d.P > 0) & (d.M > 0)].copy()
d['pan'] = np.where(d.spt.isin(['dM0', 'dM1', 'dM2', 'dM3']), 'M0M3',
                    np.where(d.spt.isin(['dM4', 'dM5', 'dM6']), 'M4M6', 'other'))
d['snr'] = d.RHa / d.sRHa


def ro(mass, P, b):
    return P / 10 ** (2.33 - 1.50 * mass - b * mass ** 2)


def slope(x, y):
    return np.polyfit(x, y, 1)[0] if len(x) >= 10 else np.nan


def free_break(x, y):
    """网格搜索断点（与 s189/s213 同口径），返回 (Ro_sat, beta)。"""
    best = None
    for rs in np.linspace(-1.1, -0.4, 401):
        s, u = x <= rs, x > rs
        if s.sum() < 20 or u.sum() < 20:
            continue
        rss = ((y[s] - y[s].mean()) ** 2).sum()
        sl, ic = np.polyfit(x[u], y[u], 1)
        rss += ((y[u] - (sl * x[u] + ic)) ** 2).sum()
        if best is None or rss < best[0]:
            best = (rss, 10 ** rs, sl)
    return best[1], best[2]


def mlfit(x, y, sy):
    """含内禀弥散的 ML（与 s213 同口径），返回 (Ro_sat, beta, sigma_int)。"""
    def nll(p):
        l, b, c, ls = p
        si = np.exp(ls)
        m = np.where(x <= l, c, c + b * (x - l))
        v = sy ** 2 + si ** 2
        return 0.5 * np.sum((y - m) ** 2 / v + np.log(v))
    best = None
    for l0 in (-1.0, -0.85, -0.7):
        r = minimize(nll, [l0, -0.7, np.median(y), np.log(.3)], method='Nelder-Mead',
                     bounds=[(-1.3, -0.5), (-1.6, 0.1), (-9, 0), (-4, 0)],
                     options={'maxiter': 5000})
        if best is None or r.fun < best.fun:
            best = r
    return 10 ** best.x[0], best.x[1], np.exp(best.x[3])


rows = []
for b, tag in ((0.31, 'Wright2018 式(6) 原值 −0.31'),
               (0.30, 'Li2024 印刷式 −0.30（本文采用）')):
    d['Ro_b'] = ro(d.M.values, d.P.values, b)
    x = np.log10(d.Ro_b.values)
    y = np.log10(d.RHa.values)
    u = x > np.log10(BP)

    r = {'约定': tag, '系数': -b,
         'Ro最小': d.Ro_b.min(), 'Ro中位': d.Ro_b.median(), 'Ro最大': d.Ro_b.max(),
         'n_Ro>3': int((d.Ro_b > 3).sum()), 'n_断点以上': int(u.sum())}

    # 固定断点：全体 + 两面板
    for k, mask in (('全体', u), ('M0M3', u & (d.pan == 'M0M3').values),
                    ('M4M6', u & (d.pan == 'M4M6').values)):
        r['β_' + k] = slope(x[mask], y[mask])

    # bootstrap（固定断点，全体斜率与 Δβ）
    rng = np.random.default_rng(20261022)
    idx = np.where(u)[0]
    i1 = np.where(u & (d.pan == 'M0M3').values)[0]
    i2 = np.where(u & (d.pan == 'M4M6').values)[0]
    bs, bd = [], []
    for _ in range(NB):
        s = rng.choice(idx, len(idx), replace=True)
        bs.append(slope(x[s], y[s]))
        q = s[np.isin(s, i1)]
        p = s[np.isin(s, i2)]
        if len(q) >= 10 and len(p) >= 10:
            bd.append(slope(x[p], y[p]) - slope(x[q], y[q]))
    r['σβ_全体'] = float(np.std(bs, ddof=1))
    r['Δβ'] = r['β_M4M6'] - r['β_M0M3']
    r['σΔβ'] = float(np.std(bd, ddof=1))

    # 三档断点
    for bp in (0.100, 0.120):
        m = x > np.log10(bp)
        r['β_bp%.3f' % bp] = slope(x[m], y[m])

    # 自由断点 OLS / ML
    rs, bs_ = free_break(x, y)
    r['Ro_sat_OLS'] = rs
    r['β_OLS自由'] = bs_
    sy = np.maximum(d.sRHa.values / np.maximum(d.RHa.values, 1e-12) / np.log(10), 0.02)
    ok = np.isfinite(x) & np.isfinite(y)
    rml, bml, sil = mlfit(x[ok], y[ok], sy[ok])
    r['Ro_sat_ML'] = rml
    r['β_ML'] = bml
    r['σ_int'] = sil

    # WLS（逆方差）
    w = 1 / sy[ok] ** 2
    r['β_WLS'] = np.polyfit(x[ok], y[ok], 1, w=np.sqrt(w))[0]

    # least-biased：高 S/N 半样本
    hi = (d.snr >= SNR_CUT).values & ok
    r['n_高SN'] = int(hi.sum())
    r['β_高SN'] = slope(x[hi], y[hi])
    xh, yh = x[hi], y[hi]
    hb = [slope(xh[s], yh[s]) for s in
          (rng.choice(len(xh), len(xh), replace=True) for _ in range(NB))]
    r['σβ_高SN'] = float(np.std(hb, ddof=1))

    # 与 Li et al. (2024) −0.91 ± 0.16 的偏差
    for key, bk, sk in (('保守下界', r['β_全体'], r['σβ_全体']),
                        ('least-biased', r['β_高SN'], r['σβ_高SN'])):
        r['vsLi_' + key] = abs(bk - (-0.91)) / np.hypot(sk, 0.16)
    rows.append(r)

T = pd.DataFrame(rows)
T.to_csv(OUT, index=False, encoding='utf-8-sig')

pd.set_option('display.width', 200, 'display.max_columns', 60)
print('=== 样本 ===')
print('n=%d  面板块：%s  高 S/N(≥%.1f) n=%d' %
      (len(d), d.pan.value_counts().to_dict(), SNR_CUT, int((d.snr >= SNR_CUT).sum())))
print('\n=== 主表 ===')
show = ['约定', 'β_全体', 'σβ_全体', 'β_M0M3', 'β_M4M6', 'Δβ', 'σΔβ',
        'Ro_sat_OLS', 'Ro_sat_ML', 'β_OLS自由', 'β_ML', 'σ_int', 'β_WLS',
        'β_高SN', 'σβ_高SN', 'vsLi_保守下界', 'vsLi_least-biased']
print(T[show].T.to_string(float_format=lambda v: '%.4f' % v))

a, b_ = T.iloc[0], T.iloc[1]
print('\n=== 0.31 → 0.30 的实际位移 ===')
for c in ['β_全体', 'β_M0M3', 'β_M4M6', 'Δβ', 'Ro_sat_OLS', 'Ro_sat_ML', 'β_ML',
          'β_WLS', 'β_高SN', 'vsLi_保守下界', 'vsLi_least-biased']:
    print('  %-16s %+.5f' % (c, b_[c] - a[c]))
print('\n已写出：%s' % OUT)
