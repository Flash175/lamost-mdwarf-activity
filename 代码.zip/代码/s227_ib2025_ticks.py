# -*- coding: utf-8 -*-
"""IB2025 图：去掉次刻度标签、挪开说明文字"""
import io, os, shutil, sys
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
import numpy as np, pandas as pd
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt, matplotlib.ticker as mticker
W = r'C:\Users\lingz\OneDrive\Desktop\复现老师工作'
D = r'C:\Users\lingz\Desktop\复现老师工作'
A = r'C:\Users\lingz\Desktop\APJS\图五及相关数据'
g = lambda *a: os.path.join(W, *a)
r = pd.read_csv(g('data', 'processed', 'dr13', 'ib2025_periodogram_selfcomputed.csv'))
det = r[r.FAP < 0.05].sort_values('P_yr', ascending=False).reset_index(drop=True)
fig, ax = plt.subplots(figsize=(6.8, 5.2))
ax.axvspan(3, 19, color='#dfe9ff', zorder=0)
ax.text(0.02, 0.975, 'shaded: 3-19 yr (range reported by Ibanez Bustos et al. 2025)',
        transform=ax.transAxes, va='top', fontsize=7, color='0.35')
y = np.arange(len(det))
ax.errorbar(det.P_yr, y, xerr=np.abs(det.P2_yr - det.P_yr), fmt='none', elinewidth=0.7, ecolor='0.65', zorder=2)
ax.scatter(det.P_yr, y, s=34, c=np.where(det.FAP < 0.01, '#1f4fd8', 'white'),
           edgecolor='#1f4fd8', lw=1.0, zorder=3)
ax.set_yticks(y)
ax.set_yticklabels(['%s  (N=%d, %.0f yr)' % (s, n, b) for s, n, b in zip(det.star, det.N, det.baseline_yr)], fontsize=7.2)
ax.set_xscale('log'); ax.set_xlim(1.9, 32)
ax.xaxis.set_major_locator(mticker.FixedLocator([2, 3, 5, 10, 20]))
ax.xaxis.set_major_formatter(mticker.FixedFormatter(['2', '3', '5', '10', '20']))
ax.xaxis.set_minor_formatter(mticker.NullFormatter())
ax.set_xlabel('P$_{cyc}$ (yr) — our Lomb-Scargle recomputation', fontsize=10)
ax.set_title('Ibanez Bustos et al. (2025) Table B1: %d of %d stars show FAP < 0.05\n'
             'filled: FAP < 0.01;  horizontal bars: separation from the secondary peak' % (len(det), len(r)), fontsize=9)
ax.tick_params(direction='in', top=True, right=True, labelsize=8)
ax.grid(alpha=0.25, axis='x', lw=0.4)
ax.set_ylim(-0.8, len(det) - 0.2)
fig.text(0.5, 0.012, 'Recomputed by us from the published time series (2,806 points, 33 stars; Lomb-Scargle, 2-25 yr, baseline >= 8 yr).\n'
                     'These are OUR estimates, not the values published by the authors.', ha='center', fontsize=6.5, color='0.3', linespacing=1.5)
fig.tight_layout(rect=(0, 0.075, 1, 1))
o = g('figures', 'dr13_figIB2025_cycles.png'); fig.savefig(o, dpi=180); plt.close(fig)
for tgt in (os.path.join(D, '图', '对照与备选', '附_IB2025_自算周期_FAP.png'), os.path.join(A, '图', '附_IB2025_自算周期_FAP.png')):
    shutil.copy2(o, tgt)
print('  已重绘并同步')
