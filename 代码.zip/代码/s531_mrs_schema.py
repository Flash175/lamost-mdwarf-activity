
import io, sys, requests, pandas as pd
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
BASE='https://www.lamost.org/openapi'; token=open('extract/lamost_token.txt').read().strip()
def q(sql, fmt='csv'):
    r = requests.get(f'{BASE}/dr13/v1.0/sql', params={'sql': sql, 'output.fmt':fmt,'token':token}, timeout=90)
    return r.text
for tbl in ('med_stellar','med_catalogue','med'):
    try:
        t = q(f'select * from {tbl} limit 2')
        if t.lstrip().startswith('{'):
            print('===', tbl, '->', t[:90]); continue
        df = pd.read_csv(io.StringIO(t.lstrip('\ufeff')))
        print('===', tbl, '列数', len(df.columns))
        print('    ', ', '.join(df.columns)[:400])
        print('     含 ew/ha:', [c for c in df.columns if 'ew' in c.lower() or 'ha' in c.lower()])
    except Exception as e:
        print('===', tbl, 'ERR', str(e)[:80])
