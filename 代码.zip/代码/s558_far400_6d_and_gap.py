# -*- coding: utf-8 -*-
"""s558：6D 日心 >400 pc 子集的属性（统一口径：先去重、再筛 RV）+ 重加权差的分解。"""
import io, sys, os
import numpy as np, pandas as pd
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
from astropy.coordinates import SkyCoord
import astropy.units as un
OUT = r'C:\Users\lingz\Desktop\复现老师工作\APJS\多个图及讨论'

def save(df, name, comments):
    fp = os.path.join(OUT, name); df.to_csv(fp, index=False, encoding='utf-8')
    txt = open(fp, encoding='utf-8').read()
    with open(fp, 'w', encoding='utf-8-sig') as f:
        f.write('\n'.join('# ' + c for c in comments) + '\n' + txt)
    print('  写出 %s（%d 行）' % (name, len(df)))

cat = pd.read_csv('data/lamost/dr13/dr13_mstellar_dM.csv', low_memory=False,
                  usecols=['uid','subclass','teff','logg','ewha','ewha_err','snrr','ra','dec',
                           'gaia_source_id','gaia_g_mean_mag'])
cat = cat[(cat.ewha > -20) & (cat.ewha <= 50) & (cat.ewha_err > 0) & (cat.ewha_err <= 5)].copy()
cat['active'] = (cat.ewha >= 0.75) & (cat.ewha > 3*cat.ewha_err)
cat['gaia_source_id'] = pd.to_numeric(cat.gaia_source_id, errors='coerce')
g = pd.read_csv('data/gaia/gaia_dr3_mstars.csv', low_memory=False,
                usecols=['source_id','parallax','parallax_error','pmra','pmdec','radial_velocity','ruwe'])
m = cat.merge(g, left_on='gaia_source_id', right_on='source_id', how='inner')
m = m[(m.parallax > 0.2) & (m.parallax/m.parallax_error > 5) & (m.ruwe < 1.4)].copy()
m['rv'] = m.radial_velocity
six = m.sort_values('ewha', ascending=False).drop_duplicates('uid').copy()
six = six[np.isfinite(six.rv) & (np.abs(six.rv) < 500)].copy()
d = 1000.0/six.parallax.values
sc = SkyCoord(ra=six.ra.values*un.deg, dec=six.dec.values*un.deg, distance=d*un.pc, frame='icrs')
six = six.assign(absz_pc=np.abs(d*np.sin(np.deg2rad(sc.galactic.b.deg))))
for tag, sel in (('no 3 kpc cap', six[six.absz_pc > 400]),
                  ('with |Z|<=3 kpc (canonical)', six[(six.absz_pc > 400) & (six.absz_pc <= 3000)])):
    far = sel
    act, ina = far[far.active], far[~far.active]
    print('6D 日心 >400 pc（%s）：%d 颗，活动 %d' % (tag, len(far), len(act)))
    print('  活动星：S/N 中位 %.2f，S/N<3 的 %d 颗；logg 中位 %.2f，logg<3.5 的 %d 颗；G 中位 %.2f'
          % (act.snrr.median(), int((act.snrr < 3).sum()), act.logg.median(), int((act.logg < 3.5).sum()),
             act.gaia_g_mean_mag.median()))
    print('  非活动：S/N 中位 %.2f；logg 中位 %.2f；G 中位 %.2f'
          % (ina.snrr.median(), ina.logg.median(), ina.gaia_g_mean_mag.median()))
    T = pd.DataFrame([dict(cut=tag, n=len(far), n_act=len(act),
                           snr_med_act=act.snrr.median(), n_snr_lt3=int((act.snrr < 3).sum()),
                           logg_med_act=act.logg.median(), n_logg_lt35=int((act.logg < 3.5).sum()),
                           g_med_act=act.gaia_g_mean_mag.median(), g_med_inact=ina.gaia_g_mean_mag.median(),
                           snr_med_inact=ina.snrr.median(), teff_med_act=act.teff.median(),
                           teff_med_inact=ina.teff.median())])
    save(T, 'far400_6d_properties.csv' if tag.startswith('with') else 'far400_6d_properties_nocap.csv', [
        '6D 子样本在日心 |Z|>400 pc 处的属性（先去重、再筛 RV，与 §0 一致）',
        'with |Z|<=3 kpc 为 §0 的 canonical 口径（6D = 83,270 颗）；no cap 一行仅用于说明差的 4 颗来自 3 kpc 上限',
        '对照：同档 2D 样本 99,684 颗，活动星 G 中位 17.33、logg 中位 4.56、logg<3.5 占 6.5%',
        '生成脚本：代码/s558_far400_6d_and_gap.py'])

# 重加权差的分解（固定 <100 pc 平面权重）
C = pd.read_csv(os.path.join(OUT, 'reweight_composition.csv'), comment='#')
rows = []
for a, b in [('200-400', '>400'), ('400-600', '600-1000')]:
    A = C[C.zbin == a].set_index('subtype'); B = C[C.zbin == b].set_index('subtype')
    tot = 0.0
    for sp in A.index:
        if sp not in B.index: continue
        w = A.loc[sp, 'weight_pct']/100.0
        d = w*(B.loc[sp, 'frac'] - A.loc[sp, 'frac'])
        tot += d
        rows.append(dict(gap=a+'>'+b, subtype=sp, weight_pct=100*w,
                         frac_from=A.loc[sp,'frac'], frac_to=B.loc[sp,'frac'],
                         contrib_pp=d, n_to=int(B.loc[sp,'n'])))
    rows.append(dict(gap=a+'>'+b, subtype='TOTAL', weight_pct=np.nan, frac_from=np.nan,
                     frac_to=np.nan, contrib_pp=tot, n_to=int(B.n.sum())))
G = pd.DataFrame(rows)
print('\n重加权差分解：')
for q in G.gap.unique():
    t = G[(G.gap == q) & (G.subtype == 'TOTAL')].contrib_pp.iloc[0]
    print('  %s 合计 %+.2f pp' % (q, t))
    for _, r in G[(G.gap == q) & (G.subtype != 'TOTAL')].sort_values('contrib_pp', key=abs, ascending=False).head(4).iterrows():
        print('     %-4s 权重 %.2f%%  %.2f → %.2f%%  贡献 %+.2f pp (%+.0f%%)  n_to=%d'
              % (r.subtype, r.weight_pct, r.frac_from, r.frac_to, r.contrib_pp, 100*r.contrib_pp/t, r.n_to))
save(G, 'reweight_gap_decomposition.csv', [
    '重加权值在相邻远档之间的差如何按亚型分解（固定 <100 pc 平面权重）',
    'contrib_pp = w_plane x (frac_to - frac_from)；TOTAL 行为两档重加权值之差',
    '用途：说明「不是单格驱动」是否成立——实际由 dM4（69%）与 dM4+dM2（45%+29%）主导',
    '生成脚本：代码/s558_far400_6d_and_gap.py'])
print('s558 完成')
