# -*- coding: utf-8 -*-
"""写入 τ 公式版本声明与敏感性、统一 sigma 表述、补 ② 行说明，并同步 CSV

【已作废 · 勿重跑】本脚本内嵌文字把 −0.31 标为“Li et al. 2024 印刷式”，与原文不符：
Li (2024, ApJS 274, 36) 印的是 −0.3，Wright et al. (2018) 式(6) 才是 −0.31。
现行单一约定见 common_activity.TAU_COEF（= −0.30），数值影响见 s223。重跑会覆盖现行文档。
"""
import io, glob, os, shutil, sys
import pandas as pd
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
W = r'C:\Users\lingz\OneDrive\Desktop\复现老师工作'
D = r'C:\Users\lingz\Desktop\复现老师工作'
A = r'C:\Users\lingz\Desktop\APJS\图五及相关数据'
g = lambda *a: os.path.join(W, *a)
t = pd.read_csv(g('data', 'processed', 'dr13', 'fig5_tau_convention_v4.csv'))
for s, d in [(g('data', 'processed', 'dr13', 'fig5_tau_convention_v4.csv'), os.path.join(D, '数据', '图5_tau公式敏感性_v4.csv')),
             (g('data', 'processed', 'dr13', 'fig5_tau_convention_v4.csv'), os.path.join(A, '数据', 'tau公式敏感性_v4.csv'))]:
    shutil.copy2(s, d); print('  同步 ->', d.split('\\')[-1])
rows = []
for _, r in t[t.样本.str.startswith('⑤') & ~t.样本.str.startswith('⑤′')].iterrows():
    rows.append('| %s | %s | %d | %.3f | %.3f | %.3f | %.3f | %.2f |' % (
        r.样本, '−0.31（Li 印刷版，本文采用）' if r.二次项符号 == '−0.31' else '+0.31（Wright 若为加号）',
        int(r.n), r.Ro_sat_OLS, r.beta_OLS, r.Ro_sat_ML, r.beta_ML, r.sigma_int))
SEC = ['', '## 七、τ 公式版本声明与 Ro_sat 的口径依赖（2026-10-21 补）', '',
       '质量–对流翻转时标关系采用 **log τ = 2.33 − 1.50 M − 0.31 M²**（与 Li et al. 2024 印刷式一致，二次项取负号）。',
       '文献中该二次项的符号存在分歧（若 Wright et al. 2018 为 +0.31，则 τ 在 M ≳ 0.4 M☉ 端偏小）。为评估影响，我们在同一批星上两种符号各拟合一遍：', '',
       '| 样本 | 二次项符号 | N | Ro_sat(OLS) | β(OLS) | Ro_sat(ML) | β(ML) | σ_int |',
       '|---|---|---|---|---|---|---|---|'] + rows + [
       '', '**结论**',
       '* 斜率稳健：β(OLS) 由 −0.851 变为 −0.894（Δ=0.043），远小于 ±0.111 的 bootstrap 误差；分面板 −0.935→−0.974、−0.702→−0.725，同样在误差内。',
       '* 饱和点不稳健：Ro_sat 由 0.137 移到 0.087（−36%）。加号口径的 0.09 反而更接近 X 射线文献的经典饱和值（~0.1）。',
       '* **与论文 Ro_sat = 0.19 ± 0.06 的比较必须同口径**：本文与 Li et al. (2024) 都用 −0.31，因此“我们 0.137 vs 论文 0.19”是在同一约定下的差异（约 0.9σ）；若改用 +0.31 口径，两者需同时重算，不可交叉比较。',
       '', '**正文可用句（中文）**：本文采用 Li 等（2024）所印的质量–τ 关系 log τ = 2.33 − 1.50M − 0.31M²；由于该式二次项符号在文献中有分歧，我们另以 +0.31 的变体做了检验：斜率仅由 −0.85 变到 −0.89（Δ=0.04，小于 bootstrap 误差 ±0.11），但饱和点由 0.137 移到 0.087，故 Ro_sat 的绝对值依赖 τ 约定，本文与 Li 等（2024）的比较均在 −0.31 约定下进行。',
       '', '**Sentence for the paper (English)**: We adopt the mass-tau relation exactly as printed by Li et al. (2024), log tau = 2.33 - 1.50M - 0.31M^2. Because the sign of the quadratic term differs among works, we repeated the fit with +0.31: the slope changes only from -0.85 to -0.89 (Delta = 0.04, well inside the +/-0.11 bootstrap error), whereas the saturation point moves from 0.137 to 0.087. The absolute value of Ro_sat is therefore convention dependent, and all comparisons with the Ro_sat = 0.19 +/- 0.06 of Li et al. (2024) are made within the -0.31 convention.', '']
BLK = '\n'.join(SEC)
NOTE2 = ('\n* ② 行 β 与 ① 行数值完全相同是必然结果，不是漏重拟合：被去别名剔除的 378 颗星 Ro 全部 < 0.129，'
         '位于断点 0.136 以下的饱和坪内，幂律分支（决定 β）的数据一字未变，故最小二乘解逐位相同。\n')
for p in (os.path.join(D, '文档', '图05_Methods文字_中英文.md'), os.path.join(A, '方法说明', '图05_Methods文字_中英文.md')):
    s = open(p, encoding='utf-8').read()
    if '七、τ 公式版本声明' not in s:
        s = s.rstrip() + '\n' + BLK
    s = s.replace('约 0.25σ', '约 0.30σ（Δβ=0.059，合成误差 0.195）')
    if '② 行 β 与 ① 行数值完全相同' not in s:
        s = s.rstrip() + '\n' + NOTE2
    open(p, 'w', encoding='utf-8').write(s)
    print('  Methods 文档已更新:', p.split('\\')[-3:])
for p in (os.path.join(D, '文档', '交付说明.md'), os.path.join(D, '文档', '口径假设台账.md'), os.path.join(D, '说明.md'),
          os.path.join(A, '方法说明', '交付说明_全量.md'), os.path.join(A, '方法说明', '口径假设台账_全量.md')):
    if not os.path.exists(p): continue
    s = open(p, encoding='utf-8').read(); o = s
    s = s.replace('约 0.25σ', '约 0.30σ')
    if s != o: open(p, 'w', encoding='utf-8').write(s); print('  sigma 表述已改:', os.path.basename(p))
p = os.path.join(A, 'README.md'); s = open(p, encoding='utf-8').read()
if 'τ 公式版本' not in s:
    s = s.replace('## 二、三个口径的关系（避免再混用）',
        '> **τ 口径声明**：本文采用 log τ = 2.33 − 1.50M − 0.31M²（与 Li et al. 2024 印刷式一致）。若二次项改取 +0.31，'
        '则 β = −0.894（Δ=0.04，可忽略）、**Ro_sat = 0.087**（由 0.137 下移 36%）。Ro_sat 的绝对值因此依赖 τ 约定，'
        '与论文 0.19 的比较须同口径。详见 数据/tau公式敏感性_v4.csv 与方法说明第七节。\n\n## 二、三个口径的关系（避免再混用）')
    open(p, 'w', encoding='utf-8').write(s); print('  README 已加 τ 口径声明')
print('\n=== tau 敏感性表（⑤ 行）===')
print(t[t.样本.str.startswith('⑤')].round(4).to_string(index=False))
