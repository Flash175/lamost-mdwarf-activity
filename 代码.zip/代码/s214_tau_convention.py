# -*- coding: utf-8 -*-
"""τ 公式符号敏感性表"""
import io, os, sys
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
import numpy as np, pandas as pd
from scipy.optimize import minimize
P = lambda f: os.path.join('data', 'processed', 'dr13', f)
def ols(d):
    x, y = np.log10(d.Ro.values), np.log10(d.RHa.values); best = None
    for rs in np.linspace(-1.1, -0.4, 401):
        s, u = x <= rs, x > rs
        if s.sum() < 20 or u.sum() < 20: continue
        rss = ((y[s]-y[s].mean())**2).sum(); sl, ic = np.polyfit(x[u], y[u], 1)
        rss += ((y[u]-(sl*x[u]+ic))**2).sum()
        if best is None or rss < best[0]: best = (rss, 10**rs, sl)
    return best[1], best[2]
def ml(d):
    x, y = np.log10(d.Ro.values), np.log10(d.RHa.values)
    sy = np.maximum(d.sRHa.values/np.maximum(d.RHa.values, 1e-12)/np.log(10), 0.02)
    def nll(p):
        l, b, c, ls = p; si = np.exp(ls)
        m = np.where(x <= l, c, c + b*(x - l)); v = sy**2 + si**2
        return 0.5*np.sum((y-m)**2/v + np.log(v))
    best = None
    for l0 in (-1.0, -0.85, -0.7):
        r = minimize(nll, [l0, -0.7, np.median(y), np.log(.3)], method='Nelder-Mead',
                     bounds=[(-1.3,-0.5),(-1.6,0.1),(-9,0),(-4,0)], options={'maxiter': 5000})
        if best is None or r.fun < best.fun: best = r
    return 10**best.x[0], best.x[1], np.exp(best.x[3])
rows = []
for tag, f in (('① 4,612 原始', 'fig5_sample_period_v4.csv'), ('⑤′ 4,114', 'fig5_sample_relaxed_v4.csv'), ('⑤ 3,340 严格', 'fig5_sample_strict_v4.csv')):
    S = pd.read_csv(P(f))
    for coef, cn in ((-0.30, 'log τ = 2.33 − 1.50M − 0.30M²（Li et al. 2024 印刷式，本文采用）'),
                     (-0.31, 'log τ = 2.33 − 1.50M − 0.31M²（Wright et al. 2018 式(6) 原值，敏感性对照）'),
                     (+0.31, 'log τ = 2.33 − 1.50M + 0.31M²（二次项取正号的假想变体，非任何原文）')):
        d = S.copy(); d['Ro'] = d.P / (10 ** (2.33 - 1.5*d.M + coef*d.M**2))
        d = d[(d.Ro > 0) & (d.Ro <= 3)]
        ro, b = ols(d); r3, b3, si = ml(d)
        pan = {}
        for nm, sel in (('M0M3', ['dM0','dM1','dM2','dM3']), ('M4M6', ['dM4','dM5','dM6'])):
            q = d[d.spt.isin(sel)]; pan[nm] = ols(q)[1]
        rows.append(dict(样本=tag, tau公式=cn, 二次项系数=('%+.2f' % coef), n=len(d),
                         Ro_sat_OLS=ro, beta_OLS=b, Ro_sat_ML=r3, beta_ML=b3, sigma_int=si,
                         beta_M0M3=pan['M0M3'], beta_M4M6=pan['M4M6']))
t = pd.DataFrame(rows)
t.to_csv(P('fig5_tau_convention_v4.csv'), index=False)
pd.set_option('display.width', 200)
print(t.round(4).to_string(index=False))
