# -*- coding: utf-8 -*-
"""写入已确认的 Ro_sat 双口径表述，并同步图

【已作废 · 勿重跑】其中“−0.31 / +0.31 双口径”的命名以 −0.31 为本文采用值，现已改为
−0.30（Li 印刷式）。现行单一约定见 common_activity.TAU_COEF。
"""
import io, os, shutil, sys
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
W = r'C:\Users\lingz\OneDrive\Desktop\复现老师工作'
D = r'C:\Users\lingz\Desktop\复现老师工作'
A = r'C:\Users\lingz\Desktop\APJS\图五及相关数据'
for s, d in [(os.path.join(W, 'figures', 'dr13_fig5_rha_rossby.png'), os.path.join(D, '图', '图05_Rossby_dr13_fig5_rha_rossby.png')),
             (os.path.join(W, 'figures', 'dr13_fig5_rha_rossby.png'), os.path.join(A, '图', '图5_两面板_终版.png')),
             (os.path.join(W, 'figures', 'dr13_fig5_rha_rossby_strict.png'), os.path.join(D, '图', '对照与备选', 'dr13_fig5_rha_rossby_strict_single.png')),
             (os.path.join(W, 'figures', 'dr13_fig5_rha_rossby_strict.png'), os.path.join(A, '图', '图5_单面板_变体.png'))]:
    shutil.copy2(s, d)
print('  图已同步（两面板 + 单面板）')
BLK = """
### 正文最终写法（2026-10-21 已确认）

**中文（Methods / 结果）**：质量–对流翻转时标关系采用 **log τ = 2.33 − 1.50M − 0.31M²**（与 Li 等 2024 的印刷式一致）。由于该二次项的符号在文献中存在分歧，我们对 +0.31 的变体重复了拟合：斜率仅由 −0.85 变到 −0.89（Δ = 0.04，远小于 ±0.11 的 bootstrap 误差），但饱和点由 **Ro_sat = 0.137 移到 0.087**。后者反而更接近 X 射线观测给出的经典饱和值（~0.1）。因此本文的 **Ro_sat 以双口径并列给出：0.137（−0.31，本文采用）与 0.087（+0.31）**；与 Li 等（2024）的 Ro_sat = 0.19 ± 0.06 的比较一律在同一 −0.31 口径下进行（差异约 0.9σ），不与 +0.31 口径交叉比较。

**English**：We adopt log tau = 2.33 - 1.50M - 0.31M^2, the relation as printed by Li et al. (2024). Since the sign of the quadratic term differs in the literature, we repeated the fit with +0.31: the slope changes only from -0.85 to -0.89 (Delta = 0.04, far below the +/-0.11 bootstrap error), while the saturation point moves from Ro_sat = 0.137 to 0.087, the latter being closer to the canonical X-ray saturation value of ~0.1. We therefore quote Ro_sat under both conventions, 0.137 (-0.31, adopted) and 0.087 (+0.31); all comparisons with Ro_sat = 0.19 +/- 0.06 from Li et al. (2024) are made within the -0.31 convention (a ~0.9 sigma difference) and are never mixed with the +0.31 value.
"""
for p in (os.path.join(D, '文档', '图05_Methods文字_中英文.md'), os.path.join(A, '方法说明', '图05_Methods文字_中英文.md')):
    s = open(p, encoding='utf-8').read()
    if '正文最终写法（2026-10-21 已确认）' in s: print('  已有该写法', p.split('\\')[-1]); continue
    open(p, 'w', encoding='utf-8').write(s.rstrip() + '\n' + BLK); print('  已写入双口径表述:', p.split('\\')[-3:])
p = os.path.join(A, 'README.md'); s = open(p, encoding='utf-8').read()
if '双口径并列' not in s:
    s = s.replace('详见 数据/tau公式敏感性_v4.csv 与方法说明第七节。',
                  '详见 数据/tau公式敏感性_v4.csv 与方法说明第七节。**正文按双口径并列写：Ro_sat = 0.137（−0.31）与 0.087（+0.31）**。')
    open(p, 'w', encoding='utf-8').write(s); print('  README 已注明双口径并列')
p = os.path.join(D, '文档', '交付说明.md'); s = open(p, encoding='utf-8').read()
if '双口径' not in s:
    open(p, 'w', encoding='utf-8').write(s.rstrip() + '\n> **Ro_sat 双口径（2026-10-21 确认）**：−0.31 口径 0.137（本文采用），+0.31 口径 0.087；β 相应为 −0.851 与 −0.894，结论不变。\n')
    print('  交付说明.md 已加双口径行')
