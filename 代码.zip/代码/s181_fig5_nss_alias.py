# -*- coding: utf-8 -*-
"""① 取 Gaia non_single_star（仅图5 样本 5,619 个 source_id）② VSX 与 Fetherolf 周期交叉验证（查别名）
③ 用 nss + 交叉验证后的严格样本重算 β，并与既有稳健性表合并"""
import io, os, sys, time
from concurrent.futures import ThreadPoolExecutor
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
import numpy as np, pandas as pd, requests
from scipy.spatial import cKDTree
from scipy.optimize import minimize
TAP = 'https://gea.esac.esa.int/tap-server/tap/sync'
H = {'User-Agent': 'repro-mstars/1.0'}

cat = pd.read_csv('data/lamost/dr13/dr13_mstellar_dM.csv', low_memory=False,
                  usecols=['uid','designation','subclass','ewha','ewha_err','teff','ra','dec','gaia_source_id'])
for c in ('ewha','ewha_err','teff','ra','dec'): cat[c] = pd.to_numeric(cat[c], errors='coerce')
cat['ewha_err'] = cat.ewha_err.abs()
cat = cat[(cat.ewha > -20) & (cat.ewha <= 50) & (cat.ewha_err > 0) & (cat.ewha_err <= 5)]
star = cat.loc[cat.groupby('uid').ewha.idxmax()].dropna(subset=['ra','dec']).copy()
star['spt'] = star.subclass.astype(str).str.strip()
v = pd.read_csv('repro/_vsx/VSX_catalog_sample.csv', low_memory=False, usecols=['Type','Period','RAJ2000','DEJ2000'])
v['Period'] = pd.to_numeric(v.Period, errors='coerce')
v = v[v.Period.gt(0) & v.RAJ2000.notna() & v.DEJ2000.notna()]
v = v[v.Type.astype(str).str.upper().str.contains('ROT')]
def uv(ra, dec):
    ra = np.radians(np.asarray(ra, float)); dec = np.radians(np.asarray(dec, float))
    return np.column_stack([np.cos(dec)*np.cos(ra), np.cos(dec)*np.sin(ra), np.sin(dec)])
tree = cKDTree(uv(star.ra.values, star.dec.values))
d0, i0 = tree.query(uv(v.RAJ2000.values, v.DEJ2000.values), k=1, distance_upper_bound=np.radians(3/3600))
okm = np.isfinite(d0) & (i0 < len(star))
vs = pd.DataFrame({'idx': i0[okm], 'P_vsx': v.Period.values[okm]}).drop_duplicates('idx')
S = star.iloc[vs.idx.values].copy(); S['P'] = vs.P_vsx.values; S['src'] = 'VSX'; S['fP'] = 0.075
fe = pd.read_csv('data/processed/dr13/dr13_fig5_sample.csv', low_memory=False, usecols=['designation','P'])
fe['designation'] = fe.designation.astype(str)
F = star[star.designation.astype(str).isin(set(fe.designation))].merge(
    fe.drop_duplicates('designation'), on='designation', how='inner')
F['src'] = 'Fetherolf'; F['fP'] = 0.03

# ② 交叉验证：同一颗星同时有 VSX 与 Fetherolf 周期时比较
both = S[['uid','P']].rename(columns={'P':'P_vsx'}).merge(
    F[['uid','P']].rename(columns={'P':'P_fet'}), on='uid', how='inner')
both['ratio'] = both.P_vsx / both.P_fet
near = lambda r, x: np.abs(r/x - 1) < 0.05
print('VSX∩Fetherolf 同星 %d 颗；周期比值 5/50/95%% = %s' % (len(both), np.round(np.percentile(both.ratio, [5,50,95]), 2).tolist()))
print('  一致(±5%%): %d (%.1f%%)；0.5×: %d；2×: %d；3×: %d；其它: %d'
      % (int(near(both.ratio,1).sum()), 100*near(both.ratio,1).mean(),
         int(near(both.ratio,0.5).sum()), int(near(both.ratio,2).sum()), int(near(both.ratio,1/3).sum()),
         int(len(both) - near(both.ratio,1).sum() - near(both.ratio,0.5).sum() - near(both.ratio,2).sum() - near(both.ratio,1/3).sum())))
alias_uid = set(both.loc[~(near(both.ratio,1) | near(both.ratio,2)), 'uid'])

# ① non_single_star（只查图5 样本）
A = pd.concat([S[['uid','designation','spt','ewha','ewha_err','teff','P','src','fP','gaia_source_id']],
               F[['uid','designation','spt','ewha','ewha_err','teff','P','src','fP','gaia_source_id']]], ignore_index=True)
A['sid'] = A.gaia_source_id.astype(str).str.split('.').str[0]
ids = sorted(set(A.sid[A.sid.str.match(r'^\d{15,}$')]))
print('待查 non_single_star 的 source_id：%d' % len(ids))
os.makedirs('data/gaia/nss_batches', exist_ok=True)
chunks = [ids[i:i+500] for i in range(0, len(ids), 500)]
def one(kc):
    k, ch = kc
    p = 'data/gaia/nss_batches/n_%03d.csv' % k
    if os.path.exists(p): return 0
    q = 'SELECT source_id, non_single_star FROM gaiadr3.gaia_source WHERE source_id IN (%s)' % ','.join(ch)
    for _ in range(3):
        try:
            r = requests.post(TAP, data={'REQUEST':'doQuery','LANG':'ADQL','FORMAT':'csv','QUERY':q}, timeout=180, headers=H)
            if r.status_code == 200 and ',' in r.text[:300]:
                open(p,'w',encoding='utf-8').write(r.text); return len(r.text.splitlines())-1
        except Exception: time.sleep(2)
    return -1
tot = 0
with ThreadPoolExecutor(max_workers=4) as ex:
    for g_ in ex.map(one, enumerate(chunks)):
        if g_ > 0: tot += g_
print('non_single_star 取到 %d 行（%d 批）' % (tot, len(chunks)))
nss = pd.concat([pd.read_csv(f) for f in sorted(__import__('glob').glob('data/gaia/nss_batches/*.csv'))], ignore_index=True)
nss['sid'] = nss.source_id.astype('int64').astype(str)
A = A.merge(nss[['sid','non_single_star']], on='sid', how='left')
print('nss 分布：', A.non_single_star.fillna(-1).value_counts().to_dict())
# 物理量
c2 = pd.read_csv('data/vizier/apjs274_36_mdwarfs.csv', low_memory=False, usecols=lambda c: c in {'EWHa','RHa','Teff','Mstar'})
c3 = c2[(c2.EWHa > 0.1) & (c2.RHa > 0) & (c2.Teff > 2800) & (c2.Teff < 4600)].copy(); c3['chi'] = c3.RHa/c3.EWHa
bins = np.arange(2800, 4601, 100); cent = 0.5*(bins[1:]+bins[:-1]); c3['b'] = np.digitize(c3.Teff, bins)
chi = np.array([c3.loc[c3.b == i, 'chi'].median() for i in range(1, len(bins))])
cm = c2[(c2.Teff > 2800) & (c2.Teff < 4600) & (c2.Mstar > 0.05) & (c2.Mstar < 0.8)]
coef = np.polyfit(cm.Teff, cm.Mstar, 2)
A['chi'] = np.interp(A.teff, cent, chi); A['M'] = np.clip(np.polyval(coef, A.teff.values), 0.08, 0.75)
A['Ro'] = A.P / (10 ** (2.33 - 1.5*A.M - 0.30*A.M**2)); A['RHa'] = A.chi * A.ewha
A['sRo'] = A.Ro*np.sqrt(A.fP**2 + 0.01); A['sRHa'] = np.sqrt((A.chi*A.ewha_err)**2 + (0.1*A.RHa)**2)
A = A[(A.Ro > 0) & (A.RHa > 0)]
A['alias_flag'] = A.uid.isin(alias_uid)
strict = A[(A.non_single_star.fillna(0) == 0) & (~A.alias_flag) & (A.Ro <= 3)]
print('\n严格样本（nss=0 且 非别名 且 Ro≤3）：%d 颗（原 4612）' % len(strict))
def ml(d):
    x, y = np.log10(d.Ro.values), np.log10(d.RHa.values)
    sy = np.maximum(d.sRHa.values/np.maximum(d.RHa.values,1e-12)/np.log(10), 0.02)
    def nll(p):
        lrs, beta, c, lsi = p; si = np.exp(lsi)
        m = np.where(x <= lrs, c, c + beta*(x-lrs)); v = sy**2 + si**2
        return 0.5*np.sum((y-m)**2/v + np.log(v))
    best = None
    for l0 in (-1.0, -0.85, -0.7):
        r = minimize(nll, [l0, -0.7, np.median(y), np.log(0.3)], method='Nelder-Mead', options={'maxiter':5000})
        if best is None or r.fun < best.fun: best = r
    return 10**best.x[0], best.x[1], np.exp(best.x[3])
def ols(d):
    x, y = np.log10(d.Ro.values), np.log10(d.RHa.values); best=None
    for rs in np.linspace(-1.1,-0.4,80):
        s,u = x<=rs, x>rs
        if s.sum()<20 or u.sum()<20: continue
        rss = ((y[s]-y[s].mean())**2).sum(); sl,ic = np.polyfit(x[u],y[u],1); rss += ((y[u]-(sl*x[u]+ic))**2).sum()
        if best is None or rss<best[0]: best=(rss,10**rs,sl)
    return best[1], best[2]
ro1, b1 = ols(strict); ro2, b2, si = ml(strict)
print('严格样本：β(OLS)=%.3f  Ro_sat=%.3f ；β(ML)=%.3f  σ_int=%.2f' % (b1, ro1, b2, si))
rows = [('去别名+ruwe(保留缺值)', 3432, 0.135, -0.749, 0.109, -0.751, 0.502),
        ('nss=0 + VSX-TESS 交叉验证非别名 + Ro<=3', len(strict), ro1, b1, ro2, b2, si)]
t = pd.DataFrame(rows, columns=['样本','n','Ro_sat OLS','β OLS','Ro_sat ML','β ML','σ_int'])
t.to_csv('data/processed/dr13/fig5_robustness_v3.csv', index=False)
print(t.round(3).to_string(index=False))
both.to_csv('data/processed/dr13/fig5_vsx_vs_fetherolf.csv', index=False)
A[['uid','designation','spt','P','src','Ro','RHa','non_single_star','alias_flag']].to_csv(
    'data/processed/dr13/fig5_sample_final.csv', index=False)
print('已存 fig5_robustness_v3.csv / fig5_vsx_vs_fetherolf.csv / fig5_sample_final.csv')
