# -*- coding: utf-8 -*-
# 探查：非饱和段星数 796/180 的口径差异 + bootstrap σ_Δβ
import csv, math, random

BASE = 'C:/Users/lingz/Desktop/复现老师工作/APJS/图五及相关数据'
FN = BASE + '/数据/图5_逐星样本_严格3340行_⑤_tau030.csv'
rows = []
with open(FN, encoding='utf-8-sig') as f:
    for row in csv.DictReader(f):
        rows.append(row)

def panel_of(s):
    if s in ('dM0','dM1','dM2','dM3'): return 'M0-M3'
    if s in ('dM4','dM5','dM6'): return 'M4-M6'
    return 'OTHER'

data = [dict(uid=r['uid'], spt=r['spt'], panel=panel_of(r['spt']),
             Ro=float(r['Ro']), logRo=math.log10(float(r['Ro'])),
             logRHa=math.log10(float(r['RHa']))) for r in rows]

BP = 0.132
print('Ro 在 0.132 附近的星（±0.0005）:')
for p in ('M0-M3','M4-M6'):
    near = [d for d in data if d['panel']==p and abs(d['Ro']-BP) <= 5e-4]
    print(f'  {p}: {len(near)} 颗, Ro 值: {sorted(round(d["Ro"],6) for d in near)}')

print()
for cmp_name, lo_f, hi_f in (
    ('Ro >  bp', lambda d: d['Ro'] >  BP, lambda d: d['Ro'] <= BP),
    ('Ro >= bp', lambda d: d['Ro'] >= BP, lambda d: d['Ro'] <  BP),
):
    print(cmp_name)
    for p in ('M0-M3','M4-M6'):
        nhi = sum(1 for d in data if d['panel']==p and hi_f(d))
        nlo = sum(1 for d in data if d['panel']==p and lo_f(d))
        print(f'  {p}: 非饱和={nhi}  坪区={nlo}')
print('  讨论体: 非饱和 796 / 180 ; 台账坪区 1287 / 1065')
print()

def ols(xs, ys):
    n = len(xs); xm = sum(xs)/n; ym = sum(ys)/n
    sxx = sum((x-xm)**2 for x in xs); sxy = sum((x-xm)*(y-ym) for x,y in zip(xs,ys))
    b = sxy/sxx; a = ym - b*xm
    rss = sum((y-a-b*x)**2 for x,y in zip(xs,ys))
    return a,b,rss

def se_b(xs, ys):
    n=len(xs); xm=sum(xs)/n; sxx=sum((x-xm)**2 for x in xs)
    _,_,rss = ols(xs,ys); return math.sqrt(rss/(n-2)/sxx)

# bootstrap σ_Δβ（固定断点 0.132，400 次）
random.seed(7)
def boot_dbeta(nboot=400):
    dA = [d for d in data if d['panel']=='M0-M3']
    dB = [d for d in data if d['panel']=='M4-M6']
    out = []
    lbp = math.log10(BP)
    for _ in range(nboot):
        sA = [random.choice(dA) for _ in range(len(dA))]
        sB = [random.choice(dB) for _ in range(len(dB))]
        hA = [d for d in sA if d['logRo'] > lbp]
        hB = [d for d in sB if d['logRo'] > lbp]
        if len(hA) < 10 or len(hB) < 10:
            continue
        _,bA,_ = ols([d['logRo'] for d in hA],[d['logRHa'] for d in hA])
        _,bB,_ = ols([d['logRo'] for d in hB],[d['logRHa'] for d in hB])
        out.append(bA-bB)
    out.sort()
    n = len(out)
    med = out[n//2]
    lo = out[int(0.025*n)]; hi = out[int(0.975*n)]
    # 16-84  as 1σ
    return med, lo, hi, (hi-lo)/2/1.96
med, lo, hi, sig = boot_dbeta()
print(f'bootstrap Δβ(固定0.132): 中位={med:.4f}  95%CI=[{lo:.4f},{hi:.4f}]  σ≈{sig:.4f}')
print(f'  讨论体/台账: Δβ=0.068 ± 0.201')

# 单面板 bootstrap SE
def boot_panel_beta(p, nboot=400):
    dP = [d for d in data if d['panel']==p]
    lbp = math.log10(BP)
    out = []
    for _ in range(nboot):
        s = [random.choice(dP) for _ in range(len(dP))]
        h = [d for d in s if d['logRo'] > lbp]
        if len(h) < 10: continue
        _,b,_ = ols([d['logRo'] for d in h],[d['logRHa'] for d in h])
        out.append(b)
    out.sort(); n=len(out)
    return out[n//2], (out[int(0.84*n)]-out[int(0.16*n)])/2
for p in ('M0-M3','M4-M6'):
    m, s = boot_panel_beta(p)
    print(f'  {p} bootstrap: β={m:.4f} ± {s:.4f}  (台账: {"-0.890 ± 0.093" if p=="M0-M3" else "-0.822 ± 0.178"})')
