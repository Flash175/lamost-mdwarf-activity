# -*- coding: utf-8 -*-
"""IB2025 自算周期：出图 + 更新 P_cyc 表注 + 同步"""
import io, os, shutil, sys
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
import numpy as np, pandas as pd
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
W = r'C:\Users\lingz\OneDrive\Desktop\复现老师工作'
D = r'C:\Users\lingz\Desktop\复现老师工作'
A = r'C:\Users\lingz\Desktop\APJS\图五及相关数据'
g = lambda *a: os.path.join(W, *a)
r = pd.read_csv(g('data', 'processed', 'dr13', 'ib2025_periodogram_selfcomputed.csv'))
det = r[r.FAP < 0.05].copy().sort_values('P_yr')
fig, ax = plt.subplots(figsize=(6.6, 5.0))
band = (det.P_yr >= 3) & (det.P_yr <= 19)
ax.axvspan(3, 19, color='#dfe9ff', zorder=0)
ax.text(3.1, 0.4, '3-19 yr (Ibanez Bustos 2025 reported range)', fontsize=7, color='0.35')
y = np.arange(len(det))
ax.scatter(det.P_yr, y, s=32, c=np.where(det.FAP < 0.01, '#1f4fd8', 'white'),
           edgecolor='#1f4fd8', lw=1.0, zorder=3)
ax.errorbar(det.P_yr, y, xerr=np.abs(det.P2_yr - det.P_yr), fmt='none', elinewidth=0.7, ecolor='0.6', zorder=2)
ax.set_yticks(y); ax.set_yticklabels(['%s (N=%d, %.0f yr)' % (s, n, b) for s, n, b in zip(det.star, det.N, det.baseline_yr)], fontsize=7)
ax.set_xscale('log'); ax.set_xlim(1.5, 30)
ax.set_xlabel('P$_{cyc}$ (yr, our Lomb-Scargle recomputation)', fontsize=10)
ax.set_title('Ibanez Bustos et al. (2025) Table B1: 20/22 stars with FAP<0.05\nfilled = FAP<0.01; bars = distance to secondary peak', fontsize=9)
ax.tick_params(direction='in', top=True, right=True, labelsize=8)
ax.grid(alpha=0.25, axis='x', lw=0.4)
fig.text(0.5, 0.012, 'Recomputed from the published time series (2,806 points, 33 stars) with a Lomb-Scargle periodogram (2-25 yr, baseline >= 8 yr).\nThese are OUR estimates, not the values published by the authors.', ha='center', fontsize=6.4, color='0.3', linespacing=1.5)
fig.tight_layout(rect=(0, 0.08, 1, 1))
o = g('figures', 'dr13_figIB2025_cycles.png')
fig.savefig(o, dpi=180); plt.close(fig)
print('  图 ->', o)
for src, tgt in [(o, os.path.join(D, '图', '对照与备选', '附_IB2025_自算周期_FAP.png')),
                 (o, os.path.join(A, '图', '附_IB2025_自算周期_FAP.png')),
                 (g('data', 'processed', 'dr13', 'ib2025_periodogram_selfcomputed.csv'), os.path.join(D, '数据', 'IB2025_时间序列自算周期_22星.csv')),
                 (g('data', 'processed', 'dr13', 'ib2025_periodogram_selfcomputed.csv'), os.path.join(A, '数据', 'IB2025_时间序列自算周期_22星.csv')),
                 (g('data', 'raw', 'ib2025', 'tableb1_time_series.dat'), os.path.join(A, '数据', 'IB2025_TableB1_时间序列.dat')),
                 (g('data', 'raw', 'ib2025', 'sources.dat'), os.path.join(A, '数据', 'IB2025_sources.dat'))]:
    shutil.copy2(src, tgt); print('  同步 ->', tgt.split('\\')[-1])
# GJ 628 对比
row628 = r[r.star.str.replace(' ', '') == 'GJ628'].iloc[0]
row273 = r[r.star.str.replace(' ', '') == 'GJ273'].iloc[0]
print('\n  GJ 628：自算 %.2f yr vs SM2016 4.4 yr，比值 %.2f' % (row628.P_yr, row628.P_yr/4.4))
print('  Gl 273：自算 %.2f yr vs GdS2012 3.5 yr，比值 %.2f' % (row273.P_yr, row273.P_yr/3.5))
src = g('data', 'raw', 'activity_cycle_data_complete.csv')
d = pd.read_csv(src)
m = d.Star.astype(str).str.strip() == 'Gl 273'
d.loc[m, 'Notes'] = 'GdS2012 报 3.5 yr；我们用 IB2025 Table B1 时间序列独立复算得 %.2f yr（FAP=%.2g）——两表一致，但 IB2025 正文未刊该值' % (row273.P_yr, row273.FAP)
m2 = d.Star.astype(str).str.strip() == 'GJ 628'
d.loc[m2, 'Notes'] = 'SM2016 报 4.4 yr；IB2025 时间序列自算 %.2f yr（比值 %.2f）——跨文献不重复的典型例子' % (row628.P_yr, row628.P_yr/4.4)
d.to_csv(src, index=False, encoding='utf-8')
for tgt in (os.path.join(D, '数据', '文献活动周周期_20颗.csv'), os.path.join(A, '数据', '文献活动周周期_20颗.csv')):
    shutil.copy2(src, tgt)
print('  周期表注释已更新并同步')
