
# -*- coding: utf-8 -*-
"""s617：金属度通道的混杂诊断（在 s616 的 2D 样本上）
1) 保存清洁样本；2) [Fe/H] 与亚型/Teff/S_N 的退化；3) 固定亚型+固定 |Z| 的效应；
4) m_h 四分位内的亚型组成；5) 固定效应 logit（亚型+档虚拟变量）
"""
import io, sys, os, json
import numpy as np, pandas as pd
from scipy import stats
from astropy.coordinates import SkyCoord
import astropy.units as u
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
OD = r'C:\Users\lingz\OneDrive\Desktop\复现老师工作\data'
OUTD = r'C:\Users\lingz\Desktop\复现老师工作\APJS\多个图及讨论'
SAMPLE = os.path.join(OUTD, '金属度_清洁样本_637973.csv')

if os.path.exists(SAMPLE):
    d = pd.read_csv(SAMPLE, low_memory=False)
else:
    lam_cols = ['uid','subclass','teff','logg','m_h','m_h_err','ewha','ewha_err','snru','gaia_source_id','gaia_g_mean_mag','ra','dec']
    d = pd.read_csv(os.path.join(OD,'lamost','dr13','dr13_mstellar_dM.csv'), usecols=lam_cols, low_memory=False)
    d = d[(d.ewha > -20) & (d.ewha <= 50) & (d.ewha_err > 0) & (d.ewha_err <= 5)].copy()
    g = pd.read_csv(os.path.join(OD,'gaia','gaia_dr3_mstars.csv'),
                    usecols=['source_id','parallax','parallax_error','ruwe','phot_g_mean_mag'], low_memory=False)
    d = d.merge(g, left_on='gaia_source_id', right_on='source_id', how='inner', suffixes=('','_g'))
    d = d[(d.parallax > 0.2) & (d.parallax/d.parallax_error > 5) & (d.ruwe < 1.4)].copy()
    d = d.sort_values('ewha', ascending=False).drop_duplicates('uid').copy()
    d['MG'] = d.gaia_g_mean_mag.values - 5*np.log10(np.clip(1000.0/d.parallax.values,1,None)) + 5
    d = d[d.MG >= 6].copy()
    d['dist_pc'] = 1000.0/d.parallax.values
    sc = SkyCoord(ra=d.ra.values*u.deg, dec=d.dec.values*u.deg, distance=d.dist_pc.values*u.pc, frame='icrs')
    d['absz'] = np.abs(d.dist_pc.values*np.sin(np.deg2rad(sc.galactic.b.deg)))
    d = d[(d.absz>0)&(d.absz<=3000)].copy()
    d['active'] = ((d.ewha>=0.75)&(d.ewha>3*d.ewha_err)).astype(int)
    E=[0,100,200,400,600,1000,3000]; L=['<100','100-200','200-400','400-600','600-1000','>1000']
    d['zb'] = pd.cut(d.absz, E, labels=L)
    d['mh_ok'] = np.isfinite(d.m_h)&np.isfinite(d.m_h_err)&(d.m_h_err>0)&(d.m_h_err<=0.25)&(d.m_h.between(-2.0,0.6))
    keep = ['uid','subclass','teff','logg','m_h','m_h_err','ewha','ewha_err','snru','gaia_g_mean_mag','MG','dist_pc','absz','zb','active','mh_ok','parallax','ruwe']
    d[keep].to_csv(SAMPLE, index=False)
print('sample', len(d))

sub = d[d.mh_ok & d.subclass.isin(['dM0','dM1','dM2','dM3','dM4','dM5','dM6'])].copy()
print('with usable m_h:', len(sub))

# 1) m_h vs subtype / teff / snr
t1 = sub.groupby('subclass').agg(n=('uid','size'), mh_med=('m_h','median'), teff_med=('teff','median'),
                                 snr_med=('snru','median'), mh_err=('m_h_err','median')).round(3)
print('\n=== m_h by subtype ===\n' + t1.to_string())
t1.reset_index().to_csv(os.path.join(OUTD,'金属度_亚型中位.csv'), index=False, encoding='utf-8-sig')
rows=[]
for st in ['dM0','dM1','dM2','dM3','dM4','dM5','dM6']:
    s = sub[sub.subclass==st]
    r1 = stats.spearmanr(s.m_h, s.teff); r2 = stats.spearmanr(s.m_h, s.snru); r3 = stats.spearmanr(s.m_h, s.m_h_err)
    rows.append(dict(subtype=st, n=len(s), rho_mh_teff=r1[0], rho_mh_snr=r2[0], rho_mh_mherr=r3[0]))
degen = pd.DataFrame(rows).round(3)
print('\n=== degeneracy within subtype ===\n' + degen.to_string())
degen.to_csv(os.path.join(OUTD,'金属度_退化诊断.csv'), index=False, encoding='utf-8-sig')

# 2) fixed subtype x fixed |Z| quartile test (dM2, dM4 as the two best-populated)
rows=[]
for st in ['dM0','dM2','dM4']:
    for lb in ['<100','100-200','200-400']:
        s = sub[(sub.subclass==st)&(sub.zb==lb)]
        if len(s) < 500: continue
        rho, p = stats.spearmanr(s.m_h, s.active)
        q1 = s[s.m_h<=s.m_h.quantile(.25)]; q4 = s[s.m_h>s.m_h.quantile(.75)]
        rows.append(dict(subtype=st, zbin=lb, n=len(s), rho=rho, p=p,
                         frac_q1_pct=100*q1.active.mean(), frac_q4_pct=100*q4.active.mean(),
                         delta_pp=100*(q4.active.mean()-q1.active.mean()),
                         mh_q1=float(q1.m_h.median()), mh_q4=float(q4.m_h.median()),
                         snr_q1=float(q1.snru.median()), snr_q4=float(q4.snru.median())))
fx = pd.DataFrame(rows).round(3)
print('\n=== fixed subtype x fixed |Z| ===\n' + fx.to_string())
fx.to_csv(os.path.join(OUTD,'金属度_固定亚型固定Z.csv'), index=False, encoding='utf-8-sig')

# 3) subtype mix inside m_h quartiles (per |Z| bin)
rows=[]
for lb in ['<100','100-200','200-400']:
    s = sub[sub.zb==lb]
    q = pd.qcut(s.m_h, 4, labels=['Q1','Q2','Q3','Q4'], duplicates='drop')
    for qq in q.cat.categories:
        t = s[q==qq]
        rows.append(dict(zbin=lb, quartile=str(qq), n=len(t), mh_med=float(t.m_h.median()),
                         late_share_pct=100*t.subclass.isin(['dM4','dM5','dM6']).mean(),
                         dM4_share_pct=100*(t.subclass=='dM4').mean(), teff_med=float(t.teff.median()),
                         frac_pct=100*t.active.mean()))
mix = pd.DataFrame(rows).round(3)
print('\n=== subtype mix within [Fe/H] quartiles ===\n' + mix.to_string())
mix.to_csv(os.path.join(OUTD,'金属度_组成混杂.csv'), index=False, encoding='utf-8-sig')

# 4) fixed-effect logit: f ~ m_h + subtype dummies + |Z| dummies (subtype dM0-dM6, |Z|<400 pc)
s = sub[sub.absz<=400].copy()
D1 = pd.get_dummies(s.subclass, drop_first=True).astype(float)
D2 = pd.get_dummies(s.zb, drop_first=True).astype(float)
X = np.column_stack([np.ones(len(s)), s.m_h.values, D1.values, D2.values])
y = s.active.values.astype(float)
b = np.zeros(X.shape[1]); b[0] = np.log(y.mean()/(1-y.mean()))
for _ in range(80):
    p = 1/(1+np.exp(-(X@b))); W = p*(1-p)
    step = np.linalg.solve(X.T@(X*W[:,None]) + 1e-10*np.eye(len(b)), X.T@(y-p)); b = b + step
    if np.max(np.abs(step))<1e-11: break
cov = np.linalg.inv(X.T@(X*(p*(1-p))[:,None])); se = np.sqrt(np.diag(cov))
print('\n=== fixed-effect logit (|Z|<=400 pc, subtype + |Z| dummies) ===')
print('b_mh = %.4f +/- %.4f (z = %.2f)' % (b[1], se[1], b[1]/se[1]))
json.dump(dict(b_mh=float(b[1]), se=float(se[1]), z=float(b[1]/se[1]), n=int(len(s))),
          open(os.path.join(OUTD,'金属度_固定效应logit.json'),'w',encoding='utf-8'), ensure_ascii=False, indent=2)
