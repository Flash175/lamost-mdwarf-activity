# -*- coding: utf-8 -*-
"""s557：§0 的 EW 闸门计数——从全部谱到 639,702 颗的可复现路径。"""
import io, sys
import numpy as np, pandas as pd
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
cat = pd.read_csv('data/lamost/dr13/dr13_mstellar_dM.csv', low_memory=False,
                  usecols=['uid','subclass','teff','ewha','ewha_err','snrr','ra','dec','gaia_source_id'])
print('全部谱（dr13_mstellar_dM.csv 行数）：%d' % len(cat))
print('  唯一 uid：%d' % cat.uid.nunique())
g1 = cat[(cat.ewha > -20) & (cat.ewha <= 50)]
print('EW 闸门 1（-20 < ewha <= 50）：%d 条谱' % len(g1))
g2 = g1[(g1.ewha_err > 0) & (g1.ewha_err <= 5)]
print('EW 闸门 2（0 < ewha_err <= 5）：%d 条谱' % len(g2))
print('  唯一 uid：%d' % g2.uid.nunique())
g2 = g2.copy()
g2['gaia_source_id'] = pd.to_numeric(g2.gaia_source_id, errors='coerce')
ga = pd.read_csv('data/gaia/gaia_dr3_mstars.csv', low_memory=False,
                 usecols=['source_id','parallax','parallax_error','ruwe'])
m = g2.merge(ga, left_on='gaia_source_id', right_on='source_id', how='inner')
print('与 Gaia 交叉匹配：%d 条谱' % len(m))
m = m[(m.parallax > 0.2) & (m.parallax/m.parallax_error > 5) & (m.ruwe < 1.4)]
print('Gaia 闸门（parallax>0.2 mas、>5sigma、ruwe<1.4）：%d 条谱' % len(m))
u = m.sort_values('ewha', ascending=False).drop_duplicates('uid')
print('每星取最大 EW 一条谱：%d 颗' % len(u))
from astropy.coordinates import SkyCoord
import astropy.units as un
d = 1000.0/u.parallax.values
sc = SkyCoord(ra=u.ra.values*un.deg, dec=u.dec.values*un.deg, distance=d*un.pc, frame='icrs')
u = u.assign(absz_pc=np.abs(d*np.sin(np.deg2rad(sc.galactic.b.deg))))
print('|Z| <= 3 kpc：%d 颗（另有 %d 颗被剔除）' % (int((u.absz_pc <= 3000).sum()), int((u.absz_pc > 3000).sum())))
print('s557 完成')
