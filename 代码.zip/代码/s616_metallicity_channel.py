
# -*- coding: utf-8 -*-
"""金属度通道检验（按 金属度效应检验实施方案：步骤 1-3 + 决策点 1 + 简化通道预算）
数据：data/lamost/dr13/dr13_mstellar_dM.csv（m_h = [Fe/H]）+ data/gaia/gaia_dr3_mstars.csv
样本：复现论文 2D 口径（EW 闸门 -> Gaia 视差质量 -> 每 uid 取最大 EW -> M_G>=6 -> |Z|<=3 kpc）
输出：APJS/多个图及讨论/金属度_*.csv + 图/新图6_金属度通道.png
"""
import io, sys, os, json
import numpy as np, pandas as pd
from scipy import stats
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
from astropy.coordinates import SkyCoord
import astropy.units as u

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
OD   = r'C:\Users\lingz\OneDrive\Desktop\复现老师工作\data'
OUTD = r'C:\Users\lingz\Desktop\复现老师工作\APJS\多个图及讨论'
FIGD = r'C:\Users\lingz\Desktop\复现老师工作\APJS\图五及相关数据\图'
os.makedirs(OUTD, exist_ok=True)

lam_cols = ['uid','subclass','teff','logg','m_h','m_h_err','ewha','ewha_err','snru','gaia_source_id','gaia_g_mean_mag','ra','dec']
d = pd.read_csv(os.path.join(OD,'lamost','dr13','dr13_mstellar_dM.csv'), usecols=lam_cols, low_memory=False)
print('catalogue rows', len(d))
d = d[(d.ewha > -20) & (d.ewha <= 50) & (d.ewha_err > 0) & (d.ewha_err <= 5)].copy()
print('after EW gate', len(d), 'uid', d.uid.nunique())

g = pd.read_csv(os.path.join(OD,'gaia','gaia_dr3_mstars.csv'),
                usecols=['source_id','parallax','parallax_error','ruwe','phot_g_mean_mag','radial_velocity'], low_memory=False)
d = d.merge(g, left_on='gaia_source_id', right_on='source_id', how='inner', suffixes=('','_g'))
print('after Gaia join', len(d))
ok = (d.parallax > 0.2) & (d.parallax/d.parallax_error > 5) & (d.ruwe < 1.4)
d = d[ok].copy()
d = d.sort_values('ewha', ascending=False).drop_duplicates('uid').copy()
print('after quality+dedupe', len(d))
d['MG'] = d.gaia_g_mean_mag.values - 5*np.log10(np.clip(1000.0/d.parallax.values, 1, None)) + 5
d = d[d.MG >= 6].copy()
d['dist_pc'] = 1000.0/d.parallax.values
sc = SkyCoord(ra=d.ra.values*u.deg, dec=d.dec.values*u.deg, distance=d.dist_pc.values*u.pc, frame='icrs')
d['absz'] = np.abs(d.dist_pc.values*np.sin(np.deg2rad(sc.galactic.b.deg)))
d = d[(d.absz > 0) & (d.absz <= 3000)].copy()
d['active'] = ((d.ewha >= 0.75) & (d.ewha > 3*d.ewha_err)).astype(int)
print('2D sample', len(d), 'active', int(d.active.sum()), 'frac %', round(100*d.active.mean(),3))

E = [0,100,200,400,600,1000,3000]; L = ['<100','100-200','200-400','400-600','600-1000','>1000']
d['zb'] = pd.cut(d.absz, E, labels=L)
print('\nbin check:'); print(d.groupby('zb', observed=True).agg(n=('uid','size'), act=('active','mean')).assign(frac=lambda x: 100*x.act).round(3).to_string())

# ---------- 金属度覆盖 ----------
d['mh_ok'] = np.isfinite(d.m_h) & np.isfinite(d.m_h_err) & (d.m_h_err > 0) & (d.m_h_err <= 0.25) & (d.m_h.between(-2.0, 0.6))
cov = d.groupby('zb', observed=True).agg(n=('uid','size'), n_mh=('mh_ok','sum'), n_act=('active','sum'))
cov['cov_pct'] = 100*cov.n_mh/cov.n
cov['mh_med'] = d[d.mh_ok].groupby('zb', observed=True).m_h.median()
cov['mh_err_med'] = d[d.mh_ok].groupby('zb', observed=True).m_h_err.median()
cov['act_all_pct'] = 100*d.groupby('zb', observed=True).active.mean()
cov['act_mh_pct'] = 100*d[d.mh_ok].groupby('zb', observed=True).active.mean()
cov.reset_index().to_csv(os.path.join(OUTD,'金属度_样本与覆盖.csv'), index=False, encoding='utf-8-sig')
print('\n=== coverage ==='); print(cov.round(3).to_string())
print('overall m_h coverage %', round(100*d.mh_ok.mean(),2), '| median m_h_err', round(float(d.m_h_err[d.mh_ok].median()),3))

# ---------- 垂直梯度 ----------
sub = d[d.mh_ok]
rng = np.random.default_rng(20261108)
rows=[]
for lb in L:
    s = sub[sub.zb==lb]
    if len(s) < 50: continue
    med = float(s.m_h.median()); bs=[]
    for _ in range(200):
        bs.append(np.median(rng.choice(s.m_h.values, len(s), replace=True)))
    rows.append(dict(zbin=lb, n=len(s), mh_med=med, lo=float(np.percentile(bs,16)), hi=float(np.percentile(bs,84)),
                     z_med=float(s.absz.median()), snr_med=float(s.snru.median()), teff_med=float(s.teff.median())))
grad = pd.DataFrame(rows)
sl, ic, r_, p_, se_ = stats.linregress(sub.absz.values, sub.m_h.values)
grad.attrs={}
grad.to_csv(os.path.join(OUTD,'金属度_垂直梯度.csv'), index=False, encoding='utf-8-sig')
print('\n=== gradient ==='); print(grad.round(3).to_string())
print('linear fit dm_h/dz = %.5f dex/pc (se %.5f, r=%.3f, p=%.2e)' % (sl, se_, r_, p_))

# ---------- 固定 |Z| 下的金属度效应 ----------
rows=[]
for lb in ['<100','100-200','200-400','400-600','600-1000']:
    s = sub[sub.zb==lb]
    if len(s) < 200: continue
    q = pd.qcut(s.m_h, 4, labels=['Q1','Q2','Q3','Q4'], duplicates='drop')
    for qq in q.cat.categories:
        t = s[q==qq]
        k=int(t.active.sum()); n=len(t); p=k/n
        w = 1.96*np.sqrt(p*(1-p)/n)
        rows.append(dict(zbin=lb, quartile=str(qq), n=n, n_act=k, frac_pct=100*p, wilson_lo=100*max(0,p-w), wilson_hi=100*min(1,p+w),
                         mh_med=float(t.m_h.median())))
    rho, pval = stats.spearmanr(s.m_h.values, s.active.values)
    rows.append(dict(zbin=lb, quartile='spearman', n=len(s), n_act=int(s.active.sum()), frac_pct=100*s.active.mean(),
                     wilson_lo=np.nan, wilson_hi=np.nan, mh_med=np.nan))
    print('bin %-9s rho=%.3f p=%.2e  Q1 %.2f%% Q4 %.2f%%  d=%.2f pp' % (lb, rho, pval,
          100*s[s.m_h<=s.m_h.quantile(.25)].active.mean(), 100*s[s.m_h>s.m_h.quantile(.75)].active.mean(),
          100*(s[s.m_h>s.m_h.quantile(.75)].active.mean()-s[s.m_h<=s.m_h.quantile(.25)].active.mean())))
fx = pd.DataFrame(rows)
fx.to_csv(os.path.join(OUTD,'金属度_固定Z活动率.csv'), index=False, encoding='utf-8-sig')

# 逐亚型
rows=[]
for st in ['dM0','dM1','dM2','dM3','dM4','dM5','dM6']:
    s = sub[(sub.subclass==st) & (sub.absz<=400)]
    if len(s) < 200: continue
    rho, pval = stats.spearmanr(s.m_h.values, s.active.values)
    q1 = s[s.m_h<=s.m_h.quantile(.25)]; q4 = s[s.m_h>s.m_h.quantile(.75)]
    rows.append(dict(subtype=st, n=len(s), rho=rho, p=pval, frac_lo_pct=100*q1.active.mean(), frac_hi_pct=100*q4.active.mean(),
                     delta_pp=100*(q4.active.mean()-q1.active.mean()), mh_span=float(q4.m_h.median()-q1.m_h.median())))
sy = pd.DataFrame(rows)
sy.to_csv(os.path.join(OUTD,'金属度_亚型依赖.csv'), index=False, encoding='utf-8-sig')
print('\n=== by subtype (|Z|<=400 pc) ==='); print(sy.round(3).to_string())

# ---------- 简化通道预算：金属度能解释多少下降 ----------
s400 = sub[sub.absz<=400]
# 逻辑回归（单变量 m_h，控制 |Z| 用分档虚拟变量）用 IRLS
X = pd.get_dummies(s400.zb, drop_first=True).astype(float).values
X = np.column_stack([np.ones(len(s400)), s400.m_h.values, X])
y = s400.active.values.astype(float)
b = np.zeros(X.shape[1]); b[0] = np.log(y.mean()/(1-y.mean()))
for _ in range(60):
    eta = X@b; p = 1/(1+np.exp(-eta)); W = p*(1-p)
    H = X.T@(X*W[:,None]); gvec = X.T@(y-p)
    step = np.linalg.solve(H + 1e-9*np.eye(len(b)), gvec); b = b + step
    if np.max(np.abs(step)) < 1e-10: break
se = np.sqrt(np.diag(np.linalg.inv(X.T@(X*(p*(1-p))[:,None]))))
print('\nlogit: intercept %.3f (se %.3f), b_mh %.4f (se %.4f, z=%.2f), bin dummies %s' % (b[0], se[0], b[1], se[1], b[1]/se[1], np.round(b[2:],3)))
med_mh = float(sub.m_h.median())
def frac_pred(mh, zb):
    x = [1.0, mh] + [1.0 if lb==zb else 0.0 for lb in ['100-200','200-400','400-600','600-1000']]
    return 1/(1+np.exp(-np.dot(x, b)))
rows=[]
for lb in ['<100','100-200','200-400']:
    mh_here = float(sub[sub.zb==lb].m_h.median())
    f_ref = frac_pred(med_mh, lb); f_here = frac_pred(mh_here, lb)
    rows.append(dict(zbin=lb, mh_med=mh_here, mh_shift_vs_median=mh_here-med_mh,
                     frac_at_median_mh_pct=100*f_ref, frac_at_bin_mh_pct=100*f_here,
                     delta_pp=100*(f_here-f_ref)))
bud = pd.DataFrame(rows)
obs_decline = 100*(sub[sub.zb=='<100'].active.mean() - sub[sub.zb=='200-400'].active.mean())
bud.to_csv(os.path.join(OUTD,'金属度_通道预算.csv'), index=False, encoding='utf-8-sig')
print('\n=== budget ==='); print(bud.round(3).to_string())
print('observed decline <100 -> 200-400 pc: %.2f pp' % obs_decline)
print('metallicity channel (linear-logit approx): %.2f pp' % float(bud.delta_pp.iloc[-1]))

# ---------- 图 ----------
fig, ax = plt.subplots(1, 3, figsize=(13.2, 4.0))
x1 = np.arange(len(grad))
ax[0].errorbar(x1, grad.mh_med, yerr=[grad.mh_med-grad.lo, grad.hi-grad.mh_med], fmt='o-', color='#7b3294', ms=6, capsize=3)
for i, r in grad.iterrows(): ax[0].text(i, r.hi+0.01, '%d' % r.n, ha='center', fontsize=7)
ax[0].set_xticks(x1); ax[0].set_xticklabels(grad.zbin, fontsize=8)
ax[0].set_xlabel('|Z|  (pc)'); ax[0].set_ylabel('[Fe/H]  (dex, median)')
ax[0].set_title('[Fe/H] versus |Z|  (dm_h/dz = %.5f dex/pc)' % sl, fontsize=9)
b2 = fx[fx.quartile!='spearman']
for lb, c in zip(['<100','100-200','200-400','400-600','600-1000'], ['#c0392b','#e08a7f','#bdc3c7','#95a5a6','#7f8c8d']):
    t = b2[b2.zbin==lb]
    if len(t): ax[1].plot(np.arange(len(t)), t.frac_pct, 'o-', color=c, ms=5, lw=1.2, label=lb)
ax[1].set_xticks(range(4)); ax[1].set_xticklabels(['Q1','Q2','Q3','Q4'], fontsize=8)
ax[1].set_xlabel('[Fe/H] quartile'); ax[1].set_ylabel('Active fraction (%)')
ax[1].set_title('Activity versus [Fe/H] at fixed |Z|', fontsize=9); ax[1].legend(fontsize=7, title='|Z| (pc)', title_fontsize=7)
ax[2].bar(np.arange(len(bud)), bud.delta_pp, color='#2c3e50', width=0.55)
for i, r in bud.iterrows(): ax[2].text(i, r.delta_pp + (0.15 if r.delta_pp>=0 else -0.35), '%.2f pp' % r.delta_pp, ha='center', fontsize=7)
ax[2].axhline(0, color='k', lw=0.8)
ax[2].set_xticks(np.arange(len(bud))); ax[2].set_xticklabels(bud.zbin, fontsize=8)
ax[2].set_ylabel('predicted effect (pp)')
ax[2].set_title('Metallicity-only contribution\n(observed decline <100 to 200-400 pc: %.1f pp)' % obs_decline, fontsize=9)
plt.tight_layout(); plt.savefig(os.path.join(FIGD,'新图6_金属度通道.png'), dpi=200); plt.close()
print('\nfigure written')

# ---------- 决策点 1 ----------
crit = dict(
  gradient_significant = bool(p_ < 0.01 and abs(sl) > 0),
  fixed_z_effect_significant = bool(np.nanmin([stats.spearmanr(sub[sub.zb==lb].m_h, sub[sub.zb==lb].active)[1] for lb in ['<100','100-200','200-400']]) < 0.01),
  budget_material = bool(abs(float(bud.delta_pp.iloc[-1])) >= 3.0),
  logistic_significant = bool(abs(b[1]/se[1]) > 3),
)
json.dump(crit, open(os.path.join(OUTD,'金属度_决策点.json'),'w',encoding='utf-8'), ensure_ascii=False, indent=2)
print('\n=== decision point ===', crit, '| met', sum(crit.values()), 'of 4')
print('sample size for m_h analysis:', int(d.mh_ok.sum()))
