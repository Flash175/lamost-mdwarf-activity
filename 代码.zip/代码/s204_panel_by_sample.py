# -*- coding: utf-8 -*-
"""分面板 β 在六种样本口径下的复算表（含 bootstrap 误差与清洗项标记）"""
import io, os, sys
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
import numpy as np, pandas as pd
from scipy.optimize import minimize
P = lambda f: os.path.join('data', 'processed', 'dr13', f)
A = pd.read_csv(P('fig5_sample_period_v4.csv'))
A = A[(A.Ro > 0) & (A.RHa > 0)]
A['alias_flag'] = A.alias_flag.fillna(False).astype(str).str.lower().isin(['true', '1', '1.0'])
A['border34'] = A.border34.fillna(False).astype(bool)
def dealias(d):
    m = np.ones(len(d), bool)
    for t in (0.5, 1.0, 2.0): m &= ~(np.abs(d.P.values/t - 1) < 0.05)
    return d[m]
def ols(d):
    x, y = np.log10(d.Ro.values), np.log10(d.RHa.values); best = None
    for rs in np.linspace(-1.1, -0.4, 401):
        s, u = x <= rs, x > rs
        if s.sum() < 20 or u.sum() < 20: continue
        rss = ((y[s]-y[s].mean())**2).sum(); sl, ic = np.polyfit(x[u], y[u], 1)
        rss += ((y[u]-(sl*x[u]+ic))**2).sum()
        if best is None or rss < best[0]: best = (rss, 10**rs, sl)
    return best[1], best[2]
def boot(d, n=200, seed=20261017):
    rng = np.random.default_rng(seed); o = []
    for _ in range(n):
        q = d.iloc[rng.integers(0, len(d), len(d))]
        try: o.append(ols(q)[1])
        except Exception: pass
    return float(np.std(o))
D = dealias(A)
ru = D[(D.ruwe.isna()) | (D.ruwe < 1.4)]
V = [('① 4,612 原始周期样本', '无附加筛选', A),
     ('① 4,612 + Ro<=3（版本 A / s174）', '仅 Ro<=3', A[A.Ro <= 3]),
     ('② 4,234 去别名', '无其他清洗', D),
     ('② 4,234 去别名 + Ro<=3', '去别名;Ro<=3', D[D.Ro <= 3]),
     ('③ 3,432 + ruwe<1.4', '去别名;ruwe;Ro<=3', ru[ru.Ro <= 3]),
     ('⑤′ 4,114（+nss=0+交叉验证别名+Ro<=3）', '去别名;nss=0;Ro<=3', pd.read_csv(P('fig5_sample_relaxed_v4.csv'))),
     ('⑤ 3,340 严格（终版图 5）', '去别名;nss=0;ruwe;去M3/M4边界;Ro<=3', pd.read_csv(P('fig5_sample_strict_v4.csv')))]
rows = []
for nm, cuts, d in V:
    r1 = {}
    for tag, sel in (('M0M3', ['dM0','dM1','dM2','dM3']), ('M4M6', ['dM4','dM5','dM6'])):
        q = d[d.spt.isin(sel)]; ro, b = ols(q)
        r1[tag] = (len(q), b, boot(q))
    ro, b = ols(d)
    rows.append(dict(口径=nm, 清洗项=cuts,
                     n_M0M3=r1['M0M3'][0], beta_M0M3=r1['M0M3'][1], beta_M0M3_boot=r1['M0M3'][2],
                     n_M4M6=r1['M4M6'][0], beta_M4M6=r1['M4M6'][1], beta_M4M6_boot=r1['M4M6'][2],
                     n_all=len(d), beta_all=b))
t = pd.DataFrame(rows)
t.to_csv(P('fig5_panel_by_sample_v4.csv'), index=False)
print(t.round(3).to_string(index=False))
print('\n已存 data/processed/dr13/fig5_panel_by_sample_v4.csv')
