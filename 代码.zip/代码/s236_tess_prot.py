# -*- coding: utf-8 -*-
"""给缺 P_rot 的 IB2025 星取 TESS 光变曲线并自算自转周期（astropy LombScargle）"""
import io, os, sys, time, json, warnings
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
warnings.filterwarnings('ignore')
import numpy as np, pandas as pd, requests
from astropy.io import fits
from astropy.timeseries import LombScargle
W = 'https://mast.stsci.edu/api/v0/invoke'
os.makedirs('data/raw/tess_lc', exist_ok=True)
S = pd.read_csv('data/processed/dr13/ib2025_ztf_periods.csv')       # has ra/dec
Z = pd.read_csv('data/processed/dr13/ib2025_stars_with_prot.csv')
Z['key'] = Z.star.str.replace(' ', '').str.upper(); S['key'] = S.star.str.replace(' ', '').str.upper()
S = S.merge(Z[['key', 'P_rot']], on='key', how='left')
todo = S[S.P_rot.isna()].head(14)
print('本轮处理 %d 颗（缺 P_rot）：%s' % (len(todo), ', '.join(todo.star)))
rows = []
for _, st in todo.iterrows():
    req = {'service': 'Mast.Caom.Cone', 'params': {'ra': st.ra, 'dec': st.dec, 'radius': 0.008},
           'format': 'json', 'pagesize': 200}
    try:
        r = requests.post(W, data={'request': json.dumps(req)}, timeout=90)
        data = r.json().get('data', [])
    except Exception as e:
        print('   %-10s MAST 查询失败 %s' % (st.star, type(e).__name__)); continue
    rows_ok = [d for d in data if d.get('obs_collection') == 'TESS' and d.get('dataproduct_type') == 'timeseries'
               and d.get('productSubGroupDescription') == 'LC']
    if not rows_ok:
        print('   %-10s 无 TESS LC' % st.star); continue
    rows_ok.sort(key=lambda d: (-(d.get('t_exptime') or 0), -(d.get('t_min') or 0)))
    best = rows_ok[0]
    uri = 'mast:TESS/product/' + best['productFilename']
    local = os.path.join('data/raw/tess_lc', best['productFilename'])
    if not os.path.exists(local):
        try:
            rr = requests.get('https://mast.stsci.edu/api/v0.1/Download/file?uri=' + uri, timeout=180)
            if rr.status_code != 200: print('   %-10s 下载失败 %s' % (st.star, rr.status_code)); continue
            open(local, 'wb').write(rr.content)
        except Exception as e:
            print('   %-10s 下载异常 %s' % (st.star, type(e).__name__)); continue
    try:
        h = fits.open(local)
        d = h[1].data
        t = np.asarray(d['TIME'], float); f = np.asarray(d['PDCSAP_FLUX'], float)
        q = np.asarray(d['QUALITY'], int) if 'QUALITY' in d.names else np.zeros(len(t), int)
        good = np.isfinite(t) & np.isfinite(f) & (q == 0)
        t, f = t[good], f[good]
        if len(t) < 200: print('   %-10s 有效点太少 %d' % (st.star, len(t))); continue
        med = np.median(f); f = f/med - 1.0
        f = f - np.polyval(np.polyfit(t, f, 2), t)      # 去慢变趋势
        freq = np.linspace(1/100.0, 1/0.2, 60000)
        ls = LombScargle(t, f, fit_mean=True)
        power = ls.power(2*np.pi*freq)
        i = int(np.argmax(power)); P = 1/freq[i]; pk = float(power[i])
        fap = float(ls.false_alarm_probability(pk, method='baluev'))
        rows.append(dict(star=st.star, P_tess=round(P, 4), power=round(pk, 3), FAP=fap, N=len(t),
                         sector=best.get('sequence_number'), exptime=best.get('t_exptime'), file=best['productFilename']))
        print('   %-10s P=%.3f d  power=%.3f  FAP=%.2g  N=%d  sector=%s' % (st.star, P, pk, fap, len(t), best.get('sequence_number')))
    except Exception as e:
        print('   %-10s 解析失败 %s' % (st.star, type(e).__name__))
T = pd.DataFrame(rows)
T.to_csv('data/processed/dr13/ib2025_tess_prot_selfcomputed.csv', index=False)
print('\n成功 %d 颗；FAP<0.01 的 %d 颗' % (len(T), int((T.FAP < 0.01).sum()) if len(T) else 0))
