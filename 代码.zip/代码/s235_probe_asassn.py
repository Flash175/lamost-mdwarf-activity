# -*- coding: utf-8 -*-
"""探测 VizieR 中可用于亮 M 矮星的周期源：ASAS-SN 变星表等"""
import io, sys
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
import requests
TAP = 'https://tapvizier.cds.unistra.fr/TAPVizieR/tap/sync'
H = {'User-Agent': 'repro-mstars/1.0'}
def q(adql, n=12):
    r = requests.post(TAP, data={'REQUEST': 'doQuery', 'LANG': 'ADQL', 'FORMAT': 'csv', 'QUERY': adql}, timeout=120, headers=H)
    if r.status_code != 200: return None, r.status_code
    return r.text.strip().splitlines(), 200
for pat in ("%ASAS%", "%ASAS-SN%"):
    lines, st = q("SELECT TOP 12 table_name FROM TAP_SCHEMA.tables WHERE table_name LIKE '%s'" % pat)
    print('模式 %-12s 状态 %s' % (pat, st))
    if lines:
        for l in lines[1:]: print('   ', l)
# 候选：ASAS-SN 变星表 J/A+A/628/A76 是否有 Period 列
for tbl in ('"J/A+A/628/A76/catalog"', '"J/A+A/626/A107/catalog"', '"J/A+A/628/A76/asas-sn"'): 
    try:
        r = requests.post(TAP, data={'REQUEST': 'doQuery', 'LANG': 'ADQL', 'FORMAT': 'csv',
                                     'QUERY': 'SELECT TOP 1 * FROM %s' % tbl}, timeout=60, headers=H)
        print('  %-28s -> %s  %r' % (tbl, r.status_code, r.text[:120].replace('\n', ' ')))
    except Exception as e:
        print('  %-28s -> 异常 %s' % (tbl, type(e).__name__))
