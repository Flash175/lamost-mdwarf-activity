# -*- coding: utf-8 -*-
"""s584：把 ln f = a + b·z 从「3 档中位点」升级为「逐星二项 GLM」

动机：s564 用三档中位 |Z| 做未加权直线拟合，χ² = 470（dof = 1），残差是二项误差的 20 倍以上，
且只有 1 个自由度，参数误差被压到 ±1.5 pc（名义），既无法检验函数形式，也无法给外推区间。

本脚本改变的是「拟合函数」本身，不再二次利用中位点：
 1) 逐星（逐格）二项似然，log 连接：ln f = Xβ，f 为活动星比例；
 2) 候选形式：M0 常数 / M1 指数 a+b·z / M2 二次 a+b·z+c·z² /
    M3 指数+亚型固定效应 / M4 二次+亚型固定效应 / M5 分段线性（7 节点，无形式假设）；
 3) 用 AIC/BIC 与偏差（deviance）比形式，用 Hessian 给参数真误差，H = −1/b 用 delta 法给区间；
 4) 留出外推改为「对内盘星的逐星预测取平均」，避免中位点替代整档带来 ±1.4% 的系统偏差。

输入：data/lamost/dr13/dr13_mstellar_dM.csv + data/gaia/gaia_dr3_mstars.csv（口径与 s551 完全相同）
输出：多个图及讨论/lnf_fit_models.csv、lnf_holdout_starlevel.csv
"""
import io, sys, os
import numpy as np, pandas as pd
from scipy.optimize import minimize
from astropy.coordinates import SkyCoord, Galactic
import astropy.units as un

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
OUT = r'C:\Users\lingz\Desktop\复现老师工作\APJS\多个图及讨论'
CAT = 'data/lamost/dr13/dr13_mstellar_dM.csv'
GAI = 'data/gaia/gaia_dr3_mstars.csv'

def save(df, name, comments):
    fp = os.path.join(OUT, name)
    df.to_csv(fp, index=False, encoding='utf-8')
    txt = open(fp, encoding='utf-8').read()
    with open(fp, 'w', encoding='utf-8-sig') as f:
        f.write('\n'.join('# ' + c for c in comments) + '\n' + txt)
    print('  写出 %s（%d 行）' % (name, len(df)))

cat = pd.read_csv(CAT, low_memory=False,
                  usecols=['uid','subclass','teff','logg','ewha','ewha_err','snrr',
                           'ra','dec','gaia_source_id','gaia_g_mean_mag','class'])
cat = cat[(cat.ewha > -20) & (cat.ewha <= 50) & (cat.ewha_err > 0) & (cat.ewha_err <= 5)].copy()
cat['active'] = (cat.ewha >= 0.75) & (cat.ewha > 3*cat.ewha_err)
cat['gaia_source_id'] = pd.to_numeric(cat.gaia_source_id, errors='coerce')
g = pd.read_csv(GAI, low_memory=False,
                usecols=['source_id','parallax','parallax_error','ruwe'])
m = cat.merge(g, left_on='gaia_source_id', right_on='source_id', how='inner')
m = m[(m.parallax > 0.2) & (m.parallax/m.parallax_error > 5) & (m.ruwe < 1.4)].copy()
u = m.sort_values('ewha', ascending=False).drop_duplicates('uid').copy()
u['MG'] = u.gaia_g_mean_mag.values - 5*np.log10(np.clip(1000.0/u.parallax.values, 1, None)) + 5
u = u[u.MG >= 6].copy()
d_pc = 1000.0/u.parallax.values
sc = SkyCoord(ra=u.ra.values*un.deg, dec=u.dec.values*un.deg, distance=d_pc*un.pc, frame='icrs')
u['absz_pc'] = np.abs(d_pc*np.sin(np.deg2rad(sc.galactic.b.deg)))
u = u[u.absz_pc <= 3000].copy()
N = len(u)
print('2D 样本：%d 颗（与 s551 同口径）' % N)
print('  合并活动率 %.3f%%' % (100*u.active.mean()))

# 聚合到 (亚型, 5 pc 格)：对 log 连接的二项模型是充分统计量
u['zcell'] = (u.absz_pc // 5).astype(int)
u['subc'] = u.subclass.astype(str)
cell = u.groupby(['subc','zcell'], observed=True).agg(n=('active','size'), k=('active','sum'),
                                                      z=('absz_pc','mean')).reset_index()
cell['z'] = u.groupby(['subc','zcell'], observed=True).absz_pc.mean().values
print('  聚合后 %d 个 (亚型,5pc) 格' % len(cell))

subs = sorted(u.subc.unique())
print('  亚型:', subs)

def design(cell, form, subs_use):
    z = cell.z.values/1000.0            # 用 kpc 作单位，b 的量纲改为 /kpc
    cols = [np.ones_like(z)]
    names = ['a']
    if form in ('exp','quad','exp_sub','quad_sub','exp_sub_int'):
        cols.append(z); names.append('b_kpc')
    if form in ('quad','quad_sub'):
        cols.append(z*z); names.append('c_kpc2')
    if form in ('exp_sub','quad_sub','exp_sub_int'):
        for s in subs_use[1:]:
            cols.append((cell['subc'].values == s).astype(float)); names.append('fe_'+s)
    if form == 'exp_sub_int':
        for s in subs_use[1:]:
            cols.append(z*(cell['subc'].values == s).astype(float)); names.append('zx_'+s)
    if form in ('spline','spline_sub'):
        cols.append(z); names.append('b_kpc')
        for i, k0 in enumerate(np.array([0.05, 0.1, 0.2, 0.4, 0.6, 1.0])):
            cols.append(np.clip(z-k0, 0, None)); names.append('h%d' % i)
    if form == 'spline_sub':
        for s in subs_use[1:]:
            cols.append((cell['subc'].values == s).astype(float)); names.append('fe_'+s)
    return np.vstack(cols).T, names

def nll_grad(beta, X, n, k, ridge=0.0):
    eta = np.clip(X @ beta, -30, 30)
    p = np.exp(eta)
    p = np.clip(p, 1e-12, 1-1e-12)
    ll = (k*np.log(p) + (n-k)*np.log1p(-p)).sum()
    # d ll/d beta = X' (k - n p)
    gr = X.T @ (k - n*p)
    grad = -gr
    # Hessian: -X' diag(n p) X
    return -ll, grad

def fit(X, n, k, beta0=None):
    p0 = beta0 if beta0 is not None else np.zeros(X.shape[1])
    # 起点用 logit 线性解附近
    p0 = np.where(np.abs(p0) < 1e-9, 0.0, p0)
    if beta0 is None:
        p0[0] = np.log(max(k.sum()/n.sum(), 1e-6))
    res = minimize(lambda b: nll_grad(b, X, n, k)[0], p0, method='BFGS',
                   jac=lambda b: nll_grad(b, X, n, k)[1],
                   options=dict(maxiter=4000, gtol=1e-10))
    return res

def hess_se(beta, X, n, k, h=1e-5):
    P = len(beta)
    Hm = np.zeros((P,P))
    gr0 = nll_grad(beta, X, n, k)[1]
    for i in range(P):
        d = np.zeros(P); d[i] = h
        gr1 = nll_grad(beta+d, X, n, k)[1]
        Hm[:, i] = (gr1-gr0)/h
    Hm = 0.5*(Hm+Hm.T)
    C = np.linalg.pinv(Hm)
    return np.sqrt(np.clip(np.diag(C), 0, None)), C

rows = []
coef_rows = []
fits = {}
for form, tag, np_ in [('const','M0 常数',1), ('exp','M1 指数 a+b·z',2), ('quad','M2 二次 a+b·z+c·z²',3),
                       ('exp_sub','M3 指数+亚型FE',2+len(subs)-1), ('quad_sub','M4 二次+亚型FE',3+len(subs)-1),
                       ('spline','M5 分段线性(7 节点)',7),
                       ('exp_sub_int','M6 指数+亚型FE+亚型×z',2+2*(len(subs)-1)),
                       ('spline_sub','M7 分段线性+亚型FE',7+len(subs)-1)]:
    X, names = design(cell, form, subs)
    r = fit(X, cell.n.values.astype(float), cell.k.values.astype(float))
    beta = r.x
    se, C = hess_se(beta, X, cell.n.values.astype(float), cell.k.values.astype(float))
    nll = r.fun
    aic = 2*len(beta) + 2*nll
    bic = len(beta)*np.log(N) + 2*nll
    nn_ = cell.n.values.astype(float); kk_ = cell.k.values.astype(float)
    pp_ = kk_/nn_
    with np.errstate(divide='ignore', invalid='ignore'):
        t1 = np.where(kk_ > 0, kk_*np.log(np.where(kk_ > 0, pp_, 1.0)), 0.0)
        qq_ = 1-pp_
        t2 = np.where(nn_-kk_ > 0, (nn_-kk_)*np.log(np.where(nn_-kk_ > 0, qq_, 1.0)), 0.0)
    sat_ = float((t1+t2).sum())
    dev = 2*(sat_ + nll)
    fits[form] = (beta, se, names, X)
    from scipy.stats import chi2 as _chi2
    dof_ = len(cell)-len(beta)
    pv = float(_chi2.sf(max(dev, 0), dof_))
    print('\n%-16s nll = %.1f  AIC = %.1f  BIC = %.1f  偏差 = %.1f / dof %d = %.2f  (p = %.1e)'
          % (tag, nll, aic, bic, dev, dof_, dev/dof_, pv))
    start_ = len(coef_rows)
    for nm, b_, s_ in zip(names, beta, se):
        print('    %-10s %+9.5f ± %.5f' % (nm, b_, s_))
        coef_rows.append(dict(model=tag, region='all', param=nm, coef=b_, se=s_, H_pc='', H_se=''))
    if 'b_kpc' in names:
        i = names.index('b_kpc')
        Hk = -1.0/beta[i]; sH = abs(se[i]/beta[i]**2)
        print('    → 尺度高 H = %.1f ± %.1f pc（逐星二项误差口径）' % (1000*Hk, 1000*sH))
        coef_rows[start_ + i]['H_pc'] = round(1000*Hk, 1)
        coef_rows[start_ + i]['H_se'] = round(1000*sH, 1)
    rows.append(dict(model=tag, n_par=len(beta), nll=nll, aic=aic, bic=bic, deviance=dev,
                     dof=len(cell)-len(beta)))
save(pd.DataFrame(rows), 'lnf_fit_models.csv', [
    's584：ln f 的活动率–|Z| 拟合形式比较（逐星二项似然，log 连接，聚合到 亚型×5pc 格）',
    '模型：M0 常数 / M1 a+b·z / M2 a+b·z+c·z² / M3 指数+亚型FE / M4 二次+亚型FE / M5 分段线性7节点',
    'nll 为负二项对数似然；饱和模型 nll = 0；AIC = 2k+2nll；BIC = k·ln(N_stars)+2nll',
    'z 以 kpc 为单位；H = −1/b 换算为 pc 见 lnf_fit_coefs.csv（本表只存 nll/AIC/BIC/deviance）',
    '生成脚本：代码/s584_starlevel_logit_z.py'])

# 留出外推：内盘（<400 pc）拟合 → 外盘逐星预测平均
inner = cell[cell.z < 400]
outer_bins = [(400,600,'400-600'), (600,1000,'600-1000'), (1000,3000,'>1000')]
hrows = []
for form, tag in [('exp','M1 指数'), ('quad','M2 二次'), ('exp_sub','M3 指数+亚型FE'),
                  ('exp_sub_int','M6 亚型FE+亚型×z'), ('spline','M5 分段线性'),
                  ('spline_sub','M7 分段线性+亚型FE')]:
    X, names = design(inner, form, subs)
    r = fit(X, inner.n.values.astype(float), inner.k.values.astype(float))
    beta = r.x
    se, C = hess_se(beta, X, inner.n.values.astype(float), inner.k.values.astype(float))
    for lo_, hi_, nm in outer_bins:
        s = u[(u.absz_pc > lo_) & (u.absz_pc <= hi_)]
        Xo, _ = design(pd.DataFrame({'z': s.absz_pc.values, 'subc': s.subc.values}), form, subs)
        p = np.exp(np.clip(Xo @ beta, -30, 30))
        pred = 100*p.mean()
        meas = 100*s.active.mean()
        hrows.append(dict(model=tag, zbin=nm, n=len(s), pred=pred, meas=meas, ratio=meas/pred))
        print('  %-12s %-9s n=%6d  pred=%.2f%%  meas=%.2f%%  比值 %.2f' % (tag, nm, len(s), pred, meas, meas/pred))
    nn_i = inner.n.values.astype(float); kk_i = inner.k.values.astype(float)
    pp_i = kk_i/nn_i
    with np.errstate(divide='ignore', invalid='ignore'):
        s1 = np.where(kk_i > 0, kk_i*np.log(np.where(kk_i > 0, pp_i, 1.0)), 0.0)
        q_i = 1-pp_i
        s2 = np.where(nn_i-kk_i > 0, (nn_i-kk_i)*np.log(np.where(nn_i-kk_i > 0, q_i, 1.0)), 0.0)
    dev_i = 2*(float((s1+s2).sum()) + r.fun)
    dof_i = len(inner)-len(beta)
    print('  %-12s 内盘拟合 偏差 = %.1f / dof %d = %.2f' % (tag, dev_i, dof_i, dev_i/dof_i))
    start_i = len(coef_rows)
    for nm, b_, s_ in zip(names, beta, se):
        coef_rows.append(dict(model=tag, region='inner(|Z|<400pc)', param=nm, coef=b_, se=s_, H_pc='', H_se=''))
    if 'b_kpc' in names:
        ib = names.index('b_kpc')
        print('  %-12s 内盘拟合 b = %+.6f ± %.6f /kpc（H = %.0f ± %.0f pc）'
              % (tag, beta[ib], se[ib], -1000/beta[ib], 1000*abs(se[ib]/beta[ib]**2)))
        coef_rows[start_i + ib]['H_pc'] = round(-1000/beta[ib], 1)
        coef_rows[start_i + ib]['H_se'] = round(1000*abs(se[ib]/beta[ib]**2), 1)
save(pd.DataFrame(coef_rows), 'lnf_fit_coefs.csv', [
    's584：各拟合形式的系数与尺度高（逐星二项似然，log 连接，聚合到 亚型×5pc 格）',
    'region=all 为全 |Z| 段拟合，region=inner(|Z|<400pc) 为内盘重拟合（正文的 H = 202 / 287 pc 取自后者）',
    'coef/se 为 GLM 系数及其 Hessian 标准误；b_kpc 行的 H_pc/H_se 为 H = −1/b 的 delta 法换算（pc）',
    'z 以 kpc 为单位；只有含 b_kpc 的模型（M1/M2/M3/M4/M6）有 H 值',
    '生成脚本：代码/s584_starlevel_logit_z.py'])

save(pd.DataFrame(hrows), 'lnf_holdout_starlevel.csv', [
    's584：内盘（|Z|<400 pc）用逐星二项 GLM 拟合 ln f 后，外盘逐星预测平均 vs 实测',
    '与 s564 的区别：不再用「档中位 |Z| 代入」，而是对档内每颗星各算一个预测再平均（消除中位替代的 ±1.4% 系统偏差）',
    'pred/meas 均为百分数；ratio = meas/pred，比值 >> 1 表示外盘不是内盘趋势的延续',
    '生成脚本：代码/s584_starlevel_logit_z.py'])
print('\ns584 完成')
