# -*- coding: utf-8 -*-
"""s580: 固定阈值 vs 分位阈值——早型活动比例低有多少来自 0.75 A 这个固定判据？
用与 s551/s578 相同的 2D 样本链，做两件事：
 ① 给出各亚型的 EW 分位（50/70/80/90）与「过 0.75 A 的比例」，看固定阈值对不同亚型意味着什么；
 ② 改用「各亚型自身 EW 分布的 80 分位」作判据，再按 |Z| 分档重算活动比例，
    看 |Z| 趋势在分位判据下是否依然存在（若存在，说明趋势不是阈值造成的）。"""
import io, sys, os
import numpy as np, pandas as pd
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
OUT = r'C:\Users\lingz\Desktop\复现老师工作\APJS\多个图及讨论'
cat = pd.read_csv('data/lamost/dr13/dr13_mstellar_dM.csv', low_memory=False,
                  usecols=['uid','subclass','ewha','ewha_err','ra','dec','gaia_g_mean_mag','gaia_source_id'])
cat = cat[(cat.ewha > -20) & (cat.ewha <= 50) & (cat.ewha_err > 0) & (cat.ewha_err <= 5)].copy()
cat['gaia_source_id'] = pd.to_numeric(cat.gaia_source_id, errors='coerce')
g = pd.read_csv('data/gaia/gaia_dr3_mstars.csv', low_memory=False,
                usecols=['source_id','parallax','parallax_error','ruwe'])
m = cat.merge(g, left_on='gaia_source_id', right_on='source_id', how='inner')
m = m[(m.parallax > 0.2) & (m.parallax/m.parallax_error > 5) & (m.ruwe < 1.4)].copy()
u = m.sort_values('ewha', ascending=False).drop_duplicates('uid').copy()
dpc = 1000.0/u.parallax.values
u['MG'] = u.gaia_g_mean_mag.values - 5*np.log10(np.clip(dpc, 1, None)) + 5
u = u[u.MG >= 6].copy()
from astropy.coordinates import SkyCoord
import astropy.units as un
sc = SkyCoord(ra=u.ra.values*un.deg, dec=u.dec.values*un.deg, distance=dpc[u.index.isin(u.index)]*un.pc if False else (1000.0/u.parallax.values)*un.pc, frame='icrs')
u['absz'] = np.abs((1000.0/u.parallax.values)*np.sin(np.deg2rad(sc.galactic.b.deg)))
u = u[u.absz <= 3000].copy()
print('2D 样本 %d 颗（应 637,973）' % len(u))
SUBS = ['dM0','dM1','dM2','dM3','dM4','dM5','dM6']
# ① 各亚型 EW 分位
rows=[]
for s in SUBS:
    q = u[u.subclass == s]
    if len(q) < 50: continue
    e = q.ewha.values
    rows.append(dict(subtype=s, n=len(q), ew_med=float(np.median(e)),
                     ew_p70=float(np.percentile(e,70)), ew_p80=float(np.percentile(e,80)),
                     ew_p90=float(np.percentile(e,90)),
                     frac_gt_075=100*float((e>=0.75).mean()),
                     frac_gt_075_3sig=100*float(((q.ewha>=0.75)&(q.ewha>3*q.ewha_err)).mean())))
P = pd.DataFrame(rows)
print('\n各亚型 EW 分位（Å）：')
print(P.to_string(index=False, float_format=lambda x: '%.3f' % x))
def save(df, name, comments):
    fp = os.path.join(OUT, name); df.to_csv(fp, index=False, encoding='utf-8')
    txt = open(fp, encoding='utf-8').read()
    open(fp,'w',encoding='utf-8-sig').write('\n'.join('# '+c for c in comments) + '\n' + txt)
    print('  写出 %s（%d 行）' % (name, len(df)))
save(P, 'subtype_ew_percentiles.csv', [
 '各亚型的 EW(Ha) 分位数与「过 0.75 A 固定阈值」的比例：说明同一阈值对不同亚型的严苛程度不同',
 '样本：与 s551/s578 相同的 2D 样本链（637,973 颗）',
 'frac_gt_075 只要求 EW>=0.75；frac_gt_075_3sig 同时要求 EW>3sigma（正文判据）',
 '生成脚本：代码/s580_threshold_vs_quantile.py'])
# ② 分位阈值下的 |Z| 依赖
bins = [(0,100,'<100'),(100,200,'100-200'),(200,400,'200-400'),(400,600,'400-600'),(600,1000,'600-1000')]
out=[]
for s in SUBS:
    q = u[u.subclass == s]
    if len(q) < 50: continue
    thr = float(np.percentile(q.ewha.values, 80))
    row = dict(subtype=s, thr_p80=thr, n_total=len(q))
    for a,b,lb in bins:
        w = q[(q.absz>=a)&(q.absz<b)]
        row['q80_'+lb] = 100*float((w.ewha>=thr).mean()) if len(w)>20 else np.nan
        row['n_'+lb] = len(w)
    out.append(row)
Q = pd.DataFrame(out)
print('\n各亚型在「自身 80 分位」判据下、按 |Z| 分档的活动比例（%）：')
cols = ['subtype','thr_p80'] + ['q80_'+lb for _,_,lb in bins]
print(Q[cols].to_string(index=False, float_format=lambda x: '%.1f' % x))
save(Q, 'subtype_quantile_by_Z.csv', [
 '改用「各亚型自身 EW 分布的 80 分位」作判据后，各亚型活动比例随 |Z| 的变化（%）',
 'thr_p80 为该亚型的 80 分位 EW（A）；q80_<> 为该亚型在该 |Z| 档中 EW 超过 thr_p80 的比例',
 '若 q80 随 |Z| 明显下降，说明趋势不是 0.75 A 固定阈值造成的；若平坦，则原趋势主要是阈值效应',
 '生成脚本：代码/s580_threshold_vs_quantile.py'])
print('\ns580 完成')
