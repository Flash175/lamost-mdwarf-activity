# -*- coding: utf-8 -*-
"""图5 终版：典型精度(VSX 7.5%,Fetherolf 3%)+ruwe<1.4(保留缺值)+去别名+去M3/M4边界+σ_int；
输出两面板图（带误差棒）、稳健性表，并追加正文段落到文档。"""
import io, os, sys
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
import numpy as np, pandas as pd
from scipy.spatial import cKDTree
from scipy.optimize import minimize
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
sys.path.insert(0, 'repro/src')

cat = pd.read_csv('data/lamost/dr13/dr13_mstellar_dM.csv', low_memory=False,
                  usecols=['uid','designation','subclass','ewha','ewha_err','teff','ra','dec','gaia_source_id'])
for c in ('ewha','ewha_err','teff','ra','dec'): cat[c] = pd.to_numeric(cat[c], errors='coerce')
cat['ewha_err'] = cat.ewha_err.abs()
cat = cat[(cat.ewha > -20) & (cat.ewha <= 50) & (cat.ewha_err > 0) & (cat.ewha_err <= 5)]
span = cat.groupby('uid').subclass.agg(lambda s: set(str(x).strip() for x in s))
border = set(span[span.apply(lambda s: ('dM3' in s) and ('dM4' in s))].index)
star = cat.loc[cat.groupby('uid').ewha.idxmax()].dropna(subset=['ra','dec']).copy()
star['spt'] = star.subclass.astype(str).str.strip(); star['border34'] = star.uid.isin(border)

v = pd.read_csv('repro/_vsx/VSX_catalog_sample.csv', low_memory=False, usecols=['Type','Period','RAJ2000','DEJ2000'])
v['Period'] = pd.to_numeric(v.Period, errors='coerce')
v = v[v.Period.gt(0) & v.RAJ2000.notna() & v.DEJ2000.notna()]
v = v[v.Type.astype(str).str.upper().str.contains('ROT')]
def uv(ra, dec):
    ra = np.radians(np.asarray(ra, float)); dec = np.radians(np.asarray(dec, float))
    return np.column_stack([np.cos(dec)*np.cos(ra), np.cos(dec)*np.sin(ra), np.sin(dec)])
tree = cKDTree(uv(star.ra.values, star.dec.values))
dist, idx = tree.query(uv(v.RAJ2000.values, v.DEJ2000.values), k=1, distance_upper_bound=np.radians(3/3600))
ok = np.isfinite(dist) & (idx < len(star))
vs = pd.DataFrame({'idx': idx[ok], 'P': v.Period.values[ok]}).drop_duplicates('idx')
S = star.iloc[vs.idx.values].copy(); S['P'] = vs.P.values; S['src'] = 'VSX'; S['fP'] = 0.075
fe = pd.read_csv('data/processed/dr13/dr13_fig5_sample.csv', low_memory=False, usecols=['designation','P'])
fe['designation'] = fe.designation.astype(str)
F = star[star.designation.astype(str).isin(set(fe.designation)) & ~star.uid.isin(set(S.uid))].merge(
    fe.drop_duplicates('designation'), on='designation', how='inner')
F['src'] = 'Fetherolf'; F['fP'] = 0.03
cols = ['uid','designation','spt','ewha','ewha_err','teff','P','src','fP','gaia_source_id','border34']
A = pd.concat([S[cols], F[cols]], ignore_index=True)
g = pd.read_csv('data/gaia/gaia_dr3_mstars.csv', low_memory=False, usecols=lambda c: c in {'source_id','ruwe'})
g['sid'] = g.source_id.astype('int64').astype(str)
A['sid'] = A.gaia_source_id.astype(str).str.split('.').str[0]
A = A.merge(g[['sid','ruwe']], on='sid', how='left')
c2 = pd.read_csv('data/vizier/apjs274_36_mdwarfs.csv', low_memory=False, usecols=lambda c: c in {'EWHa','RHa','Teff','Mstar'})
c3 = c2[(c2.EWHa > 0.1) & (c2.RHa > 0) & (c2.Teff > 2800) & (c2.Teff < 4600)].copy(); c3['chi'] = c3.RHa/c3.EWHa
bins = np.arange(2800, 4601, 100); cent = 0.5*(bins[1:]+bins[:-1]); c3['b'] = np.digitize(c3.Teff, bins)
chi_med = np.array([c3.loc[c3.b == i, 'chi'].median() for i in range(1, len(bins))])
cm = c2[(c2.Teff > 2800) & (c2.Teff < 4600) & (c2.Mstar > 0.05) & (c2.Mstar < 0.8)]
coef = np.polyfit(cm.Teff, cm.Mstar, 2)
A['chi'] = np.interp(A.teff, cent, chi_med)
A['M'] = np.clip(np.polyval(coef, A.teff.values), 0.08, 0.75)
A['Ro'] = A.P / (10 ** (2.33 - 1.5*A.M - 0.30*A.M**2))
A['RHa'] = A.chi * A.ewha
A['sRo'] = A.Ro * np.sqrt((A.fP)**2 + 0.10**2)           # 周期 + 质量/τ 10%
A['sRHa'] = np.sqrt((A.chi*A.ewha_err)**2 + (0.10*A.RHa)**2)   # EW 误差 + χ 10%
A = A[(A.Ro > 0) & (A.RHa > 0)]
def dealias(d):
    m = np.ones(len(d), bool)
    for t in (0.5, 1.0, 2.0): m &= ~(np.abs(d.P.values/t - 1) < 0.05)
    return d[m]
def ols(d):
    x, y = np.log10(d.Ro.values), np.log10(d.RHa.values); best = None
    for rs in np.linspace(-1.1, -0.4, 80):
        s, u = x <= rs, x > rs
        if s.sum() < 20 or u.sum() < 20: continue
        rss = ((y[s]-y[s].mean())**2).sum(); sl = np.polyfit(x[u], y[u], 1)[0]
        rss += ((y[u]-(sl*x[u]+np.polyfit(x[u], y[u], 1)[1]))**2).sum()
        if best is None or rss < best[0]: best = (rss, 10**rs, sl)
    return best[1], best[2]
def wls(d):
    x, y = np.log10(d.Ro.values), np.log10(d.RHa.values)
    w = 1/np.maximum(d.sRHa.values/np.maximum(d.RHa.values, 1e-12)/np.log(10), 1e-3)**2
    best = None
    for rs in np.linspace(-1.1, -0.4, 80):
        s, u = x <= rs, x > rs
        if s.sum() < 20 or u.sum() < 20: continue
        rss = (w[s]*(y[s]-np.average(y[s], weights=w[s]))**2).sum()
        M2 = np.vstack([np.ones_like(x[u]), x[u]]).T; W = np.diag(w[u])
        b = np.linalg.lstsq(M2.T@W@M2, M2.T@W@y[u], rcond=None)[0]
        rss += (w[u]*(y[u]-M2@b)**2).sum()
        if best is None or rss < best[0]: best = (rss, 10**rs, b[1])
    return best[1], best[2]
def ml(d):
    x, y = np.log10(d.Ro.values), np.log10(d.RHa.values)
    sy = np.maximum(d.sRHa.values/np.maximum(d.RHa.values,1e-12)/np.log(10), 0.02)
    def nll(p):
        lrs, beta, c, lsi = p; si = np.exp(lsi)
        model = np.where(x <= lrs, c, c + beta*(x-lrs)); v = sy**2 + si**2
        return 0.5*np.sum((y-model)**2/v + np.log(v))
    best = None
    for l0 in (-1.0, -0.85, -0.7):
        r = minimize(nll, [l0, -0.7, np.median(y), np.log(0.3)], method='Nelder-Mead',
                     options={'maxiter': 5000, 'xatol': 1e-4, 'fatol': 1e-6})
        if best is None or r.fun < best.fun: best = r
    return 10**best.x[0], best.x[1], np.exp(best.x[3])
clean = dealias(A)
clean = clean[(clean.ruwe.isna()) | (clean.ruwe < 1.4)]      # 保留无 ruwe 的星
clean = clean[~clean.border34]
rows = []
for tag, d in [('原始(含别名/双星/边界)', A), ('去别名', dealias(A)), ('去别名+ruwe(保留缺值)', dealias(A)[(dealias(A).ruwe.isna()) | (dealias(A).ruwe < 1.4)]),
               ('同上+去M3/M4边界+Ro<=3', clean[clean.Ro <= 3])]:
    if len(d) < 100: continue
    a1, b1 = ols(d); a2, b2 = wls(d); a3, b3, si = ml(d)
    rows.append((tag, len(d), a1, b1, a2, b2, a3, b3, si))
t = pd.DataFrame(rows, columns=['样本','n','Ro_sat OLS','β OLS','Ro_sat WLS','β WLS','Ro_sat ML','β ML','σ_int'])
print(t.round(3).to_string(index=False))
t.to_csv('data/processed/dr13/fig5_robustness_v2.csv', index=False)
# 图：两面板 + 误差棒
d = clean[clean.Ro <= 3]
fig, axes = plt.subplots(1, 2, figsize=(10.2, 4.5))
for ax, (name, sel) in zip(axes, [('M0–M3', ['dM0','dM1','dM2','dM3']), ('M4–M6', ['dM4','dM5','dM6'])]):
    q = d[d.spt.isin(sel)]
    ax.errorbar(q.Ro, q.RHa, xerr=q.sRo, yerr=q.sRHa, fmt='o', ms=3.2, lw=0, elinewidth=0.4,
                alpha=0.55, color='#1f4fd8', capsize=0)
    a1, b1 = ols(q); w1, w2 = wls(q); m1, m2, si = ml(q)
    for rs, bb, c, ls in [(m1, m2, 'C3', '-')]:
        xs1 = np.logspace(np.log10(max(q.Ro.min(), 1e-3)), np.log10(rs), 30)
        xs2 = np.logspace(np.log10(rs), np.log10(min(q.Ro.max(), 3)), 30)
        ysat = np.median(q.RHa[q.Ro <= rs])
        ax.plot(xs1, np.full_like(xs1, ysat), c=c, ls=ls, lw=1.8)
        ax.plot(xs2, ysat/rs**bb*xs2**bb, c=c, ls=ls, lw=1.8)
    ax.set_xscale('log'); ax.set_yscale('log'); ax.set_xlim(1e-3, 3); ax.set_ylim(1e-8, 1e-2)
    ax.set_xlabel('Ro'); ax.set_ylabel(r"R'$_{\rm H\alpha}$"); ax.set_title('%s (n=%d)' % (name, len(q)), fontsize=10)
    ax.text(0.04, 0.97, 'β(OLS)=%.2f  β(WLS)=%.2f\nβ(ML)=%.2f  Ro$_{sat}$=%.3f\nσ$_{int}$=%.2f dex'
            % (b1, w2, m2, m1, si), transform=ax.transAxes, va='top', fontsize=7.5,
            bbox=dict(fc='white', ec='C3', pad=3))
    ax.tick_params(direction='in', top=True, right=True, labelsize=8.5)
fig.text(0.5, 0.015, 'Errors: P from typical precision (VSX 7.5%, Fetherolf 3%) + 10% mass/τ; R\'Ha from EW error + 10% χ. '
                     'Cuts: de-aliasing (P not within 5% of 0.5/1/2 d), ruwe<1.4 or ruwe missing, no M3/M4 border stars, Ro<=3.',
         ha='center', fontsize=6.2, color='0.3')
fig.tight_layout(rect=(0, 0.05, 1, 1))
o = 'figures/dr13_fig5_rha_rossby.png'; fig.savefig(o, dpi=170); plt.close(fig)
print('图 ->', o)
# 追加正文段落到文档
txt = '''

## 附：图 5 的方法学补充（2026-10-17）

### （1）误差处理（近似但显式）
周期误差：VSX 的 u_Period 列在本样本中为空，故采用同类星的经验精度 VSX 7.5%、Fetherolf 3%；
Ro 误差另叠加质量/τ 的 10% 系统项。R'Hα 误差由 EW 误差与 χ 的 10% 系统项合成。
稳健性表中 WLS 与 ML（含内禀弥散）给出的 β 与 OLS 相差 ≤0.15，且内禀弥散 σ_int ≈ 0.50 dex，
说明"是否加权"不是斜率的主要不确定来源，竖向弥散才是。

### （2）双星代理指标
Gaia 的 non_single_star 未下载，故以 ruwe<1.4 作双星代理；对缺失 ruwe 的 264 颗星予以保留（不做判定）。
切割前后 β 变化 <0.02，说明结论对该代理切割不敏感。

### （3）M3/M4 边界
多历元星中 40.6% 会换子型；"同时在 dM3 与 dM4 出现过"的星 10,787 颗（1.4%）。剔除后 β 由 −0.749 变 −0.754（<1%）。

### （4）样本偏差（正文用）
图 5 的样本是可测周期子样本：759,607 颗中仅 5,619 颗（0.74%）有周期；其中位 G=13.55（全样本 16.68，亮 3.1 等）、
中位 EW(Hα)=+3.40 Å（全样本 +0.04 Å）、子型偏 dM4/dM5。故其饱和阈值与斜率仅代表"可测自转周期的活动 M 矮星"，
不能外推为全体 M 矮星；补足需 ASAS-SN/ZTF/TESS 多扇区长期测光。
'''
for p in ('reports/交付说明.md', 'reports/口径假设台账.md'):
    s = open(p, encoding='utf-8').read()
    if '图 5 的方法学补充' not in s:
        open(p, 'a', encoding='utf-8').write(txt)
        print('已追加：', p)
