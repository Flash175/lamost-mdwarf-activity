
import io, sys
import numpy as np, pandas as pd
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
K = pd.read_csv('data/processed/dr13/ktype_pilot_ew.csv')
G = pd.read_csv('data/gaia/gaia_dr3_ktype_pilot.csv')
print('Gaia 返回 K 型:', len(G))
LAM='https://www.lamost.org/openapi'; import urllib.parse, urllib.request
token=open('extract/lamost_token.txt').read().strip()
sql=("select obsid, gaia_source_id, logg_err, teff_err from stellar where subclass like 'K%' and logg > 3.8 "
     "and teff between 3900 and 5500 and obsid % 60 = 13 and snrr between 4 and 30 and gaia_g_mean_mag between 14.0 and 18.0 limit 30000")
url=LAM+'/dr13/v1.0/sql?'+urllib.parse.urlencode({'sql':sql,'output.fmt':'csv','token':token})
meta=pd.read_csv(io.StringIO(urllib.request.urlopen(url,timeout=180).read().decode('utf-8').lstrip('\ufeff')))
meta['sid']=pd.to_numeric(meta.gaia_source_id,errors='coerce')
G['sid']=G.source_id.astype('int64')
M = K.merge(meta[['obsid','sid','logg_err','teff_err']],on='obsid',how='left').merge(G[['sid','ruwe']],on='sid',how='left')
print('合并后 ruwe 非空:', M.ruwe.notna().sum(), '/', len(M))
print('全部            n=%4d  %.2f%%' % (len(M), 100*M.active.mean()))
q1=M[M.ruwe<1.4]; print('ruwe<1.4        n=%4d  %.2f%%' % (len(q1), 100*q1.active.mean()))
q2=q1[(q1.logg_err<0.5)&(q1.teff_err<200)]; print('+ 参数精度      n=%4d  %.2f%%' % (len(q2), 100*q2.active.mean()))
q3=q2[(q2.logg>4.0)&(q2.logg<5.2)]; print('+ logg 4.0-5.2  n=%4d  %.2f%%' % (len(q3), 100*q3.active.mean()))
print('清理后 Teff 范围 %.0f–%.0f K，中位 %.0f' % (q3.teff.min(), q3.teff.max(), q3.teff.median()))
