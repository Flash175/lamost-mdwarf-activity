# -*- coding: utf-8 -*-
import numpy as np, pandas as pd
from scipy.optimize import minimize_scalar
A1, A2, C = 1.50, 2.33, -0.30
D = "C:/Users/lingz/Desktop/APJS/图五及相关数据/数据/"

def free_bp(x, y, grid):
    best = None
    for rs in grid:
        s, u = x <= rs, x > rs
        if s.sum() < 20 or u.sum() < 20: continue
        rss = ((y[s] - y[s].mean())**2).sum()
        sl, ic = np.polyfit(x[u], y[u], 1)
        rss += ((y[u] - (sl*x[u]+ic))**2).sum()
        if best is None or rss < best[0]: best = (rss, 10**rs, sl)
    return best[1], best[2]

d = pd.read_csv(D + "图5_逐星样本_严格3340行_⑤.csv")
d = d[(d.RHa > 0) & (d.P > 0) & (d.M > 0)]
tau = 10**(A2 - A1*d.M.values + C*d.M.values**2)
x = np.log10(d.P.values / tau); y = np.log10(d.RHa.values)
for n in (401, 1101, 4001, 20001, 200001):
    g = np.linspace(-2.4, -0.3, n)
    rs, b = free_bp(x, y, g)
    print("grid=%6d step=%.5f Ro_sat=%.5f beta=%.5f" % (n, g[1]-g[0], rs, b))

def rss_of(lrs):
    u = x > lrs
    if u.sum() < 20: return 1e9
    sl, ic = np.polyfit(x[u], y[u], 1)
    return ((y[u]-(sl*x[u]+ic))**2).sum() + ((y[~u]-y[~u].mean())**2).sum()
r = minimize_scalar(rss_of, bounds=(-2.4,-0.3), method="bounded", options={"xatol":1e-12})
u = x > r.x
print("连续最优: Ro_sat=%.6f beta=%.6f RSS=%.5f" % (10**r.x, np.polyfit(x[u], y[u], 1)[0], r.fun))
