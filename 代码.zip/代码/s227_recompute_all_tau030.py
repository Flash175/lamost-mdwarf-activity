# -*- coding: utf-8 -*-
"""
s227_recompute_all_tau030.py —— 在 τ = Li 2024 印刷式（−0.30）下重算附录所需全部量。

产出（供 Methods §三/§10/§11/§12 与台账 §3/§5/§6 引用）：
  A. 逐级筛选表 ①②③④⑤：自由断点 OLS / WLS / ML、Ro_sat、σ_int
  B. 三档固定断点表（0.100 / 0.120 / 0.135）+ 自由断点
  C. ML 口径的全体 Ro_sat（用于核实图注 "0.121 (ML)"）
  D. Ro_sat 的 τ 漂移（1,101 点网格，−0.30 → +0.31），全体与两面板
  E. 坪区 Simpson 分解（精确值，判断 +0.0003 与 +0.0030 哪个闭合）
  F. S/N 中位二分（切点 23.5）的斜率与 bootstrap 误差
"""
import numpy as np, pandas as pd
from scipy.optimize import minimize

D = "C:/Users/lingz/Desktop/APJS/图五及相关数据/数据/"
RNG_SEED = 20261022
COEF = -0.30         # 采用值（Li 2024 印刷式：2.33 - 1.50M - 0.30M^2）
BP_GRID = (-2.4, -0.3, 1101)   # 自由断点搜索：bp ∈ [4e-3, 0.5]，宽域（旧 401 点 [-1.1,-0.4] 在 0.079 处截断）
A1, A2 = 1.50, 2.33


def ro(m, p, c=COEF):
    return p / 10 ** (A2 - A1 * m + c * m ** 2)


def free_bp_ols(x, y, grid=None):
    grid = grid or np.linspace(*BP_GRID)
    best = None
    for rs in grid:
        s, u = x <= rs, x > rs
        if s.sum() < 20 or u.sum() < 20:
            continue
        rss = ((y[s] - y[s].mean()) ** 2).sum()
        sl, ic = np.polyfit(x[u], y[u], 1)
        rss += ((y[u] - (sl * x[u] + ic)) ** 2).sum()
        if best is None or rss < best[0]:
            best = (rss, 10 ** rs, sl)
    return best[1], best[2]


def free_bp_wls(x, y, sy, grid=None):
    grid = grid or np.linspace(*BP_GRID)
    w = 1 / np.maximum(sy / np.log(10), 1e-3) ** 2
    best = None
    for rs in grid:
        s, u = x <= rs, x > rs
        if s.sum() < 20 or u.sum() < 20:
            continue
        rss = (w[s] * (y[s] - np.average(y[s], weights=w[s])) ** 2).sum()
        M2 = np.vstack([np.ones_like(x[u]), x[u]]).T
        W = np.diag(w[u])
        b = np.linalg.lstsq(M2.T @ W @ M2, M2.T @ W @ y[u], rcond=None)[0]
        rss += (w[u] * (y[u] - M2 @ b) ** 2).sum()
        if best is None or rss < best[0]:
            best = (rss, 10 ** rs, b[1])
    return best[1], best[2]


def ml_fit(x, y, sy):
    sy = np.maximum(sy / np.maximum(10 ** y, 1e-12) / np.log(10), 0.02)

    def nll(p):
        lrs, beta, c, lsi = p
        si = np.exp(lsi)
        m = np.where(x <= lrs, c, c + beta * (x - lrs))
        v = sy ** 2 + si ** 2
        return 0.5 * np.sum((y - m) ** 2 / v + np.log(v))

    best = None
    for l0 in (-1.0, -0.85, -0.7):
        r = minimize(nll, [l0, -0.7, np.median(y), np.log(0.3)], method="Nelder-Mead",
                     bounds=[(-1.30, -0.50), (-1.60, 0.10), (-9.0, 0.0), (-4.0, 0.0)],
                     options={"maxiter": 5000, "xatol": 1e-4, "fatol": 1e-6})
        if best is None or r.fun < best.fun:
            best = r
    return 10 ** best.x[0], best.x[1], np.exp(best.x[3])


def slope_fixed(x, y, bp=0.135):
    u = x > np.log10(bp)
    return np.polyfit(x[u], y[u], 1)[0], int(u.sum())


def boot_slope(x, y, bp, n=2000, seed=RNG_SEED):
    rng = np.random.default_rng(seed)
    idx = np.where(x > np.log10(bp))[0]
    out = [np.polyfit(x[s], y[s], 1)[0] for s in
           (rng.choice(idx, len(idx), replace=True) for _ in range(n))]
    return float(np.std(out, ddof=1))


def load_levels():
    """从 ① 的逐星表重建 ②③④，⑤/⑤′ 用现成 CSV。"""
    a = pd.read_csv(D + "图5_逐星样本_周期4612行_①.csv")
    a = a[(a.RHa > 0) & (a.P > 0) & (a.M > 0)].copy()
    lv = {}
    lv["① 原始(含双星/别名/边界)"] = a
    # ② 去别名：P 落在 0.5 / 1 / 2 d 的 ±5% 内（几何别名带，4612→4234）
    near = np.zeros(len(a), bool)
    for p in (0.5, 1.0, 2.0):
        near |= (np.abs(a.P.values / p - 1) < 0.05)
    b = a[~near]
    lv["② 去别名"] = b
    c = b[(b.ruwe < 1.4) | b.ruwe.isna()]
    lv["③ +ruwe<1.4"] = c
    d = c[~c.border34.astype(bool)]
    lv["④ +去M3/M4边界"] = d
    p5 = pd.read_csv(D + "图5_逐星样本_严格3340行_⑤.csv")
    lv["⑤ +nss=0+交叉验证+Ro<=3"] = p5[(p5.RHa > 0) & (p5.P > 0) & (p5.M > 0)]
    p5b = pd.read_csv(D + "图5_逐星样本_对照4114行_⑤′.csv")
    lv["⑤′ 对照"] = p5b[(p5b.RHa > 0) & (p5b.P > 0) & (p5b.M > 0)]
    return lv


print("=" * 78)
print("A. 逐级筛选表（τ = 2.33 − 1.50M − 0.30M², Li 2024 印刷式）")
print("%-30s %6s %9s %9s %9s %8s %7s %6s" % ("级", "N", "β(OLS)", "β(WLS)", "β(ML)", "Ro_sat", "σ_int", "N_orig"))
for k, d in load_levels().items():
    d = d.copy()
    d["Ro"] = ro(d.M.values, d.P.values)
    x, y = np.log10(d.Ro.values), np.log10(d.RHa.values)
    sy = d.sRHa.values
    rs_o, b_o = free_bp_ols(x, y)
    rs_w, b_w = free_bp_wls(x, y, sy / d.RHa.values)
    rs_m, b_m, si = ml_fit(x, y, sy)
    print("%-30s %6d %9.4f %9.4f %9.4f %8.4f %7.3f %6d"
          % (k, len(d), b_o, b_w, b_m, rs_o, si, len(d)))

d5 = load_levels()["⑤ +nss=0+交叉验证+Ro<=3"].copy()
d5["Ro"] = ro(d5.M.values, d5.P.values)
x5, y5 = np.log10(d5.Ro.values), np.log10(d5.RHa.values)
d5["pan"] = np.where(d5.spt.isin(["dM0", "dM1", "dM2", "dM3"]), "M0M3",
             np.where(d5.spt.isin(["dM4", "dM5", "dM6"]), "M4M6", "o"))

print()
print("=" * 78)
print("B. 三档固定断点 + 自由断点（bootstrap 2000，独立随机流）")
print("%-8s %5s %9s %9s %9s %14s" % ("sample", "n", "bp=0.100", "bp=0.120", "bp=0.135", "free"))
rows = []
for k, m in (("全体", np.ones(len(d5), bool)), ("M0–M3", (d5.pan == "M0M3").values),
             ("M4–M6", (d5.pan == "M4M6").values)):
    x, y = x5[m], y5[m]
    vals = []
    for bp in (0.100, 0.120, 0.135):
        s, nfit = slope_fixed(x, y, bp)
        e = boot_slope(x, y, bp)
        vals.append((s, e, nfit))
    rsf, bf = free_bp_ols(x, y)
    print("%-8s %5d %9s %9s %9s %14s" % (
        k, m.sum(),
        "%.3f±%.3f" % (vals[0][0], vals[0][1]),
        "%.3f±%.3f" % (vals[1][0], vals[1][1]),
        "%.3f±%.3f" % (vals[2][0], vals[2][1]),
        "%.3f (bp=%.4f)" % (bf, rsf)))
    rows.append((k, m.sum(), vals, bf, rsf))

pa = rows[1][2][2][0]; pb = rows[2][2][2][0]
ea, eb = rows[1][2][2][1], rows[2][2][2][1]
print("Δβ(固定 0.135) = %.4f ± %.4f  → %.3fσ" % (pb - pa, np.hypot(ea, eb), abs(pb - pa) / np.hypot(ea, eb)))

print()
print("=" * 78)
print("C. ML 口径的 Ro_sat（核实图注 0.121）")
rs_m, b_m, si = ml_fit(x5, y5, d5.sRHa.values)
print("全体 ML: Ro_sat = %.4f  β = %.4f  σ_int = %.3f" % (rs_m, b_m, si))
for k, m in (("M0–M3", (d5.pan == "M0M3").values), ("M4–M6", (d5.pan == "M4M6").values)):
    r, b, s = ml_fit(x5[m], y5[m], d5.sRHa.values[m])
    print("%s ML: Ro_sat = %.4f  β = %.4f  σ_int = %.3f" % (k, r, b, s))

print()
print("=" * 78)
print("D. Ro_sat 的 τ 漂移（1,101 点网格，自由断点重拟合）")
for k, m in (("全体", np.ones(len(d5), bool)), ("M0–M3", (d5.pan == "M0M3").values),
             ("M4–M6", (d5.pan == "M4M6").values)):
    out = []
    for c in (-0.30, +0.31):
        R = ro(d5.M.values, d5.P.values, c)
        xx, yy = np.log10(R[m]), y5[m]
        rr, bb = free_bp_ols(xx, yy)
        out.append((rr, bb, np.median(R[m])))
    print("%-7s −0.30: Ro_sat=%.4f β=%.3f (Ro中位 %.4f) | +0.31: Ro_sat=%.4f β=%.3f (Ro中位 %.4f) | 位移 %+.1f%%"
          % (k, out[0][0], out[0][1], out[0][2], out[1][0], out[1][1], out[1][2],
             100 * (out[1][0] / out[0][0] - 1)))

print()
print("=" * 78)
print("E. 坪区 Simpson 分解（Ro<0.135, 全体）")
plat = d5[d5.Ro < 0.135]
xp, yp = np.log10(plat.Ro.values), np.log10(plat.RHa.values)
tot_slope = np.polyfit(xp, yp, 1)[0]
Sxx_tot = ((xp - xp.mean()) ** 2).sum()
Sxy_tot = ((xp - xp.mean()) * (yp - yp.mean())).sum()
num_in = num_bt = 0.0
print("N_plat = %d  全体 OLS = %.6f  Sxx=%.4f Sxy=%.4f" % (len(plat), tot_slope, Sxx_tot, Sxy_tot))
for k in ("M0M3", "M4M6"):
    q = plat[plat.pan == k]
    xq, yq = np.log10(q.Ro.values), np.log10(q.RHa.values)
    bx = (xq - xq.mean()) * (yq - yq.mean())
    num_in += bx.sum()
    num_bt += len(q) * (xq.mean() - xp.mean()) * (yq.mean() - yp.mean())
    print("  %s n=%d  x̄=%.4f ȳ=%.4f  Sxx=%.4f  β=%.4f" % (
        k, len(q), xq.mean(), yq.mean(), ((xq - xq.mean()) ** 2).sum(), np.polyfit(xq, yq, 1)[0]))
print("  组内 = %+.4f / Sxx = %+.6f" % (num_in, num_in / Sxx_tot))
print("  组间 = %+.4f / Sxx = %+.6f" % (num_bt, num_bt / Sxx_tot))
print("  组内+组间 = %+.6f   vs 全体 OLS = %+.6f   差 %.2e" %
      ((num_in + num_bt) / Sxx_tot, tot_slope, (num_in + num_bt) / Sxx_tot - tot_slope))

print()
print("=" * 78)
print("F. S/N 中位二分（切点 23.5）")
sn = d5.RHa / d5.sRHa
cut = np.median(sn)
print("S/N 中位 = %.3f" % cut)
for lab, m in (("低 S/N", (sn < cut).values), ("高 S/N", (sn >= cut).values)):
    s = np.polyfit(x5[m & (d5.Ro.values > 0.135 * 0)], y5[m], 1)[0] if False else None
    x, y = x5[m], y5[m]
    b, nfit = slope_fixed(x, y)
    e = boot_slope(x, y, 0.135, n=1000)
    print("%-6s n=%5d  β = %.4f ± %.4f (n_fit=%d)" % (lab, m.sum(), b, e, nfit))
