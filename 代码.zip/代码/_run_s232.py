# -*- coding: utf-8 -*-
"""s232_boot_rosat_dist.py —— 用前缀和把分段拟合的 RSS 做成 O(grid) 向量化，
独立重跑 Ro_sat 的自由断点 bootstrap 分布（P1-1 定案用）。

模型：Ro<=bp 为常数坪，Ro>bp 为直线。RSS(bp) 完全由排序后的前缀和给出，
故 1,101 点网格的每次重抽样只需 ~n log n（排序）+ O(n)。

输出：点估计、>点估计比例、16/84/5/95 分位、上支原子及其占比、log 偏度。
"""
import numpy as np, pandas as pd
from scipy.stats import skew

D = "C:/Users/lingz/Desktop/APJS/图五及相关数据/数据/"
GRID = np.linspace(-2.4, -0.3, 1101)
BPS = 10 ** GRID


def rss_profile(x, y, minseg=20):
    """返回每个网格点上的 RSS（向量化）。"""
    o = np.argsort(x)
    xs, ys = x[o], y[o]
    n = len(xs)
    c1 = np.concatenate(([0.0], np.cumsum(xs)))
    c2 = np.concatenate(([0.0], np.cumsum(xs * xs)))
    d1 = np.concatenate(([0.0], np.cumsum(ys)))
    d2 = np.concatenate(([0.0], np.cumsum(ys * ys)))
    e = np.concatenate(([0.0], np.cumsum(xs * ys)))
    i = np.searchsorted(xs, GRID, side="right")

    n1 = i.astype(float); n2 = n - i
    out = np.full(len(GRID), np.inf)

    ok = (n1 >= minseg) & (n2 >= minseg)
    if not ok.any():
        return out
    k = np.where(ok)[0]
    a = i[k]
    # 下段：常数模型
    s1, s2, t1, t2, u = c1[a], c2[a], d1[a], d2[a], e[a]
    rss_low = t2 - t1 ** 2 / n1[k]
    # 上段：直线
    s1u, s2u = c1[-1] - s1, c2[-1] - s2
    t1u, t2u, uu = d1[-1] - t1, d2[-1] - t2, e[-1] - u
    sxx = s2u - s1u ** 2 / n2[k]
    syy = t2u - t1u ** 2 / n2[k]
    sxy = uu - s1u * t1u / n2[k]
    rss_up = np.where(sxx > 0, syy - sxy ** 2 / np.where(sxx > 0, sxx, 1), t2u)
    out[k] = rss_low + rss_up
    return out


def run(d, col_pan, label, nboot, seed=20261022):
    q = d[d[col_pan] == label]
    x, y = np.log10(q.Ro.values), np.log10(q.RHa.values)
    poi = BPS[np.argmin(rss_profile(x, y))]
    rng = np.random.default_rng(seed)
    bps = np.empty(nboot)
    for b in range(nboot):
        s = rng.integers(0, len(x), len(x))
        bps[b] = BPS[np.argmin(rss_profile(x[s], y[s]))]
    up = bps[bps > 0.09]
    atoms = ""
    if len(up):
        v, c = np.unique(np.round(up, 4), return_counts=True)
        for j in np.argsort(-c)[:3]:
            atoms += " %.4f(%.1f%%)" % (v[j], 100 * c[j] / nboot)
    print("%-6s n=%4d 点估计=%.4f | boot=%4d 中位=%.4f 16%%=%.4f 84%%=%.4f 5%%=%.4f 95%%=%.4f "
          ">点估计=%5.1f%% 偏度=%+.2f | 上支原子:%s"
          % (label, len(q), poi, nboot, np.median(bps), np.percentile(bps, 16),
             np.percentile(bps, 84), np.percentile(bps, 5), np.percentile(bps, 95),
             100 * (bps > poi).mean(), skew(np.log10(bps)), atoms))


if __name__ == "__main__":
    d = pd.read_csv(D + "图5_逐星样本_严格3340行_⑤.csv")
    d = d[(d.RHa > 0) & (d.P > 0) & (d.M > 0)]
    d["pan"] = np.where(d.spt.isin(["dM0", "dM1", "dM2", "dM3"]), "M0M3",
                 np.where(d.spt.isin(["dM4", "dM5", "dM6"]), "M4M6", "late"))
    d["Ro"] = d.P / 10 ** (2.33 - 1.50 * d.M + (-0.30) * d.M ** 2)
    print("网格 1,101 点宽域（log bp 步长 0.00191；0.114 与 0.116 相差 4 格，可分辨）")
    for nb in (600, 2000):
        for lab in ("M0M3", "M4M6"):
            run(d, "pan", lab, nb)
        print()
