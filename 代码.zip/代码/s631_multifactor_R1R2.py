
# -*- coding: utf-8 -*-
"""s631：R2（去掉 F6）与合并组 R1 的对照，用于判断共线性；输出追加到 多因素_方案对比.csv 与备忘。"""
import os, sys, io, json, itertools, math
import numpy as np, pandas as pd
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
D = r'C:\Users\lingz\Desktop\复现老师工作\APJS\多个图及讨论'
d = pd.read_csv(os.path.join(D,'金属度_清洁样本_637973.csv'), low_memory=False)
sb1 = pd.read_csv(os.path.join(D,'RV变星_SB1候选_多历元.csv'), low_memory=False)
d = d[~d.uid.isin(set(sb1.uid))]
for c in ['teff','logg','m_h','snru']:
    d = d[pd.to_numeric(d[c], errors='coerce').notna() & (pd.to_numeric(d[c], errors='coerce')!=-9999)]
d = d[(d.teff>=2000)&(d.teff<=4500)&(d.logg>=3)&(d.logg<=6)&(d.m_h.abs()<1)&(d.snru>0)&(d.snru<100)&(d.mh_ok==True)]
d = d[(d.dist_pc>0)&(d.absz>0)&(d.absz<=400)].copy()
d['active'] = ((d.ewha>=0.75)&(d.ewha>3*d.ewha_err)).astype(float)
d['zb3'] = pd.cut(d.absz,[0,100,200,400],labels=['<100','100-200','200-400'])
DUM = pd.get_dummies(d.subclass, prefix='s', drop_first=True).astype(float)
for c,nm in [('teff','F2'),('logg','F3'),('m_h','F4')]:
    v=pd.to_numeric(d[c]); d[nm]=v-v.mean()
d['F2']=d.F2/1000.0
lv=np.log10(d.snru); d['F5']=lv-lv.mean()
ld=np.log10(d.dist_pc); d['F6']=ld-ld.mean()
X = pd.concat([DUM, d[['F2','F3','F4','F5','F6']]], axis=1)
blocks={'F1':list(DUM.columns),'F2':['F2'],'F3':['F3'],'F4':['F4'],'F5':['F5'],'F6':['F6']}
y=d.active.values; masks={b:(d.zb3.values==b) for b in ['<100','100-200','200-400']}
f={b:100*y[m].mean() for b,m in masks.items()}; OBS={b:f['<100']-f[b] for b in ['100-200','200-400']}

def pooled_shapley(keys):
    K=len(keys); cache={}
    def delta(S):
        cols=[c for k in S for c in blocks[k]]
        A=np.column_stack([np.ones(len(d))]+[X[c].values for c in cols])
        beta,*_=np.linalg.lstsq(A,y,rcond=None); pr=A@beta
        v={b:pr[m].mean() for b,m in masks.items()}
        return {b:100*(v[b]-v['<100']) for b in ['100-200','200-400']}
    for r in range(K+1):
        for S in itertools.combinations(keys,r): cache[frozenset(S)]=delta(S)
    phi={b:{k:0.0 for k in keys} for b in ['100-200','200-400']}
    for k in keys:
        others=[x for x in keys if x!=k]
        for r in range(len(others)+1):
            for S in itertools.combinations(others,r):
                w=math.factorial(len(S))*math.factorial(K-len(S)-1)/math.factorial(K)
                for b in phi: phi[b][k]+=w*(cache[frozenset(tuple(sorted(S+(k,))))][b]-cache[frozenset(S)][b])
    return phi, cache[frozenset(keys)]

rows=[]
for tag, keys in [('A_all6',['F1','F2','F3','F4','F5','F6']),
                  ('R2_noF6',['F1','F2','F3','F4','F5']),
                  ('R1_mergeF2F3',['F1','F23','F4','F5','F6'])]:
    if 'F23' in keys:
        blocks['F23']=['F2','F3']
    phi, full = pooled_shapley(keys)
    print('\n=== %s ===' % tag)
    for b in ['100-200','200-400']:
        print('  bin %-8s observed %6.2f | model D %6.2f | residual %6.2f' % (b, OBS[b], full[b], OBS[b]-full[b]))
        print('    ' + ', '.join('%s %+.2f' % (k, phi[b][k]) for k in keys) + '  | sum %+.2f' % sum(phi[b].values()))
        for k in keys: rows.append(dict(scheme=tag, bin=b, factor=k, pp=phi[b][k]))
        rows.append(dict(scheme=tag, bin=b, factor='MODEL_D', pp=full[b]))
        rows.append(dict(scheme=tag, bin=b, factor='OBSERVED_D', pp=OBS[b]))
        rows.append(dict(scheme=tag, bin=b, factor='RESIDUAL', pp=OBS[b]-full[b]))
pd.DataFrame(rows).round(4).to_csv(os.path.join(D,'多因素_方案对比_追加.csv'), index=False, encoding='utf-8-sig')
print('\nwrote 多因素_方案对比_追加.csv')
