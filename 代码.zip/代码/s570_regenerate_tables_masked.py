# -*- coding: utf-8 -*-
"""s570：把 far400_2d_audit.csv 与 far400_6d_properties*.csv 按「屏蔽 −9999 哨兵」重算，
并补上 M_G 亮天体统计。旧表先备份为 *_备份_含哨兵.csv。
"""
import io, sys, os, shutil
import numpy as np, pandas as pd
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
from astropy.coordinates import SkyCoord
import astropy.units as un
OUT = r'C:\Users\lingz\Desktop\复现老师工作\APJS\多个图及讨论'

def wilson(k, n, z=1.96):
    if n == 0: return (np.nan, np.nan)
    p = k/n; d = 1+z*z/n; c = (p+z*z/(2*n))/d
    h = z*np.sqrt(p*(1-p)/n + z*z/(4*n*n))/d
    return 100*(c-h), 100*(c+h)

def save(df, name, comments):
    fp = os.path.join(OUT, name); df.to_csv(fp, index=False, encoding='utf-8')
    txt = open(fp, encoding='utf-8').read()
    with open(fp, 'w', encoding='utf-8-sig') as f:
        f.write('\n'.join('# ' + c for c in comments) + '\n' + txt)
    print('  写出 %s（%d 行 x %d 列）' % (name, len(df), df.shape[1]))

for f in ['far400_2d_audit.csv', 'far400_6d_properties.csv', 'far400_6d_properties_nocap.csv']:
    src_f = os.path.join(OUT, f); bak = os.path.join(OUT, f.replace('.csv', '_备份_含哨兵.csv'))
    if os.path.exists(src_f) and not os.path.exists(bak):
        shutil.copyfile(src_f, bak); print('  备份 %s → %s' % (f, os.path.basename(bak)))

cat = pd.read_csv('data/lamost/dr13/dr13_mstellar_dM.csv', low_memory=False,
                  usecols=['uid','subclass','teff','logg','ewha','ewha_err','snrr','ra','dec',
                           'gaia_source_id','gaia_g_mean_mag'])
cat = cat[(cat.ewha > -20) & (cat.ewha <= 50) & (cat.ewha_err > 0) & (cat.ewha_err <= 5)].copy()
cat['active'] = (cat.ewha >= 0.75) & (cat.ewha > 3*cat.ewha_err)
# 哨兵屏蔽：-9999 → NaN，并记录缺失
for col in ['logg', 'teff']:
    cat[col + '_missing'] = cat[col] == -9999
    cat.loc[cat[col] == -9999, col] = np.nan
cat['gaia_source_id'] = pd.to_numeric(cat.gaia_source_id, errors='coerce')
g = pd.read_csv('data/gaia/gaia_dr3_mstars.csv', low_memory=False,
                usecols=['source_id','parallax','parallax_error','pmra','pmdec','radial_velocity','ruwe'])
m = cat.merge(g, left_on='gaia_source_id', right_on='source_id', how='inner')
m = m[(m.parallax > 0.2) & (m.parallax/m.parallax_error > 5) & (m.ruwe < 1.4)].copy()
m['rv'] = m.radial_velocity
u = m.sort_values('ewha', ascending=False).drop_duplicates('uid').copy()
# [giant-cut] 去巨星：M_G >= 6（M 矮星 +8~+16；切口同时含亚巨星与误分类早型矮星）
u['MG'] = u.gaia_g_mean_mag.values - 5*np.log10(np.clip(1000.0/u.parallax.values, 1, None)) + 5
u = u[u.MG >= 6].copy()
d = 1000.0/u.parallax.values
sc = SkyCoord(ra=u.ra.values*un.deg, dec=u.dec.values*un.deg, distance=d*un.pc, frame='icrs')
u['absz'] = np.abs(d*np.sin(np.deg2rad(sc.galactic.b.deg)))
u['MG'] = u.gaia_g_mean_mag.values - 5*np.log10(np.clip(d, 1, None)) + 5
u = u[u.absz <= 3000].copy()
print('2D %d 颗；logg 缺失 %d、teff 缺失 %d、M_G<6 的 %d'
      % (len(u), int(u.logg_missing.sum()), int(u.teff_missing.sum()), int((u.MG < 6).sum())))

# ---------- 1) 2D 分档表 ----------
rows = []
for lb, zl, zh in [('<100',0,100),('100-200',100,200),('200-400',200,400),('400-600',400,600),('600-1000',600,1000),('>1000',1000,3000)]:
    s = u[(u.absz >= zl) & (u.absz < zh)]
    k = int(s.active.sum()); n = len(s); lo, hi = wilson(k, n)
    valid = s[s.logg.notna()]
    rows.append(dict(
        zbin=lb, n=n, n_act=k, frac=100*k/n, lo=lo, hi=hi,
        absz_med=float(s.absz.median()), dm0_share=100*(s.subclass == 'dM0').mean(),
        snr_med=float(s.snrr.median()), g_med=float(s.gaia_g_mean_mag.median()),
        logg_med_masked=float(valid.logg.median()) if len(valid) else np.nan,
        n_logg_valid=len(valid), n_logg_missing=int(s.logg_missing.sum()),
        n_logg_lt35_real=int((valid.logg < 3.5).sum()),
        frac_logg_lt35_real=100*(valid.logg < 3.5).mean() if len(valid) else np.nan,
        n_MG_lt6=int((s.MG < 6).sum()), frac_MG_lt6=100*(s.MG < 6).mean(),
        frac_act_after_MGcut=100*s[s.MG >= 6].active.mean(),
        teff_med_masked=float(s[s.teff.notna()].teff.median())))
T2 = pd.DataFrame(rows)
save(T2, 'far400_2d_audit.csv', [
    '2D 样本（只需视差，每星最大 EW 谱）按 |Z| 分档；active = EW(Ha)>=0.75 A 且 >3sigma',
    '**logg/teff 已屏蔽 -9999 哨兵**：logg_med_masked / teff_med_masked 只用有效值；n_logg_missing 给出缺失条数',
    'n_logg_lt35_real 与 frac_logg_lt35_real 只用有效 logg（旧版含哨兵，已备份为 *_备份_含哨兵.csv）',
    'M_G = gaia_g_mean_mag - 5log10(d) + 5；n_MG_lt6 / frac_MG_lt6 为亮天体（巨星/误分类）统计；frac_act_after_MGcut 为去掉它们后的活动比例',
    '生成脚本：代码/s570_regenerate_tables_masked.py'])
print(T2[['zbin','n','frac','n_logg_missing','n_logg_lt35_real','frac_logg_lt35_real','frac_MG_lt6','frac_act_after_MGcut']]
      .to_string(index=False, float_format=lambda x: '%.2f' % x))

# ---------- 2) 6D 远档属性表 ----------
six = u[np.isfinite(u.rv) & (np.abs(u.rv) < 500)].copy()
c6 = SkyCoord(ra=six.ra.values*un.deg, dec=six.dec.values*un.deg,
              distance=(1000.0/six.parallax.values)*un.pc,
              pm_ra_cosdec=six.pmra.values*un.mas/un.yr, pm_dec=six.pmdec.values*un.mas/un.yr,
              radial_velocity=six.rv.values*un.km/un.s, frame='icrs')
gc = c6.transform_to('galactocentric')
six = six.assign(zgc=np.abs(gc.z.to(un.kpc).value)*1000)
six = six[six.zgc <= 3000]
rows = []
u_all = m.sort_values('ewha', ascending=False).drop_duplicates('uid').copy()
# [giant-cut] 去巨星：M_G >= 6（M 矮星 +8~+16；切口同时含亚巨星与误分类早型矮星）
u_all['MG'] = u_all.gaia_g_mean_mag.values - 5*np.log10(np.clip(1000.0/u_all.parallax.values, 1, None)) + 5
u_all = u_all[u_all.MG >= 6].copy()
_d = 1000.0/u_all.parallax.values
_sc = SkyCoord(ra=u_all.ra.values*un.deg, dec=u_all.dec.values*un.deg, distance=_d*un.pc, frame='icrs')
u_all['absz'] = np.abs(_d*np.sin(np.deg2rad(_sc.galactic.b.deg)))
u_all['MG'] = u_all.gaia_g_mean_mag.values - 5*np.log10(np.clip(_d, 1, None)) + 5
for tag, sel in (('with |Z|<=3 kpc (canonical)', six[(six.absz > 400) & (six.absz <= 3000)]),
                 ('no 3 kpc cap', u_all[(u_all.absz > 400) & np.isfinite(u_all.radial_velocity) & (np.abs(u_all.radial_velocity) < 500)])):
    act = sel[sel.active]; ina = sel[~sel.active]
    av = act[act.logg.notna()]; iv = ina[ina.logg.notna()]
    rows.append(dict(cut=tag, n=len(sel), n_act=len(act),
                     snr_med_act=float(act.snrr.median()), n_snr_lt3=int((act.snrr < 3).sum()),
                     logg_med_act_masked=float(av.logg.median()) if len(av) else np.nan,
                     n_logg_missing_act=int(act.logg_missing.sum()),
                     n_logg_lt35_real_act=int((av.logg < 3.5).sum()),
                     g_med_act=float(act.gaia_g_mean_mag.median()),
                     g_med_inact=float(ina.gaia_g_mean_mag.median()),
                     snr_med_inact=float(ina.snrr.median()),
                     teff_med_act_masked=float(act[act.teff.notna()].teff.median()),
                     teff_med_inact_masked=float(ina[ina.teff.notna()].teff.median()),
                     n_MG_lt6_act=int((act.MG < 6).sum()),
                     frac_MG_lt6_act=100*(act.MG < 6).mean()))
T6 = pd.DataFrame(rows)
for tag, name in (('with |Z|<=3 kpc (canonical)', 'far400_6d_properties.csv'), ('no 3 kpc cap', 'far400_6d_properties_nocap.csv')):
    save(T6[T6.cut == tag].reset_index(drop=True), name, [
        '6D 子样本在日心 |Z|>400 pc 处的属性（先去重、再筛 RV，与 §0 一致）',
        '**logg/teff 已屏蔽 -9999 哨兵**：logg_med_act_masked / teff_med_*_masked 只用有效值；n_logg_missing_act 为活动星的缺失条数',
        'n_logg_lt35_real_act 为**真正** logg<3.5 的活动星数（旧版把 -9999 计入，已备份为 *_备份_含哨兵.csv）',
        'frac_MG_lt6_act 为活动星中 M_G<6 的亮天体比例',
        '生成脚本：代码/s570_regenerate_tables_masked.py'])
print('\n6D 表：')
print(T6.to_string(index=False, float_format=lambda x: '%.2f' % x))
print('s570 完成')
