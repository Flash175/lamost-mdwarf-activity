# -*- coding: utf-8 -*-
"""s587：不用六档自洽，改用「独立子样本」做留出——高 S/N 与 6D 子样本

s585/s586 的六档校准用的就是拟合数据本身，等于自洽检查。真正的留出要求：
子样本按与 |Z|、活动率无关的判据切出来（S/N、有无 RV），在子样本内部重新拟合内盘曲线，
再看该子样本自己的外盘档是否符合这条曲线的延拓。

子样本：
  A 全样本（参照）
  B S/N >= 15（剔除弱谱：外档 S/N 中位只 12.3，弱谱会把活动率拉低）
  C 6D（Gaia RV 有限且 |RV| < 500 km/s）
  D S/N >= 30（若 n 足够）
每个子样本：logit 样条只拟合 |Z| < 400 pc，然后预测 400-600 与 600-1000 pc 并给 Wilson 95%。

输入：data/lamost/dr13/dr13_mstellar_dM.csv + data/gaia/gaia_dr3_mstars.csv
输出：多个图及讨论/lnf_holdout_independent.csv
"""
import io, sys, os
import numpy as np, pandas as pd
from scipy.optimize import minimize
from scipy.special import expit
from astropy.coordinates import SkyCoord
import astropy.units as un

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
OUT = r'C:\Users\lingz\Desktop\复现老师工作\APJS\多个图及讨论'

def save(df, name, comments):
    fp = os.path.join(OUT, name)
    df.to_csv(fp, index=False, encoding='utf-8')
    txt = open(fp, encoding='utf-8').read()
    with open(fp, 'w', encoding='utf-8-sig') as f:
        f.write('\n'.join('# ' + c for c in comments) + '\n' + txt)
    print('  写出 %s（%d 行）' % (name, len(df)))

def wilson(k, n, z=1.96):
    if n == 0: return (np.nan, np.nan)
    p = k/n; d = 1 + z*z/n; c = (p + z*z/(2*n))/d
    h = z*np.sqrt(p*(1-p)/n + z*z/(4*n*n))/d
    return (100*(c-h), 100*(c+h))

cat = pd.read_csv('data/lamost/dr13/dr13_mstellar_dM.csv', low_memory=False,
                  usecols=['uid','subclass','teff','ewha','ewha_err','snrr',
                           'ra','dec','gaia_source_id','gaia_g_mean_mag'])
cat = cat[(cat.ewha > -20) & (cat.ewha <= 50) & (cat.ewha_err > 0) & (cat.ewha_err <= 5)].copy()
cat['active'] = (cat.ewha >= 0.75) & (cat.ewha > 3*cat.ewha_err)
cat['gaia_source_id'] = pd.to_numeric(cat.gaia_source_id, errors='coerce')
g = pd.read_csv('data/gaia/gaia_dr3_mstars.csv', low_memory=False,
                usecols=['source_id','parallax','parallax_error','ruwe','radial_velocity'])
m = cat.merge(g, left_on='gaia_source_id', right_on='source_id', how='inner')
m = m[(m.parallax > 0.2) & (m.parallax/m.parallax_error > 5) & (m.ruwe < 1.4)].copy()
u = m.sort_values('ewha', ascending=False).drop_duplicates('uid').copy()
u['MG'] = u.gaia_g_mean_mag.values - 5*np.log10(np.clip(1000.0/u.parallax.values, 1, None)) + 5
u = u[u.MG >= 6].copy()
d_pc = 1000.0/u.parallax.values
sc = SkyCoord(ra=u.ra.values*un.deg, dec=u.dec.values*un.deg, distance=d_pc*un.pc, frame='icrs')
u['absz'] = np.abs(d_pc*np.sin(np.deg2rad(sc.galactic.b.deg)))
u = u[u.absz <= 3000].copy()
u['snrr'] = pd.to_numeric(u.snrr, errors='coerce')
u['rv'] = pd.to_numeric(u.radial_velocity, errors='coerce')
print('母样本 %d 颗' % len(u))

def fit_predict(s, tag):
    z = s.absz.values/1000.0; y = s.active.values.astype(float)
    inner = z < 0.4
    zi, yi = z[inner], y[inner]
    if len(zi) < 500 or yi.sum() < 50:
        print('  %-12s 内盘样本不足（n=%d）' % (tag, len(zi))); return []
    X = [np.ones_like(zi), zi]
    for k0 in (0.05, 0.1, 0.2, 0.4):
        X.append(np.clip(zi-k0, 0, None))
    X = np.column_stack(X)
    def nll(b):
        p = expit(np.clip(X @ b, -30, 30))
        return -float((yi*np.log(np.clip(p,1e-12,1)) + (1-yi)*np.log(np.clip(1-p,1e-12,1))).sum())
    def gr(b):
        p = expit(np.clip(X @ b, -30, 30))
        return -(X.T @ (yi - p))
    b0 = np.zeros(X.shape[1]); b0[0] = np.log(max(yi.mean(),1e-6)/(1-max(yi.mean(),1e-6)))
    r = minimize(nll, b0, method='BFGS', jac=gr, options=dict(maxiter=4000, gtol=1e-9))
    out = []
    print('  %-12s 内盘 n=%6d 活动率 %.2f%%（拟合 %d 参数，nll=%.1f）'
          % (tag, len(zi), 100*yi.mean(), X.shape[1], r.fun))
    for lo_, hi_, nm in [(400,600,'400-600'), (600,1000,'600-1000'), (0,400,'<400 复核')]:
        sel = (s.absz.values > lo_) & (s.absz.values <= hi_)
        if sel.sum() == 0: continue
        Xo = [np.ones(sel.sum()), z[sel]]
        for k0 in (0.05, 0.1, 0.2, 0.4):
            Xo.append(np.clip(z[sel]-k0, 0, None))
        pred = 100*expit(np.clip(np.column_stack(Xo) @ r.x, -30, 30)).mean()
        k = int(y[sel].sum()); n = int(sel.sum()); meas = 100*k/n
        lo, hi = wilson(k, n)
        ratio = meas/pred if pred > 0 else np.nan
        inside = (lo <= pred <= hi)
        print('      %-9s n=%6d  pred %6.2f%%  实测 %6.2f%% [%.2f, %.2f]  比值 %5.2f  预测%s落在实测区间内'
              % (nm, n, pred, meas, lo, hi, ratio, '' if inside else '不'))
        out.append(dict(subsample=tag, zbin=nm, n=n, pred=pred, meas=meas, lo=lo, hi=hi,
                        ratio=ratio, pred_in_meas_ci=bool(inside)))
    return out

rows = []
for tag, sel in [('A 全样本', np.ones(len(u), bool)),
                 ('B S/N>=15', (u.snrr >= 15).values),
                 ('C 6D(RV)', (np.isfinite(u.rv) & (np.abs(u.rv) < 500)).values),
                 ('D S/N>=30', (u.snrr >= 30).values)]:
    s = u[sel]
    if len(s) < 1000:
        print('  %-12s n=%d 太少，跳过' % (tag, len(s))); continue
    print('\n%s：n = %d，活动率 %.2f%%，|Z| 中位 %.0f pc，S/N 中位 %.1f'
          % (tag, len(s), 100*s.active.mean(), s.absz.median(), s.snrr.median()))
    rows += fit_predict(s, tag)

save(pd.DataFrame(rows), 'lnf_holdout_independent.csv', [
    's587：独立子样本留出——每个子样本内部只用 |Z|<400 pc 拟合 logit 样条，再预测自己的外盘档',
    '子样本判据（S/N、有无 RV）与 |Z| 分档无关，故六档自洽检验的循环性问题被避开',
    'pred_in_meas_ci = 预测值是否落在实测的 Wilson 95% 区间内；ratio = meas/pred',
    '生成脚本：代码/s587_holdout_independent.py'])
print('\ns587 完成')
