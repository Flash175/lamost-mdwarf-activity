# -*- coding: utf-8 -*-
"""图5 终版 v4：严格样本(nss=0 + 别名交叉验证 + 去M3/M4边界 + ruwe<1.4)两面板出图。
输出 figures/dr13_fig5_rha_rossby.png（覆盖，旧图进 _superseded/）与单面板变体、稳健性表 v4。"""
import io, os, sys, shutil, glob
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
import numpy as np, pandas as pd
from scipy.spatial import cKDTree
from scipy.optimize import minimize
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt

cat = pd.read_csv('data/lamost/dr13/dr13_mstellar_dM.csv', low_memory=False,
                  usecols=['uid','designation','subclass','ewha','ewha_err','teff','ra','dec','gaia_source_id'])
for c in ('ewha','ewha_err','teff','ra','dec'): cat[c] = pd.to_numeric(cat[c], errors='coerce')
cat['ewha_err'] = cat.ewha_err.abs()
cat = cat[(cat.ewha > -20) & (cat.ewha <= 50) & (cat.ewha_err > 0) & (cat.ewha_err <= 5)]
span = cat.groupby('uid').subclass.agg(lambda s: set(str(x).strip() for x in s))
border = set(span[span.apply(lambda s: ('dM3' in s) and ('dM4' in s))].index)
star = cat.loc[cat.groupby('uid').ewha.idxmax()].dropna(subset=['ra','dec']).copy()
star['spt'] = star.subclass.astype(str).str.strip(); star['border34'] = star.uid.isin(border)

v = pd.read_csv('repro/_vsx/VSX_catalog_sample.csv', low_memory=False, usecols=['Type','Period','RAJ2000','DEJ2000'])
v['Period'] = pd.to_numeric(v.Period, errors='coerce')
v = v[v.Period.gt(0) & v.RAJ2000.notna() & v.DEJ2000.notna()]
v = v[v.Type.astype(str).str.upper().str.contains('ROT')]
def uv(ra, dec):
    ra = np.radians(np.asarray(ra, float)); dec = np.radians(np.asarray(dec, float))
    return np.column_stack([np.cos(dec)*np.cos(ra), np.cos(dec)*np.sin(ra), np.sin(dec)])
tree = cKDTree(uv(star.ra.values, star.dec.values))
dist, idx = tree.query(uv(v.RAJ2000.values, v.DEJ2000.values), k=1, distance_upper_bound=np.radians(3/3600))
ok = np.isfinite(dist) & (idx < len(star))
vs = pd.DataFrame({'idx': idx[ok], 'P': v.Period.values[ok]}).drop_duplicates('idx')
S = star.iloc[vs.idx.values].copy(); S['P'] = vs.P.values; S['src'] = 'VSX'; S['fP'] = 0.075
fe = pd.read_csv('data/processed/dr13/dr13_fig5_sample.csv', low_memory=False, usecols=['designation','P'])
fe['designation'] = fe.designation.astype(str)
F = star[star.designation.astype(str).isin(set(fe.designation)) & ~star.uid.isin(set(S.uid))].merge(
    fe.drop_duplicates('designation'), on='designation', how='inner')
F['src'] = 'Fetherolf'; F['fP'] = 0.03
cols = ['uid','designation','spt','ewha','ewha_err','teff','P','src','fP','gaia_source_id','border34']
A = pd.concat([S[cols], F[cols]], ignore_index=True)
print('周期样本：%d（VSX %d + Fetherolf %d）' % (len(A), len(S), len(F)))

g = pd.read_csv('data/gaia/gaia_dr3_mstars.csv', low_memory=False, usecols=lambda c: c in {'source_id','ruwe'})
g['sid'] = g.source_id.astype('int64').astype(str)
A['sid'] = A.gaia_source_id.astype(str).str.split('.').str[0]
A = A.merge(g[['sid','ruwe']], on='sid', how='left')
fin = pd.read_csv('data/processed/dr13/fig5_sample_final.csv', low_memory=False,
                  usecols=['uid','non_single_star','alias_flag'])
A = A.merge(fin.drop_duplicates('uid'), on='uid', how='left')
A['non_single_star'] = pd.to_numeric(A.non_single_star, errors='coerce')
A['alias_flag'] = A.alias_flag.fillna(False).astype(str).str.lower().isin(['true', '1', '1.0'])
A['border34'] = A.border34.fillna(False).astype(bool)
print('nss 分布：', A.non_single_star.fillna(-1).value_counts().to_dict(), ' 别名星：', int(A.alias_flag.fillna(False).sum()))

c2 = pd.read_csv('data/vizier/apjs274_36_mdwarfs.csv', low_memory=False, usecols=lambda c: c in {'EWHa','RHa','Teff','Mstar'})
c3 = c2[(c2.EWHa > 0.1) & (c2.RHa > 0) & (c2.Teff > 2800) & (c2.Teff < 4600)].copy(); c3['chi'] = c3.RHa/c3.EWHa
bins = np.arange(2800, 4601, 100); cent = 0.5*(bins[1:]+bins[:-1]); c3['b'] = np.digitize(c3.Teff, bins)
chi_med = np.array([c3.loc[c3.b == i, 'chi'].median() for i in range(1, len(bins))])
cm = c2[(c2.Teff > 2800) & (c2.Teff < 4600) & (c2.Mstar > 0.05) & (c2.Mstar < 0.8)]
coef = np.polyfit(cm.Teff, cm.Mstar, 2)
A['chi'] = np.interp(A.teff, cent, chi_med)
A['M'] = np.clip(np.polyval(coef, A.teff.values), 0.08, 0.75)
A['Ro'] = A.P / (10 ** (2.33 - 1.5*A.M - 0.30*A.M**2))
A['RHa'] = A.chi * A.ewha
A['sRo'] = A.Ro * np.sqrt(A.fP**2 + 0.10**2)
A['sRHa'] = np.sqrt((A.chi*A.ewha_err)**2 + (0.10*A.RHa)**2)
A = A[(A.Ro > 0) & (A.RHa > 0)]

R_SAT_FIX = 0.132   # 定稿口径：全体与各面板都固定此断点（2026-11-03 改；原为 401 点自由搜索）
def ols(d):
    """固定断点 0.132 的分段拟合：饱和段取自由常数、非饱和段最小二乘直线。
    返回 (R_SAT_FIX, slope)，保持与原自由搜索版的返回契约一致，故下游全部沿用。"""
    x, y = np.log10(d.Ro.values), np.log10(d.RHa.values)
    rs = np.log10(R_SAT_FIX)
    s, u = x <= rs, x > rs
    if s.sum() < 20 or u.sum() < 20:
        raise RuntimeError('固定断点下样本不足：sat=%d, unsat=%d' % (s.sum(), u.sum()))
    sl, ic = np.polyfit(x[u], y[u], 1)
    return R_SAT_FIX, sl
def wls(d):
    x, y = np.log10(d.Ro.values), np.log10(d.RHa.values)
    w = 1/np.maximum(d.sRHa.values/np.maximum(d.RHa.values, 1e-12)/np.log(10), 1e-3)**2
    best = None
    for rs in np.linspace(-1.1, -0.4, 401):
        s, u = x <= rs, x > rs
        if s.sum() < 20 or u.sum() < 20: continue
        rss = (w[s]*(y[s]-np.average(y[s], weights=w[s]))**2).sum()
        M2 = np.vstack([np.ones_like(x[u]), x[u]]).T; W = np.diag(w[u])
        b = np.linalg.lstsq(M2.T@W@M2, M2.T@W@y[u], rcond=None)[0]
        rss += (w[u]*(y[u]-M2@b)**2).sum()
        if best is None or rss < best[0]: best = (rss, 10**rs, b[1])
    return best[1], best[2]
def ml(d):
    x, y = np.log10(d.Ro.values), np.log10(d.RHa.values)
    sy = np.maximum(d.sRHa.values/np.maximum(d.RHa.values, 1e-12)/np.log(10), 0.02)
    def nll(p):
        lrs, beta, c, lsi = p; si = np.exp(lsi)
        m = np.where(x <= lrs, c, c + beta*(x-lrs)); v = sy**2 + si**2
        return 0.5*np.sum((y-m)**2/v + np.log(v))
    best = None
    for l0 in (-1.0, -0.85, -0.7):
        r = minimize(nll, [l0, -0.7, np.median(y), np.log(0.3)], method='Nelder-Mead',
                     bounds=[(-1.30, -0.50), (-1.60, 0.10), (-9.0, 0.0), (-4.0, 0.0)],
                     options={'maxiter': 5000, 'xatol': 1e-4, 'fatol': 1e-6})
        if best is None or r.fun < best.fun: best = r
    return 10**best.x[0], best.x[1], np.exp(best.x[3])
def boot(d, n=200, seed=20261017):
    rng = np.random.default_rng(seed); out = []
    for _ in range(n):
        q = d.iloc[rng.integers(0, len(d), len(d))]
        try: out.append(ols(q)[1])
        except Exception: pass
    return float(np.std(out))

def dealias(d):
    m = np.ones(len(d), bool)
    for t in (0.5, 1.0, 2.0): m &= ~(np.abs(d.P.values/t - 1) < 0.05)
    return d[m]
ruwe_ok = lambda d: d[(d.ruwe.isna()) | (d.ruwe < 1.4)]
chain = [('① 原始周期样本(含双星/别名/M3-M4边界)', A),
         ('② 去别名(P 不在 0.5/1/2 d ±5%)', dealias(A)),
         ('③ + ruwe<1.4(保留缺值)', ruwe_ok(dealias(A))),
         ('④ + 去 M3/M4 边界星', ruwe_ok(dealias(A))[~ruwe_ok(dealias(A)).border34]),
         ('⑤ + non_single_star=0 且 Ro<=3   ← 采用', None)]
strict = ruwe_ok(dealias(A))
strict = strict[(strict.non_single_star.fillna(0) == 0) & (strict.Ro <= 3)
                & (~strict.border34) & (~strict.alias_flag.fillna(False))]
chain[-1] = ('⑤ + nss=0 + VSX/TESS 交叉验证非别名 + Ro<=3   ← 采用', strict)
relax = dealias(A)[(dealias(A).non_single_star.fillna(0) == 0) & (dealias(A).Ro <= 3)
                  & (~dealias(A).alias_flag.fillna(False))]
chain.insert(-1, ('⑤′ nss=0 + 交叉验证别名 + Ro<=3（不做 ruwe/边界 = 此前 4,563 口径）', relax))
rows = []
for tag, d in chain:
    if d is None or len(d) < 100: continue
    a1, b1 = ols(d); a2, b2 = wls(d); a3, b3, si = ml(d)
    rows.append((tag, len(d), a1, b1, a2, b2, a3, b3, si))
t = pd.DataFrame(rows, columns=['样本','n','Ro_sat OLS','β OLS','Ro_sat WLS','β WLS','Ro_sat ML','β ML','σ_int'])
print(t.round(3).to_string(index=False))
t.to_csv('data/processed/dr13/fig5_robustness_v4.csv', index=False)
ro1, b1 = ols(strict); ro2, b2 = wls(strict); ro3, b3, si = ml(strict)
eb = boot(strict)
print('\n严格样本 n=%d：β(OLS)=%.3f (bootstrap ±%.3f)  β(WLS)=%.3f  β(ML)=%.3f  Ro_sat(ML)=%.3f  σ_int=%.2f dex'
      % (len(strict), b1, eb, b2, b3, ro3, si))

_r1, _b1 = ols(relax); _r3, _b3, _ = ml(relax)
RELAX = '%.3f (OLS) / %.3f (ML)' % (_b1, _b3)
print('对照口径（不做 ruwe/边界，n=%d）：β(OLS)=%.3f  β(ML)=%.3f' % (len(relax), _b1, _b3))

PAN = [('M0–M3', ['dM0','dM1','dM2','dM3']), ('M4–M6', ['dM4','dM5','dM6'])]
res = {}
for nm, sel in PAN:
    q = strict[strict.spt.isin(sel)]
    ro1, p1 = ols(q); rm1, p2, si1 = ml(q)
    e1 = boot(q, n=120)
    res[nm] = (len(q), p1, e1, ro1, p2, rm1, si1)
    print('  %s: n=%d  β(OLS)=%.3f±%.3f  Ro_sat(OLS)=%.3f | β(ML)=%.3f  Ro_sat(ML)=%.3f  σ_int=%.2f'
          % (nm, len(q), p1, e1, ro1, p2, rm1, si1))

def draw(q, ax, title, note):
    ax.errorbar(q.Ro, q.RHa, xerr=q.sRo, yerr=q.sRHa, fmt='o', ms=3.0, lw=0, elinewidth=0.35,
                alpha=0.5, color='#1f4fd8', capsize=0, zorder=2)
    xs1 = np.logspace(-3, np.log10(note['rs']), 40)
    xs2 = np.logspace(np.log10(note['rs']), np.log10(3), 40)
    ys = np.median(q.RHa[q.Ro <= note['rs']])
    ax.plot(xs1, np.full_like(xs1, ys), c='C3', lw=1.9, zorder=3)
    ax.plot(xs2, ys/note['rs']**note['b']*xs2**note['b'], c='C3', lw=1.9, zorder=3)
    ax.axvline(note['rs'], c='C3', ls=':', lw=0.9, alpha=0.7)
    ax.set_xscale('log'); ax.set_yscale('log'); ax.set_xlim(1e-3, 3); ax.set_ylim(1e-8, 1e-2)
    ax.set_xlabel(r'$R_{\rm o}=P_{\rm rot}/\tau$', fontsize=10)
    ax.set_ylabel(r"$R'_{\rm H\alpha}=\chi(T_{\rm eff})\cdot{\rm EW(H\alpha)}$", fontsize=10)
    ax.set_title(title, fontsize=10)
    ax.text(0.035, 0.965, note['txt'], transform=ax.transAxes, va='top', fontsize=7.4,
            bbox=dict(fc='white', ec='C3', lw=0.8, pad=3), zorder=5)
    ax.tick_params(direction='in', top=True, right=True, labelsize=8.5)

FOOT = ("Sample: LAMOST DR13 M dwarfs with VSX ROT or Fetherolf+2023 periods (3 arcsec match, n=%d).\n"
        "Removed: Gaia non_single_star != 0, alias periods within 5%% of 0.5/1/2 d, M3/M4 border stars, Ro > 3 "
        "(fitted n=%d).  Error bars: period precision (VSX 7.5%%, Fetherolf 3%%) + 10%% mass/tau; "
        "R'Halpha from EW error + 10%% chi(Teff).") % (len(A), len(strict))

fig, axes = plt.subplots(1, 2, figsize=(10.6, 4.7))
for ax, (nm, sel) in zip(axes, PAN):
    q = strict[strict.spt.isin(sel)]
    n_, b_o, e_o, ro_o, b_ml, ro_ml, si1 = res[nm]
    draw(q, ax, '%s  (n=%d)' % (nm, n_), dict(rs=ro_o, b=b_o,
         txt='β(OLS)=%.2f ± %.2f\nβ(ML)=%.2f\nRo$_{sat}$=%.3f\nσ$_{int}$=%.2f dex' % (b_o, e_o, b_ml, ro_o, si1)))
fig.suptitle("LAMOST DR13 M dwarfs: chromospheric activity vs. Rossby number (reproduction of Fig. 5)",
             fontsize=10.5, y=0.995)
fig.text(0.5, 0.958, 'adopted strict sample: N=%d,  β(OLS)=%.3f±%.3f,  β(ML)=%.3f,  Ro$_{sat}$=%.3f,  σ$_{int}$=%.2f dex'
         % (len(strict), b1, eb, b3, ro3, si), ha='center', va='top', fontsize=8.4, color='0.15')
fig.text(0.5, 0.912, 'relaxed cuts (N=%d, without ruwe/border cuts): β=%s   |   paper (Li et al. 2024): β=−0.91±0.16, Ro$_{sat}$=0.19±0.06'
         % (len(relax), RELAX), ha='center', va='top', fontsize=8.4, color='0.15')
fig.text(0.5, 0.008, FOOT, ha='center', va='bottom', fontsize=6.2, color='0.3', linespacing=1.5)
fig.tight_layout(rect=(0, 0.075, 1, 0.885))
if os.path.exists('figures/dr13_fig5_rha_rossby.png'):
    os.makedirs('figures/_superseded', exist_ok=True)
    shutil.copy2('figures/dr13_fig5_rha_rossby.png', 'figures/_superseded/dr13_fig5_rha_rossby_v3_ruwe.png')
fig.savefig('figures/dr13_fig5_rha_rossby.png', dpi=180); plt.close(fig)
print('两面板 -> figures/dr13_fig5_rha_rossby.png')

fig, ax = plt.subplots(figsize=(6.4, 5.0))
draw(strict, ax, 'LAMOST DR13 M dwarfs (n=%d)' % len(strict), dict(rs=ro1, b=b1,
     txt='β(OLS)=%.2f ± %.2f\nβ(ML)=%.2f\nRo$_{sat}$=%.3f\nσ$_{int}$=%.2f dex' % (b1, eb, b3, ro1, si)))
fig.text(0.5, 0.008, FOOT, ha='center', va='bottom', fontsize=5.4, color='0.3', linespacing=1.5)
fig.tight_layout(rect=(0, 0.10, 1, 1))
fig.savefig('figures/dr13_fig5_rha_rossby_strict.png', dpi=180); plt.close(fig)
print('单面板 -> figures/dr13_fig5_rha_rossby_strict.png')
pd.DataFrame([dict(panel=k, n=v[0], beta_ols=v[1], beta_ols_err=v[2], beta_ml=v[4], sigma_int=v[6],
                       panel_ro_sat_ols=v[3], panel_ro_sat_ml=v[5]) for k, v in res.items()]).assign(
              full_n=len(strict), full_ro_sat_ols=ro1, full_beta_ols=b1, full_beta_ols_err=eb,
              full_beta_ml=b3, full_ro_sat_ml=ro3, full_sigma_int=si).to_csv(
    'data/processed/dr13/fig5_panel_fits_v4.csv', index=False)
print('表 -> data/processed/dr13/fig5_panel_fits_v4.csv')
COL = ['uid','designation','spt','teff','P','src','ruwe','non_single_star','alias_flag','border34',
       'M','chi','Ro','sRo','RHa','sRHa','ewha','ewha_err']
strict[COL].to_csv('data/processed/dr13/fig5_sample_strict_v4.csv', index=False)
relax[COL].to_csv('data/processed/dr13/fig5_sample_relaxed_v4.csv', index=False)
A[COL].to_csv('data/processed/dr13/fig5_sample_period_v4.csv', index=False)
print('逐星样本 -> %d(周期全量) / %d(⑤′) / %d(⑤)' % (len(A), len(relax), len(strict)))
assert strict.uid.is_unique and relax.uid.is_unique and A.uid.is_unique, 'uid 重复'
assert not strict[['Ro','sRo','RHa','sRHa']].isna().any().any(), '严格样本存在 NaN'

