
# -*- coding: utf-8 -*-
"""关键检验：按亚型分层的 f_act(|Z|)——|Z| 趋势是不是亚型混合造成的？"""
import io, sys
import numpy as np, pandas as pd
from astropy.coordinates import SkyCoord
import astropy.units as un
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')

cat = pd.read_csv('data/lamost/dr13/dr13_mstellar_dM.csv', low_memory=False,
                  usecols=['uid','subclass','teff','ewha','ewha_err','snrr','ra','dec','gaia_source_id','gaia_g_mean_mag'])
cat = cat[(cat.ewha > -20) & (cat.ewha <= 50) & (cat.ewha_err > 0) & (cat.ewha_err <= 5)].copy()
cat['active'] = (cat.ewha >= 0.75) & (cat.ewha > 3*cat.ewha_err)
cat = cat.sort_values('ewha', ascending=False).drop_duplicates('uid')
print('逐星（取最大 EW 的一条谱）: %d 颗' % len(cat))

g = pd.read_csv('data/gaia/gaia_dr3_mstars.csv', low_memory=False, usecols=['source_id','parallax','parallax_error','ruwe'])
g['sid'] = pd.to_numeric(g.source_id, errors='coerce')
cat['sid'] = pd.to_numeric(cat.gaia_source_id, errors='coerce')
M = cat.merge(g[['sid','parallax','parallax_error','ruwe']], on='sid', how='left')
M = M[(M.parallax > 0.2) & (M.parallax/M.parallax_error > 5) & (M.ruwe < 1.4)].copy()
print('Gaia 质量后: %d 颗' % len(M))
c = SkyCoord(ra=M.ra.values*un.deg, dec=M.dec.values*un.deg, distance=(1000.0/M.parallax.values)*un.pc, frame='icrs')
M['absz'] = np.abs(c.galactic.b.to(un.deg).value)
M['dist_pc'] = 1000.0/M.parallax.values
M['absz_pc'] = M.dist_pc*np.abs(np.sin(np.radians(M.absz)))
M['zb'] = pd.cut(M.absz_pc, [0,100,200,400,3000], labels=['<100','100-200','200-400','>400'])

print('\n=== 合并（不控亚型）===')
for b in ['<100','100-200','200-400','>400']:
    s = M[M.zb == b]
    print('  %-8s n=%6d  活动率 %.2f%%' % (b, len(s), 100*s.active.mean()))

print('\n=== 按亚型分层：每格 活动率%（n）===')
rows=[]
for sp in ['dM0','dM1','dM2','dM3','dM4','dM5','dM6','dM7']:
    s = M[M.subclass == sp]
    line = '  %-4s' % sp
    rec = dict(subclass=sp)
    for b in ['<100','100-200','200-400']:
        q = s[s.zb == b]
        if len(q) >= 50:
            line += '  %s: %5.1f%% (n=%5d)' % (b, 100*q.active.mean(), len(q))
            rec[b] = 100*q.active.mean(); rec['n_'+b] = len(q)
        else:
            line += '  %s:    --  (n=%5d)' % (b, len(q)); rec[b] = np.nan; rec['n_'+b] = len(q)
    print(line); rows.append(rec)
T = pd.DataFrame(rows)
T.to_csv('data/processed/dr13/fact_by_subtype_and_Z.csv', index=False, encoding='utf-8-sig')

print('\n=== 亚型组成随 |Z| 的变化（%）===')
for b in ['<100','100-200','200-400']:
    s = M[M.zb == b]
    comp = s.subclass.value_counts(normalize=True).mul(100).round(1)
    print('  %-8s n=%6d  ' % (b, len(s)) + '  '.join('%s %.0f%%' % (k, v) for k, v in comp.head(6).items()))
