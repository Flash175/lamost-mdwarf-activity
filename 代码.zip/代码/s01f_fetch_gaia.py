"""
Step 1f：按 Gaia DR3 source_id 批量取天体测量（Gaia 归档 TAP sync）
==================================================================
本机实测：ESAC TAP 的 UPLOAD（votable 上传）在本网络下不可用（ReadTimeout / RemoteDisconnected），
但同步 doQuery 直接可用。因此这里用 source_id IN (...) 分批查询。

输入：任一含 gaia_source_id 列的 CSV（默认 LAMOST DR10 dM 星表 dump）
输出：data/gaia/gaia_batches/batch_XXXXX.csv，可断点续传（已存在的批跳过）

用法：
  python repro/src/s01f_fetch_gaia.py --input data/lamost/dr10_mstellar_dM.csv --workers 6 --batch 500
  python repro/src/s01f_fetch_gaia.py --merge --out data/gaia/gaia_dr3_mstars.csv
"""
from __future__ import annotations

import argparse
import glob
import io
import os
import sys
import threading
import time
from concurrent.futures import ThreadPoolExecutor

import pandas as pd
import requests

TAP = "https://gea.esac.esa.int/tap-server/tap/sync"
HEADERS = {"User-Agent": "Mozilla/5.0 (reproduction-pipeline)"}
COLS = ("source_id,ra,dec,parallax,parallax_error,pmra,pmdec,ruwe,phot_g_mean_mag,"
        "bp_rp,teff_gspphot,radial_velocity")
PRINT_LOCK = threading.Lock()


def log(msg: str) -> None:
    with PRINT_LOCK:
        print(f"[{time.strftime('%H:%M:%S')}] {msg}", flush=True)


def gaia_query(ids, timeout=300, retries=4):
    sql = f'SELECT {COLS} FROM gaiadr3.gaia_source WHERE source_id IN ({",".join(str(i) for i in ids)})'
    for i in range(retries):
        try:
            r = requests.post(TAP, data={"REQUEST": "doQuery", "LANG": "ADQL", "FORMAT": "csv", "QUERY": sql},
                              timeout=timeout, headers=HEADERS)
            if r.status_code == 200 and not r.text.lstrip().startswith("<?xml"):
                return r.text
            detail = r.text[:120].replace("\n", " ")
        except Exception as exc:
            detail = f"{type(exc).__name__}: {str(exc)[:100]}"
        if i < retries - 1:
            time.sleep(4 + 6 * i)
    log(f"批失败（{len(ids)} 个 id）：{detail}")
    return None


def run(args):
    os.makedirs(args.outdir, exist_ok=True)
    log(f"读取 {args.input}")
    # 注意：source_id 是 19 位整数，用 float 读会丢精度（实测命中率从 99.6% 掉到 25%），必须按字符串读
    df = pd.read_csv(args.input, usecols=["gaia_source_id"], dtype={"gaia_source_id": str}, low_memory=False)
    raw = df["gaia_source_id"].fillna("").str.strip()
    raw = raw[raw.str.fullmatch(r"\d{15,19}")]
    ids = sorted({int(v) for v in raw})     # 用 python int，避免 numpy 精度问题
    log(f"唯一 Gaia source_id：{len(ids)}（原始 {len(df)} 行）")
    batches = [ids[i:i + args.batch] for i in range(0, len(ids), args.batch)]
    ids = None  # 释放
    log(f"批次：{len(batches)} × {args.batch}")

    lock = threading.Lock()
    counter = {"done": 0, "skip": 0, "rows": 0}

    def work(item):
        idx, chunk = item
        dest = os.path.join(args.outdir, f"batch_{idx:05d}.csv")
        if os.path.exists(dest) and os.path.getsize(dest) > 0:
            with lock:
                counter["skip"] += 1
            return
        txt = gaia_query(chunk)
        if txt is None:
            return
        with open(dest, "w", encoding="utf-8", newline="") as fh:
            fh.write(txt)
        with lock:
            counter["done"] += 1
            counter["rows"] += max(0, len(txt.splitlines()) - 1)
            if counter["done"] % 20 == 0:
                log(f"进度：完成 {counter['done']}/{len(batches)} 批，跳过 {counter['skip']}，累计 {counter['rows']} 行")

    with ThreadPoolExecutor(max_workers=args.workers) as ex:
        list(ex.map(work, list(enumerate(batches))))
    log(f"结束：完成 {counter['done']} 批 / 跳过 {counter['skip']} / 命中 {counter['rows']} 行")


def merge(outdir, out):
    files = sorted(glob.glob(os.path.join(outdir, "batch_*.csv")))
    log(f"合并 {len(files)} 批 -> {out}")
    first = True
    with open(out, "w", encoding="utf-8", newline="") as fo:
        for f in files:
            with open(f, encoding="utf-8") as fi:
                head = fi.readline()
                if first:
                    fo.write(head)
                    first = False
                for line in fi:
                    fo.write(line)
    n = sum(1 for _ in open(out, encoding="utf-8")) - 1
    log(f"合并完成 {out} 行数={n}")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--input", default="data/lamost/dr10_mstellar_dM.csv")
    ap.add_argument("--outdir", default="data/gaia/gaia_batches")
    ap.add_argument("--batch", type=int, default=500)
    ap.add_argument("--workers", type=int, default=6)
    ap.add_argument("--merge", action="store_true")
    ap.add_argument("--out", default="data/gaia/gaia_dr3_mstars.csv")
    args = ap.parse_args()
    if args.merge:
        merge(args.outdir, args.out)
    else:
        run(args)


if __name__ == "__main__":
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")
    main()
