# -*- coding: utf-8 -*-
"""s583：扫描正文里所有「X 颗（Y 活动）」型计数，与 CSV 的 (n, n_act) 对照。"""
import io, sys, os, re
import pandas as pd
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
OUT = r'C:\Users\lingz\Desktop\复现老师工作\APJS\多个图及讨论'
text = open(os.path.join(OUT,'新一节_银盘示踪_中文草稿.md'), encoding='utf-8').read()

pairs = set()
def add(n, k): pairs.add((int(n), int(k)))
for f, cols in [('新图1_数据_6D分箱.csv', ('n','n_act')),
                ('far400_2d_audit.csv', ('n','n_act')),
                ('far400_2d_audit_备份_含哨兵.csv', ('n','n_act'))]:
    try:
        d = pd.read_csv(os.path.join(OUT,f), comment='#')
        for _, r in d.iterrows():
            try: add(r[cols[0]], r[cols[1]])
            except Exception: pass
    except Exception as e:
        print('  跳过', f, e)
for f in ['far400_6d_properties.csv','far400_6d_properties_备份_含哨兵.csv']:
    try:
        d = pd.read_csv(os.path.join(OUT,f), comment='#')
        add(d.n.iloc[0], d.n_act.iloc[0])
    except Exception: pass
# 另加已知的成对值（2D >400 与 6D 各口径）
for a,b in [(99684,7090),(99368,7029),(98692,6932),(98666,6928),(316,61),(320,62),(267,213),(1728,1376)]:
    add(a,b)

pat = re.compile(r'([\d,]{1,7})\s*颗\s*[（(]\s*([\d,]{1,7})\s*活')
hits = []
for m in pat.finditer(text):
    n, k = int(m.group(1).replace(',','')), int(m.group(2).replace(',',''))
    hits.append((n, k, text[max(0,m.start()-60):m.end()+20].replace('\n',' ')))
print('扫描到「X 颗（Y 活动）」计数：%d 处' % len(hits))
bad = [h for h in hits if (h[0], h[1]) not in pairs]
for n,k,ctx in hits:
    flag = '✓' if (n,k) in pairs else '✗'
    print('  %s %s 颗（%s 活动）  …%s' % (flag, format(n,','), format(k,','), ctx[:70]))
print('\n可疑 %d 处' % len(bad))
