"""
活动性统计工具：活动比例、二项置信区间、ΔEW 变化判据、R'Hα 与 Rossby 数拟合。

复现依据：
  论文A §3.1：活动比例 = N_active/(N_active+N_inactive)；
              ΔEW = EW_max - EW_min > k·sqrt(σ_max²+σ_min²)（Bell et al. 2012；PDF 中根号丢失）
  论文A §3.2：χ_Hα = F_Hα/(σ_SB·T_eff⁴)，R'Hα = χ_Hα·EW_Hα；Ro = P/τ；
              分段回归在 [0.08, 0.4] 取 100 个候选饱和点，取最小二乘误差最小者
  论文B §3.4-3.5：Ro = P/τ，τ 的质量标定见下方 TAU_COEF（统一采用 Li et al. 2024 印刷式 −0.30）；
              Ro_sat=0.18±0.03，斜率 -0.56±0.07
"""
from __future__ import annotations

from dataclasses import dataclass

import numpy as np
from scipy import stats

SIGMA_SB = 5.670374419e-5  # erg s^-1 cm^-2 K^-4


# ---------------------------------------------------------------- 活动比例
def active_fraction(n_active: int, n_total: int) -> float:
    """f_active = N_active / (N_active + N_inactive)。"""
    return float(n_active) / float(n_total) if n_total else float("nan")


def binomial_ci(k: int, n: int, level: float = 0.68, method: str = "clopper-pearson"):
    """
    二项分布置信区间（论文A/B 用 68% 置信区间，引自 Pineda et al. 2013）。

    method:
      'clopper-pearson' —— 精确区间（默认，最保守，推荐）
      'wilson'          —— Wilson 得分区间
      'normal'          —— 正态近似 sqrt(p(1-p)/n)，Pineda 等人常用
    """
    if n == 0:
        return (float("nan"), float("nan"))
    alpha = 1.0 - level
    if method == "clopper-pearson":
        lo = 0.0 if k == 0 else stats.beta.ppf(alpha / 2, k, n - k + 1)
        hi = 1.0 if k == n else stats.beta.ppf(1 - alpha / 2, k + 1, n - k)
        return (float(lo), float(hi))
    p = k / n
    if method == "normal":
        z = stats.norm.ppf(1 - alpha / 2)
        half = z * np.sqrt(p * (1 - p) / n)
        return (float(max(0.0, p - half)), float(min(1.0, p + half)))
    z = stats.norm.ppf(1 - alpha / 2)
    denom = 1 + z * z / n
    centre = (p + z * z / (2 * n)) / denom
    half = z * np.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / denom
    return (float(max(0.0, centre - half)), float(min(1.0, centre + half)))


# ---------------------------------------------------------------- ΔEW 判据
def delta_ew_variable(ews, errs, k: float = 1.0) -> bool:
    """ΔEW = EW_max - EW_min > k·sqrt(σ_max²+σ_min²)  (Bell et al. 2012)。

    论文 A 式 (6) 里**没有系数**（即 k=1），图 8（repro/src/s85_dr13_fig8.py）用的就是 k=1；
    k=3 是我们自己的更严格对照方案（tests/selfcheck.py 显式传 k=3 做单元测试）。
    """
    ews = np.asarray(ews, dtype=float)
    errs = np.asarray(errs, dtype=float)
    m = np.isfinite(ews) & np.isfinite(errs)
    if m.sum() < 2:
        return False
    ews, errs = ews[m], errs[m]
    i_max, i_min = int(np.argmax(ews)), int(np.argmin(ews))
    d = ews[i_max] - ews[i_min]
    thresh = k * np.sqrt(errs[i_max] ** 2 + errs[i_min] ** 2)
    return bool(d > thresh)


# ---------------------------------------------------------------- R'Hα / Ro
def chi_ha(f_ha_continuum: float, teff: float) -> float:
    """χ_Hα = F_Hα / (σ_SB · T_eff⁴)；F_Hα 为 Hα 处连续谱流量（PHOENIX ACES 模型谱）。"""
    return float(f_ha_continuum) / (SIGMA_SB * float(teff) ** 4)


def r_prime_ha(ew_ha: float, f_ha_continuum: float, teff: float) -> float:
    """R'Hα = χ_Hα · EW_Hα = L_Hα/L_bol。"""
    return chi_ha(f_ha_continuum, teff) * float(ew_ha)


# ---------------------------------------------------------------- τ 标定
#: 对流翻转时标关系的二次项系数。**全文唯一约定，改这一行即全局切换。**
#:
#: 采用 Li et al. (2024, ApJS 274, 36) 的印刷式
#:     log τ = 2.33 - 1.50 (M/Msun) - 0.30 (M/Msun)^2
#: 该文注明此式引自 N. J. Wright et al. (2018)。
#:
#: 但两文并不一致（已核 Wright 原文 arXiv:1807.03304 式(6)）：
#:     Wright et al. (2018) 式(6): log τ = 2.33 - 1.50 M + 0.31 M^2
#:     适用区间 0.08 < M/Msun < 1.36，log τ 的 rms 弥散 0.055 dex
#: 即二次项在 Wright 原文为 **+0.31（加号）**，Li 等人印为 -0.30，
#: **是符号不同，不是末位取整**。此外 Carmenes 团队（2025）指出 W18 式(5)(6)
#: 存在印刷错误，其按 Table 2 重拟合的结果为 2.30 - 1.38M + 0.22M^2。
#:
#: 本文取 Li 的 -0.30，理由是**可比性**：正文要把 Ro_sat 与 Li 等（2024）的
#: 0.19 ± 0.06 直接比较，必须同口径。影响评估（s223，严格样本 n=3,340）：
#:   0.31(负号) -> 0.30：β -0.857 -> -0.855、Ro_sat 自由拟合 0.137 -> 0.135；
#:   若改用 Wright 原式 +0.31：Ro_sat -> 约 0.07-0.09、β -> 约 -0.894，
#:   Ro_sat 近乎减半，与 Li 的比较即失去可比性。
TAU_COEF = 0.30

#: Wright et al. (2018) 式(6) 原值（**正号**）；仅供敏感性对照，不作为采用约定。
TAU_COEF_WRIGHT = +0.31

TAU_A = 1.50


def convective_turnover_log(mass_msun: float, a: float = TAU_A, b: float = TAU_COEF) -> float:
    """log τ = 2.33 - a·m - b·m²（默认取 Li et al. 2024 印刷式，见 TAU_COEF）。"""
    m = float(mass_msun)
    return 2.33 - a * m - b * m * m


def tau_days(mass_msun: float, a: float = TAU_A, b: float = TAU_COEF):
    """τ 本身（天）。"""
    return 10.0 ** convective_turnover_log(mass_msun, a, b)


def rossby_number(period_days: float, mass_msun: float, a: float = TAU_A,
                  b: float = TAU_COEF) -> float:
    """Ro = P / τ。"""
    return float(period_days) / tau_days(mass_msun, a, b)


@dataclass
class SaturationFit:
    ro_sat: float
    ro_sat_err: float
    slope: float          # 饱和区之后的幂律指数 β（log R'Hα = log C + β log Ro）
    slope_err: float
    n_used: int
    method: str


def _segmented_once(x, y, grid, npoints, min_per_side):
    """单次分段回归（内部用）：返回 (ro_sat, slope, rss)；无可行解时 ro_sat=nan。"""
    best = None
    for rs in np.linspace(grid[0], grid[1], npoints):
        sat = x <= np.log10(rs)
        uns = ~sat
        if sat.sum() < min_per_side or uns.sum() < min_per_side:
            continue
        c = y[sat].mean()
        rss = float(np.sum((y[sat] - c) ** 2))
        slope, intercept = np.polyfit(x[uns], y[uns], 1)
        rss += float(np.sum((y[uns] - (slope * x[uns] + intercept)) ** 2))
        if best is None or rss < best[2]:
            best = (float(rs), float(slope), rss)
    return best if best is not None else (float("nan"), float("nan"), float("inf"))


def fit_saturation(
    ro,
    rha,
    grid: tuple[float, float] = (0.08, 0.40),
    npoints: int = 100,
    min_per_side: int = 10,
    n_boot: int = 200,
    seed: int = 20261017,
) -> SaturationFit:
    """
    论文A §3.2 的分段回归：
      在 [0.08, 0.4] 内取 100 个候选饱和点，对每个断点分别做线性拟合，
      选最小二乘误差最小的断点作为 Ro_sat。
    实现细节（论文未说明，此处显式声明）：
      - 拟合在 log10(Ro)–log10(R'Hα) 双对数空间进行（因论文给出的是幂律斜率）
      - 饱和区（Ro<=Ro_sat）取常数模型；非饱和区取线性模型
      - 误差用 bootstrap 估计（论文只报 ±，未说方法）：有放回重采样 n_boot 次，
        每次把整套分段回归重跑一遍，取 Ro_sat / slope 的标准差（n_boot=0 可关掉）
    """
    ro = np.asarray(ro, dtype=float)
    rha = np.asarray(rha, dtype=float)
    m = np.isfinite(ro) & np.isfinite(rha) & (ro > 0) & (rha > 0)
    ro, rha = ro[m], rha[m]
    if ro.size < 2 * min_per_side:
        return SaturationFit(np.nan, np.nan, np.nan, np.nan, int(ro.size), "insufficient")

    x, y = np.log10(ro), np.log10(rha)
    rs, slope, _ = _segmented_once(x, y, grid, npoints, min_per_side)
    if not np.isfinite(rs):
        return SaturationFit(np.nan, np.nan, np.nan, np.nan, int(ro.size), "no-solution")
    rs_err = slope_err = float("nan")
    method = "segmented-regression"
    if n_boot and ro.size >= 2 * min_per_side:
        rng = np.random.default_rng(seed)
        bs, ss = [], []
        for _ in range(int(n_boot)):
            i = rng.integers(0, ro.size, ro.size)
            b_rs, b_slope, _ = _segmented_once(x[i], y[i], grid, npoints, min_per_side)
            if np.isfinite(b_rs):
                bs.append(b_rs); ss.append(b_slope)
        if len(bs) >= max(10, int(n_boot) // 4):
            rs_err = float(np.std(bs, ddof=1)); slope_err = float(np.std(ss, ddof=1))
            method = "segmented-regression+bootstrap(%d/%d)" % (len(bs), int(n_boot))
    return SaturationFit(float(rs), rs_err, float(slope), slope_err, int(ro.size), method)
