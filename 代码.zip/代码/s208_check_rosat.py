# -*- coding: utf-8 -*-
"""核对 ⑤ 样本的 Ro_sat：稳健性表 vs 面板表 vs 逐星表重算"""
import io, os, sys
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
import numpy as np, pandas as pd
from scipy.optimize import minimize
P = lambda f: os.path.join('data', 'processed', 'dr13', f)
S = pd.read_csv(P('fig5_sample_strict_v4.csv'))
print('逐星表 ⑤：n=%d' % len(S))
def ols(d):
    x, y = np.log10(d.Ro.values), np.log10(d.RHa.values); best = None; allm = []
    for rs in np.linspace(-1.1, -0.4, 401):
        s, u = x <= rs, x > rs
        if s.sum() < 20 or u.sum() < 20: continue
        rss = ((y[s]-y[s].mean())**2).sum(); sl, ic = np.polyfit(x[u], y[u], 1)
        rss += ((y[u]-(sl*x[u]+ic))**2).sum()
        allm.append((rss, 10**rs, sl))
        if best is None or rss < best[0]: best = (rss, 10**rs, sl)
    allm.sort()
    return best, allm[:5]
(best, top) = ols(S)
print('OLS 最优：Ro_sat=%.4f  β=%.4f  RSS=%.2f' % (best[1], best[2], best[0]))
print('RSS 最小的 5 个断点（说明是否存在多极小）：')
for r, rs, sl in top:
    print('   Ro_sat=%.4f  β=%+.4f  RSS=%.2f' % (rs, sl, r))
def ml(d):
    x, y = np.log10(d.Ro.values), np.log10(d.RHa.values)
    sy = np.maximum(d.sRHa.values/np.maximum(d.RHa.values, 1e-12)/np.log(10), 0.02)
    def nll(p):
        l, b, c, ls = p; si = np.exp(ls)
        m = np.where(x <= l, c, c + b*(x - l)); v = sy**2 + si**2
        return 0.5*np.sum((y - m)**2/v + np.log(v))
    besti = None
    for l0 in (-1.0, -0.85, -0.7):
        r = minimize(nll, [l0, -0.7, np.median(y), np.log(.3)], method='Nelder-Mead',
                     bounds=[(-1.3,-0.5),(-1.6,0.1),(-9,0),(-4,0)], options={'maxiter': 5000})
        if besti is None or r.fun < besti.fun: besti = r
    return 10**besti.x[0], besti.x[1], np.exp(besti.x[3])
r3, b3, si = ml(S)
print('ML  : Ro_sat=%.4f  β=%.4f  σ_int=%.3f' % (r3, b3, si))
print('\n稳健性表 v4 末行：')
t = pd.read_csv(P('fig5_robustness_v4.csv')); print(t.tail(1).to_string(index=False))
print('\n面板拟合表 full_* 列：')
q = pd.read_csv(P('fig5_panel_fits_v4.csv'))
print(q[['panel','n','beta_ols','beta_ols_err','beta_ml','panel_ro_sat_ols','panel_ro_sat_ml',
         'full_ro_sat_ols','full_beta_ols','full_ro_sat_ml','full_beta_ml','full_sigma_int']].to_string(index=False))
