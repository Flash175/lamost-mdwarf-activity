
# -*- coding: utf-8 -*-
"""K 型试点：用 Yi(2014) 窗口自测 EW(Ha)，并算各 K 亚型的活动比例（含 S/N 匹配）。"""
import io, os, sys, gzip
import numpy as np, pandas as pd
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
META = 'data/processed/dr13/ktype_pilot_meta.csv'
DIR = 'data/lrs/ktype_pilot'
C_L, C_R, LINE = (6555.0, 6560.0), (6570.0, 6575.0), (6557.66, 6571.66)

def ew_one(path, z):
    d = pd.read_csv(gzip.open(path, 'rt'), usecols=['Wavelength', 'Flux'])
    w = d.Wavelength.values / (1.0 + (z if np.isfinite(z) else 0.0))
    f = d.Flux.values.astype(float)
    ok = np.isfinite(w) & np.isfinite(f); w, f = w[ok], f[ok]
    if len(w) < 100: return np.nan, np.nan
    o = np.argsort(w); w, f = w[o], f[o]
    mL = (w >= C_L[0]) & (w <= C_L[1]); mR = (w >= C_R[0]) & (w <= C_R[1])
    if mL.sum() < 2 or mR.sum() < 2: return np.nan, np.nan
    wl, fl = w[mL].mean(), f[mL].mean(); wr, fr = w[mR].mean(), f[mR].mean()
    if fr == fl: return np.nan, np.nan
    m = (fr - fl) / (wr - wl); b = fl - m * wl
    g = np.arange(LINE[0], LINE[1] + 1e-9, 0.1)
    fg = np.interp(g, w, f); fc = m * g + b
    ew = -np.trapezoid(1.0 - fg / fc, g)
    # 误差：只用线外的连续谱窗口估噪声（线内残差含线本身，会高估）
    cont = (w >= 6545) & (w <= 6585) & ~((w >= 6557) & (w <= 6572))
    if cont.sum() < 10:
        return ew, np.nan
    cm, cb = np.polyfit(w[cont], f[cont], 1)
    res = f[cont] - (cm*w[cont] + cb)
    sig = 1.4826*np.median(np.abs(res - np.median(res)))     # 稳健 rms
    dl = np.median(np.diff(w))
    npix = (LINE[1]-LINE[0])/dl
    err = sig/abs(np.nanmedian(fc))*dl*np.sqrt(npix)
    return ew, err

M = pd.read_csv(META)
M['f'] = [os.path.join(DIR, str(int(o)) + '.csv.gz') for o in M.obsid]
M['have'] = [os.path.exists(x) for x in M.f]
print('元数据 %d 颗，已下载 %d 颗' % (len(M), M.have.sum()))
if M.have.sum() == 0: sys.exit(0)
R = []
for _, r in M[M.have].iterrows():
    try:
        ew, err = ew_one(r.f, r.z)
        R.append((r.obsid, r.uid, r.subclass, r.teff, r.logg, r.snrr, r.gaia_g_mean_mag, ew, err))
    except Exception:
        pass
T = pd.DataFrame(R, columns=['obsid','uid','subclass','teff','logg','snrr','G','ew','ew_err']).dropna(subset=['ew'])
T['active'] = (T.ew >= 0.75) & (T.ew > 3*T.ew_err)
T.to_csv('data/processed/dr13/ktype_pilot_ew.csv', index=False, encoding='utf-8-sig')
print('测出 EW 的 %d 颗；活动比例（自测）%.1f%%' % (len(T), 100*T.active.mean()))
print('\n按亚型：')
for sp in ['K0','K1','K2','K3','K4','K5','K7']:
    s = T[T.subclass == sp]
    if len(s) < 20: continue
    q = s[(s.snrr >= 6) & (s.snrr <= 20)]
    print('  %-3s n=%4d  EW 中位 %6.2f  活动 %5.1f%% | S/N 6-20: n=%4d 活动 %5.1f%%'
          % (sp, len(s), s.ew.median(), 100*s.active.mean(), len(q), 100*q.active.mean() if len(q) >= 20 else np.nan))
