
# -*- coding: utf-8 -*-
"""s638：给六因素 Shapley 贡献加 bootstrap 区间（16–84 百分位）
用 Gram 矩阵技巧：A^T W A 一次算好，任意子集的 OLS 只是一次小规模求解 → 每次重抽样 <0.5 s。
"""
import os, sys, io, math, itertools, json
import numpy as np, pandas as pd
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
D = r'C:\Users\lingz\Desktop\复现老师工作\APJS\多个图及讨论'
d = pd.read_csv(os.path.join(D,'分解样本_snrr_470548.csv'), low_memory=False)
d['zb'] = pd.cut(d.absz,[0,100,200,400],labels=['<100','100-200','200-400'])
DUM = pd.get_dummies(d.subclass, prefix='s', drop_first=True).astype(float)
for c,nm in [('teff','F2'),('logg','F3'),('m_h','F4')]:
    v=d[c]; d[nm]=v-v.mean()
d['F2']=d.F2/1000.0
lv=np.log10(d.snrr); d['F5']=lv-lv.mean()
ld=np.log10(d.dist_pc); d['F6']=ld-ld.mean()
cont_cols = ['F2','F3','F4','F5','F6']
A = np.column_stack([np.ones(len(d))] + [DUM[c].values for c in DUM.columns] + [d[c].values for c in cont_cols])
y = d.active.values.astype(float)
n, P = A.shape
blocks = {'F1': list(range(1, 1+len(DUM.columns))),
          'F2': [1+len(DUM.columns)+0], 'F3': [1+len(DUM.columns)+1],
          'F4': [1+len(DUM.columns)+2], 'F5': [1+len(DUM.columns)+3], 'F6': [1+len(DUM.columns)+4]}
keys = list(blocks); K = 6
bins = ['100-200','200-400']
mref = (d.zb.values=='<100'); mb = {b:(d.zb.values==b) for b in bins}
print('A', A.shape, '| bins:', {b:int(mb[b].sum()) for b in bins}, 'ref', int(mref.sum()))

def shapley_from_gram(G, g, num, den, ref_num, ref_den):
    out = {b: {} for b in bins}
    def fit_delta(cols_idx):
        idx = [0] + sorted(set(cols_idx))
        sub = np.ix_(idx, idx)
        try: beta = np.linalg.solve(G[sub], g[idx])
        except np.linalg.LinAlgError: beta = np.linalg.lstsq(G[sub], g[idx], rcond=None)[0]
        res = {}
        for b in bins:
            pr = (num[b][idx] @ beta)/den[b]
            pr0 = (ref_num[idx] @ beta)/ref_den
            res[b] = 100*(pr - pr0)
        return res
    cache = {}
    for r in range(K+1):
        for S in itertools.combinations(keys, r):
            cs = [c for k in S for c in blocks[k]]
            cache[frozenset(S)] = fit_delta(cs)
    phi = {b:{k:0.0 for k in keys} for b in bins}
    for k in keys:
        o=[x for x in keys if x!=k]
        for r in range(len(o)+1):
            for S in itertools.combinations(o, r):
                w = math.factorial(len(S))*math.factorial(K-len(S)-1)/math.factorial(K)
                a = cache[frozenset(tuple(sorted(S+(k,))))]; b0 = cache[frozenset(S)]
                for b in bins: phi[b][k] += w*(a[b]-b0[b])
    return phi, cache[frozenset(keys)]

def gram(w):
    G = A.T @ (A * w[:,None]); g = A.T @ (y * w)
    num = {b: (A[mb[b]].T @ w[mb[b]]) for b in bins}
    den = {b: w[mb[b]].sum() for b in bins}
    ref_num = A[mref].T @ w[mref]; ref_den = w[mref].sum()
    return G, g, num, den, ref_num, ref_den

w0 = np.ones(n)
phi0, full0 = shapley_from_gram(*gram(w0))
f = {b:100*y[mb[b]].mean() for b in bins}; f['<100']=100*y[mref].mean()
OBS = {b: f['<100']-f[b] for b in bins}
print('\npoint estimate (decline convention):')
for b in bins:
    print('  %s: observed %.3f | explained %.3f | ' % (b, OBS[b], -full0[b]) + ', '.join('%s %.3f' % (k, -phi0[b][k]) for k in keys))

rng = np.random.default_rng(20261109)
NB = 200
samples = {b: {k: [] for k in keys} for b in bins}
expl = {b: [] for b in bins}
for it in range(NB):
    idx = rng.integers(0, n, n)
    w = np.bincount(idx, minlength=n).astype(float)
    ph, fu = shapley_from_gram(*gram(w))
    for b in bins:
        expl[b].append(-fu[b])
        for k in keys: samples[b][k].append(-ph[b][k])
    if (it+1) % 50 == 0: print('  bootstrap', it+1, '/', NB)
rows=[]
for b in bins:
    for k in keys:
        arr = np.array(samples[b][k]); lo, hi = np.percentile(arr, [16, 84])
        rows.append(dict(bin=b, quantity=k, pp=round(-phi0[b][k], 4), lo16=round(lo, 4), hi84=round(hi, 4),
                         share_of_observed_pct=round(100*(-phi0[b][k])/OBS[b], 2),
                         share_lo16=round(100*lo/OBS[b], 2), share_hi84=round(100*hi/OBS[b], 2)))
    meas = -(phi0[b]['F5']+phi0[b]['F6']); marr = np.array(samples[b]['F5'])+np.array(samples[b]['F6'])
    lo, hi = np.percentile(marr, [16,84])
    rows.append(dict(bin=b, quantity='MEAS(F5+F6)', pp=round(meas,4), lo16=round(lo,4), hi84=round(hi,4),
                     share_of_observed_pct=round(100*meas/OBS[b],2), share_lo16=round(100*lo/OBS[b],2), share_hi84=round(100*hi/OBS[b],2)))
    e = np.array(expl[b]); lo, hi = np.percentile(e, [16,84])
    rows.append(dict(bin=b, quantity='EXPLAINED_SUM', pp=round(-full0[b],4), lo16=round(lo,4), hi84=round(hi,4),
                     share_of_observed_pct=round(100*(-full0[b])/OBS[b],2), share_lo16=round(100*lo/OBS[b],2), share_hi84=round(100*hi/OBS[b],2)))
    rows.append(dict(bin=b, quantity='OBSERVED_DECLINE', pp=round(OBS[b],4), lo16=np.nan, hi84=np.nan,
                     share_of_observed_pct=100.0, share_lo16=np.nan, share_hi84=np.nan))
    rows.append(dict(bin=b, quantity='UNEXPLAINED', pp=round(OBS[b]+full0[b],4), lo16=round(OBS[b]-hi,4), hi84=round(OBS[b]-lo,4),
                     share_of_observed_pct=round(100*(OBS[b]+full0[b])/OBS[b],2), share_lo16=round(100*(OBS[b]-hi)/OBS[b],2), share_hi84=round(100*(OBS[b]-lo)/OBS[b],2)))
T = pd.DataFrame(rows)
T.to_csv(os.path.join(D,'多因素_六因素贡献_snrr版_带误差.csv'), index=False, encoding='utf-8-sig')
print('\n=== with bootstrap 16-84 intervals (pp) ===')
print(T.to_string(index=False))
json.dump({'n_boot':NB,'seed':20261109,'note':'resample with replacement over the 470,548 stars; Gram-matrix shortcut for OLS'},
          open(os.path.join(D,'多因素_bootstrap_设置.json'),'w',encoding='utf-8'), ensure_ascii=False, indent=2)
print('\nwrote 多因素_六因素贡献_snrr版_带误差.csv')
