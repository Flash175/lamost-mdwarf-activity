
# -*- coding: utf-8 -*-
"""新图6：金属度通道三面板（全部读自已保存的 CSV，不引入新数字）
(a) [Fe/H] 的垂直梯度  (b) 固定 |Z| 下活动率 vs [Fe/H] 四分位（混合口径）
(c) 逐亚型 logit 斜率（固定亚型后符号反转）
"""
import os
import numpy as np, pandas as pd
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
D = r'C:\Users\lingz\Desktop\复现老师工作\APJS\多个图及讨论'
FIG = r'C:\Users\lingz\Desktop\复现老师工作\APJS\图五及相关数据\图\新图6_金属度通道.png'
grad = pd.read_csv(os.path.join(D,'金属度_垂直梯度.csv'))
fx   = pd.read_csv(os.path.join(D,'金属度_固定Z活动率.csv'))
per  = pd.read_csv(os.path.join(D,'金属度_逐亚型斜率.csv'))

fig, ax = plt.subplots(1, 3, figsize=(13.4, 4.1))
x = np.arange(len(grad))
ax[0].errorbar(x, grad.mh_med, yerr=[grad.mh_med-grad.lo, grad.hi-grad.mh_med], fmt='o-', color='#7b3294', ms=6, capsize=3)
for i, r in grad.iterrows(): ax[0].text(i, r.hi+0.012, '%s' % format(int(r.n), ','), ha='center', fontsize=6.5)
ax[0].set_xticks(x); ax[0].set_xticklabels(grad.zbin, fontsize=8)
ax[0].set_xlabel('|Z|  (pc)'); ax[0].set_ylabel('[Fe/H]  (dex, median)')
ax[0].set_title('[Fe/H] decreases outwards\n(%.5f dex pc$^{-1}$, r = -0.195)' % (-2.3e-4), fontsize=9)
b = fx[fx.quartile!='spearman']
cols = ['#c0392b','#e08a7f','#bdc3c7','#95a5a6','#7f8c8d']
for lb, c in zip(['<100','100-200','200-400','400-600','600-1000'], cols):
    t = b[b.zbin==lb]
    if len(t): ax[1].plot(np.arange(len(t)), t.frac_pct, 'o-', color=c, ms=5, lw=1.2, label=lb)
ax[1].set_xticks(range(4)); ax[1].set_xticklabels(['Q1','Q2','Q3','Q4'], fontsize=8)
ax[1].set_xlabel('[Fe/H] quartile (metal-poor to metal-rich)'); ax[1].set_ylabel('Active fraction (%)')
ax[1].set_title('Mixed subtype mix: apparent positive trend\n(b_mh = +0.59 $\\pm$ 0.02 with |Z| fixed)', fontsize=9)
ax[1].legend(fontsize=6.5, title='|Z| (pc)', title_fontsize=6.5, ncol=2)
xx = np.arange(len(per))
ax[2].errorbar(xx, per.b_mh, yerr=1.96*per.se, fmt='o', color='#2c3e50', ms=6, capsize=3)
ax[2].axhline(0, color='k', lw=0.8)
ax[2].axhline(0.588, color='#c0392b', ls='--', lw=1.2)
ax[2].text(len(per)-0.6, 0.75, 'global (mixed): +0.59', color='#c0392b', fontsize=6.5, ha='right')
ax[2].set_xticks(xx); ax[2].set_xticklabels(per.subtype, fontsize=8)
ax[2].set_xlabel('spectral subtype ($|Z|\\leq400$ pc)'); ax[2].set_ylabel('logit slope  $\\partial\\ln[f/(1-f)]/\\partial[\\rm Fe/H]$')
ax[2].set_title('Within subtype the sign reverses\n(fixed-effect b_mh = $-$1.51 $\\pm$ 0.02)', fontsize=9)
plt.tight_layout(); plt.savefig(FIG, dpi=200); plt.close()
print('written', FIG, os.path.getsize(FIG), 'bytes')
print('gradient rows', len(grad), '| quartile rows', len(b), '| subtype rows', len(per))
