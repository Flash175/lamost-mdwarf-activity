# -*- coding: utf-8 -*-
"""量出论文 Fig2 两板的地图框与红色带范围，推断其经度中心与方向。"""
import io, sys
import numpy as np
from PIL import Image
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

for path, label in [("extract/pdf_images/fig2_SDSS_zoom.png", "论文右板 SDSS"),
                    ("extract/pdf_images/fig2_LAMOST_zoom.png", "论文左板 LAMOST")]:
    a = np.asarray(Image.open(path).convert("RGB")).astype(int)
    H, W, _ = a.shape
    r, g, b = a[:, :, 0], a[:, :, 1], a[:, :, 2]
    colored = (a.max(2) - a.min(2) > 40) & (a.min(2) < 240)
    red = colored & (r > b + 20)
    # 地图边框：浅灰曲线（r≈g≈b 且 100<v<220）
    grayish = (np.abs(r - g) < 12) & (np.abs(g - b) < 12) & (r > 60) & (r < 215)
    ys, xs = np.where(grayish)
    print(f"--- {label}  {W}x{H}")
    print(f"  灰框 x {xs.min()}..{xs.max()}  y {ys.min()}..{ys.max()}  → 中心 x {(xs.min()+xs.max())/2:.0f}")
    # 每一行里彩色像素的 x 范围（找赤道带：红色像素最多的一行）
    rows = np.array([int(red[y].sum()) for y in range(H)])
    yb = int(rows.argmax())
    print(f"  红色最多的一行 y={yb}, 该行红像素 {rows[yb]}")
    band = red[max(0, yb - 6):yb + 7]
    cs = np.where(band.any(0))[0]
    print(f"  红带 x 范围 {cs.min()}..{cs.max()}（共 {len(cs)} 列）")
    # 反推经度：椭圆的 x 半宽
    xc = (xs.min() + xs.max()) / 2; hw = (xs.max() - xs.min()) / 2
    for name, x0 in [("红带左端", cs.min()), ("红带右端", cs.max()), ("红带中心", (cs.min()+cs.max())/2)]:
        print(f"    {name} x={x0:.0f} → 经度 {180*(x0-xc)/hw:+.1f}°")
    print()
