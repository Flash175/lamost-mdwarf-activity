# -*- coding: utf-8 -*-
"""s606：双/三判据活动比例图（目录 Hα / 本地 Hα / 本地 Hβ，六档）"""
import io, sys, os
import numpy as np, pandas as pd
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
D = "C:/Users/lingz/Desktop/复现老师工作/APJS/多个图及讨论"
OUT = "C:/Users/lingz/Desktop/复现老师工作/APJS/图五及相关数据/图_20261103/新图"
os.makedirs(OUT, exist_ok=True)
T = pd.read_csv(D + "/hbeta30k_by_zbin.csv")
ORDER = ['<100','100-200','200-400','400-600','600-1000','>1000']
XC = {'<100':50,'100-200':150,'200-400':300,'400-600':500,'600-1000':800,'>1000':1200}
T = T.set_index('zbin').reindex(ORDER).reset_index()
x = np.array([XC[z] for z in T.zbin]); weak = T.zbin == '>1000'

fig, ax = plt.subplots(figsize=(7.4, 4.8))
specs = [('cat','Catalogue EW (H$\\alpha$)', 'k', 'o'), ('ha','Local H$\\alpha$', 'tab:red', 's'),
         ('hb','Local H$\\beta$', 'tab:blue', '^')]
for key, lab, c, m in specs:
    ax.errorbar(x, T['f_'+key], yerr=[T['f_'+key]-T['lo_'+key], T['hi_'+key]-T['f_'+key]],
                color=c, marker=m, ms=5, lw=1.7, capsize=3, label=lab)
ax.axvspan(900, 1600, color='0.9', zorder=0)
ax.text(1200, ax.get_ylim()[1]*0.55, 'weak\n(n=300)', ha='center', fontsize=7.5, color='0.35')
ax.set_xscale('log'); ax.set_xlabel(r'$|Z|$  (pc)'); ax.set_ylabel('active fraction  (%)')
ax.set_title('Activity fraction from three criteria: same shape, H$\\beta$ lower by a constant factor', fontsize=10)
ax.legend(fontsize=8.5, frameon=False); ax.grid(alpha=.25); ax.tick_params(labelsize=8.5)
fig.tight_layout()
fp = OUT + "/新图_三判据活动比例.png"
fig.savefig(fp, dpi=180); plt.close(fig)
print('写出 %s（%d B）' % (fp, os.path.getsize(fp)))
print('\nHβ/Hα 比值：' + '  '.join('%s %.2f' % (z, t.f_hb/t.f_ha) for z, t in zip(T.zbin, T.itertuples())))
