
# -*- coding: utf-8 -*-
"""s629：六因素多因素联合定量分配（分布位移 / Shapley），按《六因素分解_研究流程》实现。
不写入任何草稿；输出 CSV/JSON/图 供审核。
"""
import os, sys, io, json, itertools, math
import numpy as np, pandas as pd
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
D = r'C:\Users\lingz\Desktop\复现老师工作\APJS\多个图及讨论'
main = pd.read_csv(os.path.join(D,'金属度_清洁样本_637973.csv'), low_memory=False)
sb1  = pd.read_csv(os.path.join(D,'RV变星_SB1候选_多历元.csv'), low_memory=False)
print('main rows', len(main))

# ---------- step 1: sentinel diagnostics
print('\n=== sentinel / range diagnostics ===')
for c in ['teff','logg','m_h','snru','dist_pc']:
    s = pd.to_numeric(main[c], errors='coerce')
    print('  %-8s min %10.3f max %10.3f  n(-9999)=%6d  n(0)=%6d  n(nan)=%6d' % (
        c, np.nanmin(s), np.nanmax(s), int((s==-9999).sum()), int((s==0).sum()), int(s.isna().sum())))

# ---------- step 2: cleaning (A already done; here B)
d = main.copy()
d = d[~d.uid.isin(set(sb1.uid))]
print('\nafter SB1 removal:', len(d))
for c in ['teff','logg','m_h','snru','dist_pc']:
    d = d[pd.to_numeric(d[c], errors='coerce').notna()]
    d = d[pd.to_numeric(d[c], errors='coerce') != -9999]
d = d[(d.teff>=2000)&(d.teff<=4500)&(d.logg>=3)&(d.logg<=6)&(d.m_h.abs()<1)&(d.snru>0)&(d.snru<100)]
d = d[(d.mh_ok==True) & (d.dist_pc>0) & (d.absz>0) & (d.absz<=400)].copy()
print('after B-layer cleaning:', len(d), '(expected ~4.0-4.5e5)')
d['active'] = ((d.ewha>=0.75)&(d.ewha>3*d.ewha_err)).astype(float)
d['zb3'] = pd.cut(d.absz, [0,100,200,400], labels=['<100','100-200','200-400'])
print('\n=== bin activity ===')
g = d.groupby('zb3', observed=True).agg(n=('uid','size'), act=('active','mean'))
g['pct'] = 100*g.act
print(g.round(3).to_string())
OBS = {'100-200': 100*(g.loc['<100','act']-g.loc['100-200','act']),
       '200-400': 100*(g.loc['<100','act']-g.loc['200-400','act'])}
print('observed D (pp):', {k: round(v,3) for k,v in OBS.items()})

# ---------- step 5: factor matrix
d['F1'] = d.subclass
for c, nm in [('teff','F2'),('logg','F3'),('m_h','F4')]:
    d[nm] = (pd.to_numeric(d[c]) - pd.to_numeric(d[c]).mean())
d['F2'] = d.F2/1000.0
d['F5'] = np.log10(pd.to_numeric(d.snru)) - np.log10(pd.to_numeric(d.snru)).mean()
d['F6'] = np.log10(pd.to_numeric(d.dist_pc)) - np.log10(pd.to_numeric(d.dist_pc)).mean()
SUBS = ['dM0','dM1','dM2','dM3','dM4','dM5','dM6']
DUM = pd.get_dummies(d.F1, prefix='s', drop_first=True).astype(float)
X = pd.concat([DUM, d[['F2','F3','F4','F5','F6']]], axis=1)
blocks = {'F1': list(DUM.columns), 'F2':['F2'], 'F3':['F3'], 'F4':['F4'], 'F5':['F5'], 'F6':['F6']}
y = d.active.values
binid = d.zb3.values
masks = {b: (binid==b) for b in ['<100','100-200','200-400']}
print('\nmodel matrix:', X.shape, '| factors:', list(blocks))

def fit_delta(cols):
    A = np.column_stack([np.ones(len(d))] + [X[c].values for c in cols])
    beta, *_ = np.linalg.lstsq(A, y, rcond=None)
    pred = A@beta
    v = {b: pred[m].mean() for b,m in masks.items()}
    return {b: 100*(v[b]-v['<100']) for b in ['100-200','200-400']}, beta

def shapley(block_keys, label=''):
    K = len(block_keys); keys = list(block_keys)
    phi = {b: {k: 0.0 for k in keys} for b in ['100-200','200-400']}
    cache = {}
    for r in range(K+1):
        for S in itertools.combinations(keys, r):
            cols = [c for k in S for c in blocks[k]]
            cache[frozenset(S)] = fit_delta(cols)[0]
    for k in keys:
        others = [x for x in keys if x != k]
        for r in range(len(others)+1):
            for S in itertools.combinations(others, r):
                wgt = math.factorial(len(S))*math.factorial(K-len(S)-1)/math.factorial(K)
                dS = cache[frozenset(S)]; dSk = cache[frozenset(tuple(sorted(S+(k,))))]
                for b in phi:
                    phi[b][k] += wgt*(dSk[b]-dS[b])
    full = cache[frozenset(keys)]
    return phi, full

phi, full = shapley(['F1','F2','F3','F4','F5','F6'])
print('\n=== Shapley contributions (pp) ===')
for b in ['100-200','200-400']:
    s = sum(phi[b].values())
    print('  bin %-8s  D(full model)=%6.3f  sum(phi)=%6.3f  diff=%.2e' % (b, full[b], s, s-full[b]))
    for k in ['F1','F2','F3','F4','F5','F6']:
        print('      %s %+7.3f  (%5.1f%% of observed)' % (k, phi[b][k], 100*phi[b][k]/OBS[b]))
    print('      residual (observed - explained) %+7.3f' % (OBS[b]-full[b]))
# ---------- outputs
rows=[]
for b in ['100-200','200-400']:
    expl = sum(phi[b].values())
    for k in ['F1','F2','F3','F4','F5','F6']:
        rows.append(dict(bin=b, factor=k, contribution_pp=phi[b][k],
                         share_of_observed_pct=100*phi[b][k]/OBS[b],
                         share_of_explained_pct=100*phi[b][k]/expl))
    rows.append(dict(bin=b, factor='OBSERVED_D', contribution_pp=OBS[b], share_of_observed_pct=100.0, share_of_explained_pct=np.nan))
    rows.append(dict(bin=b, factor='EXPLAINED_SUM', contribution_pp=expl, share_of_observed_pct=100*expl/OBS[b], share_of_explained_pct=100.0))
    rows.append(dict(bin=b, factor='RESIDUAL', contribution_pp=OBS[b]-expl, share_of_observed_pct=100*(OBS[b]-expl)/OBS[b], share_of_explained_pct=np.nan))
T = pd.DataFrame(rows).round(4)
T.to_csv(os.path.join(D,'多因素_六因素贡献.csv'), index=False, encoding='utf-8-sig')
print('\nwrote 多因素_六因素贡献.csv')
print(T.to_string(index=False))
json.dump(dict(n_main=int(len(main)), n_clean=int(len(d)),
               bins={b: dict(n=int(masks[b].sum()), frac_pct=100*g.loc[b,'pct']) for b in ['<100','100-200','200-400']},
               observed_D_pp=OBS, shapley_pp=phi, explained_pp=full,
               residual_pp={b: OBS[b]-full[b] for b in OBS}),
          open(os.path.join(D,'多因素_汇总.json'),'w',encoding='utf-8'), ensure_ascii=False, indent=2)
print('wrote 多因素_汇总.json')
