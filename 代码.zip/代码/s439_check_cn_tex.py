# -*- coding: utf-8 -*-
"""中英一致性自检 v2：区分“表格专用数值”与真正的不一致"""
import io, re, sys
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
B = r'repro/_zipcheck/图五及相关数据/'
CNt = open(B + 'discussion_subsec_rossby_cycle_dynamo_中文.md', encoding='utf-8').read()
TXt = open(B + 'discussion_subsec_rossby_cycle_dynamo.tex', encoding='utf-8').read()

def nums(t):
    return {m.group(0).replace('−','-') for m in re.finditer(r'(?<![\d.])[−-]?0\.\d{2,4}(?![\d])', t)}

# 表格行里的数值单独统计（表格只在中文稿里）
table_nums = set()
for line in CNt.split('\n'):
    if line.strip().startswith('|'):
        table_nums |= nums(line)

cn, tx = nums(CNt), nums(TXt)
only_cn = sorted(cn - tx)
real_cn = [x for x in only_cn if x not in table_nums]
only_tx = sorted(tx - cn)

print('中文稿 %d 个数值 token，tex %d 个' % (len(cn), len(tx)))
print('只在中文稿：%d 个，其中 %d 个来自表格（正常，tex 无对应表格），%d 个需核对'
      % (len(only_cn), len(only_cn) - len(real_cn), len(real_cn)))
if real_cn: print('   需核对：', ', '.join(real_cn))
print('只在 tex：%d 个' % len(only_tx))
if only_tx: print('   ', ', '.join(only_tx))

FORBID = [
 ('均小于该口径自身的统计误差', 'R4 反例：自由断点 M0–M3 = 0.30'),
 ('13 颗具有', 'R1：应为“13 个周期”'),
 ('M0–M3 约 0.07、M4–M6 可达 0.16', 'R3：旧值'),
 ('20.6 yr 周期是其 15 yr 基线的 1.38 倍', 'R1：缺发表值 7038 d'),
 ('同一批星改用', 'R3：A→C 为联合变更'),
 ('由单历元谱测得', '应写“最强历元”'),
 ('on the same stars', 'R3 英文对应'),
 ('measured from single-epoch spectra', '应写 strongest epoch'),
 ('约 0.06 的影响', 'τ 段旧措辞'),
]
bad = [(s, w) for s, w in FORBID if s in CNt or s in TXt]
print('\n禁用措辞：', '无命中 ✅' if not bad else '命中 %d 条' % len(bad))
for s, w in bad: print('   ✗', s, '→', w)

ok = (not bad) and (not only_tx or set(only_tx) <= {'-0.06','-0.16','-0.31','0.43'})
print('\n总体：', '一致 ✅' if ok else '仍有差异，需人工确认上面列出的 token')
