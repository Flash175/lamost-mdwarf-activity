# -*- coding: utf-8 -*-
"""s556：把 §1/§2 的关键数字全部落盘（回答 P1-4/P1-5）
 1) zmatch_kinematics.csv：六档 + 40-80 pc 窗口，含 std 与 MAD 两套
 2) reweight_composition.csv：<100/200-400/400-600/600-1000/>400 的逐亚型 n、frac、权重、贡献
"""
import io, sys, os
import numpy as np, pandas as pd
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
from astropy.coordinates import SkyCoord
import astropy.units as un

OUT = r'C:\Users\lingz\Desktop\复现老师工作\APJS\多个图及讨论'

def mad_sigma(x):
    x = np.asarray(x, float); x = x[np.isfinite(x)]
    if len(x) < 10: return np.nan
    return 1.4826*np.median(np.abs(x-np.median(x)))

def save(df, name, comments):
    fp = os.path.join(OUT, name)
    df.to_csv(fp, index=False, encoding='utf-8')
    txt = open(fp, encoding='utf-8').read()
    with open(fp, 'w', encoding='utf-8-sig') as f:
        f.write('\n'.join('# ' + c for c in comments) + '\n' + txt)
    print('  写出 %s（%d 行 x %d 列）' % (name, len(df), df.shape[1]))

cat = pd.read_csv('data/lamost/dr13/dr13_mstellar_dM.csv', low_memory=False,
                  usecols=['uid','subclass','teff','ewha','ewha_err','snrr','ra','dec',
                           'gaia_source_id','gaia_g_mean_mag'])
cat = cat[(cat.ewha > -20) & (cat.ewha <= 50) & (cat.ewha_err > 0) & (cat.ewha_err <= 5)].copy()
cat['active'] = (cat.ewha >= 0.75) & (cat.ewha > 3*cat.ewha_err)
cat['gaia_source_id'] = pd.to_numeric(cat.gaia_source_id, errors='coerce')
g = pd.read_csv('data/gaia/gaia_dr3_mstars.csv', low_memory=False,
                usecols=['source_id','parallax','parallax_error','pmra','pmdec','radial_velocity','ruwe'])
m = cat.merge(g, left_on='gaia_source_id', right_on='source_id', how='inner')
m = m[(m.parallax > 0.2) & (m.parallax/m.parallax_error > 5) & (m.ruwe < 1.4)].copy()
m['rv'] = m.radial_velocity

# --- 2D（日心 |Z|）---
u2 = m.sort_values('ewha', ascending=False).drop_duplicates('uid').copy()
# [giant-cut] 去巨星：M_G >= 6（M 矮星 +8~+16；切口同时含亚巨星与误分类早型矮星）
u2['MG'] = u2.gaia_g_mean_mag.values - 5*np.log10(np.clip(1000.0/u2.parallax.values, 1, None)) + 5
u2 = u2[u2.MG >= 6].copy()
d2 = 1000.0/u2.parallax.values
sc2 = SkyCoord(ra=u2.ra.values*un.deg, dec=u2.dec.values*un.deg, distance=d2*un.pc, frame='icrs')
u2['absz_pc'] = np.abs(d2*np.sin(np.deg2rad(sc2.galactic.b.deg)))
u2 = u2[u2.absz_pc <= 3000].copy()

# --- 6D（银心 z）---
six = m.sort_values('ewha', ascending=False).drop_duplicates('uid').copy()
# [giant-cut] 去巨星：M_G >= 6（M 矮星 +8~+16；切口同时含亚巨星与误分类早型矮星）
six['MG'] = six.gaia_g_mean_mag.values - 5*np.log10(np.clip(1000.0/six.parallax.values, 1, None)) + 5
six = six[six.MG >= 6].copy()
six = six[np.isfinite(six.rv) & (np.abs(six.rv) < 500)].copy()
c6 = SkyCoord(ra=six.ra.values*un.deg, dec=six.dec.values*un.deg,
              distance=(1000.0/six.parallax.values)*un.pc,
              pm_ra_cosdec=six.pmra.values*un.mas/un.yr, pm_dec=six.pmdec.values*un.mas/un.yr,
              radial_velocity=six.rv.values*un.km/un.s, frame='icrs')
gc = c6.transform_to('galactocentric')
v6 = gc.velocity.d_xyz.to(un.km/un.s).value
six = six.assign(vx=v6[0], vy=v6[1], vz=v6[2], zgc_pc=np.abs(gc.z.to(un.kpc).value)*1000)
six = six[six.zgc_pc <= 3000].copy()

# --- 1. 运动学表（六档 + 40-80 窗口）---
rows = []
def add_row(label, s, lo, hi):
    act, ina = s[s.active], s[~s.active]
    rows.append(dict(slice=label, zlo=lo, zhi=hi, n=len(s), n_act=len(act), n_inact=len(ina),
                     zmed_act=float(act.zgc_pc.median()), zmed_inact=float(ina.zgc_pc.median()),
                     teff_act=float(act.teff.median()), teff_inact=float(ina.teff.median()),
                     svx_act=act.vx.std(), svy_act=act.vy.std(), svz_act=act.vz.std(),
                     svx_inact=ina.vx.std(), svy_inact=ina.vy.std(), svz_inact=ina.vz.std(),
                     svz_act_mad=mad_sigma(act.vz), svz_inact_mad=mad_sigma(ina.vz),
                     d_svz=act.vz.std()-ina.vz.std(),
                     d_svz_mad=mad_sigma(act.vz)-mad_sigma(ina.vz)))
for lo, hi in [(0,50),(50,100),(100,150),(150,200),(200,400),(400,3000),(0,25),(25,50),(50,75),(75,100),(40,80)]:
    s = six[(six.zgc_pc >= lo) & (six.zgc_pc < hi)]
    if len(s) < 50: continue
    add_row('%d-%d' % (lo, hi), s, lo, hi)
K = pd.DataFrame(rows)
print(K[['slice','n_act','n_inact','zmed_act','zmed_inact','svz_act','svz_inact','svz_act_mad','svz_inact_mad','d_svz','d_svz_mad']]
      .to_string(index=False, float_format=lambda x: '%.1f' % x))
save(K, 'zmatch_kinematics.csv', [
    '6D 子样本（Gaia 视差+自行+RV）按银心 z 分档：活动/非活动各自的 z 中位、Teff 中位、三分量弥散',
    'svz_*_mad 为 1.4826*MAD；d_svz / d_svz_mad 为活动减非活动的差；含 25 pc 细片与 40-80 pc 共同窗口',
    '注意：6D 的 |Z| 用 astropy galactocentric z，与 2D（日心 d*sin b）不同，故 >400 pc 为 346 颗（§1 的 320 颗是日心口径）',
    '生成脚本：代码/s556_finalize_tables.py'])

# --- 2. 组成重加权明细 ---
base = u2[u2.absz_pc < 100]
w = base.subclass.value_counts(normalize=True)
rows = []
for lb, zl, zh in [('<100',0,100), ('100-200',100,200), ('200-400',200,400), ('400-600',400,600), ('600-1000',600,1000), ('>400',400,3000)]:
    s = u2[(u2.absz_pc >= zl) & (u2.absz_pc < zh)]
    for sp in ['dM0','dM1','dM2','dM3','dM4','dM5','dM6','dM7','dM8']:
        q = s[s.subclass == sp]
        if len(q) == 0: continue
        wt = float(w.get(sp, 0.0))
        rows.append(dict(zbin=lb, subtype=sp, n=len(q), n_act=int(q.active.sum()),
                         frac=100*q.active.mean(), weight_pct=100*wt,
                         contrib_pp=100*wt*q.active.mean() if wt > 0 else np.nan))
    tot = rows[-len(s.subclass.unique()) if False else 0:0]
C = pd.DataFrame(rows)
print('\n重加权明细（前 20 行）：')
print(C.head(20).to_string(index=False, float_format=lambda x: '%.2f' % x))
for lb in ['<100','100-200','200-400','400-600','600-1000','>400']:
    q = C[C.zbin == lb]
    qq = q[q.weight_pct > 0]
    print('  %-8s 实测 %.2f%%  重加权 %.2f%%（参与重加权的亚型 %d 个，覆盖该档 %d/%d 颗）'
          % (lb, 100*u2[(u2.absz_pc>=dict([('<100',(0,100)),('100-200',(100,200)),('200-400',(200,400)),('400-600',(400,600)),('600-1000',(600,1000)),('>400',(400,3000))])[lb][0]) &
                        (u2.absz_pc < dict([('<100',(0,100)),('100-200',(100,200)),('200-400',(200,400)),('400-600',(400,600)),('600-1000',(600,1000)),('>400',(400,3000))])[lb][1])].active.mean(),
             qq.contrib_pp.sum()/qq.weight_pct.sum()*100 if len(qq) else np.nan, len(qq), qq.n.sum(), q.n.sum()))
save(C, 'reweight_composition.csv', [
    '组成重加权明细：各 |Z| 档内每个亚型的 n、活动数、活动比例、在 <100 pc 组成中的权重、对重加权值的贡献（权重 x 比例）',
    '重加权值 = 该档内 weight_pct>0 的亚型的 contrib_pp 之和 / 权重之和；权重来自 <100 pc 档的亚型组成',
    '2D 样本 637,973 颗（每星最大 EW 谱，日心 |Z|）；active = EW(Ha)>=0.75 A 且 >3sigma',
    '含 100-200 pc 档（此前缺失，s582 曾用 <100 pc 组成代填，已废弃）',
    '生成脚本：代码/s556_finalize_tables.py'])

# 3b) 各档重加权值的 Kish 与二项有效样本量
rows2 = []
for lb, zl, zh in [('200-400',200,400), ('400-600',400,600), ('600-1000',600,1000), ('>400',400,3000)]:
    q = C[(C.zbin == lb) & (C.weight_pct > 0)]
    wsum = q.weight_pct.sum()
    w = q.weight_pct.values/wsum
    p = q.frac.values/100
    n = q.n.values
    rw = float((w*p).sum()*100)
    kish = float((w*n).sum()**2 / (w**2*n).sum())
    var = float((w**2 * p*(1-p)/n).sum())
    pbar = float((w*p).sum())
    neff_bin = float(pbar*(1-pbar)/var) if var > 0 else np.nan
    rows2.append(dict(zbin=lb, n=int(q.n.sum()), frac_raw=float(100*q.n_act.sum()/q.n.sum()),
                      frac_rw=rw, kish_neff=kish, binom_neff=neff_bin))
R2 = pd.DataFrame(rows2)
print('\n=== 重加权值的两种有效样本量 ===')
print(R2.to_string(index=False, float_format=lambda x: '%.0f' if abs(x) > 100 else '%.2f'))
save(R2, 'reweight_effective_n.csv', [
    '各远档重加权值的两种有效样本量（回答 P1-5 的 Kish 误导问题）',
    'kish_neff：Kish 定义 (sum w n)^2 / sum(w^2 n)，只反映权重分布，不含单元格二项误差',
    'binom_neff：由 Var = sum w^2 p(1-p)/n 得到的等效二项样本量，pbar(1-pbar)/Var；远小于 Kish 值，才是误差的真实来源',
    '生成脚本：代码/s556_finalize_tables.py'])

# 3c) 移位分解（相邻远档之间）
rows3 = []
bins_order = ['200-400','400-600','600-1000']
for b1, b2 in zip(bins_order[:-1], bins_order[1:]):
    A = C[C.zbin == b1].set_index('subtype'); Bq = C[C.zbin == b2].set_index('subtype')
    common = [x for x in A.index if x in Bq.index]
    n1 = A.loc[common,'n'].sum(); n2 = Bq.loc[common,'n'].sum()
    for sp in common:
        w1 = A.loc[sp,'n']/n1; w2 = Bq.loc[sp,'n']/n2
        f1 = A.loc[sp,'frac']/100; f2 = Bq.loc[sp,'frac']/100
        rows3.append(dict(transition=b1+'>'+b2, subtype=sp,
                          rate_pp=100*w1*(f2-f1),
                          comp_pp=100*f1*(w2-w1),
                          inter_pp=100*(f2-f1)*(w2-w1),
                          w1_pct=100*w1, w2_pct=100*w2,
                          f1_pct=100*f1, f2_pct=100*f2, n1=A.loc[sp,'n'], n2=Bq.loc[sp,'n']))
S = pd.DataFrame(rows3)
print('\n=== 移位分解 ===')
for t in S.transition.unique():
    q = S[S.transition == t]
    print('  %s: 率 %+.2f pp | 组成 %+.2f pp | 交互 %+.2f pp | 合计 %+.2f pp'
          % (t, q.rate_pp.sum(), q.comp_pp.sum(), q.inter_pp.sum(), (q.rate_pp+q.comp_pp+q.inter_pp).sum()))
    for _, r in q.iterrows():
        print('     %-4s 权重 %5.1f→%5.1f%% 比例 %5.2f→%5.2f%%  贡献(率+组成+交互) %+.3f pp'
              % (r.subtype, r.w1_pct, r.w2_pct, r.f1_pct, r.f2_pct, r.rate_pp+r.comp_pp+r.inter_pp))
save(S, 'shift_share.csv', [
    '相邻远档之间的移位分解（率效应 / 组成效应 / 交互），用于说明合并值下降/上升的来源',
    'rate_pp = w1*(f2-f1)、comp_pp = f1*(w2-w1)、inter_pp = (f2-f1)*(w2-w1)，单位百分点',
    '生成脚本：代码/s556_finalize_tables.py'])

# --- 3. §1 的 >400 pc 剔除核对 ---
far2d = u2[u2.absz_pc > 400]
farsix_helio = six  # 用银心 z 的 6D
six_helio = six.copy()
d6 = 1000.0/six_helio.parallax.values
sc6 = SkyCoord(ra=six_helio.ra.values*un.deg, dec=six_helio.dec.values*un.deg, distance=d6*un.pc, frame='icrs')
six_helio['absz_pc'] = np.abs(d6*np.sin(np.deg2rad(sc6.galactic.b.deg)))
fs = six_helio[six_helio.absz_pc > 400]
rem = far2d[~far2d.uid.isin(set(fs.uid))]
print('\n>400 pc（2D, 日心）：n=%d, 活动=%d' % (len(far2d), far2d.active.sum()))
print('  6D 日心口径 >400 pc：%d 颗（活动 %d）；其中落在 2D 该档内 %d 颗（活动 %d）'
      % (len(fs), fs.active.sum(), len(far2d) - len(rem), int(far2d.active.sum() - rem.active.sum())))
print('  剔除后：%d 颗、活动 %d → %.4f%%' % (len(rem), rem.active.sum(), 100*rem.active.mean()))
print('s556 完成')
