# -*- coding: utf-8 -*-
# 独立审计脚本：从权威逐星表重算 discussion_subsec_rossby_cycle_dynamo_中文_讨论体.md 的关键数字
# 口径：图5_逐星样本_严格3340行_⑤_tau030.csv（-0.30 Li 式）
import csv, math, random

BASE = 'C:/Users/lingz/Desktop/复现老师工作/APJS/图五及相关数据'
FN = BASE + '/数据/图5_逐星样本_严格3340行_⑤_tau030.csv'

rows = []
with open(FN, encoding='utf-8-sig') as f:
    for row in csv.DictReader(f):
        rows.append(row)
assert len(rows) == 3340, len(rows)

def fl(x):
    return float(x)

def panel_of(spt):
    if spt in ('dM0', 'dM1', 'dM2', 'dM3'):
        return 'M0-M3'
    if spt in ('dM4', 'dM5', 'dM6'):
        return 'M4-M6'
    return 'OTHER'

data = []
for r in rows:
    M = fl(r['M']); P = fl(r['P'])
    tau30 = 10 ** (2.33 - 1.50 * M - 0.30 * M * M)
    tau31 = 10 ** (2.33 - 1.50 * M + 0.31 * M * M)
    Ro30 = P / tau30
    Ro31 = P / tau31
    # 验证 Ro 列与 -0.30 公式一致
    assert abs(Ro30 - fl(r['Ro'])) / fl(r['Ro']) < 2e-3, (r['uid'], Ro30, r['Ro'])
    data.append(dict(
        uid=r['uid'], spt=r['spt'], panel=panel_of(r['spt']),
        M=M, P=P, snrr=fl(r['snrr']), ewha=fl(r['ewha']),
        Ro30=Ro30, Ro31=Ro31,
        logRo30=math.log10(Ro30), logRo31=math.log10(Ro31),
        logRHa=math.log10(fl(r['RHa'])),
    ))

BP = 0.132

def ols(xs, ys):
    n = len(xs)
    xm = sum(xs) / n
    ym = sum(ys) / n
    sxx = sum((x - xm) ** 2 for x in xs)
    sxy = sum((x - xm) * (y - ym) for x, y in zip(xs, ys))
    b = sxy / sxx
    a = ym - b * xm
    rss = sum((y - a - b * x) ** 2 for x, y in zip(xs, ys))
    return a, b, rss

def se_of(xs, ys):
    n = len(xs)
    xm = sum(xs) / n
    sxx = sum((x - xm) ** 2 for x in xs)
    a, b, rss = ols(xs, ys)
    s2 = rss / (n - 2)
    return math.sqrt(s2 / sxx)

def fit_panel(ds, key, bp, anchored=False, other=None):
    """单面板非饱和支拟合；anchored 时返回截距约束模型参数"""
    sub = [d for d in ds if d[key] > math.log10(bp)]
    xs = [d[key] for d in sub]
    ys = [d['logRHa'] for d in sub]
    return xs, ys, sub

print('=' * 70)
print('【C1】面板固定断点 0.132 OLS（自由截距）')
res = {}
for p in ('M0-M3', 'M4-M6'):
    sub = [d for d in data if d['panel'] == p and d['logRo30'] > math.log10(BP)]
    xs = [d['logRo30'] for d in sub]
    ys = [d['logRHa'] for d in sub]
    a, b, rss = ols(xs, ys)
    se = se_of(xs, ys)
    res[p] = (b, se, len(sub), rss)
    print(f'  {p}: n(非饱和)={len(sub)}  beta={b:.4f} ± {se:.4f}  RSS={rss:.2f}')
b1, se1, n1, rss1 = res['M0-M3']
b2, se2, n2, rss2 = res['M4-M6']
db = b1 - b2
sedb = math.sqrt(se1 ** 2 + se2 ** 2)
print(f'  Δβ = {db:.4f} ± {sedb:.4f} ({abs(db)/sedb:.2f}σ)')
print(f'  2σ阈={2*sedb:.3f}  1.96σ阈={1.96*sedb:.3f}  3σ阈={3*sedb:.3f}')
print(f'  观测差95%CI = {db-1.96*sedb:.3f} ~ {db+1.96*sedb:.3f}')

print('=' * 70)
print('【C1/坪区】坪区(Ro<0.132)星数')
for p in ('M0-M3', 'M4-M6', 'OTHER'):
    n = sum(1 for d in data if d['panel'] == p and d['logRo30'] <= math.log10(BP))
    print(f'  {p}: {n}')

print('=' * 70)
print('【C4】EW(Hα) < 0.75 Å 星数')
nlo = sum(1 for d in data if d['ewha'] < 0.75)
print(f'  {nlo} / 3340 = {nlo/3340*100:.1f}%  (讨论体: 729 / 21.8%)')

print('=' * 70)
print('【C2】高 S/N 半样本 (snrr ≥ 23.5) 固定断点 0.132')
sub = [d for d in data if d['snrr'] >= 23.5 and d['logRo30'] > math.log10(BP)]
xs = [d['logRo30'] for d in sub]
ys = [d['logRHa'] for d in sub]
a, b, rss = ols(xs, ys)
print(f'  n={len(sub)}  beta={b:.4f}  (讨论体: -1.096 ± 0.111)')

print('=' * 70)
print('【C3】全体自由断点扫描（1101 点, linspace(-2.4,-0.3)）')
def rss_at(ds, key, bp):
    lo = [d['logRHa'] for d in ds if d[key] <= math.log10(bp)]
    hi = [(d[key], d['logRHa']) for d in ds if d[key] > math.log10(bp)]
    c = sum(lo) / len(lo)
    rss = sum((y - c) ** 2 for y in lo)
    xs = [x for x, _ in hi]
    ys = [y for _, y in hi]
    _, b, r2 = ols(xs, ys)
    return rss + r2

import numpy as np
grid = np.linspace(-2.4, -0.3, 1101)
bp_lin = [10 ** g for g in grid]
rss_prof = [rss_at(data, 'logRo30', bp) for bp in bp_lin]
imin = int(np.argmin(rss_prof))
print(f'  RSS_min = {min(rss_prof):.3f} @ Ro={bp_lin[imin]:.4f}  (台账: 1132.20 @ 0.1352)')
for bpq, tag in ((0.05, '0.05'), (0.132, '0.132'), (0.20, '0.20'),
                 (0.1543, '0.1543'), (0.1577, '0.1577'), (0.1598, '0.1598')):
    i = min(range(len(bp_lin)), key=lambda i: abs(bp_lin[i] - bpq))
    print(f'  ΔRSS({tag}) = {rss_prof[i]-min(rss_prof):.3f}  (grid {bp_lin[i]:.5f})')

# 缺口窗口星数（-0.30 口径）
gap = [d for d in data if 0.155 < d['Ro30'] <= 0.160]
print(f'  缺口窗口 (0.155,0.160]: {len(gap)} 颗  (讨论体/台账: 29)')
from collections import Counter
print('   型别:', Counter(d['spt'] for d in gap))
win = [d for d in data if 0.150 <= d['Ro30'] <= 0.166]
print(f'  宽窗口 [0.150,0.166]: {len(win)} 颗  (台账: 73)')

print('=' * 70)
print('【C6】+0.31 (Wright 原式) 口径重算')
# 全体自由断点
rss31 = [rss_at(data, 'logRo31', bp) for bp in bp_lin]
imin31 = int(np.argmin(rss31))
print(f'  全体自由断点: RSS_min={min(rss31):.2f} @ {bp_lin[imin31]:.4f}  (台账: 0.069)')
# 全体固定断点 0.132
sub = [d for d in data if d['logRo31'] > math.log10(BP)]
a, b, rss = ols([d['logRo31'] for d in sub], [d['logRHa'] for d in sub])
print(f'  全体固定0.132: beta={b:.4f}  (讨论体 -0.30 口径: -0.857)')
# 全体固定断点 0.069
sub069 = [d for d in data if d['logRo31'] > math.log10(0.069)]
a, b069, rss = ols([d['logRo31'] for d in sub069], [d['logRHa'] for d in sub069])
print(f'  全体固定0.069: beta={b069:.4f}  (≈自由断点口径 {b069:.3f}; 台账5b: -0.913)')
# 面板：-0.30 vs +0.31，固定断点 0.132 与自由断点
print('  面板 β:')
for p in ('M0-M3', 'M4-M6'):
    for tag, key in (('-0.30', 'logRo30'), ('+0.31', 'logRo31')):
        sub = [d for d in data if d['panel'] == p and d[key] > math.log10(BP)]
        a, bfix, rss = ols([d[key] for d in sub], [d['logRHa'] for d in sub])
        # 自由断点（面板自己的 argmin，宽域网格）
        rp = [rss_at([d for d in data if d['panel'] == p], key, bp) for bp in bp_lin]
        ib = int(np.argmin(rp))
        sub2 = [d for d in data if d['panel'] == p and d[key] > math.log10(bp_lin[ib])]
        a2, bfree, _ = ols([d[key] for d in sub2], [d['logRHa'] for d in sub2])
        print(f'    {p} {tag}: 固定0.132 β={bfix:.4f}  自由({bp_lin[ib]:.4f}) β={bfree:.4f}')
print('  讨论体C6: 固定0.132 M0-M3约0.13(-0.890→-1.021), M4-M6约0.14(-0.822→-0.679);')
print('           自由断点 M0-M3约0.30(-0.642→-0.931), M4-M6约0.02')

print('=' * 70)
print('【C1】2×2 估计量对照（面板 Δβ 及 bootstrap σ, 400 次）')
random.seed(20261104)

def panel_fit_free(ds, key, nboot=0):
    """自由断点 + 自由截距"""
    rp = [rss_at(ds, key, bp) for bp in bp_lin]
    ib = int(np.argmin(rp))
    sub = [d for d in ds if d[key] > math.log10(bp_lin[ib])]
    _, b, _ = ols([d[key] for d in sub], [d['logRHa'] for d in sub])
    return b

def anchored_fit(d1, d2, key, bp):
    """两面板共享断点处高度 h, 各自斜率 (自由断点/固定断点通用)"""
    lbp = math.log10(bp)
    s1 = [(d[key], d['logRHa']) for d in d1 if d[key] > lbp]
    s2 = [(d[key], d['logRHa']) for d in d2 if d[key] > lbp]
    # 参数 h, b1, b2；设计矩阵
    A, Y = [], []
    for x, y in s1:
        A.append([1.0, x - lbp, 0.0]); Y.append(y)
    for x, y in s2:
        A.append([1.0, 0.0, x - lbp]); Y.append(y)
    # 最小二乘 (3 参数)
    import numpy as np
    A = np.array(A); Y = np.array(Y)
    sol, *_ = np.linalg.lstsq(A, Y, rcond=None)
    return sol[1], sol[2]

def anchored_bp_scan(d1, d2, key):
    best = None
    for bp in bp_lin:
        try:
            b1, b2 = anchored_fit(d1, d2, key, bp)
            # RSS
            lbp = math.log10(bp)
            s1 = [(d[key], d['logRHa']) for d in d1 if d[key] > lbp]
            s2 = [(d[key], d['logRHa']) for d in d2 if d[key] > lbp]
            h = None
            # 重算 h: 用拟合值
            import numpy as np
            A, Y = [], []
            for x, y in s1:
                A.append([1.0, x - lbp, 0.0]); Y.append(y)
            for x, y in s2:
                A.append([1.0, 0.0, x - lbp]); Y.append(y)
            A = np.array(A); Y = np.array(Y)
            sol, *_ = np.linalg.lstsq(A, Y, rcond=None)
            r = Y - A @ sol
            rss = float(r @ r)
            if best is None or rss < best[0]:
                best = (rss, sol[1], sol[2], bp)
        except Exception:
            pass
    return best

dA = [d for d in data if d['panel'] == 'M0-M3']
dB = [d for d in data if d['panel'] == 'M4-M6']

# 格1: 自由截距 + 固定 0.132
sA = [d for d in dA if d['logRo30'] > math.log10(BP)]
sB = [d for d in dB if d['logRo30'] > math.log10(BP)]
_, bA, _ = ols([d['logRo30'] for d in sA], [d['logRHa'] for d in sA])
_, bB, _ = ols([d['logRo30'] for d in sB], [d['logRHa'] for d in sB])
print(f'  格1 自由截距+固定0.132: Δβ={bA-bB:.4f} (讨论体: 0.068)')

# 格2: 锚定连续 + 固定 0.132
bA2, bB2 = anchored_fit(dA, dB, 'logRo30', BP)
print(f'  格2 锚定连续+固定0.132: Δβ={bA2-bB2:.4f} (台账8b: -0.63, 4.3σ; 讨论体: 4.1σ)')

# 格3: 自由截距 + 自由断点
bA3 = panel_fit_free(dA, 'logRo30')
bB3 = panel_fit_free(dB, 'logRo30')
print(f'  格3 自由截距+自由断点: Δβ={bA3-bB3:.4f}')

# 格4: 锚定连续 + 自由断点
rss4, bA4, bB4, bp4 = anchored_bp_scan(dA, dB, 'logRo30')
print(f'  格4 锚定连续+自由断点: Δβ={bA4-bB4:.4f} @bp={bp4:.4f} (台账8b: ≈1σ)')

print('=' * 70)
print('【历元】n_ep 中位数与 90% 分位')
n_eps = []
with open(BASE + '/数据/图5_历元峰值与平均.csv', encoding='utf-8-sig') as f:
    rd = csv.reader(f)
    hdr = None
    for row in rd:
        if not row:
            continue
        if row[0] == 'uid':
            hdr = row
            continue
        if hdr and len(row) >= 2:
            try:
                n_eps.append(int(float(row[hdr.index('n_ep')])))
            except Exception:
                pass
n_eps.sort()
nn = len(n_eps)
print(f'  N={nn}  中位={n_eps[nn//2]}  90%分位={n_eps[int(0.9*nn)]}  (讨论体: 中位1, 90%分位3)')
