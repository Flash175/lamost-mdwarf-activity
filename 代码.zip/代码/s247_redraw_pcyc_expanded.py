# -*- coding: utf-8 -*-
"""附_Pcyc_vs_Prot_扩展_自算.png 的独立重绘脚本（自包含 + 图面断言）

代际说明
--------
本图现行版本 = 文献 8 点 + 复算 2 点（GJ 205、GJ 876），共 10 点。
原绘图代码只存在于复现工程的 repro/src/s244_redraw_expanded.py，**从未归档进本包**
（该文件与包里已有的 s244_diag_rosat_degeneracy.py 是两件不同的事）。本脚本是它的重写：
不再读 C:\\Users\\lingz\\OneDrive\\... 的原始中间表，只用本包 数据/ 下的三份表，
并把「判据、点数、哪几颗被否」全部写成断言，图面与现行 PNG 逐点一致。

⚠ 不要重跑 2026-10-21 判据收紧之前的旧代脚本（已归档，重跑会把 0.75 判据冲回 0.5，
   并把 10 点图冲回 13 点 / 5 新点版本）：
     s231_pcyc_expanded.py · s232_pcyc_expanded_v2.py · s239_merge_prot.py
     s240_finalize_pcyc.py · s241_perm_fap.py · s242_quality_rebuild.py
   现行终表由 s243_fix_docs_audit.py 生成：perm_FAP ≤ 0.001 且 P_cyc ≤ 0.75×基线。

输入（全部在本包内）
--------------------
数据/文献活动周周期_20颗.csv        文献表（20 颗，其中有 P_cyc 且有 P_rot 的 8 颗入图）
数据/Pcyc与Prot_扩展样本.csv        复算点（按 s243 判据通过且有 5″ 内 VSX 周期的 2 颗）
数据/IB2025_周期质量表_置换FAP.csv  质量表（22 行，用于断言 6 颗置换检验里被否的 3 颗）

输出
----
图/附_Pcyc_vs_Prot_扩展_自算.png     （另：若 复现老师工作/图/对照与备选 存在则同步一份）

口径（改判据必须同步改这里的常量，否则断言即拦）
----------------------------------------------
FAP_MAX = 0.001（置换 bootstrap FAP，1000 次）; RATIO_MAX = 0.75（P_cyc/基线）
文献点误差棒：P_cyc_err_yr / P_rot_err_days（缺测则为零长误差棒）
"""

import io, os, sys, shutil
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA = os.path.join(ROOT, '数据')
OUT = os.path.join(ROOT, '图', '附_Pcyc_vs_Prot_扩展_自算.png')
MIRROR = os.path.join(r'C:\Users\lingz\Desktop\复现老师工作', '图', '对照与备选',
                      '附_Pcyc_vs_Prot_扩展_自算.png')

# ---- 定稿口径与图面原子（2026-10-21 收紧后；见 Methods §九）----
FAP_MAX, RATIO_MAX = 1e-3, 0.75
LIT_N = 8
LIT_STARS = ['GJ 285', 'LP 816-60', 'GJ 740', 'GJ 628',
             'GJ 447', 'GJ 184', 'GJ 4057', 'GJ 3997']
RECOMP = {'GJ 205': (33.61, 14.74), 'GJ 876': (16.86, 3.32)}   # star -> (P_rot d, P_cyc yr)
REJECTED = {'GJ 79': 0.334, 'GJ 699': 0.027, 'GJ 674': 0.011}  # 做过置换检验但被否的三颗
N_PERM = 6      # 做过置换检验的星数
N_PASS = 11     # 质量表 pass=True 的行数（其中 9 颗拿不到 5″ 内周期，故只入图 2 颗）
XLIM, YLIM = (1.5, 330.0), (1.5, 34.0)
TOL = 5e-3      # 表内数值精度为 2 位小数


def _need(p):
    if not os.path.exists(p):
        raise SystemExit('缺少输入文件：%s' % p)
    return p


def load():
    lit = pd.read_csv(_need(os.path.join(DATA, '文献活动周周期_20颗.csv')))
    lit['P_cyc'] = pd.to_numeric(lit.P_cyc_yr, errors='coerce')
    lit['ProT'] = pd.to_numeric(lit.P_rot_days, errors='coerce')
    ok = lit.dropna(subset=['P_cyc', 'ProT']).copy()

    use = pd.read_csv(_need(os.path.join(DATA, 'Pcyc与Prot_扩展样本.csv')))
    qual = pd.read_csv(_need(os.path.join(DATA, 'IB2025_周期质量表_置换FAP.csv')))
    return ok, use, qual


def check(ok, use, qual):
    # 1) 文献点：8 颗，星名集合逐一对上
    assert len(ok) == LIT_N, '文献入图点数 %d ≠ 定稿 %d' % (len(ok), LIT_N)
    assert set(ok.Star.str.strip()) == set(LIT_STARS), \
        '文献点星名不符：多 %s / 缺 %s' % (sorted(set(ok.Star) - set(LIT_STARS)),
                                        sorted(set(LIT_STARS) - set(ok.Star)))
    # 2) 复算点：2 颗，坐标与定稿原子一致
    assert len(use) == len(RECOMP), '复算点数 %d ≠ 定稿 %d' % (len(use), len(RECOMP))
    assert set(use.star.str.strip()) == set(RECOMP), \
        '复算点星名不符：%s' % sorted(use.star)
    for _, r in use.iterrows():
        pr, pc = RECOMP[str(r.star).strip()]
        assert abs(r.P_rot - pr) < TOL and abs(r.P_yr - pc) < TOL, \
            '%s 坐标 (%.3f, %.3f) ≠ 定稿 (%.3f, %.3f)' % (r.star, r.P_rot, r.P_yr, pr, pc)
        assert r.perm_FAP <= FAP_MAX, '%s 置换 FAP %.3f 未过 %.3f' % (r.star, r.perm_FAP, FAP_MAX)
        assert r.base_ratio <= RATIO_MAX, '%s P/基线 %.3f 未过 %.2f' % (r.star, r.base_ratio, RATIO_MAX)
        assert str(r.src) in ('VSX', 'TESS(ours)'), '未知 P_rot 来源：%s' % r.src

    # 3) 质量表：置换检验 6 颗、被否恰为脚注那 3 颗；pass=True 11 行、入图 2 颗
    perm = qual[qual.perm_FAP.notna()]
    assert len(perm) == N_PERM, '置换检验星数 %d ≠ %d' % (len(perm), N_PERM)
    perm_fail = set(perm[perm.perm_FAP > FAP_MAX].star.str.strip())
    assert perm_fail == set(REJECTED), '被否星名不符：%s' % sorted(perm_fail)
    for s, f in REJECTED.items():
        got = float(perm[perm.star.str.strip() == s].perm_FAP.iloc[0])
        assert abs(got - f) < TOL, '%s 置换 FAP %.3f ≠ 脚注口径 %.3f' % (s, got, f)
    assert int(qual['pass'].sum()) == N_PASS, \
        'pass=True 行数 %d ≠ %d（质量表若更新，请同步 N_PASS）' % (int(qual['pass'].sum()), N_PASS)
    assert N_PASS - len(use) == 9, '通过判据却无周期的星数应为 9，实为 %d' % (N_PASS - len(use))

    # 4) 全部点落在坐标域内（对数轴，出界即被裁掉却仍在图例里）
    for nm, x, y in [('literature', ok.ProT.values, ok.P_cyc.values),
                     ('recomputed', use.P_rot.values, use.P_yr.values)]:
        assert x.min() > XLIM[0] and x.max() < XLIM[1], '%s 的 P_rot 越界' % nm
        assert y.min() > YLIM[0] and y.max() < YLIM[1], '%s 的 P_cyc 越界' % nm


def draw(ok, use):
    fig, ax = plt.subplots(figsize=(7.0, 5.4))
    ax.errorbar(ok.ProT, ok.P_cyc, yerr=pd.to_numeric(ok.P_cyc_err_yr, errors='coerce'),
                xerr=pd.to_numeric(ok.P_rot_err_days, errors='coerce'),
                fmt='none', ecolor='0.78', lw=0.7, zorder=2)
    ax.scatter(ok.ProT, ok.P_cyc, s=34, c='#1f4fd8',
               label='literature table (N=%d)' % len(ok), zorder=3)

    # 复算点：VSX 周期用空心圆，TESS 自算周期用空心三角（现行数据全为 VSX）
    style = {'VSX': ('o', '#d95f02', '#8c3b00'),
             'TESS(ours)': ('^', '#2e8b57', '#2e8b57')}
    first = True
    for src, (mk, ec, tc) in style.items():
        q = use[use.src == src]
        if not len(q):
            continue
        ax.scatter(q.P_rot, q.P_yr, s=60, marker=mk, facecolors='none',
                   edgecolors=ec, lw=1.6, zorder=4,
                   label=('recomputed, permutation-FAP filtered (N=%d)' % len(use)) if first else '_nolegend_')
        first = False
        for _, r in q.iterrows():
            ax.annotate(str(r.star), (r.P_rot, r.P_yr), textcoords='offset points',
                        xytext=(7, 3), fontsize=6.6, color=tc)
    for _, r in ok.iterrows():
        ax.annotate(str(r.Star), (r.ProT, r.P_cyc), textcoords='offset points',
                    xytext=(5, -9), fontsize=5.9, color='0.4')

    ax.scatter([25.4], [11.0], marker='*', s=220, color='goldenrod',
               edgecolor='k', lw=0.6, zorder=5)
    ax.annotate('Sun', (25.4, 11.0), xytext=(7, -9), textcoords='offset points', fontsize=7)

    ax.set_xscale('log')
    ax.set_yscale('log')
    ax.set_xlabel('P$_{rot}$ (days)', fontsize=11)
    ax.set_ylabel('P$_{cyc}$ (years)', fontsize=11)
    ax.set_xlim(*XLIM)
    ax.set_ylim(*YLIM)
    ax.grid(alpha=0.25, which='both', lw=0.4)
    ax.tick_params(direction='in', top=True, right=True, labelsize=9)
    ax.legend(fontsize=7.0, loc='upper left', framealpha=0.95)
    ax.set_title('Activity cycle vs rotation period: %d literature + %d recomputed points'
                 % (len(ok), len(use)), fontsize=10)

    foot = ('Recomputed points require permutation-bootstrap FAP <= 0.1% and '
            'P$_{cyc}$ <= 0.75 x baseline.\n'
            'Three (GJ 79, GJ 699, GJ 674) were rejected by that test; '
            'the surviving sample is too small to define any relation.')
    ftxt = fig.text(0.5, 0.012, foot, ha='center', fontsize=6.3,
                    color='0.3', linespacing=1.6)
    fig.tight_layout(rect=(0, 0.075, 1, 1))
    return fig, ax, ftxt


def check_layout(fig, ax, ftxt):
    fig.canvas.draw()
    r = fig.canvas.get_renderer()

    def bb(o):
        b = o.get_window_extent(renderer=r).transformed(fig.transFigure.inverted())
        return (round(b.x0, 4), round(b.y0, 4), round(b.x1, 4), round(b.y1, 4))

    fb, xb, tb = bb(ftxt), bb(ax.xaxis.label), bb(ax.title)
    print('  [版式] 脚注 %s  xlabel %s  标题 %s' % (fb, xb, tb))
    assert fb[1] < xb[1] - 0.004, \
        '脚注与 x 轴标签重叠：脚注上沿 %.4f，xlabel 下沿 %.4f' % (fb[1], xb[1])
    assert 0.004 < fb[0] and fb[2] < 0.996, '脚注横向溢出：x0=%.4f x1=%.4f' % (fb[0], fb[2])
    assert tb[3] < 0.995, '标题顶到画布上沿：y1=%.4f' % tb[3]


def main():
    ok, use, qual = load()
    check(ok, use, qual)
    fig, ax, ftxt = draw(ok, use)
    check_layout(fig, ax, ftxt)

    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    fig.savefig(OUT, dpi=180)
    plt.close(fig)
    if os.path.isdir(os.path.dirname(MIRROR)):
        shutil.copy2(OUT, MIRROR)
        print('  已同步镜像 -> %s' % MIRROR)

    print('\n入图 %d 点（文献 %d + 复算 %d）' % (len(ok) + len(use), len(ok), len(use)))
    print('  %-10s %9s %14s %10s %8s %s' % ('star', 'P_rot(d)', 'P_cyc(yr)', 'FAP', 'P/base', 'src'))
    for _, r in ok.sort_values('P_cyc').iterrows():
        e = ('±%.1f' % r.P_cyc_err_yr) if pd.notna(r.P_cyc_err_yr) else '(err -)'
        print('  %-10s %9.1f %11.1f %-6s %10s %8s %s' % (str(r.Star), r.ProT, r.P_cyc, e, '-', '-', 'literature'))
    for _, r in use.iterrows():
        print('  %-10s %9.2f %11.2f %-6s %10.3f %8.3f %s'
              % (str(r.star), r.P_rot, r.P_yr, '', r.perm_FAP, r.base_ratio, r.src))
    print('  复算点判据：置换 FAP ≤ %.3f 且 P_cyc/基线 ≤ %.2f' % (FAP_MAX, RATIO_MAX))
    print('  被置换检验否掉：' + '、'.join('%s(FAP=%.3f)' % (k, v) for k, v in REJECTED.items()))
    print('  通过判据 %d 颗，其中 9 颗无 5″ 内 VSX 周期 → 只入图 2 颗' % N_PASS)
    print('已出图 -> %s' % OUT)


if __name__ == '__main__':
    main()
