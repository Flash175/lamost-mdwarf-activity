# -*- coding: utf-8 -*-
"""s561：①§11 的 9,383 差额来源；②χ²=29.2 是否可能由某种合理变体得到。"""
import io, sys, os
import numpy as np, pandas as pd
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
from scipy.stats import chi2 as chi2dist

cat = pd.read_csv('data/lamost/dr13/dr13_mstellar_dM.csv', low_memory=False,
                  usecols=['uid','subclass','teff','ewha','ewha_err','gaia_source_id'])
cat = cat[(cat.ewha > -20) & (cat.ewha <= 50) & (cat.ewha_err > 0) & (cat.ewha_err <= 5)].copy()
cat = cat.sort_values('ewha', ascending=False).drop_duplicates('uid')
g = pd.read_csv('data/gaia/gaia_dr3_mstars.csv', low_memory=False, usecols=['source_id','ruwe'])
g['sid'] = g.source_id.astype('int64')
cat['sid'] = pd.to_numeric(cat.gaia_source_id, errors='coerce')
cat = cat.merge(g[['sid','ruwe']].drop_duplicates('sid'), on='sid', how='left')
q = cat[cat.ruwe < 1.4]
print('M 侧（逐星 + ruwe<1.4）: %d' % len(q))
print('  Teff 为 NaN : %d' % int(q.teff.isna().sum()))
print('  Teff < 3100 : %d' % int((q.teff < 3100).sum()))
print('  Teff 3100-4200: %d' % int(((q.teff >= 3100) & (q.teff < 4200)).sum()))
print('  Teff >= 4200: %d' % int((q.teff >= 4200).sum()))
print('  表内 11 档（3100-4200）合计应为 %d；CSV 合计 633,213；差 %d'
      % (int(((q.teff >= 3100) & (q.teff < 4200)).sum()),
         int(((q.teff >= 3100) & (q.teff < 4200)).sum()) - 633213))

K = pd.read_csv(r'C:\Users\lingz\Desktop\复现老师工作\APJS\多个图及讨论\新图3_K与M活动比例.csv', comment='#')
K = K[K.kind == 'K']
n = K.n.values.astype(float); fr = K.frac.values/100.0
def chi(k, nn):
    pbar = k.sum()/nn.sum()
    return float((((k-nn*pbar)**2)/(nn*pbar*(1-pbar))).sum())
print('\nχ² 变体：')
print('  全部七档、未四舍五入        %.2f (p=%.2g)' % (chi(n*fr, n), chi2dist.sf(chi(n*fr, n), 6)))
i6 = [i for i,s in enumerate(K.spt) if s != 'K6']
K7 = K[K.spt != 'K2']
n7 = K7.n.values.astype(float); f7 = K7.frac.values/100
print('  去掉 K2（n=72）              %.2f (p=%.2g)' % (chi(n7*f7, n7), chi2dist.sf(chi(n7*f7, n7), len(n7)-1)))
k = np.round(n*fr)
# Yates 连续性校正
pbar = k.sum()/n.sum(); e = n*pbar
chiY = float(((np.abs(k-e)-0.5)**2/(e*(1-pbar))).sum())
print('  Yates 连续性校正            %.2f (p=%.2g)' % (chiY, chi2dist.sf(chiY, 6)))
# 用四舍五入到 0.1% 的比例
k2 = n*np.round(fr, 3)
print('  比例先四舍五入到 0.1%%       %.2f (p=%.2g)' % (chi(k2, n), chi2dist.sf(chi(k2, n), 6)))
# 合并 K0/K1/K2 与 K3/K4/K5/K7 两档
nG = np.array([282+566+72, 1317+411+2368+1095], float)
kG = np.array([round(282*0.014184)+round(566*0.010601)+0, round(1317*0.014427)+round(411*0.029197)+round(2368*0.016892)+round(1095*0.039269)], float)
print('  合并成两档                    %.2f' % chi(kG, nG))
print('s561 完成')
