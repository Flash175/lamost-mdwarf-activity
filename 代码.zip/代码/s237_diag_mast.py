# -*- coding: utf-8 -*-
"""诊断 MAST 返回结构（以 GJ 273 为例）"""
import io, sys, json, requests
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
import pandas as pd
W = 'https://mast.stsci.edu/api/v0/invoke'
S = pd.read_csv('data/processed/dr13/ib2025_ztf_periods.csv')
st = S[S.star.str.strip() == 'GJ 273'].iloc[0]
print('GJ 273 坐标 %.4f %.4f' % (st.ra, st.dec))
for req in [
    {'service': 'Mast.Caom.Cone', 'params': {'ra': float(st.ra), 'dec': float(st.dec), 'radius': 0.008}, 'format': 'json', 'pagesize': 50},
    {'service': 'Mast.Caom.Cone', 'params': {'ra': float(st.ra), 'dec': float(st.dec), 'radius': 0.008},
     'format': 'json', 'pagesize': 50, 'columns': '*'},
    {'service': 'Mast.Caom.Filtered', 'params': {'columns': '*', 'filters': [
        {'paramName': 'obs_collection', 'values': ['TESS']},
        {'paramName': 'dataproduct_type', 'values': ['timeseries']}]}, 'format': 'json', 'pagesize': 50}]:
    try:
        r = requests.post(W, data={'request': json.dumps(req)}, timeout=90)
        j = r.json(); d = j.get('data', [])
        print('  service=%s status=%s 行数=%d' % (req['service'], j.get('status'), len(d)))
        if d:
            keys = sorted(d[0].keys())
            print('    字段:', keys[:20])
            for row in d[:5]:
                print('    ', row.get('obs_collection'), '|', row.get('dataproduct_type'), '|',
                      row.get('productSubGroupDescription'), '|', row.get('productFilename'), '|', row.get('t_exptime'))
    except Exception as e:
        print('  异常', type(e).__name__, e)
