# -*- coding: utf-8 -*-
"""核对本地 SDSS(West+2011, J/AJ/141/97) 星表是否完整：与 VizieR 官方行数、论文数字比对。"""
import io, sys, json
import urllib.request
import pandas as pd
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

f = "data/vizier/aj141_97_sdss_dwarfs.csv"
df = pd.read_csv(f, low_memory=False)
print(f"本地行数 {len(df):,}   列数 {df.shape[1]}")
print(f"唯一 ObjID {df['ObjID'].nunique():,}   唯一 (Plate,MJD,Fiber) {len(df.drop_duplicates(['Plate','MJD','Fiber'])):,}")
w = pd.to_numeric(df["W(Ha)"], errors="coerce")
print(f"活动(W>=0.75) {int((w>=0.75).sum()):,}   论文写 17,991")
print(f"RA 范围 {df.RAJ2000.min():.2f}..{df.RAJ2000.max():.2f}   Dec 范围 {df.DEJ2000.min():.2f}..{df.DEJ2000.max():.2f}")
print(f"空值：RA {df.RAJ2000.isna().sum()}  Dec {df.DEJ2000.isna().sum()}  W(Ha) {w.isna().sum()}")
print()
# VizieR TAP 官方行数
q = ('SELECT COUNT(*) AS n FROM "J/AJ/141/97/table1"')
url = ("https://tapvizier.cds.unistra.fr/TAPVizieR/tap/sync?request=doQuery&lang=ADQL&format=json&query="
       + urllib.parse.quote(q))
try:
    with urllib.request.urlopen(url, timeout=60) as r:
        j = json.load(r)
    print("VizieR TAP J/AJ/141/97/table1 官方行数:", j["data"][0][0])
except Exception as e:
    print("TAP 查询失败:", type(e).__name__, str(e)[:200])
