
# -*- coding: utf-8 -*-
"""把 新图3 的 v2 数值写回中文草稿 §9 与英文 Figure C 图注（幂等替换）。"""
import io, os, sys
import pandas as pd
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
BS = chr(92)
OUT = r'C:\Users\lingz\Desktop\复现老师工作\APJS\多个图及讨论'
T = pd.read_csv(os.path.join(OUT, '新图3_K与M活动比例.csv'), comment='#')
K = T[T.kind == 'K']; Mn = T[T.kind == 'M']

def pct(x):
    return ('%.1f%%' % x) if pd.notna(x) else '-'

lines = ['## 9. K/M 过渡：活动比例从 K0 到 dM6 单调上升（v2 定稿）', '',
         '| 亚型 | 样本 | n | 活动比例 | S/N 6-20 的 n | S/N 6-20 活动比例 |',
         '|---|---|---|---|---|---|']
for _, r in T.iterrows():
    src = '本文自测' if r.kind == 'K' else '目录值'
    lines.append('| %s | %s | %d | %s | %d | %s |' % (r.spt, src, r.n, pct(r.frac), r.n_sn, pct(r.frac_sn)))
k0 = K.iloc[0]
m6 = Mn[Mn.spt == 'dM6']
f6 = pct(m6.frac.iloc[0]) if len(m6) else '-'
lines += ['',
 '**要点**：从 K0 到 dM6 活动比例单调上升（' + pct(k0.frac) + ' 到 ' + f6 + '），K/M 过渡处无台阶；K 侧合计 **' + str(int(K.n.sum())) + ' 颗**（其中 S/N 6-20 匹配 **' + str(int(K.n_sn.sum())) + ' 颗**），M 侧为目录全样本。冷端 dM7-dM8 的表观下降为已证明的探测效应（见第 7 节）。', '',
 '**图 A3（新图3_K与M活动比例.png）注**：活动比例随光谱亚型的变化。实线为全样本（紫色 K 型为本文自测，红色 M 型为目录值），虚线为 S/N 6-20 的匹配子样本；点上数字为该档星数，竖虚线标出 K/M 分界。K 侧用 LAMOST DR13 光谱按 Yi 等（2014）窗口自测 EW(Ha)，M 侧取 mstellar 目录值；两侧判据相同（EW >= 0.75 A 且 > 3 sigma）。']
cnp = os.path.join(OUT, '新一节_银盘示踪_中文草稿.md')
cn = open(cnp, encoding='utf-8').read()
i = cn.find('## 9. K/M')
cn = (cn[:i] if i >= 0 else cn.rstrip() + '\n\n') + '\n'.join(lines) + '\n'
open(cnp, 'w', encoding='utf-8').write(cn)

en = ('\n' + BS + 'textbf{Figure C (K/M transition).} Active fraction as a function of spectral\n'
 'subtype. Solid lines show all spectra (purple: K dwarfs measured here from LAMOST\n'
 'DR13 with the Yi et al. (2014)-style windows; red: catalogue values for M dwarfs)\n'
 'and dashed lines the S/N 6-20 matched subsamples; numbers give the stars per bin\n'
 'and the vertical dashed line marks the K/M boundary. The same activity criterion\n'
 '(EW >= 0.75 A and > 3 sigma) is applied on both sides. The fraction rises\n'
 'monotonically from ' + pct(k0.frac) + ' at K0 to ' + f6 + ' at dM6 with no step at the K/M\n'
 'transition, and the decline at dM7-dM8 is the detection effect demonstrated in\n'
 'the preceding section.\n')
txp = os.path.join(OUT, '新一节_银盘示踪_英文草稿.tex')
tx = open(txp, encoding='utf-8').read()
j = tx.find(BS + 'textbf{Figure C')
tx = (tx[:j] if j >= 0 else tx.rstrip() + '\n') + en
open(txp, 'w', encoding='utf-8').write(tx)
print('已写回 v2 数值：K 侧 ' + str(int(K.n.sum())) + ' 颗')
