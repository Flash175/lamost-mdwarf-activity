# -*- coding: utf-8 -*-
"""用 s174 当初同一函数(fit_saturation)复现 -0.912 / -0.764，确认口径"""
import io, os, sys
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
sys.path.insert(0, 'repro/src')
import numpy as np, pandas as pd
from common import activity as A
P = lambda f: os.path.join('data', 'processed', 'dr13', f)
d = pd.read_csv(P('fig5_sample_period_v4.csv'))
d = d[(d.Ro > 0) & (d.RHa > 0) & (d.Ro <= 3)]
print('s174 口径样本 n=%d' % len(d))
for nm, sel in (('M0–M3', ['dM0','dM1','dM2','dM3']), ('M4–M6', ['dM4','dM5','dM6'])):
    q = d[d.spt.isin(sel)]
    f5 = A.fit_saturation(q.Ro.values, q.RHa.values, n_boot=200)
    print('   %-7s n=%-5d ro_sat=%.3f±%.3f  beta=%.3f±%.3f  method=%s'
          % (nm, len(q), f5.ro_sat, f5.ro_sat_err, f5.slope, f5.slope_err, f5.method))
