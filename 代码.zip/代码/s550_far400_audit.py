
# -*- coding: utf-8 -*-
""">400 pc 那 346 颗（含 67 颗活动）的属性排查：Teff / logg / S/N / G。"""
import io, sys
import numpy as np, pandas as pd
from astropy.coordinates import SkyCoord
import astropy.units as un
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')

cat = pd.read_csv('data/lamost/dr13/dr13_mstellar_dM.csv', low_memory=False,
                  usecols=['uid','subclass','teff','logg','logg_err','ewha','ewha_err','snrr','ra','dec','gaia_source_id','gaia_g_mean_mag','class'])
cat = cat[(cat.ewha > -20) & (cat.ewha <= 50) & (cat.ewha_err > 0) & (cat.ewha_err <= 5)].copy()
cat['active'] = (cat.ewha >= 0.75) & (cat.ewha > 3*cat.ewha_err)
g = cat.sort_values('ewha', ascending=False).drop_duplicates('uid')
gal = pd.read_csv('data/gaia/gaia_dr3_mstars.csv', low_memory=False,
                  usecols=['source_id','parallax','parallax_error','pmra','pmdec','radial_velocity','ruwe'])
gal['sid'] = pd.to_numeric(gal.source_id, errors='coerce'); g['sid'] = pd.to_numeric(g.gaia_source_id, errors='coerce')
M = g.merge(gal, on='sid', how='left')
M = M[(M.parallax > 0.2) & (M.parallax/M.parallax_error > 5) & (M.ruwe < 1.4)]
M = M[np.isfinite(M.radial_velocity) & (np.abs(M.radial_velocity) < 500)].copy()
c = SkyCoord(ra=M.ra.values*un.deg, dec=M.dec.values*un.deg, distance=(1000.0/M.parallax.values)*un.pc,
             pm_ra_cosdec=M.pmra.values*un.mas/un.yr, pm_dec=M.pmdec.values*un.mas/un.yr,
             radial_velocity=M.radial_velocity.values*un.km/un.s, frame='icrs')
M['Z'] = np.abs(c.transform_to('galactocentric').z.to(un.kpc).value*1000)
far = M[M.Z > 400]
print('>400 pc 子样本: %d 颗，其中活动 %d 颗（%.2f%%）' % (len(far), int(far.active.sum()), 100*far.active.mean()))

for nm, s in (('活动', far[far.active]), ('非活动', far[~far.active])):
    print('\n[%s] n=%d' % (nm, len(s)))
    for col, unit in (('teff','K'), ('logg','dex'), ('snrr',''), ('gaia_g_mean_mag','mag'), ('ewha','Å'), ('ewha_err','Å')):
        v = pd.to_numeric(s[col], errors='coerce').dropna()
        if len(v)==0: print('  %-16s 无数据' % col); continue
        print('  %-16s 中位 %8.2f  16–84%%: %7.2f – %7.2f %s' % (col, v.median(), v.quantile(.16), v.quantile(.84), unit))
print('\n奇异值检查（活动星）：')
a = far[far.active]
for cond, lab in (((a.logg < 3.5), 'logg<3.5（巨星嫌疑）'),
                  ((a.snrr < 3), 'S/N<3'),
                  ((a.teff < 3000) | (a.teff > 4300), 'Teff 出 [3000,4300]'),
                  ((a.ewha > 20), 'EW>20 Å（耀发/QSO 嫌疑）')):
    print('  %-22s %d 颗' % (lab, int(cond.sum())))
print('\nclass 取值分布（活动）:', a['class'].value_counts().to_dict())
far.to_csv('data/processed/dr13/far400_audit.csv', index=False, encoding='utf-8-sig')
print('\n已保存 far400_audit.csv')
