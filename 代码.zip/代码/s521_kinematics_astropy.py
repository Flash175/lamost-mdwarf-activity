
# -*- coding: utf-8 -*-
"""活动–运动学（正式版）：astropy 转换到银心坐标系，RV 剔除异常值。"""
import io, sys
import numpy as np, pandas as pd
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
from astropy.coordinates import SkyCoord
import astropy.units as un

CAT = 'data/lamost/dr13/dr13_mstellar_dM.csv'
GAI = 'data/gaia/gaia_dr3_mstars.csv'
cat = pd.read_csv(CAT, low_memory=False,
                  usecols=['uid','subclass','teff','ewha','ewha_err','z','ra','dec','gaia_source_id'])
cat = cat[(cat.ewha > -20) & (cat.ewha <= 50) & (cat.ewha_err > 0) & (cat.ewha_err <= 5)]
cat['active'] = (cat.ewha >= 0.75) & (cat.ewha > 3*cat.ewha_err)
cat['gaia_source_id'] = pd.to_numeric(cat.gaia_source_id, errors='coerce')
g = pd.read_csv(GAI, low_memory=False, usecols=['source_id','parallax','parallax_error','pmra','pmdec','radial_velocity','ruwe'])
m = cat.merge(g, left_on='gaia_source_id', right_on='source_id', how='inner')
m = m[(m.parallax > 0.2) & (m.parallax/m.parallax_error > 5) & (m.ruwe < 1.4)]
m['rv'] = m.radial_velocity
u = m.sort_values('ewha', ascending=False).drop_duplicates('uid').copy()
u = u[np.isfinite(u.rv) & (np.abs(u.rv) < 500)]
print('逐星样本 %d 颗（有视差+自行+RV）' % len(u))

c = SkyCoord(ra=u.ra.values*un.deg, dec=u.dec.values*un.deg,
             distance=(1000.0/u.parallax.values)*un.pc,
             pm_ra_cosdec=u.pmra.values*un.mas/un.yr, pm_dec=u.pmdec.values*un.mas/un.yr,
             radial_velocity=u.rv.values*un.km/un.s, frame='icrs')
gc = c.transform_to('galactocentric')
v = gc.velocity.d_xyz.to(un.km/un.s).value
u['X'], u['Y'], u['Z'] = gc.x.to(un.kpc).value, gc.y.to(un.kpc).value, gc.z.to(un.kpc).value
u['vx'], u['vy'], u['vz'] = v[0], v[1], v[2]
u['absz_pc'] = np.abs(u.Z)*1000

for nm, sel in (('活动', u.active), ('非活动', ~u.active)):
    s = u[sel]
    print('%s n=%6d | σ(vx)=%.1f σ(vy)=%.1f σ(vz)=%.1f km/s | |Z| 中位 %.0f pc'
          % (nm, len(s), s.vx.std(), s.vy.std(), s.vz.std(), s.absz_pc.median()))
print('\n按 |Z| 分层：')
u['zb'] = pd.cut(u.absz_pc, [0,100,200,400,3000], labels=['<100','100-200','200-400','>400'])
for b_ in u.zb.cat.categories:
    s = u[u.zb == b_]; a = s[s.active]; i = s[~s.active]
    print('  |Z| %-8s n=%6d 活动比例 %5.1f%% | σ(vz) 活动 %.1f (n=%5d) / 非活动 %.1f (n=%6d)'
          % (b_, len(s), 100*s.active.mean(), a.vz.std(), len(a), i.vz.std(), len(i)))
