
# -*- coding: utf-8 -*-
"""(2) 活动率随光谱型的双端下降；(3) Ro–活动关系是否依赖 |Z|。"""
import io, sys
import numpy as np, pandas as pd
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
CAT = 'data/lamost/dr13/dr13_mstellar_dM.csv'
cat = pd.read_csv(CAT, low_memory=False, usecols=['uid','subclass','teff','ewha','ewha_err','snrr','gaia_source_id'])
cat = cat[(cat.ewha > -20) & (cat.ewha <= 50) & (cat.ewha_err > 0) & (cat.ewha_err <= 5)].copy()
cat['active'] = (cat.ewha >= 0.75) & (cat.ewha > 3*cat.ewha_err)
print('按光谱型（DR13 Hα，量程闸门后）：')
print('  亚型   光谱数    星数   活动率%%   EW 中位  S/N_r 中位  Teff 中位')
for sp in ['dM0','dM1','dM2','dM3','dM4','dM5','dM6','dM7','dM8']:
    s = cat[cat.subclass == sp]
    if len(s) < 50: continue
    print('  %-4s %8d %7d   %5.1f    %6.2f     %5.1f     %6.0f'
          % (sp, len(s), s.uid.nunique(), 100*s.active.mean(), s.ewha.median(), s.snrr.median(), s.teff.median()))

# (3) Ro–活动关系对 |Z| 的依赖
A = pd.read_csv('repro/_zipcheck/图五及相关数据/数据/图5_逐星样本_严格3340行_⑤_tau030.csv')
g = pd.read_csv('data/gaia/gaia_dr3_mstars.csv', low_memory=False, usecols=['source_id','parallax','ra','dec'])
A['gaia_source_id'] = pd.to_numeric(A.gaia_source_id, errors='coerce')
m = A.merge(g, left_on='gaia_source_id', right_on='source_id', how='left')
m['dist_pc'] = np.where(m.parallax > 0.2, 1000.0/m.parallax, np.nan)
# 2026-10-26 修正：原写法把赤纬当银纬（z = d·sin(dec)），中位会从 180 pc 偏到 125 pc。
# 改用 astropy 银道坐标的银纬 b。
from astropy.coordinates import SkyCoord
import astropy.units as u
_c = SkyCoord(ra=m.ra.values*u.deg, dec=m.dec.values*u.deg, frame='icrs')
m['z_pc'] = m.dist_pc*np.sin(np.radians(_c.galactic.b.to(u.deg).value))
s = m.dropna(subset=['z_pc','Ro','RHa']).copy()
s['absz'] = np.abs(s.z_pc)
s['x'] = np.log10(s.Ro); s['y'] = np.log10(s.RHa)
med = s.absz.median()
def beta(d, bp=0.132):
    u = d.x > np.log10(bp)
    return np.polyfit(d[u].x, d[u].y, 1)[0] if u.sum() >= 20 else np.nan
print('\nRo–活动关系按 |Z| 二分（全部面板合并，固定断点 0.132）：')
print('  |Z| 中位 = %.0f pc，可用 %d 颗' % (med, len(s)))
for nm, sel in (('低 |Z| 半', s.absz <= med), ('高 |Z| 半', s.absz > med)):
    d = s[sel]
    print('  %-10s n=%4d  β = %+.3f   y 弥散 = %.3f   |Z| 中位 %.0f pc'
          % (nm, len(d), beta(d), d.y.std(), d.absz.median()))
