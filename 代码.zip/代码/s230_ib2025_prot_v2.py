# -*- coding: utf-8 -*-
"""修正解析（≥6 tokens）后重新交叉 VSX"""
import io, os, sys
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
import numpy as np, pandas as pd
from scipy.spatial import cKDTree
rows = []
for line in open('data/raw/ib2025/sources.dat', encoding='utf-8', errors='replace'):
    if len(line.strip()) < 12: continue
    name = line[:11].strip(); tok = line[11:].split()
    if len(tok) < 6: continue
    hh, mm, ss = float(tok[0]), float(tok[1]), float(tok[2])
    dd, dm, ds = float(tok[3]), float(tok[4]), float(tok[5])
    rows.append(dict(star=name, ra=15*(hh+mm/60+ss/3600), dec=np.sign(dd)*(abs(dd)+dm/60+ds/3600), extra=' '.join(tok[6:])))
S = pd.DataFrame(rows); print('IB2025 星表 %d 颗' % len(S))
def uv(ra, dec):
    ra = np.radians(np.asarray(ra, float)); dec = np.radians(np.asarray(dec, float))
    return np.column_stack([np.cos(dec)*np.cos(ra), np.cos(dec)*np.sin(ra), np.sin(dec)])
v = pd.read_csv('data/vizier/vsx_variables.csv', low_memory=False,
                usecols=lambda c: c in {'Name','Type','Period','RAJ2000','DEJ2000'})
v = v[v.RAJ2000.notna() & v.DEJ2000.notna()]
v['Period'] = pd.to_numeric(v.Period, errors='coerce')
# 每颗 IB2025 星取最近的 VSX 条目，且优先 ROT+有周期
tree = cKDTree(uv(v.RAJ2000.values, v.DEJ2000.values))
d, i = tree.query(uv(S.ra.values, S.dec.values), k=5, distance_upper_bound=np.radians(60/3600))
rows2 = []
for k in range(len(S)):
    cand = []
    for col in range(d.shape[1]):
        dd, ii = d[k, col], i[k, col]
        if not np.isfinite(dd) or ii >= len(v): continue
        r = v.iloc[ii]
        cand.append(dict(star=S.star[k], vsx_name=r.Name, vsx_type=r.Type, P=r.Period, sep_as=dd*3600))
    if not cand: rows2.append(dict(star=S.star[k], vsx_name='', vsx_type='', P=np.nan, sep_as=np.nan)); continue
    c = pd.DataFrame(cand)
    c['rot'] = c.vsx_type.astype(str).str.upper().str.contains('ROT') & c.P.notna()
    c = c.sort_values(['rot', 'sep_as'], ascending=[False, True])
    rows2.append(c.iloc[0].to_dict())
M = pd.DataFrame(rows2).drop(columns=['star']).reset_index(drop=True)
S = pd.concat([S.reset_index(drop=True), M], axis=1)
S['P_rot'] = S.P
good = S.P_rot.notna()
print('60" 内有 VSX 对应：%d 颗；其中带 ROT 周期：%d 颗' % (int((S.vsx_name != '').sum()), int(good.sum())))
print(S[S.vsx_name != ''][['star','vsx_name','vsx_type','P_rot','sep_as']].to_string(index=False))
S.to_csv('data/processed/dr13/ib2025_stars_with_prot.csv', index=False)
print('\n可用 P_rot 的星：', S.loc[good, 'star'].tolist())
