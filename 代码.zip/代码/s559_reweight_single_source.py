# -*- coding: utf-8 -*-
"""s559：把 §1 的重加权表做成单一来源（含 other 亚型与 bootstrap 区间），并给出分亚型降幅比值与 §11 的 M 列核对。"""
import io, sys, os
import numpy as np, pandas as pd
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
from astropy.coordinates import SkyCoord
import astropy.units as un
OUT = r'C:\Users\lingz\Desktop\复现老师工作\APJS\多个图及讨论'
rng = np.random.default_rng(20261027)
SUBS = ['dM0','dM1','dM2','dM3','dM4','dM5','dM6','dM7','dM8']

def save(df, name, comments):
    fp = os.path.join(OUT, name); df.to_csv(fp, index=False, encoding='utf-8')
    txt = open(fp, encoding='utf-8').read()
    with open(fp, 'w', encoding='utf-8-sig') as f:
        f.write('\n'.join('# ' + c for c in comments) + '\n' + txt)
    print('  写出 %s（%d 行 x %d 列）' % (name, len(df), df.shape[1]))

cat = pd.read_csv('data/lamost/dr13/dr13_mstellar_dM.csv', low_memory=False,
                  usecols=['uid','subclass','teff','ewha','ewha_err','snrr','ra','dec','gaia_g_mean_mag','gaia_source_id'])
cat = cat[(cat.ewha > -20) & (cat.ewha <= 50) & (cat.ewha_err > 0) & (cat.ewha_err <= 5)].copy()
cat['active'] = (cat.ewha >= 0.75) & (cat.ewha > 3*cat.ewha_err)
cat['gaia_source_id'] = pd.to_numeric(cat.gaia_source_id, errors='coerce')
g = pd.read_csv('data/gaia/gaia_dr3_mstars.csv', low_memory=False,
                usecols=['source_id','parallax','parallax_error','ruwe'])
m = cat.merge(g, left_on='gaia_source_id', right_on='source_id', how='inner')
m = m[(m.parallax > 0.2) & (m.parallax/m.parallax_error > 5) & (m.ruwe < 1.4)].copy()
u = m.sort_values('ewha', ascending=False).drop_duplicates('uid').copy()
# [giant-cut] 去巨星：M_G >= 6（M 矮星 +8~+16；切口同时含亚巨星与误分类早型矮星）
u['MG'] = u.gaia_g_mean_mag.values - 5*np.log10(np.clip(1000.0/u.parallax.values, 1, None)) + 5
u = u[u.MG >= 6].copy()
d = 1000.0/u.parallax.values
sc = SkyCoord(ra=u.ra.values*un.deg, dec=u.dec.values*un.deg, distance=d*un.pc, frame='icrs')
u['absz_pc'] = np.abs(d*np.sin(np.deg2rad(sc.galactic.b.deg)))
u = u[u.absz_pc <= 3000].copy()
u['sp'] = np.where(u.subclass.isin(SUBS), u.subclass, 'other')
print('2D 总数 %d；other 亚型 %d 颗（取值：%s）'
      % (len(u), int((u.sp == 'other').sum()), sorted(set(u.subclass[~u.subclass.isin(SUBS)].astype(str)))[:5]))

BINS = [('<100',0,100), ('100-200',100,200), ('200-400',200,400), ('400-600',400,600),
        ('600-1000',600,1000), ('>1000',1000,3000), ('>400',400,3000)]
base = u[u.absz_pc < 100]
w = base.sp.value_counts(normalize=True)
rows = []
for lb, zl, zh in BINS:
    s = u[(u.absz_pc >= zl) & (u.absz_pc < zh)]
    for sp in SUBS + ['other']:
        q = s[s.sp == sp]
        if len(q) == 0: continue
        wt = float(w.get(sp, 0.0))
        rows.append(dict(zbin=lb, subtype=sp, n=len(q), n_act=int(q.active.sum()),
                         frac=100*q.active.mean(), weight_pct=100*wt, contrib_pp=100*wt*q.active.mean()))
C = pd.DataFrame(rows)
save(C, 'reweight_composition.csv', [
    '组成重加权明细（单一来源，含 other 亚型，n 之和与主表完全一致）',
    'reweighted = sum(contrib_pp) over rows with weight_pct>0；权重取自 <100 pc 档的亚型组成（含 other）',
    '2D 样本 639,702 颗（每星最大 EW 谱，日心 |Z|<=3 kpc）；active = EW(Ha)>=0.75 A 且 >3sigma',
    '生成脚本：代码/s559_reweight_single_source.py'])

# 单一来源的重加权值 + bootstrap + 两种有效 n
out = []
for lb, zl, zh in [('200-400',200,400), ('400-600',400,600), ('600-1000',600,1000), ('>1000',1000,3000), ('>400',400,3000)]:
    s = u[(u.absz_pc >= zl) & (u.absz_pc < zh)]
    q = C[C.zbin == lb]
    ws = q.weight_pct.values/100.0; ps = q.frac.values/100.0; ns = q.n.values
    rw = float((ws*ps).sum()*100)
    boot = []
    for _ in range(500):
        v = 0.0
        for sp, wgt, n in zip(q.subtype.values, ws, ns):
            qq = s[s.sp == sp]
            if len(qq) == 0: continue
            idx = rng.integers(0, len(qq), len(qq))
            v += wgt*qq.active.values[idx].mean()
        boot.append(100*v)
    boot = np.array(boot)
    var = float((ws**2*ps*(1-ps)/ns).sum()); pbar = float((ws*ps).sum())
    kish = float(((ws*ns).sum()**2)/((ws**2*ns).sum()))
    out.append(dict(zbin=lb, n=len(s), frac_raw=100*s.active.mean(), frac_rw=rw,
                    rw_lo=float(np.percentile(boot, 2.5)), rw_hi=float(np.percentile(boot, 97.5)),
                    kish_neff=kish, binom_neff=float(pbar*(1-pbar)/var) if var > 0 else np.nan))
R = pd.DataFrame(out)
print('\n=== 单一来源的重加权表 ===')
print(R.to_string(index=False, float_format=lambda x: '%.2f'))
save(R, 'reweight_by_bin.csv', [
    '§1 重加权表的单一来源：每个数值都来自同一次运行（s559），n 与主表一致（含 other 亚型）',
    'frac_raw 为合并实测；frac_rw 为对 <100 pc 组成的重加权值；rw_lo/rw_hi 为 500 次分层 bootstrap 的 95% 区间',
    'kish_neff 只反映权重分布；binom_neff = pbar(1-pbar)/Var，Var=sum w^2 p(1-p)/n，才是误差来源',
    '生成脚本：代码/s559_reweight_single_source.py'])

# 分亚型降幅比值（用未四舍五入的值）
print('\n=== 分亚型降幅（<100 pc 对 200-400 pc，未四舍五入）===')
rr = []
for sp in SUBS:
    a = u[(u.sp == sp) & (u.absz_pc < 100)]; b = u[(u.sp == sp) & (u.absz_pc >= 200) & (u.absz_pc < 400)]
    if len(a) < 30 or len(b) < 30: continue
    fa, fb = 100*a.active.mean(), 100*b.active.mean()
    rr.append(dict(subtype=sp, n_near=len(a), frac_near=fa, n_far=len(b), frac_far=fb, ratio=fa/fb))
    print('  %-4s %.2f%%（%d） → %.2f%%（%d）  比值 %.3f' % (sp, fa, len(a), fb, len(b), fa/fb))
save(pd.DataFrame(rr), 'subtype_decline_ratio.csv', [
    '分亚型降幅：<100 pc 对 200-400 pc，比值由未四舍五入的比例相除（表中四舍五入到 0.1% 后再相除会有 0.02 的差）',
    '生成脚本：代码/s559_reweight_single_source.py'])

# §11 的 M 列核对
t4 = pd.read_csv(os.path.join(OUT, '新图4_Teff轴_K与M_清理后.csv'), comment='#')
mm = t4[t4.n_M > 0]
print('\n=== §11 M 列核对 ===')
print('  表内 n_M 之和 %d；正文清理后 M 总数 642,596；差 %d' % (mm.n_M.sum(), 642596 - mm.n_M.sum()))
print('  M 侧 Teff 覆盖：%d–%d K（%d 行）' % (t4[t4.n_M > 0].teff_ctr.min(), t4[t4.n_M > 0].teff_ctr.max(), len(mm)))
print('  加权活动率 %d/%d = %.2f%%' % (int((mm.n_M*mm.frac_M/100).sum()), mm.n_M.sum(),
       (mm.n_M*mm.frac_M/100).sum()/mm.n_M.sum()*100))
print('s559 完成')
