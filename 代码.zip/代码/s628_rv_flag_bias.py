
import pandas as pd, numpy as np
D = r'C:\Users\lingz\Desktop\复现老师工作\APJS\多个图及讨论'
# recompute the flag rates by activity using the saved candidate table + clean sample
cand = pd.read_csv(D + r'\RV变星_SB1候选_多历元.csv')
cl = pd.read_csv(D + r'\金属度_清洁样本_637973.csv', low_memory=False, usecols=['uid','active','subclass','absz'])
cl = cl[cl.subclass.isin(['dM0','dM1','dM2','dM3','dM4','dM5','dM6'])]
cl['flag'] = cl.uid.isin(set(cand.uid))
m = cl[cl.flag | (cl.uid.isin(set(cand.uid)) | True)]
print('clean sample', len(cl), '| in candidate table', int(cl.flag.sum()))
act = cl[cl.active==1]; ina = cl[cl.active==0]
print('flagged among ACTIVE: %d / %d = %.1f%%' % (act.flag.sum(), len(act), 100*act.flag.mean()))
print('flagged among INACTIVE: %d / %d = %.1f%%' % (ina.flag.sum(), len(ina), 100*ina.flag.mean()))
for lb, lo, hi in [('<100',0,100), ('200-400',200,400)]:
    s = cl[(cl.absz>lo)&(cl.absz<=hi)]
    a = s[s.active==1]; i2 = s[s.active==0]
    print('%s: active flagged %.1f%%, inactive flagged %.1f%%' % (lb, 100*a.flag.mean(), 100*i2.flag.mean()))
