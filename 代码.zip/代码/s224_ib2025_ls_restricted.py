# -*- coding: utf-8 -*-
"""IB2025 Table B1：限定 2-25 yr、基线>=8 yr 的 LS 周期复算，并把原文表存进项目"""
import io, os, re, shutil, sys
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
import numpy as np, pandas as pd
from scipy.signal import lombscargle
SRC = r'C:\Users\lingz\.dsh-community\attachments\v1\files\31\31afcd15d6f6354f1aaff218069e1030f10d7983a87b4efd8b3ac878bde8b2e4\tableb1.dat.txt'
SRC2 = r'C:\Users\lingz\.dsh-community\attachments\v1\files\ed\ed2dcc526f6033c16f942ab6abaad72e4d41d552313dd2a89600e48ae5264479\sources.dat.txt'
os.makedirs('data/raw/ib2025', exist_ok=True)
shutil.copy2(SRC, 'data/raw/ib2025/tableb1_time_series.dat')
shutil.copy2(SRC2, 'data/raw/ib2025/sources.dat')
rows = []
for line in open(SRC, encoding='utf-8', errors='replace'):
    m = re.match(r'^(.{10})(\s*\d+\.?\d*)\s+(.*)$', line.rstrip('\n'))
    if not m: continue
    try: rows.append((m.group(1).strip(), float(m.group(2)), float(m.group(3).strip().split()[-1])))
    except Exception: pass
t = pd.DataFrame(rows, columns=['star', 'hjd', 'val'])
out = []
for star, g in t.groupby('star'):
    g = g.sort_values('hjd'); x = (g.hjd.values - g.hjd.min())/365.25; y = g.val.values
    if len(x) < 15 or x.max() < 8: continue
    y = y - y.mean()
    f = np.linspace(1/25.0, 1/2.0, 30000)
    p = lombscargle(x, y, f*2*np.pi, normalize=True)
    i = int(np.argmax(p)); pk = float(p[i]); P = 1/f[i]; N = len(x)
    fap = (1.0 - pk) ** ((N - 3)/2.0)
    mask = np.abs(f - f[i]) > 0.1*f[i]
    j = int(np.argmax(np.where(mask, p, -1)))
    out.append(dict(star=star, N=N, baseline_yr=round(float(x.max()), 1), P_yr=round(P, 2),
                    power=round(pk, 3), FAP=float('%.3g' % fap), P2_yr=round(1/f[j], 2), power2=round(float(p[j]), 3)))
r = pd.DataFrame(out).sort_values('P_yr')
r.to_csv('data/processed/dr13/ib2025_periodogram_selfcomputed.csv', index=False)
pd.set_option('display.width', 200)
print('可分析星数 %d（N>=15、基线>=8 yr）' % len(r))
print(r.to_string(index=False))
print('\nFAP<0.01: %d ; FAP<0.05: %d ; 落在 3-19 yr 且 FAP<0.05: %d'
      % (int((r.FAP < 0.01).sum()), int((r.FAP < 0.05).sum()), int(((r.P_yr >= 3) & (r.P_yr <= 19) & (r.FAP < 0.05)).sum())))
