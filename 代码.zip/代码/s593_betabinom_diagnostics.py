# -*- coding: utf-8 -*-
"""s593：β-二项的三个口径核对（回答审稿人式追问）

1) 「二项偏差/dof」的确切定义：细胞级二项 deviance = 2*(ℓ_sat − ℓ_fit)，dof = 细胞数 − 参数数
2) 同一设计下的 Pearson 散布：X²_binom = Σ (k−nμ)²/(nμ(1−μ))，以及 β-二项方差下的
   X²_BB = Σ (k−nμ)²/(nμ(1−μ)[1+ρ(n−1)])
3) 说明 ρ 与 deviance/dof 为何不必相等：deviance 每格只计 1 个 dof，而 β-二项似然按信息量（≈n）加权，
   5 pc 格的 n 从 1 跨到上万
4) 交代样本量：2D 样本 637,973 → 剔除亚型 n<500 的 dM7–dM9 后 637,352
输出：多个图及讨论/betabinom_diagnostics.csv
"""
import io, sys, os
import numpy as np, pandas as pd
from scipy.optimize import minimize
from scipy.special import expit, gammaln
from astropy.coordinates import SkyCoord
import astropy.units as un

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
OUT = r'C:\Users\lingz\Desktop\复现老师工作\APJS\多个图及讨论'

cat = pd.read_csv('data/lamost/dr13/dr13_mstellar_dM.csv', low_memory=False,
                  usecols=['uid','subclass','teff','ewha','ewha_err','snrr',
                           'ra','dec','gaia_source_id','gaia_g_mean_mag'])
cat = cat[(cat.ewha > -20) & (cat.ewha <= 50) & (cat.ewha_err > 0) & (cat.ewha_err <= 5)].copy()
cat['active'] = (cat.ewha >= 0.75) & (cat.ewha > 3*cat.ewha_err)
cat['gaia_source_id'] = pd.to_numeric(cat.gaia_source_id, errors='coerce')
g = pd.read_csv('data/gaia/gaia_dr3_mstars.csv', low_memory=False,
                usecols=['source_id','parallax','parallax_error','ruwe'])
m = cat.merge(g, left_on='gaia_source_id', right_on='source_id', how='inner')
m = m[(m.parallax > 0.2) & (m.parallax/m.parallax_error > 5) & (m.ruwe < 1.4)].copy()
u = m.sort_values('ewha', ascending=False).drop_duplicates('uid').copy()
u['MG'] = u.gaia_g_mean_mag.values - 5*np.log10(np.clip(1000.0/u.parallax.values, 1, None)) + 5
n_pre = len(u); u = u[u.MG >= 6].copy(); n_cut = n_pre - len(u)
d_pc = 1000.0/u.parallax.values
sc = SkyCoord(ra=u.ra.values*un.deg, dec=u.dec.values*un.deg, distance=d_pc*un.pc, frame='icrs')
u['absz'] = np.abs(d_pc*np.sin(np.deg2rad(sc.galactic.b.deg)))
u = u[u.absz <= 3000].copy()
u['subc'] = u.subclass.astype(str)
print('2D 样本 %d 颗（此前去掉 |Z|>3 kpc 之前的去巨星数 %d）' % (len(u), n_cut))
vc = u.subc.value_counts().sort_index()
print('逐亚型计数：' + '  '.join('%s=%d' % (k, v) for k, v in vc.items()))
keep = [s for s in vc.index if vc[s] >= 500]
drop = [s for s in vc.index if vc[s] < 500]
print('保留（n>=500）: %s；剔除: %s，合计 %d 颗' % ('/'.join(keep), '/'.join('%s(%d)' % (s, vc[s]) for s in drop), int(vc[drop].sum())))

u = u[u.subc.isin(keep)].copy()
print('进入 β-二项拟合：%d 颗' % len(u))
u['zcell'] = (u.absz // 5).astype(int)
cell = u.groupby(['subc','zcell'], observed=True).agg(n=('active','size'), k=('active','sum'),
                                                     zmean=('absz','mean')).reset_index()
cn = cell.n.values.astype(float); ck = cell.k.values.astype(float); cz = cell.zmean.values/1000.0
print('细胞数 %d；n 的算术平均 %.1f、中位 %.0f、最大 %.0f' % (len(cell), cn.mean(), np.median(cn), cn.max()))
subs = sorted(keep)

def design(fe):
    cols = [np.ones_like(cz), cz]
    for k0 in (0.05, 0.1, 0.2, 0.4, 0.6, 1.0):
        cols.append(np.clip(cz-k0, 0, None))
    if fe:
        for s in subs[1:]:
            cols.append((cell.subc.values == s).astype(float))
    return np.column_stack(cols)

def binomial_fit(X):
    def nll(b):
        mu = np.clip(expit(X @ b), 1e-8, 1-1e-8)
        return -float((ck*np.log(mu) + (cn-ck)*np.log(1-mu)).sum())
    r = minimize(nll, np.zeros(X.shape[1]), method='BFGS', options=dict(maxiter=5000, gtol=1e-9))
    return r.x, r.fun

def bb_fit(X):
    def nll(th):
        beta = th[:-1]; phi = np.exp(th[-1])
        mu = np.clip(expit(X @ beta), 1e-8, 1-1e-8)
        a = mu*phi; b = (1-mu)*phi
        ll = (gammaln(cn+1) - gammaln(ck+1) - gammaln(cn-ck+1)
              + gammaln(ck+a) + gammaln(cn-ck+b) - gammaln(cn+phi)
              + gammaln(phi) - gammaln(a) - gammaln(b))
        return -float(ll.sum())
    th0 = np.concatenate([np.zeros(X.shape[1]), [np.log(10.0)]])
    r = minimize(nll, th0, method='BFGS', options=dict(maxiter=8000, gtol=1e-9))
    return r.x[:-1], np.exp(r.x[-1]), r.fun

rows = []
for fe, tag in [(False, 'B1 仅样条'), (True, 'B2 样条+亚型FE')]:
    X = design(fe); p = X.shape[1]
    b_bin, nll_bin = binomial_fit(X)
    mu_b = np.clip(expit(X @ b_bin), 1e-8, 1-1e-8)
    pp = ck/cn
    with np.errstate(divide='ignore', invalid='ignore'):
        t1 = np.where(ck > 0, ck*np.log(np.where(ck > 0, pp, 1.0)), 0.0)
        q = 1-pp
        t2 = np.where(cn-ck > 0, (cn-ck)*np.log(np.where(cn-ck > 0, q, 1.0)), 0.0)
    sat = float((t1+t2).sum())
    dev = 2*(sat + nll_bin); dof = len(cell) - p
    x2_bin = float((((ck - cn*mu_b)**2)/(cn*mu_b*(1-mu_b))).sum())/dof

    beta, phi, nll_bb = bb_fit(X)
    rho = 1/(phi+1)
    mu = np.clip(expit(X @ beta), 1e-8, 1-1e-8)
    var_bb = cn*mu*(1-mu)*(1 + rho*(cn-1))
    x2_bb = float((((ck - cn*mu)**2)/var_bb).sum())/(len(cell) - p)

    # 只看 n>=20 的格：deviance 主要由这些格贡献
    big = cn >= 20
    dev_big = 2*(float((t1[big]+t2[big]).sum()) + (-nll_bin)) if False else np.nan
    print('\n%s（参数 %d）' % (tag, p))
    print('  二项 deviance/dof（细胞级）= %.2f' % (dev/dof))
    print('  二项 Pearson X²/dof          = %.2f' % x2_bin)
    print('  φ = %.1f，ρ = %.3f，1+ρ(n̄−1) = %.1f（n̄ = %.0f）' % (phi, rho, 1+rho*(cn.mean()-1), cn.mean()))
    print('  β-二项方差下的 Pearson X²/dof = %.2f' % x2_bb)
    rows.append(dict(model=tag, n_par=p, n_cells=len(cell), n_stars=int(cn.sum()),
                     dev_over_dof=dev/dof, pearson_binom_over_dof=x2_bin,
                     phi=phi, rho=rho, n_mean=float(cn.mean()),
                     expected_dispersion=float(1+rho*(cn.mean()-1)),
                     pearson_BB_over_dof=x2_bb))
save = None
df = pd.DataFrame(rows)
fp = os.path.join(OUT, 'betabinom_diagnostics.csv')
df.to_csv(fp, index=False, encoding='utf-8')
txt = open(fp, encoding='utf-8').read()
hdr = ('# s593：β-二项三口径核对。dev_over_dof = 细胞级二项 deviance = 2*(ℓ_sat − ℓ_fit)，dof = 细胞数 − 参数数\n'
       '# pearson_binom_over_dof = 同设计下 Σ(k−nμ)²/(nμ(1−μ))/dof；pearson_BB_over_dof = 把方差换成 nμ(1−μ)[1+ρ(n−1)]\n'
       '# expected_dispersion = 1+ρ(n̄−1)；若均值函数与控制变量正确，Pearson_BB/dof 应 ≈ 1\n'
       '# 生成脚本：代码/s593_betabinom_diagnostics.py\n')
open(fp, 'w', encoding='utf-8-sig').write(hdr + txt)
print('\n写出 betabinom_diagnostics.csv（%d 行）' % len(df))
