# -*- coding: utf-8 -*-
"""s566：第三判据的削除率按 |Z| 分档——检验「外盘地板是判据效应」这一解释。
步骤：抽样 dr13 本地谱 → 同一管线算 EW/峰高/噪声 → join Gaia 视差与银纬得 |Z|
     → 分档给出「活动谱中不满足第三判据的比例」→ 把该比例套回 §1 的实测活动比例。
"""
import io, sys, os, gzip
import numpy as np, pandas as pd
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
from astropy.coordinates import SkyCoord
import astropy.units as un
OUT = r'C:\Users\lingz\Desktop\复现老师工作\APJS\多个图及讨论'
DIR = 'data/lrs/dr13'
N = 6000
C_L, C_R, LINE = (6555.0, 6560.0), (6570.0, 6575.0), (6557.66, 6571.66)

def save(df, name, comments):
    fp = os.path.join(OUT, name); df.to_csv(fp, index=False, encoding='utf-8')
    txt = open(fp, encoding='utf-8').read()
    with open(fp, 'w', encoding='utf-8-sig') as f:
        f.write('\n'.join('# ' + c for c in comments) + '\n' + txt)
    print('  写出 %s（%d 行）' % (name, len(df)))

def wilson(k, n, z=1.96):
    if n == 0: return (np.nan, np.nan)
    p = k/n; d = 1+z*z/n; c = (p+z*z/(2*n))/d
    h = z*np.sqrt(p*(1-p)/n + z*z/(4*n*n))/d
    return 100*(c-h), 100*(c+h)

def analyse(path, z):
    d = pd.read_csv(gzip.open(path, 'rt'), usecols=['Wavelength', 'Flux'])
    w = d.Wavelength.values/(1.0 + (z if np.isfinite(z) else 0.0)); f = d.Flux.values.astype(float)
    ok = np.isfinite(w) & np.isfinite(f); w, f = w[ok], f[ok]
    if len(w) < 100: return None
    o = np.argsort(w); w, f = w[o], f[o]
    mL = (w >= C_L[0]) & (w <= C_R[0]); mR = (w >= C_R[0]) & (w <= C_R[1])
    if mL.sum() < 2 or mR.sum() < 2: return None
    wl, fl = w[mL].mean(), f[mL].mean(); wr, fr = w[mR].mean(), f[mR].mean()
    if fr == fl: return None
    mm = (fr - fl)/(wr - wl); bb = fl - mm*wl
    g = np.arange(LINE[0], LINE[1] + 1e-9, 0.1)
    fg = np.interp(g, w, f); fc = mm*g + bb
    if np.nanmedian(fc) <= 0: return None
    ew = -np.trapezoid(1.0 - fg/fc, g)
    cont = (w >= 6545) & (w <= 6585) & ~((w >= 6557) & (w <= 6572))
    if cont.sum() < 10: return None
    cm, cb = np.polyfit(w[cont], f[cont], 1)
    res = f[cont] - (cm*w[cont] + cb)
    sig = 1.4826*np.median(np.abs(res - np.median(res)))
    dl = np.median(np.diff(w)); npix = (LINE[1]-LINE[0])/dl
    err = sig/abs(np.nanmedian(fc))*dl*np.sqrt(npix)
    rms_norm = sig/abs(np.nanmedian(fc))
    prof = fg/fc - 1.0
    prof_s = np.convolve(prof, np.ones(5)/5, mode='same')
    peak = float(np.nanmax(prof_s))
    return dict(ew=ew, err=err, rms_norm=rms_norm, peak=peak, snr_peak=peak/rms_norm if rms_norm>0 else np.nan)

cat = pd.read_csv('data/lamost/dr13/dr13_mstellar_dM.csv', low_memory=False,
                  usecols=['obsid','subclass','teff','ewha','ewha_err','snrr','z','ra','dec','gaia_source_id'])
cat = cat[(cat.ewha > -20) & (cat.ewha <= 50) & (cat.ewha_err > 0) & (cat.ewha_err <= 5)].copy()
cat['active_cat'] = (cat.ewha >= 0.75) & (cat.ewha > 3*cat.ewha_err)
have = set(os.path.splitext(os.path.splitext(x)[0])[0] for x in os.listdir(DIR) if x.endswith('.csv.gz'))
cat = cat[cat.obsid.astype(str).isin(have)]
g = pd.read_csv('data/gaia/gaia_dr3_mstars.csv', low_memory=False,
                usecols=['source_id','parallax','parallax_error','ruwe'])
cat['gaia_source_id'] = pd.to_numeric(cat.gaia_source_id, errors='coerce')
m = cat.merge(g, left_on='gaia_source_id', right_on='source_id', how='inner')
m = m[(m.parallax > 0.2) & (m.parallax/m.parallax_error > 5) & (m.ruwe < 1.4)].copy()
dpc = 1000.0/m.parallax.values
sc = SkyCoord(ra=m.ra.values*un.deg, dec=m.dec.values*un.deg, distance=dpc*un.pc, frame='icrs')
m['absz'] = np.abs(dpc*np.sin(np.deg2rad(sc.galactic.b.deg)))
print('dr13 本地谱且有 Gaia 视差：%d 条；活动 %d（%.1f%%）' % (len(m), int(m.active_cat.sum()), 100*m.active_cat.mean()))
sub = m.sample(n=min(N, len(m)), random_state=20261028)
rows = []
for _, r in sub.iterrows():
    try: d = analyse(os.path.join(DIR, '%d.csv.gz' % int(r.obsid)), r.z)
    except Exception: d = None
    if d is None: continue
    d.update(obsid=int(r.obsid), subclass=r.subclass, active_cat=bool(r.active_cat),
             absz=float(r.absz), z=r.z, snrr=r.snrr)
    d['pass_c3'] = bool(np.isfinite(d['snr_peak']) and d['snr_peak'] > 3)
    rows.append(d)
T = pd.DataFrame(rows)
print('成功处理 %d 条' % len(T))
T.to_csv(os.path.join(OUT, 'criterion3_by_zb_sample.csv'), index=False, encoding='utf-8')

T['zb'] = pd.cut(T.absz, [0,100,200,400,3000], labels=['<100','100-200','200-400','>400'])
out = []
print('\n=== 活动谱中不满足第三判据的比例（按 |Z| 分档）===')
for lb in ['<100','100-200','200-400','>400']:
    q = T[(T.zb == lb) & T.active_cat]
    if len(q) == 0: continue
    k = int((~q.pass_c3).sum()); n = len(q); lo, hi = wilson(k, n)
    print('  %-8s 活动谱 %5d  不满足 %4d  %5.1f%%  [%.1f, %.1f]' % (lb, n, k, 100*k/n, lo, hi))
    out.append(dict(zbin=lb, n=n, k_fail=k, fail_pct=100*k/n, lo=lo, hi=hi, zmed=float(q.absz.median())))
R = pd.DataFrame(out)
save(R, 'criterion3_fail_by_zb.csv', [
    '第三判据（峰高 > 3×线外 rms，5 像素平滑）在「现判据判为活动」的谱中的不满足率，按 |Z| 分档',
    '样本：data/lrs/dr13 随机 6,000 条（该目录 90% 为活动星）；|Z| 由 Gaia 视差与银纬算得',
    'lo/hi 为 Wilson 95%；zmed 为该档活动谱的 |Z| 中位',
    '生成脚本：代码/s566_criterion3_by_zb.py'])

print('\n=== 把不满足率套回 §1 的实测活动比例 ===')
A = pd.read_csv(os.path.join(OUT, 'far400_2d_audit.csv'), comment='#').set_index('zbin')
for lb in ['<100','200-400','400-600','600-1000']:
    key = lb if lb in R.zbin.values else None
    if key is None: continue
    f = float(A.loc[lb,'frac']); fr = float(R.set_index('zbin').loc[key,'fail_pct'])
    print('  %-9s 实测 %.2f%% → 补齐第三判据后 %.2f%%（×%.3f）' % (lb, f, f*(1-fr/100), 1-fr/100))
print('s566 完成')
