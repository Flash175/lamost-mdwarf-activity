# -*- coding: utf-8 -*-
"""按置换 bootstrap + 基线判据重建 IB2025 周期质量表与扩展图"""
import io, os, shutil, sys
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
import numpy as np, pandas as pd
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
W = r'C:\Users\lingz\OneDrive\Desktop\复现老师工作'; D = r'C:\Users\lingz\Desktop\复现老师工作'; A = r'C:\Users\lingz\Desktop\APJS\图五及相关数据'
g = lambda *a: os.path.join(W, *a)
c = pd.read_csv(g('data','processed','dr13','ib2025_periodogram_selfcomputed.csv'))
perm = pd.read_csv(g('data','processed','dr13','ib2025_permutation_fap.csv')).rename(columns={'P_yr': 'P_perm', 'power': 'power_perm'})
c['base_ratio'] = c.P_yr/c.baseline_yr
c = c.merge(perm[['star','perm_FAP','nperm']], on='star', how='left')
c['criterion'] = np.where(c.perm_FAP.notna(), 'perm-bootstrap', 'analytic only')
c['pass'] = np.where(c.perm_FAP.notna(),
                     (c.perm_FAP <= 0.001) & (c.base_ratio <= 0.5),
                     (c.FAP < 0.01) & (c.base_ratio <= 0.5))
c.to_csv(g('data','processed','dr13','ib2025_cycles_quality.csv'), index=False)
print('总探测 %d ; 严格通过 %d ; 其中做过置换检验的 %d 颗' % (len(c), int(c['pass'].sum()), int(c.perm_FAP.notna().sum())))
print(c[c['pass']][['star','P_yr','baseline_yr','base_ratio','FAP','perm_FAP']].round(3).to_string(index=False))
print('\n做过置换检验的 6 颗：')
print(c[c.perm_FAP.notna()][['star','P_yr','power','FAP','perm_FAP','base_ratio','pass']].round(3).to_string(index=False))
# 扩展图：只用严格通过且拿到 P_rot 的点
vsx = pd.read_csv(g('data','processed','dr13','ib2025_stars_with_prot.csv'))
tes = pd.read_csv(g('data','processed','dr13','ib2025_tess_prot_selfcomputed.csv'))
for d in (vsx, tes, c): d['key'] = d.star.str.replace(' ', '').str.upper()
vsx['P_vsx'] = np.where(vsx.sep_as < 5, vsx.P_rot, np.nan)
tes['P_tess_ok'] = np.where((tes.power >= 0.10) & (tes.P_tess < 90) & (tes.P_tess > 0.25), tes.P_tess, np.nan)
M = c.merge(vsx[['key','P_vsx']], on='key', how='left').merge(tes[['key','P_tess_ok']], on='key', how='left')
M['P_rot'] = M.P_vsx.fillna(M.P_tess_ok)
M['src'] = np.where(M.P_vsx.notna(), 'VSX', np.where(M.P_tess_ok.notna(), 'TESS(ours)', ''))
use = M[M['pass'] & M.P_rot.notna()].copy()
use.to_csv(g('data','processed','dr13','pcyc_vs_prot_expanded.csv'), index=False)
print('\n最终入图的新点 %d：' % len(use)); print(use[['star','P_rot','src','P_yr','perm_FAP','baseline_yr']].round(3).to_string(index=False))
lit = pd.read_csv(g('data','raw','activity_cycle_data_complete.csv'))
lit['P_cyc'] = pd.to_numeric(lit.P_cyc_yr, errors='coerce'); lit['ProT'] = pd.to_numeric(lit.P_rot_days, errors='coerce')
ok = lit.dropna(subset=['P_cyc','ProT'])
fig, ax = plt.subplots(figsize=(7.0, 5.4))
ax.errorbar(ok.ProT, ok.P_cyc, yerr=pd.to_numeric(ok.P_cyc_err_yr, errors='coerce'),
            xerr=pd.to_numeric(ok.P_rot_err_days, errors='coerce'), fmt='none', ecolor='0.78', lw=0.7, zorder=2)
ax.scatter(ok.ProT, ok.P_cyc, s=34, c='#1f4fd8', label='literature table (N=%d)' % len(ok), zorder=3)
for s, m, cc in (('VSX','o','#d95f02'), ('TESS(ours)','^','#2e8b57')):
    q = use[use.src == s]
    if len(q): ax.scatter(q.P_rot, q.P_yr, s=56, marker=m, facecolors='none', edgecolors=cc, lw=1.5,
                          label='recomputed, P$_{rot}$ from %s (N=%d)' % (s, len(q)), zorder=4)
for _, r in use.iterrows():
    ax.annotate(str(r.star), (r.P_rot, r.P_yr), textcoords='offset points', xytext=(6, 3), fontsize=6.4,
                color='#2e8b57' if str(r.src).startswith('TESS') else '#8c3b00')
for _, r in ok.iterrows():
    ax.annotate(str(r.Star), (r.ProT, r.P_cyc), textcoords='offset points', xytext=(5, -9), fontsize=5.9, color='0.4')
ax.scatter([25.4],[11.0], marker='*', s=220, color='goldenrod', edgecolor='k', lw=0.6, zorder=5)
ax.annotate('Sun', (25.4, 11.0), xytext=(7, -9), textcoords='offset points', fontsize=7)
ax.set_xscale('log'); ax.set_yscale('log'); ax.set_xlabel('P$_{rot}$ (days)', fontsize=11); ax.set_ylabel('P$_{cyc}$ (years)', fontsize=11)
ax.set_xlim(1.5, 330); ax.set_ylim(1.5, 34); ax.grid(alpha=0.25, which='both', lw=0.4)
ax.tick_params(direction='in', top=True, right=True, labelsize=9)
ax.legend(fontsize=6.8, loc='upper left', framealpha=0.95)
ax.set_title('Activity cycle vs rotation period: %d literature + %d recomputed (permutation-FAP filtered)' % (len(ok), len(use)), fontsize=9.5)
fig.text(0.5, 0.012, 'Only points with permutation-bootstrap FAP <= 0.001 and P$_{cyc}$ <= baseline/2 are plotted.\n'
                     'P$_{rot}$: VSX (circles) or our Lomb-Scargle analysis of TESS SPOC light curves (triangles).', ha='center', fontsize=6.3, color='0.3', linespacing=1.6)
fig.tight_layout(rect=(0, 0.075, 1, 1))
o = g('figures','dr13_figPcyc_Prot_expanded.png'); fig.savefig(o, dpi=180); plt.close(fig)
for s, t in [(o, os.path.join(D,'图','对照与备选','附_Pcyc_vs_Prot_扩展_自算.png')), (o, os.path.join(A,'图','附_Pcyc_vs_Prot_扩展_自算.png')),
             (g('data','processed','dr13','pcyc_vs_prot_expanded.csv'), os.path.join(D,'数据','Pcyc与Prot_扩展样本.csv')),
             (g('data','processed','dr13','pcyc_vs_prot_expanded.csv'), os.path.join(A,'数据','Pcyc与Prot_扩展样本.csv')),
             (g('data','processed','dr13','ib2025_cycles_quality.csv'), os.path.join(A,'数据','IB2025_周期质量表_置换FAP.csv')),
             (g('data','processed','dr13','ib2025_permutation_fap.csv'), os.path.join(A,'数据','IB2025_置换FAP_6星.csv'))]:
    shutil.copy2(s, t)
print('  图/表已同步')
