# -*- coding: utf-8 -*-
"""s584：诊断 2D 样本 >1000 pc 档活动比例"回升"的来源。
复刻 s569 的样本构造，逐档给出：
  (1) G 星等分布（中位/四分位）——判断是否为真实远处暗星（G~18-19）
      还是邻近亮星被视差误差推到远处（G~14-15）
  (2) 各亚型在 >1000 pc 档的活动比例——判断回升来自 dM0 自身还是混入的晚型
  (3) 视差相对误差、S/N、M_G 分布——辅助判断距离可靠性
输出：far1000_diagnose.csv（逐档汇总）、far1000_subtype.csv（逐档 × 亚型）
"""
import io, sys, os
import numpy as np, pandas as pd
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
from astropy.coordinates import SkyCoord
import astropy.units as un

OUT = r'C:\Users\lingz\Desktop\复现老师工作\APJS\多个图及讨论'
LAMOST = r'C:\Users\lingz\OneDrive\Desktop\复现老师工作\data\lamost\dr13\dr13_mstellar_dM.csv'
GAIA = r'C:\Users\lingz\OneDrive\Desktop\复现老师工作\data\gaia\gaia_dr3_mstars.csv'


def wilson(k, n, z=1.96):
    if n == 0:
        return (np.nan, np.nan)
    p = k / n
    d = 1 + z * z / n
    c = (p + z * z / (2 * n)) / d
    h = z * np.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / d
    return 100 * (c - h), 100 * (c + h)


print('读取 LAMOST ...')
cat = pd.read_csv(LAMOST, low_memory=False,
                  usecols=['uid', 'subclass', 'teff', 'logg', 'ewha', 'ewha_err', 'snrr',
                           'ra', 'dec', 'gaia_source_id', 'gaia_g_mean_mag'])
cat = cat[(cat.ewha > -20) & (cat.ewha <= 50) &
          (cat.ewha_err > 0) & (cat.ewha_err <= 5)].copy()
cat['active'] = (cat.ewha >= 0.75) & (cat.ewha > 3 * cat.ewha_err)
cat['gaia_source_id'] = pd.to_numeric(cat.gaia_source_id, errors='coerce')
print('  EW 闸门后 %d 条 / %d 星' % (len(cat), cat.uid.nunique()))

print('读取 Gaia ...')
g = pd.read_csv(GAIA, low_memory=False,
                usecols=['source_id', 'parallax', 'parallax_error', 'ruwe'])
m = cat.merge(g, left_on='gaia_source_id', right_on='source_id', how='inner')
m = m[(m.parallax > 0.2) & (m.parallax / m.parallax_error > 5) & (m.ruwe < 1.4)].copy()
u = m.sort_values('ewha', ascending=False).drop_duplicates('uid').copy()

d = 1000.0 / u.parallax.values
sc = SkyCoord(ra=u.ra.values * un.deg, dec=u.dec.values * un.deg,
              distance=d * un.pc, frame='icrs')
u['absz'] = np.abs(d * np.sin(np.deg2rad(sc.galactic.b.deg)))
u['MG'] = u.gaia_g_mean_mag.values - 5 * np.log10(np.clip(d, 1, None)) + 5
u['relerr'] = u.parallax_error / u.parallax
u = u[u.absz <= 3000].copy()
print('  2D 去巨星前 %d 颗' % len(u))
n_pre = len(u)
u = u[u.MG >= 6].copy()
print('  2D 去巨星后 %d 颗（剔除 %d）' % (len(u), n_pre - len(u)))

# 亚型
u['sub'] = u.subclass.astype(str).str.extract(r'd?M?\s*(\d)')[0]
u['sub'] = pd.to_numeric(u['sub'], errors='coerce')

BINS = [0, 100, 200, 400, 600, 1000, 3000]
LAB = ['<100', '100-200', '200-400', '400-600', '600-1000', '>1000']
u['zb'] = pd.cut(u.absz, BINS, labels=LAB, right=False)

rows = []
for lab in LAB:
    s = u[u.zb == lab]
    if len(s) == 0:
        continue
    k, n = int(s.active.sum()), len(s)
    wl, wh = wilson(k, n)
    rows.append(dict(
        bin=lab, n=n, n_act=k, frac=100 * k / n, wilson_lo=wl, wilson_hi=wh,
        G_med=s.gaia_g_mean_mag.median(),
        G_q25=s.gaia_g_mean_mag.quantile(0.25),
        G_q75=s.gaia_g_mean_mag.quantile(0.75),
        G_q05=s.gaia_g_mean_mag.quantile(0.05),
        G_q95=s.gaia_g_mean_mag.quantile(0.95),
        MG_med=s.MG.median(), MG_q10=s.MG.quantile(0.10), MG_q90=s.MG.quantile(0.90),
        snr_med=s.snrr.median(),
        relerr_med=100 * s.relerr.median(),
        teff_med=s.teff.median(),
        dmed_med=s.absz.median(),
        frac_G_lt15=100 * (s.gaia_g_mean_mag < 15).mean(),
        frac_G_lt16=100 * (s.gaia_g_mean_mag < 16).mean(),
        frac_G_gt18=100 * (s.gaia_g_mean_mag > 18).mean(),
        frac_z_gt2000=100 * (s.absz > 2000).mean(),
    ))
tab = pd.DataFrame(rows)
pd.set_option('display.width', 220, 'display.max_columns', 40)
print('\n=== 逐档汇总 ===')
print(tab.round(2).to_string(index=False))

# 逐档 × 亚型
rows2 = []
for lab in LAB:
    s = u[u.zb == lab]
    for sb in [0, 1, 2, 3, 4, 5, 6, 7]:
        t = s[s['sub'] == sb]
        if len(t) < 5:
            continue
        k, n = int(t.active.sum()), len(t)
        wl, wh = wilson(k, n)
        rows2.append(dict(bin=lab, sub='dM%d' % sb, n=n, n_act=k,
                          frac=100 * k / n, wilson_lo=wl, wilson_hi=wh,
                          G_med=t.gaia_g_mean_mag.median(),
                          MG_med=t.MG.median(), teff_med=t.teff.median(),
                          snr_med=t.snrr.median()))
tab2 = pd.DataFrame(rows2)
print('\n=== 逐档 × 亚型 ===')
print(tab2.round(2).to_string(index=False))

# >1000 档的 G 直方图（看清是亮端还是暗端）
far = u[u.zb == '>1000']
hist = np.arange(10, 22.5, 0.5)
hh, _ = np.histogram(far.gaia_g_mean_mag.dropna(), hist)
hact, _ = np.histogram(far[far.active].gaia_g_mean_mag.dropna(), hist)
histdf = pd.DataFrame(dict(G_lo=hist[:-1], G_hi=hist[1:], n=hh, n_act=hact,
                           frac=100 * np.where(hh > 0, hact / np.maximum(hh, 1), 0)))
print('\n=== >1000 pc 档的 G 分布 ===')
print(histdf[histdf.n > 0].round(1).to_string(index=False))

# 附加检验：ruwe（双星指标）随距离的变化；以及 >1000 档内按 M_G 分层
print('\n=== 逐档 ruwe（未分辨双星指标，越接近 1.4 越可疑） ===')
rr = []
for lab in LAB:
    s = u[u.zb == lab]
    rr.append(dict(bin=lab, n=len(s), ruwe_med=s.ruwe.median(),
                   ruwe_p90=s.ruwe.quantile(0.90), ruwe_p99=s.ruwe.quantile(0.99),
                   frac_ruwe_gt13=100 * (s.ruwe > 1.3).mean()))
print(pd.DataFrame(rr).round(3).to_string(index=False))

print('\n=== 远档内按 M_G 分层（M_G 越低 = 越亮，可能是双星或早型） ===')
for lab in ['400-600', '600-1000', '>1000']:
    s = u[u.zb == lab]
    print('  [%s] n=%d' % (lab, len(s)))
    for lo, hi in [(6, 7), (7, 8), (8, 9), (9, 20)]:
        t = s[(s.MG >= lo) & (s.MG < hi)]
        if len(t) < 10:
            continue
        print('    M_G %.0f-%.0f : n=%5d  活动 %5.2f%%  (Wilson %.2f-%.2f)'
              % (lo, hi, len(t), 100 * t.active.mean(), *wilson(int(t.active.sum()), len(t))))

tab.to_csv(os.path.join(OUT, 'far1000_diagnose.csv'), index=False, encoding='utf-8-sig')
tab2.to_csv(os.path.join(OUT, 'far1000_subtype.csv'), index=False, encoding='utf-8-sig')
histdf.to_csv(os.path.join(OUT, 'far1000_Ghist.csv'), index=False, encoding='utf-8-sig')
print('\n已写出 far1000_diagnose.csv / far1000_subtype.csv / far1000_Ghist.csv')
