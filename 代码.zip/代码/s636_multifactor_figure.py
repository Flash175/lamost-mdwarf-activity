
import os, math, itertools, numpy as np, pandas as pd
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
D = r'C:\Users\lingz\Desktop\复现老师工作\APJS\多个图及讨论'
d = pd.read_csv(os.path.join(D,'分解样本_snrr_470548.csv'), low_memory=False)
d['zb'] = pd.cut(d.absz,[0,100,200,400],labels=['<100','100-200','200-400'])
DUM = pd.get_dummies(d.subclass, prefix='s', drop_first=True).astype(float)
for c,nm in [('teff','F2'),('logg','F3'),('m_h','F4')]:
    v=d[c]; d[nm]=v-v.mean()
d['F2']=d.F2/1000.0
lv=np.log10(d.snrr); d['F5']=lv-lv.mean()
ld=np.log10(d.dist_pc); d['F6']=ld-ld.mean()
X=pd.concat([DUM,d[['F2','F3','F4','F5','F6']]],axis=1)
blocks={'F1':list(DUM.columns),'F2':['F2'],'F3':['F3'],'F4':['F4'],'F5':['F5'],'F6':['F6']}
y=d.active.values; masks={b:(d.zb.values==b) for b in ['<100','100-200','200-400']}
keys=['F1','F2','F3','F4','F5','F6']; K=6; cache={}
def delta(S):
    cols=[c for k in S for c in blocks[k]]
    A=np.column_stack([np.ones(len(y))]+[X[c].values for c in cols]) if cols else np.ones((len(y),1))
    beta,*_=np.linalg.lstsq(A,y,rcond=None); pr=A@beta
    v={b:pr[m].mean() for b,m in masks.items()}
    return {b:100*(v[b]-v['<100']) for b in ['100-200','200-400']}
for r in range(K+1):
    for S in itertools.combinations(keys,r): cache[frozenset(S)]=delta(S)
phi={b:{k:0.0 for k in keys} for b in ['100-200','200-400']}
for k in keys:
    o=[x for x in keys if x!=k]
    for r in range(len(o)+1):
        for S in itertools.combinations(o,r):
            w=math.factorial(len(S))*math.factorial(K-len(S)-1)/math.factorial(K)
            for b in phi: phi[b][k]+=w*(cache[frozenset(tuple(sorted(S+(k,))))][b]-cache[frozenset(S)][b])
full=cache[frozenset(keys)]
f={b:100*y[masks[b]].mean() for b in ['<100','100-200','200-400']}
OBS={b:f['<100']-f[b] for b in ['100-200','200-400']}
fig, axes = plt.subplots(1,2, figsize=(11.8,4.3))
for ax,b in zip(axes,['100-200','200-400']):
    labs=['F1 subtype','F2 T$_{eff}$','F3 log g','F4 [Fe/H]','F5 log S/N','F6 log d','unexplained']
    vals=[phi[b][k] for k in keys]+[OBS[b]-full[b]]
    cum=0.0
    for i,v in enumerate(vals):
        ax.bar(i, v, bottom=cum, color=('#c0392b' if i==6 else '#2c3e50'), width=0.62)
        ax.text(i, cum+v/2, '%+.2f'%v, ha='center', va='center', fontsize=6.8, color='white' if abs(v)>0.9 else 'black')
        cum+=v
    ax.axhline(OBS[b], color='k', ls='--', lw=1.0)
    ax.set_xticks(range(len(vals))); ax.set_xticklabels(labs, rotation=32, ha='right', fontsize=7.5)
    ax.set_ylabel('activity decline (pp)')
    ax.set_title('%s pc bin: observed %.2f pp, explained %+.2f pp' % (b, OBS[b], full[b]), fontsize=9)
    ax.grid(axis='y', ls=':', lw=0.4, alpha=0.6)
plt.tight_layout(); plt.savefig(os.path.join(D,'多因素_瀑布图_snrr版.png'), dpi=180); plt.close()
print('figure rewritten (English labels)')
print('check numbers: ', {b: (round(OBS[b],2), round(full[b],2)) for b in OBS})
