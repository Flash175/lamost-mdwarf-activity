# -*- coding: utf-8 -*-
"""s583c: 年龄 vs 亚型组成的反事实分解（接 s582；原编号 s585，因与 s585_fit_covariates.py 重号改名）
问：模型预测的 |Z| 下降里，「人口变老」和「亚型组成随 |Z| 改变」各贡献多少？
三个口径（β = 0.45 基准，另报 0.30 / 0.53）：
  完整模型  P_full(z) = Σ_s w_s(z)   · exp(−t(z)/τ_s)     （同 s582）
  年龄单独  P_age(z)  = Σ_s w_s(<100)· exp(−t(z)/τ_s)     （组成冻结在 <100 pc 档）
  组成单独  P_comp(z) = Σ_s w_s(z)   · exp(−t_ref/τ_s)    （年龄冻结在 t_ref）
分解（Shapley 式，对下降量 D = P(<100) − P(z)）：
  年龄效应 A = P(<100) − P_age(z)；组成效应 C = P(<100) − P_comp(z)；
  交互  I = D − A − C（两个冻结口径不交换次序时的残余，= P_age + P_comp − P(<100) − P_full）
输入与 s582 完全相同（6D 非活动星 σ(vz)、2D 分档、reweight_composition.csv、West 2008 Table 2 的 τ），
t_ref 用 <100 pc 档定标（与 s582 同法，二分反解 P(<100) = 观测值）。"""
import io, sys, os
import numpy as np, pandas as pd
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
OUT = r'C:\Users\lingz\Desktop\复现老师工作\APJS\多个图及讨论'
d6 = pd.read_csv(os.path.join(OUT, '新图1_数据_6D分箱.csv'), comment='#')
z6 = d6['zmed_inact'].values; s6 = d6['svz_inact'].values
keep = np.isfinite(z6) & np.isfinite(s6); z6, s6 = z6[keep], s6[keep]
B = pd.read_csv(os.path.join(OUT, '新图1_数据_2D分箱.csv'), comment='#')
zb = dict(zip(B.zbin, B.absz_med)); fb = dict(zip(B.zbin, B.frac/100.0))
R = pd.read_csv(os.path.join(OUT, 'reweight_composition.csv'), comment='#')
share = {z: R[R.zbin == z].set_index('subtype').n / R[R.zbin == z].n.sum() for z in R.zbin.unique()}
TAU = {'dM0': 0.8, 'dM1': 0.4, 'dM2': 1.2, 'dM3': 2.0, 'dM4': 4.5,
       'dM5': 7.0, 'dM6': 7.0, 'dM7': 8.0, 'dM8': 8.0}
def sigma_at(z):
    return float(np.interp(np.log(z), np.log(z6), s6)) if z <= z6[-1] else \
        float(s6[-1] + (s6[-1]-s6[-2])/(np.log(z6[-1])-np.log(z6[-2]))*(np.log(z)-np.log(z6[-1])))
ORDER = ['<100', '100-200', '200-400', '400-600', '600-1000']
def age_at(z, t_ref, beta):
    return t_ref * (sigma_at(z)/sigma_at(zb['<100']))**(1.0/beta)
def Pmix(w, t):
    return sum(wv*float(np.exp(-t/TAU[s])) for s, wv in w.items())
def calibrate(beta):
    lo, hi = 0.05, 20.0
    for _ in range(80):
        mid = 0.5*(lo+hi)
        if Pmix(share['<100'], age_at(zb['<100'], mid, beta)) > fb['<100']: lo = mid
        else: hi = mid
    return 0.5*(lo+hi)
rows = []
for beta in (0.30, 0.45, 0.53):
    t_ref = calibrate(beta)
    P0 = Pmix(share['<100'], t_ref)          # = 观测 <100 pc（构造恒等）
    for k in ORDER:
        t = age_at(zb[k], t_ref, beta)
        pf = Pmix(share[k], t)               # 完整模型
        pa = Pmix(share['<100'], t)          # 年龄单独
        pc = Pmix(share[k], t_ref)           # 组成单独
        D = P0 - pf; A = P0 - pa; C = P0 - pc; I = D - A - C
        A_sh = 0.5*((P0 - pa) + (pc - pf))   # Shapley：交互项均摊
        C_sh = 0.5*((P0 - pc) + (pa - pf))
        rows.append(dict(beta=beta, t_ref_Gyr=t_ref, zbin=k, z_med=zb[k], t_Gyr=t,
                         P_full_pct=100*pf, P_ageonly_pct=100*pa, P_componly_pct=100*pc,
                         obs_pct=100*fb[k], drop_full_pp=100*D, drop_age_pp=100*A,
                         drop_comp_pp=100*C, drop_inter_pp=100*I,
                         shapley_age_pp=100*A_sh, shapley_comp_pp=100*C_sh,
                         shapley_age_share_pct=(100*A_sh/D if D != 0 else np.nan),
                         age_share_pct=(100*A/D if D != 0 else np.nan),
                         comp_share_pct=(100*C/D if D != 0 else np.nan)))
T = pd.DataFrame(rows)
fp = os.path.join(OUT, 'avr_model_decomposition.csv')
T.to_csv(fp, index=False, encoding='utf-8')
txt = open(fp, encoding='utf-8').read()
open(fp, 'w', encoding='utf-8-sig').write(
 '# 年龄 vs 亚型组成的反事实分解（接 s582 的年龄模型）：P_age = 组成冻结在 <100 pc 档只让年龄变；P_comp = 年龄冻结在 t_ref 只让组成变\n'
 '# drop_*_pp 为相对 <100 pc 档的下降量（百分点）；D = A + C + I（I 为交互残余）；shapley_* 为交互项均摊后的分解（A_sh+C_sh=D 恒等）\n'
 '# tau 取 West et al. (2008) Table 2；t_ref 用 <100 pc 档定标（与 s582 同）；生成脚本：代码/s583c_avr_decomposition.py\n' + txt)

# ---- 观测数据的同法分解（对照）：亚型内部活动率下降 vs 亚型组成变化 ----
# P_obs(z) = Σ_s w_s(z)·f_s(z)；within-only = 组成冻结在 <100 pc 用实测逐型活动率；comp-only = 逐型活动率冻结在 <100 pc
fsub = {z: R[R.zbin == z].set_index('subtype').frac/100.0 for z in R.zbin.unique()}
P0o = float((share['<100']*fsub['<100']).sum())
orows = []
for k in ORDER:
    Pz = float((share[k]*fsub[k]).sum())
    pw = float((share['<100']*fsub[k]).sum())
    pc = float((share[k]*fsub['<100']).sum())
    D = P0o-Pz; A = P0o-pw; C = P0o-pc
    Ash = 0.5*((P0o-pw)+(pc-Pz)); Csh = 0.5*((P0o-pc)+(pw-Pz))
    orows.append(dict(zbin=k, P_obs_pct=100*Pz, P_withinonly_pct=100*pw, P_componly_pct=100*pc,
                      drop_pp=100*D, within_pp=100*A, comp_pp=100*C, inter_pp=100*(D-A-C),
                      shapley_within_pp=100*Ash, shapley_comp_pp=100*Csh,
                      shapley_within_share_pct=(100*Ash/D if D != 0 else np.nan)))
TO = pd.DataFrame(orows)
fo = os.path.join(OUT, 'obs_decomposition_within_vs_comp.csv')
TO.to_csv(fo, index=False, encoding='utf-8')
txt = open(fo, encoding='utf-8').read()
open(fo, 'w', encoding='utf-8-sig').write(
 '# 观测活动比例下降的同法分解（与 avr_model_decomposition.csv 对照）：within-only = 组成冻结在 <100 pc 档、用实测逐型活动率；comp-only = 逐型活动率冻结在 <100 pc\n'
 '# 数据：reweight_composition.csv（2D 全体，EW 口径）；shapley 为交互项均摊；400 pc 以外受选择系统污染（§4.2），仅作参考\n'
 '# 生成脚本：代码/s583c_avr_decomposition.py\n' + txt)
print('\n=== 观测侧分解（对照）===')
for _, r in TO.iterrows():
    print('  %-9s P_obs=%5.2f%%  within=%5.2f%%  comp=%5.2f%% | D=%5.2f  within=%5.2f  comp=%5.2f  Shapley within=%s'
          % (r.zbin, r.P_obs_pct, r.P_withinonly_pct, r.P_componly_pct, r.drop_pp, r.within_pp, r.comp_pp,
             ('%3.0f%%' % r.shapley_within_share_pct) if np.isfinite(r.shapley_within_share_pct) else ' --'))
print('t_ref(β) =', {b: round(calibrate(b), 6) for b in (0.30, 0.45, 0.53)})
for beta in (0.45, 0.30, 0.53):
    print('\n=== β = %.2f ===' % beta)
    q = T[T.beta == beta]
    for _, r in q.iterrows():
        print('  %-9s t=%5.2f  P_full=%5.2f%%  P_age=%5.2f%%  P_comp=%5.2f%%  obs=%5.2f%% | '
              'D=%5.2f  A=%5.2f(%s)  C=%5.2f(%s)  I=%+.2f'
              % (r.zbin, r.t_Gyr, r.P_full_pct, r.P_ageonly_pct, r.P_componly_pct, r.obs_pct,
                 r.drop_full_pp, r.drop_age_pp,
                 ('%4.0f%%' % r.age_share_pct) if np.isfinite(r.age_share_pct) else '  -- ',
                 r.drop_comp_pp,
                 ('%4.0f%%' % r.comp_share_pct) if np.isfinite(r.comp_share_pct) else '  -- ',
                 r.drop_inter_pp))
print('\n写出 avr_model_decomposition.csv')
