# -*- coding: utf-8 -*-
"""s563：用现有数据能做的一条动力学自洽检验——
「活动比例更高的晚型，是否在近平面内也确实运动学更冷（=更年轻）？」
若成立，则活动–年龄解释与运动学自洽；若不成立，则活动差异不能只归因于年龄。
只取非活动星，避免「活动性本身与运动学相关」的反向污染。
"""
import io, sys, os
import numpy as np, pandas as pd
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
from astropy.coordinates import SkyCoord
import astropy.units as un
OUT = r'C:\Users\lingz\Desktop\复现老师工作\APJS\多个图及讨论'
SUBS = ['dM0','dM1','dM2','dM3','dM4','dM5','dM6']

def save(df, name, comments):
    fp = os.path.join(OUT, name); df.to_csv(fp, index=False, encoding='utf-8')
    txt = open(fp, encoding='utf-8').read()
    with open(fp, 'w', encoding='utf-8-sig') as f:
        f.write('\n'.join('# ' + c for c in comments) + '\n' + txt)
    print('  写出 %s（%d 行）' % (name, len(df)))

cat = pd.read_csv('data/lamost/dr13/dr13_mstellar_dM.csv', low_memory=False,
                  usecols=['uid','subclass','teff','ewha','ewha_err','snrr','ra','dec','gaia_g_mean_mag','gaia_source_id'])
cat = cat[(cat.ewha > -20) & (cat.ewha <= 50) & (cat.ewha_err > 0) & (cat.ewha_err <= 5)].copy()
cat['active'] = (cat.ewha >= 0.75) & (cat.ewha > 3*cat.ewha_err)
cat['gaia_source_id'] = pd.to_numeric(cat.gaia_source_id, errors='coerce')
g = pd.read_csv('data/gaia/gaia_dr3_mstars.csv', low_memory=False,
                usecols=['source_id','parallax','parallax_error','pmra','pmdec','radial_velocity','ruwe'])
m = cat.merge(g, left_on='gaia_source_id', right_on='source_id', how='inner')
m = m[(m.parallax > 0.2) & (m.parallax/m.parallax_error > 5) & (m.ruwe < 1.4)].copy()
m['rv'] = m.radial_velocity
u = m.sort_values('ewha', ascending=False).drop_duplicates('uid').copy()
# [giant-cut] 去巨星：M_G >= 6（M 矮星 +8~+16；切口同时含亚巨星与误分类早型矮星）
u['MG'] = u.gaia_g_mean_mag.values - 5*np.log10(np.clip(1000.0/u.parallax.values, 1, None)) + 5
u = u[u.MG >= 6].copy()
u = u[np.isfinite(u.rv) & (np.abs(u.rv) < 500)].copy()
c6 = SkyCoord(ra=u.ra.values*un.deg, dec=u.dec.values*un.deg,
              distance=(1000.0/u.parallax.values)*un.pc,
              pm_ra_cosdec=u.pmra.values*un.mas/un.yr, pm_dec=u.pmdec.values*un.mas/un.yr,
              radial_velocity=u.rv.values*un.km/un.s, frame='icrs')
gc = c6.transform_to('galactocentric')
v = gc.velocity.d_xyz.to(un.km/un.s).value
u = u.assign(vx=v[0], vy=v[1], vz=v[2], zgc=np.abs(gc.z.to(un.kpc).value)*1000)
u = u[u.zgc <= 3000]
inner = u[u.zgc < 100]
print('0–100 pc 的 6D 星：%d 颗' % len(inner))
print(' 亚型  n(非活动)  σ(vz) km/s  ±SE   中位 \\|Z\\|  活跃比例(全样本 <100 pc)')
rows = []
for sp in SUBS:
    s_inact = inner[(inner.subclass == sp) & (~inner.active)]
    s_all = inner[inner.subclass == sp]
    if len(s_inact) < 100: continue
    sv = s_inact.vz.std(); se = sv/np.sqrt(2*max(len(s_inact)-1,1))
    print('  %-4s %6d     %5.2f    ±%.2f    %5.1f     %5.1f%%'
          % (sp, len(s_inact), sv, se, s_inact.zgc.median(), 100*s_all.active.mean()))
    rows.append(dict(subtype=sp, n_inact=len(s_inact), svz_inact=sv, se=se,
                     zmed=float(s_inact.zgc.median()), frac_active=100*s_all.active.mean(),
                     n_all=len(s_all)))
T = pd.DataFrame(rows)
save(T, 'subtype_kinematics_inner.csv', [
    '0–100 pc 内、只取非活动星的 σ(vz)：检验「活动比例更高的晚型是否真的运动学更冷（更年轻）」',
    'SE = σ/sqrt(2(n−1))；zmed 为该亚型非活动星的 |银心 z| 中位（pc）',
    'active = EW(Ha)>=0.75 A 且 >3sigma；6D 子样本（Gaia 视差>5σ、ruwe<1.4、有 RV、|RV|<500、|z_gc|<=3 kpc）',
    '去巨星：M_G = G - 5log10(d) + 5 >= 6（M 矮星 +8~+16；切口同时含亚巨星与误分类早型矮星）；去巨星前 0-100 pc 为 47,634 颗，去巨星后 47,516 颗',
    '生成脚本：代码/s563_subtype_kinematics.py'])
print('\n排序（σ(vz) 由小到大）：', ' < '.join(T.sort_values('svz_inact').subtype.tolist()))
print('活动比例（由高到低）：', ' > '.join(T.sort_values('frac_active', ascending=False).subtype.tolist()))
print('s563 完成')
