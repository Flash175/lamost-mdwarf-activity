# -*- coding: utf-8 -*-
"""图5 重画（VSX 大样本 + Fetherolf）：P = VSX(ROT 优先) ∪ Fetherolf；M = Gaia FLAME 优先，缺失用 Teff–Mass 拟合；
Ro = P/τ（Wright+2018），R'Hα = χ(Teff)·EWHα；分段回归 + bootstrap。"""
from __future__ import annotations
import io, os, sys
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
import numpy as np, pandas as pd
from scipy.spatial import cKDTree
sys.path.insert(0, 'repro/src')
from common import activity as A
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt

VSX = 'repro/_vsx/VSX_catalog_sample.csv'
cat = pd.read_csv('data/lamost/dr13/dr13_mstellar_dM.csv', low_memory=False,
                  usecols=['uid','designation','subclass','ewha','ewha_err','teff','ra','dec','gaia_source_id'])
for c in ('ewha','ewha_err','teff','ra','dec'): cat[c] = pd.to_numeric(cat[c], errors='coerce')
cat['ewha_err'] = cat.ewha_err.abs()
cat = cat[(cat.ewha > -20) & (cat.ewha <= 50) & (cat.ewha_err > 0) & (cat.ewha_err <= 5)]
star = cat.loc[cat.groupby('uid').ewha.idxmax()].dropna(subset=['ra','dec']).copy()
print('逐星样本 %d 颗' % len(star))

v = pd.read_csv(VSX, low_memory=False, usecols=['Name','Type','Period','RAJ2000','DEJ2000'])
v = v[pd.to_numeric(v.Period, errors='coerce').gt(0) & v.RAJ2000.notna() & v.DEJ2000.notna()].copy()
v['Period'] = pd.to_numeric(v.Period, errors='coerce')
print('VSX 有周期 %d 行；类型分布 %s' % (len(v), v.Type.astype(str).value_counts().head(5).to_dict()))

def uv(ra, dec):
    ra = np.radians(np.asarray(ra, float)); dec = np.radians(np.asarray(dec, float))
    return np.column_stack([np.cos(dec)*np.cos(ra), np.cos(dec)*np.sin(ra), np.sin(dec)])
tree = cKDTree(uv(star.ra.values, star.dec.values))
d, i = tree.query(uv(v.RAJ2000.values, v.DEJ2000.values), k=1, distance_upper_bound=np.radians(3/3600))
ok = np.isfinite(d) & (i < len(star))
m = pd.DataFrame({'idx': i[ok], 'P_vsx': v.Period.values[ok], 'Type': v.Type.astype(str).values[ok]})
rot = m[m.Type.str.upper().str.contains('ROT')]
best = rot.drop_duplicates('idx')                          # 只用 ROT（旋转调制）型，非自转周期不要
vsx = star.iloc[best.idx.values].copy(); vsx['P'] = best.P_vsx.values; vsx['src'] = 'VSX'
print('VSX 3″ 命中 M 矮星 %d 颗（其中 ROT 型 %d）' % (len(m), len(rot)))

# Fetherolf（已有）
fet = pd.read_csv('data/processed/dr13/dr13_fig5_sample.csv', low_memory=False, usecols=['designation','P'])
fet['designation'] = fet.designation.astype(str)
f = star[star.designation.astype(str).isin(set(fet.designation)) & ~star.uid.isin(set(vsx.uid))].merge(
    fet.drop_duplicates('designation'), on='designation', how='inner')
f['src'] = 'Fetherolf'
cols = ['uid','designation','subclass','ewha','teff','P','src','gaia_source_id']
g = pd.concat([vsx[cols], f[cols]], ignore_index=True).dropna(subset=['P'])
print('合并周期样本 %d 颗（VSX %d / Fetherolf %d）' % (len(g), (g.src=='VSX').sum(), (g.src=='Fetherolf').sum()))

# 质量：FLAME 优先，缺失用论文 CDS 的 Teff–Mass 拟合
fl = pd.read_csv('data/gaia/gaia_flame_mass.csv', low_memory=False, usecols=['source_id','mass_flame'])
fl['sid'] = fl.source_id.astype('int64').astype(str)
g['sid'] = g.gaia_source_id.astype(str).str.split('.').str[0]
g = g.merge(fl[['sid','mass_flame']], on='sid', how='left')
cds = pd.read_csv('data/vizier/apjs274_36_mdwarfs.csv', low_memory=False, usecols=lambda c: c in {'Mstar','Teff'})
cds = cds[(cds.Teff > 2800) & (cds.Teff < 4600) & (cds.Mstar > 0.05) & (cds.Mstar < 0.8)]
coef = np.polyfit(cds.Teff, cds.Mstar, 2)
g['M'] = g.mass_flame
fit_mask = g.M.isna()
g.loc[fit_mask, 'M'] = np.clip(np.polyval(coef, g.loc[fit_mask, 'teff']), 0.08, 0.75)
print('质量来源：FLAME %d 颗 / Teff–Mass 拟合 %d 颗' % (int((~fit_mask).sum()), int(fit_mask.sum())))
g['tau'] = 10 ** (2.33 - 1.5*g.M - 0.30*g.M**2)
g['Ro'] = g.P / g.tau
# χ(Teff) 由论文 CDS 反演
c2 = pd.read_csv('data/vizier/apjs274_36_mdwarfs.csv', low_memory=False,
                 usecols=lambda c: c in {'EWHa','RHa','Teff'})
c2 = c2[(c2.EWHa > 0.1) & (c2.RHa > 0) & (c2.Teff > 2800) & (c2.Teff < 4600)].copy()
c2['chi'] = c2.RHa / c2.EWHa
bins = np.arange(2800, 4601, 100); cent = 0.5*(bins[1:]+bins[:-1])
c2['b'] = np.digitize(c2.Teff, bins)
chi_med = np.array([c2.loc[c2.b == i, 'chi'].median() for i in range(1, len(bins))])
g['RHa'] = np.interp(g.teff, cent, chi_med) * g.ewha
pos = g[(g.Ro > 0) & (g.RHa > 0)].copy()
print('入图 %d 颗' % len(pos))
f5 = A.fit_saturation(pos.Ro.values, pos.RHa.values, n_boot=200)
print('Ro_sat = %.3f ± %.3f ；β = %.3f ± %.3f （论文 0.19±0.06 / −0.91±0.16）'
      % (f5.ro_sat, f5.ro_sat_err, f5.slope, f5.slope_err))
fig, ax = plt.subplots(figsize=(5.2, 4.6))
ax.scatter(pos.Ro, pos.RHa, s=7, c=np.where(pos.src == 'VSX', '#d95f02', '#1f4fd8'), lw=0, alpha=0.8,
           label=None)
xs1 = np.logspace(np.log10(pos.Ro.min()), np.log10(f5.ro_sat), 40)
xs2 = np.logspace(np.log10(f5.ro_sat), np.log10(min(pos.Ro.max(), 3)), 40)
ysat = np.median(pos.RHa[pos.Ro <= f5.ro_sat])
ax.plot(xs1, np.full_like(xs1, ysat), c='red', lw=2)
ax.plot(xs2, ysat/f5.ro_sat**f5.slope*xs2**f5.slope, c='red', lw=2)
ax.set_xscale('log'); ax.set_yscale('log'); ax.set_xlim(1e-3, 3); ax.set_ylim(1e-8, 1e-2)
ax.set_xlabel('Ro', fontsize=12); ax.set_ylabel(r"R'$_{\rm H\alpha}$", fontsize=12)
ax.text(0.04, 0.97, 'slope = %.2f ± %.2f\nRo_sat = %.2f\n(VSX+Fetherolf periods, N=%d)\nVSX %d / Fetherolf %d'
        % (f5.slope, f5.slope_err, f5.ro_sat, len(pos), int((pos.src=='VSX').sum()), int((pos.src=='Fetherolf').sum())),
        transform=ax.transAxes, va='top', fontsize=8, bbox=dict(fc='white', ec='red', pad=3))
ax.tick_params(direction='in', top=True, right=True, labelsize=9)
fig.tight_layout(); os.makedirs('figures', exist_ok=True)
o = 'figures/dr13_fig5_rha_rossby_vsx.png'; fig.savefig(o, dpi=170); plt.close(fig)
print('图 ->', o)
