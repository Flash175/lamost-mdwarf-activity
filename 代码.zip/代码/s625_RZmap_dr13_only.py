
# -*- coding: utf-8 -*-
"""s625：只用 DR13 一侧的 (R,Z) 活动率图（论文口径 2D 样本 637,973 颗）
制图规则沿用 s112.fig12 的 map_panel：网格 0.05x0.05 kpc，格内 >=5 颗才给比例，
不足 5 颗则逐星着色（活动 25% / 不活动 0%），色标 0-25%。
输出：第一篇APJS/figures/fig_RZmap_dr13.png + 多个图及讨论/RZ网格_DR13.csv
"""
import os, sys, io
import numpy as np, pandas as pd
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
from astropy.coordinates import SkyCoord
import astropy.units as u
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
OD  = r'C:\Users\lingz\OneDrive\Desktop\复现老师工作\data'
OUTD= r'C:\Users\lingz\Desktop\复现老师工作\APJS\多个图及讨论'
FIG = r'C:\Users\lingz\Desktop\第一篇APJS\figures\fig_RZmap_dr13.png'
lam = ['uid','subclass','ewha','ewha_err','gaia_source_id','gaia_g_mean_mag','ra','dec']
d = pd.read_csv(os.path.join(OD,'lamost','dr13','dr13_mstellar_dM.csv'), usecols=lam, low_memory=False)
d = d[(d.ewha>-20)&(d.ewha<=50)&(d.ewha_err>0)&(d.ewha_err<=5)]
g = pd.read_csv(os.path.join(OD,'gaia','gaia_dr3_mstars.csv'),
                usecols=['source_id','parallax','parallax_error','ruwe','phot_g_mean_mag'], low_memory=False)
d = d.merge(g, left_on='gaia_source_id', right_on='source_id', how='inner')
d = d[(d.parallax>0.2)&(d.parallax/d.parallax_error>5)&(d.ruwe<1.4)]
d = d.sort_values('ewha', ascending=False).drop_duplicates('uid')
d['MG'] = d.gaia_g_mean_mag.values - 5*np.log10(np.clip(1000.0/d.parallax.values,1,None)) + 5
d = d[d.MG>=6].copy()
d['dist_pc'] = 1000.0/d.parallax.values
sc = SkyCoord(ra=d.ra.values*u.deg, dec=d.dec.values*u.deg, distance=d.dist_pc.values*u.pc, frame='icrs')
d['absz'] = np.abs(d.dist_pc.values*np.sin(np.deg2rad(sc.galactic.b.deg)))
d = d[(d.absz>0)&(d.absz<=3000)].copy()
gc = sc.galactocentric
d['R'] = np.hypot(gc.x.to_value(u.kpc), gc.y.to_value(u.kpc))
d['Z'] = gc.z.to_value(u.kpc)
d['act'] = ((d.ewha>=0.75)&(d.ewha>3*d.ewha_err)).astype(float)
print('2D sample %d | active %d (%.2f%%) | R %.2f-%.2f | Z %.2f..%.2f' % (
    len(d), int(d.act.sum()), 100*d.act.mean(), d.R.min(), d.R.max(), d.Z.min(), d.Z.max()))

Rb = np.arange(6.5, 11.001, 0.05); Zb = np.arange(-2.0, 2.001, 0.05)
h, _, _ = np.histogram2d(d.R.values, d.Z.values, bins=[Rb, Zb], weights=d.act.values)
tot, _, _ = np.histogram2d(d.R.values, d.Z.values, bins=[Rb, Zb])
frac = np.where(tot >= 5, h/np.maximum(tot,1), np.nan)
ri = np.clip(np.digitize(d.R.values, Rb)-1, 0, frac.shape[0]-1)
zj = np.clip(np.digitize(d.Z.values, Zb)-1, 0, frac.shape[1]-1)
fv = np.asarray(frac[ri, zj]*100.0, float).copy()
sp = ~(tot[ri, zj] >= 5)
fv[sp] = np.where(d.act.values[sp] > 0, 25.0, 0.0)
# grid table for the archive
Rc = 0.5*(Rb[:-1]+Rb[1:]); Zc = 0.5*(Zb[:-1]+Zb[1:])
RR, ZZ = np.meshgrid(Rc, Zc, indexing='ij')
tab = pd.DataFrame(dict(R_kpc=RR.ravel(), Z_kpc=ZZ.ravel(), n=tot.ravel().astype(int),
                        n_act=h.ravel().astype(int), frac_pct=(100*np.where(tot>0, h/np.maximum(tot,1), np.nan)).ravel()))
tab = tab[tab.n >= 5]
tab.to_csv(os.path.join(OUTD,'RZ网格_DR13.csv'), index=False, encoding='utf-8-sig')
print('grid cells with n>=5:', len(tab))

fig, ax = plt.subplots(figsize=(5.4, 5.0))
pc = ax.scatter(d.R.values, d.Z.values, c=fv, cmap='jet', vmin=0, vmax=25, s=1.6, lw=0)
cb = plt.colorbar(pc, ax=ax, fraction=0.046, pad=0.02); cb.set_label('Active fraction (%)', fontsize=7)
cb.ax.tick_params(labelsize=6.5)
ax.set_xlim(6.5, 11.0); ax.set_ylim(-2.0, 2.0)
ax.set_xticks(np.arange(6.5, 11.01, 0.5)); ax.set_yticks(np.arange(-2.0, 2.01, 0.5))
ax.set_xlabel('$R_{\\rm gc}$  (kpc)'); ax.set_ylabel('$z_{\\rm gc}$  (kpc)')
ax.set_title('LAMOST DR13: %s stars, %s active' % (format(len(d),','), format(int(d.act.sum()),',')), fontsize=9)
plt.tight_layout(); plt.savefig(FIG, dpi=200); plt.close()
print('written', FIG, os.path.getsize(FIG), 'bytes')
