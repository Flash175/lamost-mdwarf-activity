# -*- coding: utf-8 -*-
"""s572：核对正文（非表格）里的关键数字与 CSV 是否一致。"""
import io, sys, os, re
import numpy as np, pandas as pd
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
OUT = r'C:\Users\lingz\Desktop\复现老师工作\APJS\多个图及讨论'
text = open(os.path.join(OUT, '新一节_银盘示踪_中文草稿.md'), encoding='utf-8').read()

C3 = pd.read_csv(os.path.join(OUT,'criterion3_fail_by_zb.csv'), comment='#').set_index('zbin')
C3s = pd.read_csv(os.path.join(OUT,'criterion3_sample.csv'), comment='#')
G = pd.read_csv(os.path.join(OUT,'giant_cut_by_MG.csv'), comment='#').set_index('zbin')
G6 = pd.read_csv(os.path.join(OUT,'far400_6d_properties.csv'), comment='#').iloc[0]
A2 = pd.read_csv(os.path.join(OUT,'far400_2d_audit.csv'), comment='#').set_index('zbin')

checks = []
def chk(label, pattern, expected, tol):
    m = re.search(pattern, text)
    got = float(m.group(1).replace(',','')) if m else None
    ok = (got is not None) and abs(got - expected) <= tol
    checks.append((ok, label, got, expected))

# 第三判据（附录 A.2）
chk('A.2 活动谱总不合格率 19.4%', r'(\d+\.\d) per cent of the 2,255|全样本不合格率 \*\*(\d+\.\d)%', 19.4, 0.05) if False else None
m = re.search(r'全样本不合格率 \*\*([\d.]+)%', text)
checks.append((m is not None and abs(float(m.group(1)) - 19.4) <= 0.05, 'A.2 全样本不合格率', m.group(1) if m else None, 19.4))
for lb, key in [('<100','<100'),('100-200','100-200'),('200-400','200-400'),('>400','>400')]:
    exp = float(C3.loc[key,'fail_pct'])
    m = re.search(re.escape(key) + r'[^\n]{0,40}?([\d]{2}\.[\d])%', text)
    checks.append((m is not None and abs(float(m.group(1)) - exp) <= 0.1, 'A.2 %s 不合格率' % key, m.group(1) if m else None, round(exp,1)))

# 去巨星（§1）
m = re.search(r'M_G < 6\S*[^\n]{0,30}?(\d[\d,]*)\s*颗（([\d.]+)%）', text)
checks.append((m is not None and abs(float(m.group(2)) - 0.27) <= 0.01, '§1 M_G<6 总数占比', m.group(2) if m else None, 0.27))
m = re.search(r'(\d[\d,]*) 颗（93\.4%）', text)
checks.append((m is not None and m.group(1).replace(',','') == '57', '§1 6D 远档 93.4% 的 57 颗', m.group(1) if m else None, 57))
m = re.search(r'> 1000 pc[^\n]{0,120}?([\d]{2}\.[\d])% 的星 \$M_G<6\$', text)
checks.append((m is not None and abs(float(m.group(1)) - 23.06) <= 0.1, '§1 >1000 pc 亮天体 23.1%', m.group(1) if m else None, 23.06))
for lb in ['<100','400-600','600-1000']:
    exp = float(G.loc[lb,'frac_bright'])
    pat = re.escape(lb.replace('-','–')) + r'[^\n]{0,40}?([\d.]+)%'
    m = re.search(pat, text)
    checks.append((m is not None and abs(float(m.group(1)) - exp) <= 0.05, '§1 %s 亮天体比例' % lb, m.group(1) if m else None, round(exp,2)))

print('%-28s %-10s %-10s %s' % ('检查项','草案值','CSV 值','结果'))
for ok, label, got, exp in checks:
    print('%-28s %-10s %-10s %s' % (label, got, exp, '✓' if ok else '✗'))
bad = [c for c in checks if not c[0]]
print('\n不一致 %d / %d' % (len(bad), len(checks)))
