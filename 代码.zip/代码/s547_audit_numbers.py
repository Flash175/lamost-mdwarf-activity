
# -*- coding: utf-8 -*-
"""可审计数字：Wilson 区间、S/N 匹配前后、单历元、组成重加权、稳健 σ(vz)、>400pc 敏感性与属性。"""
import io, sys
import numpy as np, pandas as pd
from astropy.coordinates import SkyCoord
import astropy.units as un
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
OUT='data/processed/dr13'
def wilson(k, n, z=1.96):
    if n == 0: return (np.nan, np.nan)
    p = k/n; d = 1 + z*z/n
    c = (p + z*z/(2*n))/d; h = z*np.sqrt(p*(1-p)/n + z*z/(4*n*n))/d
    return (100*max(0, c-h), 100*min(1, c+h))

cat = pd.read_csv('data/lamost/dr13/dr13_mstellar_dM.csv', low_memory=False,
                  usecols=['uid','subclass','teff','ewha','ewha_err','snrr','ra','dec','gaia_source_id'])
cat = cat[(cat.ewha > -20) & (cat.ewha <= 50) & (cat.ewha_err > 0) & (cat.ewha_err <= 5)].copy()
cat['active'] = (cat.ewha >= 0.75) & (cat.ewha > 3*cat.ewha_err)
nep = cat.groupby('uid').size().rename('n_ep').reset_index()
g = cat.sort_values('ewha', ascending=False).drop_duplicates('uid').merge(nep, on='uid', how='left')
gg = pd.read_csv('data/gaia/gaia_dr3_mstars.csv', low_memory=False, usecols=['source_id','parallax','parallax_error','ruwe'])
gg['sid'] = pd.to_numeric(gg.source_id, errors='coerce'); g['sid'] = pd.to_numeric(g.gaia_source_id, errors='coerce')
M = g.merge(gg[['sid','parallax','parallax_error','ruwe']], on='sid', how='left')
M = M[(M.parallax > 0.2) & (M.parallax/M.parallax_error > 5) & (M.ruwe < 1.4)].copy()
c = SkyCoord(ra=M.ra.values*un.deg, dec=M.dec.values*un.deg, distance=(1000.0/M.parallax.values)*un.pc, frame='icrs')
M['Z'] = np.abs(c.galactic.b.to(un.deg).value)
M['dist'] = 1000.0/M.parallax.values
M['absz'] = M.dist*np.sin(np.radians(M.Z))
M['zb'] = pd.cut(M.absz, [0,100,200,400,3000], labels=['<100','100-200','200-400','>400'])

print('=== A3/D2 每格 n 与 Wilson 95%% 区间（max-EW，全 S/N）===')
rows=[]
for sp in ['dM0','dM1','dM2','dM3','dM4','dM5','dM6']:
    for zb in ['<100','100-200','200-400']:
        q = M[(M.subclass==sp)&(M.zb==zb)]
        if len(q)<50: continue
        k = int(q.active.sum()); lo,hi = wilson(k,len(q))
        rows.append(dict(subclass=sp, zb=zb, n=len(q), k=k, f=100*k/len(q), lo=lo, hi=hi, snr_med=q.snrr.median()))
T=pd.DataFrame(rows); T.to_csv(f'{OUT}/numbers_cells_wilson.csv', index=False, encoding='utf-8-sig')
print(T.round(2).to_string(index=False))

print('\n=== A1 每个亚型 S/N 匹配(10-30) 前后 ===')
rows2=[]
for sp in ['dM0','dM1','dM2','dM3','dM4','dM5','dM6']:
    s = M[M.subclass==sp]
    for zb in ['<100','100-200','200-400']:
        q = s[s.zb==zb]; qm = q[(q.snrr>=10)&(q.snrr<=30)]
        if len(q)<50: continue
        lo1,hi1 = wilson(int(q.active.sum()),len(q)); lo2,hi2 = wilson(int(qm.active.sum()),len(qm)) if len(qm)>=20 else (np.nan,np.nan)
        rows2.append(dict(subclass=sp, zb=zb, n_all=len(q), f_all=100*q.active.mean(),
                          n_m=len(qm), f_m=100*qm.active.mean() if len(qm)>=20 else np.nan))
T2=pd.DataFrame(rows2); T2.to_csv(f'{OUT}/numbers_sn_matched.csv', index=False, encoding='utf-8-sig'); print(T2.round(2).to_string(index=False))

print('\n=== A2 单历元样本 ===')
one = M[M.n_ep==1]; rows3=[]
for sp in ['dM0','dM1','dM2','dM3','dM4','dM5','dM6']:
    s = one[one.subclass==sp]; vals=[]
    for zb in ['<100','100-200','200-400']:
        q = s[s.zb==zb]; vals.append((100*q.active.mean() if len(q)>=50 else np.nan, len(q)))
    if all(np.isnan(v[0]) for v in vals): continue
    ratio = vals[0][0]/vals[2][0] if vals[0][0]==vals[0][0] and vals[2][0]==vals[2][0] else np.nan
    rows3.append(dict(subclass=sp, f_lt100=vals[0][0], n1=vals[0][1], f_100_200=vals[1][0],
                      f_200_400=vals[2][0], n3=vals[2][1], ratio=ratio))
T3=pd.DataFrame(rows3); T3.to_csv(f'{OUT}/numbers_single_epoch.csv', index=False, encoding='utf-8-sig'); print(T3.round(2).to_string(index=False))

print('\n=== A4 按 <100 pc 亚型组成重加权 200–400 pc ===')
comp = M[M.zb=='<100'].subclass.value_counts(normalize=True)
sub = M[M.zb=='200-400']
num=0.0; den=0.0
for sp,w in comp.items():
    q = sub[sub.subclass==sp]
    if len(q)>=50 and sp in ('dM0','dM1','dM2','dM3','dM4','dM5','dM6'):
        num += w*q.active.mean(); den += w
print('  重加权后 200–400 pc 活动率 = %.2f%%（用 <100 pc 的亚型权重，覆盖权重 %.2f）' % (100*num/den, den))
print('  未重加权（实际组成）= %.2f%%' % (100*sub.active.mean()))
print('  若按 <100 pc 组成外推，合并降幅 = %.2f×' % (M[M.zb=='<100'].active.mean()/(num/den)))

print('\n=== C1 200–400 pc 活动星的稳健 σ(vz) ===')
GAI='data/gaia/gaia_dr3_mstars.csv'
u = M[M.zb.isin(['<100','200-400'])].copy()
gal = pd.read_csv(GAI, low_memory=False, usecols=['source_id','radial_velocity','phot_g_mean_mag'])
gal['sid']=pd.to_numeric(gal.source_id,errors='coerce')
u = u.merge(gal[['sid','radial_velocity','phot_g_mean_mag']], on='sid', how='left')
u = u[np.isfinite(u.radial_velocity)&(np.abs(u.radial_velocity)<500)]
print('  有 Gaia RV 的：<100 pc %d 颗，200–400 pc %d 颗' % ((u.zb=='<100').sum(), (u.zb=='200-400').sum()))
k = SkyCoord(ra=u.ra.values*un.deg, dec=u.dec.values*un.deg, distance=(1000.0/u.parallax.values)*un.pc,
             pm_ra_cosdec=u.pmra.values*un.mas/un.yr if 'pmra' in u else None, frame='icrs') if False else None
print('  （σ(vz) 需自行，此处只报 RV 一侧的稳健离散）')
for zb in ['<100','200-400']:
    for act in (True, False):
        s = u[(u.zb==zb)&(u.active==act)]
        if len(s)<30: continue
        rv = s.radial_velocity.values
        mad = 1.4826*np.median(np.abs(rv-np.median(rv)))
        print('  %-8s active=%-5s n=%5d  σ(RV)=%.1f  MAD-σ(RV)=%.1f km/s  |RV| 95%%=%.0f' %
              (zb, act, len(s), rv.std(), mad, np.percentile(np.abs(rv),95)))

print('\n=== C3 >400 pc 那 67 颗活动星 ===')
b = M[M.zb=='>400']
print('  >400 pc: n=%d，活动 %d（%.2f%%）' % (len(b), int(b.active.sum()), 100*b.active.mean()))
print('  活动星 Teff 中位 %.0f、logg? 无；S/N 中位 %.1f、G 中位 %.1f' %
      (b[b.active].teff.median(), b[b.active].snrr.median(), b[b.active].gaia_g_mean_mag.median() if 'gaia_g_mean_mag' in b else np.nan))
for thr in (0.75, 1.0):
    k_ = int(((b.ewha>=thr)&(b.ewha>3*b.ewha_err)).sum())
    print('  阈值 EW>=%.2f Å 且 >3σ：活动 %d 颗 → %.2f%%' % (thr, k_, 100*k_/len(b)))
k5 = int(((b.ewha>=0.75)&(b.ewha>5*b.ewha_err)).sum()); print('  EW>=0.75 且 >5σ：%d 颗 → %.2f%%' % (k5, 100*k5/len(b)))
