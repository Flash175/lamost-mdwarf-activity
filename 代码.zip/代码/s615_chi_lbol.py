# -*- coding: utf-8 -*-
"""s615：χ(Teff) 换算 L_Hα/L_bol 后的两种口径复核（§2.4 亚型 + §4.2 |Z|）。

χ 取 Walkowicz 等（2004, PASP 116, 1105）表 1 的 mean log χ（dM0 用 M0.5 的值，dM1–dM9 对应整亚型）。

输出两套判据，用于回答「L 判据是否带 EW > 3σ」这一口径问题：
  A. L 判据不带显著性截断：L_Hα/L_bol >= 1e-4
  B. L 判据带同样的显著性截断：L_Hα/L_bol >= 1e-4 **且** EW > 3σ(EW)   ← 与 EW 判据严格可比
EW 判据固定为 EW >= 0.75 Å 且 EW > 3σ(EW)。

输出：多个图及讨论/chi_lbol_by_subtype.csv、chi_lbol_by_zbin.csv
"""
import io
import os
import sys

import numpy as np
import pandas as pd
from astropy import units as un
from astropy.coordinates import SkyCoord

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

BASE = r"C:\Users\lingz\OneDrive\Desktop\复现老师工作"
OUT = r"C:\Users\lingz\Desktop\复现老师工作\APJS\多个图及讨论"
LOGCHI = {"dM0": -3.93619, "dM1": -3.93438, "dM2": -4.01516, "dM3": -4.13192, "dM4": -4.19592,
          "dM5": -4.56243, "dM6": -4.75570, "dM7": -5.28066, "dM8": -5.21965, "dM9": -5.41719}

cat = pd.read_csv(os.path.join(BASE, "data", "lamost", "dr13", "dr13_mstellar_dM.csv"), low_memory=False,
                  usecols=["uid", "subclass", "ewha", "ewha_err", "ra", "dec", "gaia_source_id", "gaia_g_mean_mag"])
cat = cat[(cat.ewha > -20) & (cat.ewha <= 50) & (cat.ewha_err > 0) & (cat.ewha_err <= 5)].copy()
cat["gaia_source_id"] = pd.to_numeric(cat.gaia_source_id, errors="coerce")
g = pd.read_csv(os.path.join(BASE, "data", "gaia", "gaia_dr3_mstars.csv"), low_memory=False,
                usecols=["source_id", "parallax", "parallax_error", "ruwe"])
m = cat.merge(g, left_on="gaia_source_id", right_on="source_id", how="inner")
m = m[(m.parallax > 0.2) & (m.parallax / m.parallax_error > 5) & (m.ruwe < 1.4)].copy()
u = m.sort_values("ewha", ascending=False).drop_duplicates("uid").copy()
u["MG"] = u.gaia_g_mean_mag.values - 5 * np.log10(np.clip(1000.0 / u.parallax.values, 1, None)) + 5
u = u[u.MG >= 6].copy()
u["spt"] = u.subclass.astype(str).str.strip()
u["logchi"] = u.spt.map(LOGCHI)
u = u.dropna(subset=["logchi"]).copy()
u["lbol"] = 10 ** u.logchi.values * u.ewha.values
sig = u.ewha > 3 * u.ewha_err
u["act_ew"] = (u.ewha >= 0.75) & sig
u["act_lA"] = u.lbol >= 1e-4
u["act_lB"] = (u.lbol >= 1e-4) & sig
print("2D 样本 %d 颗；活动率 EW(A)=%.3f%%  L(A)=%.3f%%  L(B)=%.3f%%" % (
    len(u), 100 * u.act_ew.mean(), 100 * u.act_lA.mean(), 100 * u.act_lB.mean()))

rows = []
for spt, q in u.groupby("spt"):
    rows.append(dict(spt=spt, n=len(q), med_EW=float(q.ewha.median()), p90_EW=float(q.ewha.quantile(0.9)),
                     pct_EW=100 * float(q.act_ew.mean()), pct_lA=100 * float(q.act_lA.mean()),
                     pct_lB=100 * float(q.act_lB.mean()), logchi=float(q.logchi.iloc[0]),
                     ew_at_1e4=1e-4 / 10 ** float(q.logchi.iloc[0])))
tab = pd.DataFrame(rows).sort_values("spt")
print(tab.to_string(index=False, float_format=lambda v: "%.3f" % v))
for tag, col in [("EW", "pct_EW"), ("L(A, 无 3σ)", "pct_lA"), ("L(B, 带 3σ)", "pct_lB")]:
    print("极差 %-12s %.2f pp（%.2f → %.2f）" % (tag, tab[col].max() - tab[col].min(), tab[col].min(), tab[col].max()))
path = os.path.join(OUT, "chi_lbol_by_subtype.csv")
with open(path, "w", encoding="utf-8") as f:
    f.write("# s615：χ(Teff)→L_Hα/L_bol 后按亚型的活动比例（Walkowicz+2004 表 1 的 mean log chi；dM0 用 M0.5）\n")
    f.write("# pct_EW = EW>=0.75 且 EW>3σ；pct_lA = L>=1e-4（不带 3σ）；pct_lB = L>=1e-4 且 EW>3σ\n")
    f.write("# ew_at_1e4 = 该亚型在固定 χ 下 L=1e-4 对应的 EW 阈值（Å）\n")
    f.write("# 生成脚本：代码/s615_chi_lbol.py\n")
    f.write("spt,n,med_EW,p90_EW,pct_EW,pct_lA,pct_lB,logchi,ew_at_1e4\n")
    for _, r in tab.iterrows():
        f.write("%s,%d,%.4f,%.4f,%.4f,%.4f,%.4f,%.5f,%.4f\n" % (r.spt, r.n, r.med_EW, r.p90_EW, r.pct_EW, r.pct_lA, r.pct_lB, r.logchi, r.ew_at_1e4))

d = 1000.0 / u.parallax.values
sc = SkyCoord(ra=u.ra.values * un.deg, dec=u.dec.values * un.deg, frame="icrs")
u["absz"] = np.abs(d * np.sin(np.deg2rad(sc.galactic.b.deg)))
BINS = [(0, 100, "<100"), (100, 200, "100-200"), (200, 400, "200-400"), (400, 600, "400-600"), (600, 1000, "600-1000"), (1000, 3000, ">1000")]
zrows = []
for lo, hi, nm in BINS:
    q = u[(u.absz >= lo) & (u.absz < hi)]
    zrows.append((nm, len(q), 100 * q.act_ew.mean(), 100 * q.act_lA.mean(), 100 * q.act_lB.mean()))
    print("%-9s n=%7d  EW %.2f%%  L(A) %.2f%%  L(B) %.2f%%" % zrows[-1])
path2 = os.path.join(OUT, "chi_lbol_by_zbin.csv")
with open(path2, "w", encoding="utf-8") as f:
    f.write("# s615：χ 换算 L_Hα/L_bol 后的 |Z| 分档活动比例（三种判据并列）\n")
    f.write("# pct_EW = EW>=0.75 且 EW>3σ；pct_lA = L>=1e-4；pct_lB = L>=1e-4 且 EW>3σ\n")
    f.write("# 生成脚本：代码/s615_chi_lbol.py\n")
    f.write("zbin,n,pct_EW,pct_lA,pct_lB\n")
    for nm, n, a, b, c in zrows:
        f.write("%s,%d,%.4f,%.4f,%.4f\n" % (nm, n, a, b, c))
print("写出", path, os.path.getsize(path), "B;", path2, os.path.getsize(path2), "B")
