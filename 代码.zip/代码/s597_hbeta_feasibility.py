# -*- coding: utf-8 -*-
"""s597：Hβ 可行性检查——用已落盘的谱，看 Hβ 能不能作为第二条活动判据

做法：从 2D 星表里按「活动 / 非活动 × S/N 分档」抽样（只取本地已有谱的 obsid），
对每条谱在 Hβ（4861）与 Hα（6563）各做一次独立测量：
  连续谱 = 两侧窗口的中位线性内插；EW = Σ (1 − F/Fc) Δλ；σ(EW) = 侧窗逐像元散度的传播。
不假设目录 EW 正确——这正是要检验的：本地测得的 EW_Hα 与目录是否一致，以及 EW_Hβ 是否可分活动/非活动。

输出：多个图及讨论/hbeta_feasibility.csv（逐谱）+ 控制台汇总
"""
import io, sys, os, gzip
import numpy as np, pandas as pd

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
BASE = r'C:\Users\lingz\OneDrive\Desktop\复现老师工作'
OUT = r'C:\Users\lingz\Desktop\复现老师工作\APJS\多个图及讨论'

# 1) 目录 + 本地谱清单
cat = pd.read_csv(os.path.join(BASE, 'data', 'lamost', 'dr13', 'dr13_mstellar_dM.csv'), low_memory=False,
                  usecols=['obsid','uid','subclass','ewha','ewha_err','snrr'])
cat = cat[(cat.ewha > -20) & (cat.ewha <= 50) & (cat.ewha_err > 0) & (cat.ewha_err <= 5)].copy()
cat['active'] = (cat.ewha >= 0.75) & (cat.ewha > 3*cat.ewha_err)
have = {}
for sub in ['lrs/dr13', 'lrs/dr13_rest']:
    dd = os.path.join(BASE, 'data', sub)
    if os.path.isdir(dd):
        with os.scandir(dd) as it:
            for e in it:
                if e.name.endswith('.csv.gz') and e.stat().st_size > 500:
                    have[e.name[:-7]] = e.path
cat['obsid_s'] = cat.obsid.astype(str)
cat = cat[cat.obsid_s.isin(have)].copy()
print('可用的星-谱对：%d 条谱 / %d 颗星' % (len(cat), cat.uid.nunique()))
cat['snr_bin'] = pd.cut(cat.snrr, [0, 5, 10, 20, 40, 1e9], labels=['<5','5-10','10-20','20-40','>40'])

C_HA = ((6555.0, 6560.0), (6570.0, 6575.0), (6557.66, 6571.66), (6545.0, 6585.0), (6557.0, 6572.0))
C_HB = ((4852.0, 4857.0), (4866.0, 4871.0), (4855.33, 4869.33), (4842.0, 4882.0), (4854.0, 4870.0))

def measure(w, f, win):
    """与 s574/s566 同一管线：两侧窗均值定线性伪连续谱 + 0.1 A 网格积分 EW + 线外稳健 rms。
    ew = -∫(1 - f/fc) du，故发射线为正。返回 (ew, sigma_ew, rms, npix)。"""
    C_L, C_R, LINE, CT, CE = win
    ok = np.isfinite(w) & np.isfinite(f); w, f = w[ok], f[ok]
    if len(w) < 500: return np.nan, np.nan, np.nan, 0
    o = np.argsort(w); w, f = w[o], f[o]
    mL = (w >= C_L[0]) & (w <= C_L[1]); mR = (w >= C_R[0]) & (w <= C_R[1])
    if mL.sum() < 2 or mR.sum() < 2: return np.nan, np.nan, np.nan, 0
    wl, fl = w[mL].mean(), f[mL].mean(); wr, fr = w[mR].mean(), f[mR].mean()
    if fr == fl: return np.nan, np.nan, np.nan, 0
    mm = (fr - fl)/(wr - wl); bb = fl - mm*wl
    g = np.arange(LINE[0], LINE[1] + 1e-9, 0.1)
    fg = np.interp(g, w, f); fc = mm*g + bb
    fcmed = float(np.nanmedian(fc))
    if fcmed <= 0: return np.nan, np.nan, np.nan, 0
    ew = -np.trapezoid(1.0 - fg/fc, g)
    cont = (w >= CT[0]) & (w <= CT[1]) & ~((w >= CE[0]) & (w <= CE[1]))
    if cont.sum() < 10: return np.nan, np.nan, np.nan, 0
    cm, cb = np.polyfit(w[cont], f[cont], 1)
    res = f[cont] - (cm*w[cont] + cb)
    sig = 1.4826*np.median(np.abs(res - np.median(res)))
    dl = np.median(np.diff(w)); npix = (LINE[1]-LINE[0])/dl
    err = sig/fcmed*dl*np.sqrt(npix)
    return float(ew), float(err), float(sig/fcmed), int(round(npix))

rows = []
rng = np.random.default_rng(11)
for act in (True, False):
    for sb in ['5-10','10-20','20-40','>40']:
        pool = cat[(cat.active == act) & (cat.snr_bin == sb)]
        if len(pool) == 0: continue
        take = pool.sample(min(120, len(pool)), random_state=int(rng.integers(1e6)))
        for _, r in take.iterrows():
            try:
                with gzip.open(have[r.obsid_s], 'rt', encoding='utf-8', errors='replace') as fh:
                    d = pd.read_csv(fh)
            except Exception:
                continue
            if not {'Wavelength','Flux'}.issubset(d.columns): continue
            wl = d.Wavelength.values.astype(float); fl = d.Flux.values.astype(float)
            ok = np.isfinite(wl) & np.isfinite(fl)
            wl, fl = wl[ok], fl[ok]
            if len(wl) < 1000: continue
            ha = measure(wl, fl, C_HA)
            hb = measure(wl, fl, C_HB)
            rows.append(dict(obsid=r.obsid_s, subclass=r.subclass, snr=r.snrr, snr_bin=sb,
                             active_cat=bool(r.active), ewha_cat=r.ewha, snr_cat=r.snrr,
                             ew_ha=ha[0], sig_ha=ha[1], ew_hb=hb[0], sig_hb=hb[1]))
T = pd.DataFrame(rows)
print('实际测量 %d 条谱' % len(T))
if len(T) == 0: sys.exit()
T['ha_det'] = T.ew_ha/T.sig_ha > 3
T['hb_det'] = T.ew_hb/T.sig_hb > 3
print('\n按 S/N 与目录活动性：')
g = T.groupby(['snr_bin','active_cat']).agg(n=('obsid','size'),
        ha_ew=('ew_ha','median'), ha_det=('ha_det','mean'),
        hb_ew=('ew_hb','median'), hb_det=('hb_det','mean'))
print(g.to_string(float_format=lambda x: '%.2f' % x))
print('\nHβ 与 Hα 的本地测量相关性（仅两端都 >3σ 的谱）：')
m = T[(T.ha_det) & (T.hb_det)]
if len(m) > 20:
    print('  n = %d，Pearson r = %.2f，log-log 斜率 %.2f' % (len(m), m.ew_ha.corr(m.ew_hb),
          np.polyfit(np.log10(m.ew_ha.clip(lower=0.2)), np.log10(m.ew_hb.clip(lower=0.1)), 1)[0]))
fp = os.path.join(OUT, 'hbeta_feasibility.csv')
T.to_csv(fp, index=False, encoding='utf-8')
txt = open(fp, encoding='utf-8').read()
hdr = ('# s597：Hβ 可行性——逐谱本地测量 Hα(6563) 与 Hβ(4861) 的 EW 与 σ(EW)\n'
       '# 连续谱为侧窗中位线性内插；ha_det/hb_det = EW/σ(EW) > 3；active_cat 为目录判据（EW>=0.75 且 >3σ）\n'
       '# 生成脚本：代码/s597_hbeta_feasibility.py\n')
open(fp, 'w', encoding='utf-8-sig').write(hdr + txt)
print('\n写出 hbeta_feasibility.csv（%d 行）' % len(T))
