# -*- coding: utf-8 -*-
# 验证：锚定连续模型 Δβ（暴力）、格4 RSS 面、文件一致性、+0.31 全体 β、固定0.135 vs 0.132
import csv, math

BASE = 'C:/Users/lingz/Desktop/复现老师工作/APJS/图五及相关数据'

def load(fn):
    with open(fn, encoding='utf-8-sig') as f:
        return list(csv.DictReader(f))

def panel_of(s):
    if s in ('dM0','dM1','dM2','dM3'): return 'M0-M3'
    if s in ('dM4','dM5','dM6'): return 'M4-M6'
    return 'OTHER'

data = []
for r in load(BASE + '/数据/图5_逐星样本_严格3340行_⑤_tau030.csv'):
    M = float(r['M']); P = float(r['P'])
    Ro30 = P / 10 ** (2.33 - 1.50 * M - 0.30 * M * M)
    Ro31 = P / 10 ** (2.33 - 1.50 * M + 0.31 * M * M)
    data.append(dict(spt=r['spt'], panel=panel_of(r['spt']), Ro30=Ro30, Ro31=Ro31,
                     logRo30=math.log10(Ro30), logRo31=math.log10(Ro31),
                     logRHa=math.log10(float(r['RHa']))))

def ols(xs, ys):
    n=len(xs); xm=sum(xs)/n; ym=sum(ys)/n
    sxx=sum((x-xm)**2 for x in xs); sxy=sum((x-xm)*(y-ym) for x,y in zip(xs,ys))
    b=sxy/sxx; a=ym-b*xm
    rss=sum((y-a-b*x)**2 for x,y in zip(xs,ys))
    return a,b,rss

dA=[d for d in data if d['panel']=='M0-M3']
dB=[d for d in data if d['panel']=='M4-M6']

print('--- 格2 暴力验证：固定 bp=0.132, 共享断点高度 h, 各自斜率 ---')
lbp = math.log10(0.132)
s1=[(d['logRo30'],d['logRHa']) for d in dA if d['logRo30']>lbp]
s2=[(d['logRo30'],d['logRHa']) for d in dB if d['logRo30']>lbp]
def rss_given_h(h):
    tot = 0; bs = []
    for s in (s1, s2):
        u = [x-lbp for x,_ in s]; w = [y-h for _,y in s]
        suu = sum(t*t for t in u); suw = sum(t*w for t,w in zip(u,w))
        b = suw/suu
        bs.append(b)
        tot += sum((w - b*t)**2 for t,w in zip(u,w))
    return tot, bs
# h 粗扫
best = None
h0 = sum(y for _,y in s1+s2)/len(s1+s2)
for k in range(-200, 201):
    h = h0 + k*0.002
    r, bs = rss_given_h(h)
    if best is None or r < best[0]:
        best = (r, h, bs)
print(f'  暴力: h={best[1]:.4f} bA={best[2][0]:.4f} bB={best[2][1]:.4f} Δβ={best[2][0]-best[2][1]:+.4f} RSS={best[0]:.3f}')
print(f'  (台账8b: Δβ=-0.63 4.3σ; 讨论体: 4.1σ; 我的正规方程: +0.4247)')

print()
print('--- 格4 debug：锚定连续+自由断点 RSS 面 ---')
def anchored_rss(bp):
    l = math.log10(bp)
    t1=[(d['logRo30'],d['logRHa']) for d in dA if d['logRo30']>l]
    t2=[(d['logRo30'],d['logRHa']) for d in dB if d['logRo30']>l]
    if len(t1)<3 or len(t2)<3: return None
    # 给定 h 求 b
    def rss_h(h):
        tot=0; bs=[]
        for s in (t1,t2):
            u=[x-l for x,_ in s]; w=[y-h for _,y in s]
            suu=sum(t*t for t in u)
            if suu < 1e-12:
                bs.append(0.0); tot += sum(w_**2 for w_ in w); continue
            b=sum(t*w_ for t,w_ in zip(u,w))/suu
            bs.append(b); tot += sum((w_-b*t)**2 for t,w_ in zip(u,w))
        return tot, bs
    h0 = sum(y for _,y in t1+t2)/len(t1+t2)
    bb = None
    for k in range(-100,101):
        h = h0 + k*0.004
        r, bs = rss_h(h)
        if bb is None or r < bb[0]: bb = (r, h, bs)
    return bb
for bp in (0.02, 0.03, 0.05, 0.08, 0.132, 0.2, 0.3, 0.5):
    out = anchored_rss(bp)
    if out:
        r, h, bs = out
        print(f'  bp={bp:.3f}: RSS={r:.2f} Δβ={bs[0]-bs[1]:+.4f}')
    else:
        print(f'  bp={bp:.3f}: 无效')

print()
print('--- ⑤.csv 与 ⑤_tau030.csv 一致性 ---')
a = load(BASE + '/数据/图5_逐星样本_严格3340行_⑤.csv')
b = load(BASE + '/数据/图5_逐星样本_严格3340行_⑤_tau030.csv')
ia = {r['uid']: r for r in a}
ib = {r['uid']: r for r in b}
print(f'  行数: ⑤={len(a)} tau030={len(b)}; uid 集合相同: {set(ia)==set(ib)}')
same_RHa = all(abs(float(ia[u]['RHa'])-float(ib[u]['RHa']))<1e-12 for u in ia)
same_M = all(abs(float(ia[u]['M'])-float(ib[u]['M']))<1e-12 for u in ia)
same_P = all(abs(float(ia[u]['P'])-float(ib[u]['P']))<1e-12 for u in ia)
same_Ro = all(abs(float(ia[u]['Ro'])-float(ib[u]['Ro']))<1e-12 for u in ia)
print(f'  RHa 相同: {same_RHa}; M 相同: {same_M}; P 相同: {same_P}; Ro 相同: {same_Ro}')

print()
print('--- 全体 +0.31 自由断点 β 精确复算（free_bp_ols 逻辑）---')
grid = [-2.4 + i*2.1/1100 for i in range(1101)]
best = None
for g in grid:
    l = g  # log10(bp)
    lo = [d['logRHa'] for d in data if d['logRo31'] <= l]
    hi = [(d['logRo31'], d['logRHa']) for d in data if d['logRo31'] > l]
    if len(lo) < 20 or len(hi) < 20: continue
    c = sum(lo)/len(lo)
    rss = sum((y-c)**2 for y in lo)
    _, bsl, r2 = ols([x for x,_ in hi], [y for _,y in hi])
    rss += r2
    if best is None or rss < best[0]:
        best = (rss, 10**g, bsl)
print(f'  RSS_min={best[0]:.3f} bp={best[1]:.4f} β={best[2]:.4f}  (台账5b: β=-0.913, bp=0.069)')

print()
print('--- 固定断点 0.135 vs 0.132（-0.30 口径）---')
for bp in (0.132, 0.135):
    sub = [d for d in data if d['logRo30'] > math.log10(bp)]
    _, bb, _ = ols([d['logRo30'] for d in sub], [d['logRHa'] for d in sub])
    print(f'  全体 bp={bp}: β={bb:.4f} (n={len(sub)})  (台账§3 标注 0.132; s227/s230 用 0.135)')
for p in ('M0-M3','M4-M6'):
    for bp in (0.132, 0.135):
        sub = [d for d in data if d['panel']==p and d['logRo30'] > math.log10(bp)]
        _, bb, _ = ols([d['logRo30'] for d in sub], [d['logRHa'] for d in sub])
        print(f'  {p} bp={bp}: β={bb:.4f} (n={len(sub)})')
