# -*- coding: utf-8 -*-
"""s605：3 万条分层抽样，测 Hα 与 Hβ，出六档三判据对照表（后台跑）

抽样：按 |Z| 六档分层，目标 30,000 条（近档多、远档按可用量取满）。
测量：与 s574/s566 同管线（Yi 2014 窗口 + 线外稳健 rms）。
输出：hbeta30k_per_spectrum.csv、hbeta30k_by_zbin.csv（完成时写出）
"""
import io, sys, os, gzip
import numpy as np, pandas as pd
from astropy.coordinates import SkyCoord
import astropy.units as un

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
BASE = "C:/Users/lingz/OneDrive/Desktop/复现老师工作"
OUT = "C:/Users/lingz/Desktop/复现老师工作/APJS/多个图及讨论"
C_HA = ((6555.0,6560.0),(6570.0,6575.0),(6557.66,6571.66),(6545.0,6585.0),(6557.0,6572.0))
C_HB = ((4852.0,4857.0),(4866.0,4871.0),(4855.33,4869.33),(4842.0,4882.0),(4854.0,4870.0))
BINS = [(0,100,'<100'),(100,200,'100-200'),(200,400,'200-400'),(400,600,'400-600'),
        (600,1000,'600-1000'),(1000,3000,'>1000')]
TARGET = 30000

def measure(w, f, win):
    C_L, C_R, LINE, CT, CE = win
    ok = np.isfinite(w) & np.isfinite(f); w, f = w[ok], f[ok]
    if len(w) < 500: return np.nan, np.nan
    o = np.argsort(w); w, f = w[o], f[o]
    mL = (w>=C_L[0])&(w<=C_L[1]); mR = (w>=C_R[0])&(w<=C_R[1])
    if mL.sum()<2 or mR.sum()<2: return np.nan, np.nan
    wl_, fl_ = w[mL].mean(), f[mL].mean(); wr_, fr_ = w[mR].mean(), f[mR].mean()
    if fr_ == fl_: return np.nan, np.nan
    mm = (fr_-fl_)/(wr_-wl_); bb = fl_-mm*wl_
    g = np.arange(LINE[0], LINE[1]+1e-9, 0.1)
    fg = np.interp(g, w, f); fc = mm*g+bb
    fcmed = float(np.nanmedian(fc))
    if fcmed <= 0: return np.nan, np.nan
    ew = -np.trapezoid(1.0-fg/fc, g)
    cont = (w>=CT[0])&(w<=CT[1])&~((w>=CE[0])&(w<=CE[1]))
    if cont.sum()<10: return float(ew), np.nan
    cm, cb = np.polyfit(w[cont], f[cont], 1)
    res = f[cont]-(cm*w[cont]+cb)
    sig = 1.4826*np.median(np.abs(res-np.median(res)))
    dl = np.median(np.diff(w)); npix = (LINE[1]-LINE[0])/dl
    return float(ew), float(sig/fcmed*dl*np.sqrt(npix))

cat = pd.read_csv(BASE+"/data/lamost/dr13/dr13_mstellar_dM.csv", low_memory=False,
                  usecols=['obsid','uid','subclass','ewha','ewha_err','snrr','ra','dec','gaia_source_id'])
cat = cat[(cat.ewha>-20)&(cat.ewha<=50)&(cat.ewha_err>0)&(cat.ewha_err<=5)].copy()
cat['active'] = (cat.ewha>=0.75)&(cat.ewha>3*cat.ewha_err)
paths = {}
for sub in ['lrs/dr13','lrs/dr13_rest']:
    dd = BASE+"/data/"+sub
    with os.scandir(dd) as it:
        for e in it:
            if e.name.endswith('.csv.gz') and e.stat().st_size>500: paths[e.name[:-7]] = e.path
cat['obsid_s'] = cat.obsid.astype(str)
cat = cat[cat.obsid_s.isin(paths)].copy()
g = pd.read_csv(BASE+"/data/gaia/gaia_dr3_mstars.csv", low_memory=False,
                usecols=['source_id','parallax','parallax_error','ruwe'])
cat['gaia_source_id'] = pd.to_numeric(cat.gaia_source_id, errors='coerce')
cat = cat.merge(g, left_on='gaia_source_id', right_on='source_id', how='inner')
cat = cat[(cat.parallax>0.2)&(cat.parallax/cat.parallax_error>5)&(cat.ruwe<1.4)].copy()
d_pc = 1000.0/cat.parallax.values
sc = SkyCoord(ra=cat.ra.values*un.deg, dec=cat.dec.values*un.deg, distance=d_pc*un.pc, frame='icrs')
cat['absz'] = np.abs(d_pc*np.sin(np.deg2rad(sc.galactic.b.deg)))
cat['path'] = cat.obsid_s.map(paths)
pools = []
for lo, hi, nm in BINS:
    q = cat[(cat.absz>lo)&(cat.absz<=hi)]
    if len(q): pools.append((nm, q))
tot = sum(len(q) for _, q in pools)
parts = []
for nm, q in pools:
    n = max(300, int(TARGET*len(q)/tot))
    n = min(n, len(q))
    parts.append((nm, q.sample(n, random_state=5)))
    print('  %-9s 池 %6d -> 抽 %5d' % (nm, len(q), n), flush=True)
W = pd.concat([q for _, q in parts])
print('合计抽 %d 条谱，开始测量（约 %d 分钟）' % (len(W), int(len(W)*0.08/60)), flush=True)

rows = []
for i, (_, r) in enumerate(W.iterrows()):
    try:
        with gzip.open(r.path, 'rt', encoding='utf-8', errors='replace') as fh:
            d = pd.read_csv(fh)
        wl = d.Wavelength.values.astype(float); fl = d.Flux.values.astype(float)
    except Exception:
        continue
    ha, ea = measure(wl, fl, C_HA); hb, eb = measure(wl, fl, C_HB)
    zb = next(nm for lo, hi, nm in BINS if lo < r.absz <= hi)
    rows.append(dict(obsid=r.obsid_s, zbin=zb, subclass=r.subclass, snr=r.snrr, absz=r.absz,
                     act_cat=bool(r.active), ew_ha=ha, sig_ha=ea, ew_hb=hb, sig_hb=eb))
    if (i+1) % 1000 == 0:
        print('  已测 %d / %d' % (i+1, len(W)), flush=True)
T = pd.DataFrame(rows)
T['act_ha'] = (T.ew_ha>=0.75)&(T.ew_ha>3*T.sig_ha)
T['act_hb'] = (T.ew_hb>=0.75)&(T.ew_hb>3*T.sig_hb)
T.to_csv(OUT+"/hbeta30k_per_spectrum.csv", index=False, encoding='utf-8')

def wilson(k, n, z=1.96):
    if n==0: return (np.nan, np.nan)
    p=k/n; d=1+z*z/n; c=(p+z*z/(2*n))/d
    h=z*np.sqrt(p*(1-p)/n+z*z/(4*n*n))/d
    return (100*(c-h), 100*(c+h))
out = []
for zb in [b[2] for b in BINS]:
    q = T[T.zbin==zb]
    if len(q)==0: continue
    row = dict(zbin=zb, n=len(q))
    for tag, col in [('cat','act_cat'),('ha','act_ha'),('hb','act_hb')]:
        k=int(q[col].sum()); lo,hi=wilson(k,len(q))
        row['f_'+tag]=100*k/len(q); row['lo_'+tag]=lo; row['hi_'+tag]=hi
    out.append(row)
D = pd.DataFrame(out)
D.to_csv(OUT+"/hbeta30k_by_zbin.csv", index=False, encoding='utf-8')
print('\n六档三判据：')
print(D[['zbin','n','f_cat','f_ha','f_hb']].to_string(index=False, float_format=lambda x:'%.2f'%x))
print('\n完成：hbeta30k_per_spectrum.csv（%d 行）与 hbeta30k_by_zbin.csv' % len(T))
