
import pandas as pd, numpy as np
D = r'C:\Users\lingz\Desktop\复现老师工作\APJS\多个图及讨论'
cl = pd.read_csv(D + r'\金属度_清洁样本_637973.csv', low_memory=False, usecols=['uid','subclass','m_h','m_h_err','mh_ok','active','absz'])
pe = pd.read_csv(r'C:\Users\lingz\Desktop\复现老师工作\APJS\图五及相关数据\数据\图5_逐星样本_严格3340行_⑤_tau030.csv', low_memory=False)
print('periodic sample', len(pe), '| columns', ', '.join(pe.columns[:10]))
m = pe.merge(cl[['uid','subclass','m_h','m_h_err','mh_ok','absz']], on='uid', how='left', suffixes=('','_cl'))
print('matched uid:', int(m.subclass_cl.notna().sum()) if 'subclass_cl' in m else int(m['subclass'].notna().sum()))
col = 'subclass_cl' if 'subclass_cl' in m.columns else 'subclass'
m['mh_ok2'] = (np.isfinite(m.m_h) & (m.m_h_err<=0.25))
print('with usable m_h:', int(m.mh_ok2.sum()), '| median m_h_err %.3f' % m.m_h_err.median())
g = m[m.mh_ok2].groupby(col).agg(n=('uid','size'), mh_med=('m_h','median')).round(3)
print('\nperiodic stars with m_h by subtype:\n' + g.to_string())
print('\nsubtype of periodic sample overall:'); print(m[col].value_counts().to_string())
