# -*- coding: utf-8 -*-
"""s240：图 5 两面板「终版」重绘（U3 收口）。

背景：原 `图/图5_两面板_终版.png`（2026-10-22 13:27）烧死 5 个旧值
      （−0.857 / −0.874 / −0.871 / 0.003 / −0.850）。
      生图脚本此前不在 代码/（U3 一直挂起），本脚本以「逐星样本 CSV + 台账审计值」
      重建同一版式，不改版式、只改数字。

数据源：数据/图5_逐星样本_严格3340行_⑤.csv（定稿 ⑤ 口径，n=3340）
数值源：方法说明/fig5_final_numbers.md（固定断点 0.132、τ 取 Li 印刷式 −0.30）

2026-11-04 口径统一：全项目断点一律 0.132（此前本脚本与 s227/s230/s235/s245 残留 0.135，
与已定稿的图注/台账/讨论体/tex 不一致，重跑会产出 0.135 口径的图并覆盖定稿）。

⚠ 重要（2026-10-22 23:55 查明）：该 CSV 的 `Ro` / `sRo` 两列是 **τ=−0.31 旧口径**的导出
   （实测 Ro_col / [P/10^(2.33−1.5M−0.31M²)] 中位比 = 1.000000，最大偏差 3.6e-14），
   直接拿列值拟合会得到 −0.8565 / −0.8744 / −0.8708 —— 正是旧图上烧死的 −0.857/−0.874/−0.871。
   本脚本因此**不读 Ro 列**，按 M、P 以 −0.30 重算 Ro，并把 sRo 按同一比例缩放（sRo/Ro 不变）。
   RHa / sRHa / spt / M 等列不受影响。

口径约定（与正文完全一致）：
  主结果 = 全体 + 固定断点 Ro_sat=0.132 + OLS        β = −0.857 ± 0.083
  面板   = 同断点 OLS，仅注记不画线                  −0.890±0.093 / −0.822±0.178
  Δβ     = √(0.093²+0.178²)=0.201，两面板差 −0.068 ± 0.201
  对照   = 自由断点 OLS                              β = −0.853 ± 0.114
  Ro_sat 区间来自 0.132 定稿的 600 次 bootstrap        68%: 0.095–0.167

输出：图/图5_两面板_终版_v2.png（不覆盖原图 `图5_两面板_终版.png`）

v2.1（2026-10-23 00:1x）——只改标注，不动任何数值。五项：
  ① 自由断点行补 `β(ML) = −0.856`、`Ro_sat = 0.120 (ML)`（与图注 L21「0.135 OLS / 0.120 ML」并列）；
  ② 主拟合行补内禀弥散 `σ_int = 0.49 dex`（图注 A/B 版均含此项，图面原先缺）；
  ③ 脚注删坪内倾斜括号 `(+0.35 / −0.20 / ≈0.00)`——按 C5，该诊断只进附录，不进主图；
  ④ 标题删 `(reproduction of Fig. 5)` 复现备注（投稿稿不要）；
  ⑤ 脚注样本链起算改为 5,619 → 4,612 → 3,340（与台账 §1 主支逐级对齐，原写 4,612 起算属断链）。
"""
import io, os, sys
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
import numpy as np, pandas as pd
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
SAMPLE = os.path.join(ROOT, '数据', '图5_逐星样本_严格3340行_⑤.csv')
# 不再覆盖交付图（v2/v3 是 s189 的 0.132 定稿）；本脚本只出「重校版」供比对
OUT = r'C:\Users\lingz\Desktop\第一篇APJS\figures\fig2_rossby.png'

# ---------- 台账审计值（图面只印这些） ----------
BP = 0.132
BOOK = dict(beta=-0.857, beta_err=0.083,
            b_m03=-0.890, b_m03_err=0.093,
            b_m46=-0.822, b_m46_err=0.178,
            db=0.068, db_err=0.201,
            fb_beta=-0.853, fb_beta_err=0.114,
            # ML：断点自由（自带最优 0.1199 → 0.120），见台账 §2 第 5 行；若断点锁 0.132 则为 −0.928
            fb_ml=-0.856, ro_ml=0.120,
            sig_int=0.49,          # 内禀弥散，dex；台账 §2 第 55 行、§8 稳健性表 0.49–0.50
            ro68=(0.095, 0.167),
            least_biased=-1.096, least_biased_err=0.111,
            n_period=5619, n_step1=4612, n_fit=3340)


def fixed_bp_ols(x, y, rs=np.log10(BP)):
    """固定断点：坪区取常数（均值），上段直线。返回 (slope, plateau_value_in_log, n_low, n_up)."""
    s, u = x <= rs, x > rs
    plat = y[s].mean()
    sl, ic = np.polyfit(x[u], y[u], 1)
    return sl, plat, int(s.sum()), int(u.sum())


def free_bp_ols(x, y, grid=None):
    """自由断点扫描；默认宽域 1,101 点（s227 BP_GRID = [4e-3, 0.5]），可传 401 点窄域作对照。"""
    best = None
    for r in (np.linspace(-2.4, -0.3, 1101) if grid is None else grid):
        s, u = x <= r, x > r
        if s.sum() < 20 or u.sum() < 20:
            continue
        rss = ((y[s] - y[s].mean()) ** 2).sum()
        sl, ic = np.polyfit(x[u], y[u], 1)
        rss += ((y[u] - (sl * x[u] + ic)) ** 2).sum()
        if best is None or rss < best[0]:
            best = (rss, 10 ** r, sl)
    return best[1], best[2]


def main():
    d = pd.read_csv(SAMPLE)
    d = d[(d.Ro > 0) & (d.RHa > 0)].copy()
    assert len(d) == BOOK['n_fit'], '样本行数与定稿 n=3340 不符：%d' % len(d)

    # ---- 按 −0.30 重算 Ro（CSV 的 Ro 列是 −0.31 旧口径）----
    r30 = d.P / 10 ** (2.33 - 1.50 * d.M - 0.30 * d.M ** 2)
    ratio = float(np.median(d.Ro / r30))
    print('CSV Ro 列 / −0.30 复算 中位比 = %.6f（≈1.0056 即 −0.31 口径；≈1.0000 则为 −0.30）' % ratio)
    if abs(ratio - 1.0) < 1e-4:
        d['Roc'], d['sRoc'] = d.Ro, d.sRo
        print('  → 列值即 −0.30 口径，直接使用')
    else:
        d['Roc'] = r30
        d['sRoc'] = d.sRo * (r30 / d.Ro)          # sRo/Ro 比例不变
        print('  → 列值为旧口径，已按 M、P 重算（sRo 同比例缩放）')

    x, y = np.log10(d.Roc.values), np.log10(d.RHa.values)

    sl, plat, nlow, nup = fixed_bp_ols(x, y)
    fb_rs, fb_sl = free_bp_ols(x, y)
    print('全体 固定断点 0.132 OLS：β = %.4f（台账 −0.857）' % sl)
    print('      坪区 n=%d（Ro<=0.132）、上段 n=%d；坪区常数 y=%.3f' % (nlow, nup, plat))
    fb_rs401, fb_sl401 = free_bp_ols(x, y, np.linspace(-1.1, -0.4, 401))
    print('全体 自由断点 OLS：宽域 1,101 点 → β = %.4f @ Ro_sat = %.3f ；窄域 401 点 → β = %.4f @ %.3f'
          % (fb_sl, fb_rs, fb_sl401, fb_rs401))
    print('      台账报 −0.853 ± 0.114（401 点口径；网格依赖见台账末位说明）')

    PAN = [('M0–M3', ['dM0', 'dM1', 'dM2', 'dM3'], BOOK['b_m03'], BOOK['b_m03_err']),
           ('M4–M6', ['dM4', 'dM5', 'dM6'], BOOK['b_m46'], BOOK['b_m46_err'])]
    chk = []
    for nm, sel, bw, be in PAN:
        q = d[d.spt.isin(sel)]
        qs, _, _, _ = fixed_bp_ols(np.log10(q.Roc.values), np.log10(q.RHa.values))
        print('  %s: n=%d  β(OLS, 固定 0.132) = %.4f（台账 %.3f）' % (nm, len(q), qs, bw))
        chk.append((nm, len(q), qs))

    # 自检：图上印的值必须与复算一致到 0.001（否则拒绝出图）
    for nm, n, qs in chk:
        bw = BOOK['b_m03'] if nm == 'M0–M3' else BOOK['b_m46']
        assert abs(qs - bw) < 1e-3, '%s 复算 %.4f 与台账 %.3f 不符' % (nm, qs, bw)
    assert abs(sl - BOOK['beta']) < 1e-3, '全体复算 %.4f 与台账 %.3f 不符' % (sl, BOOK['beta'])
    assert abs(fb_sl - BOOK['fb_beta']) < 2e-3, '自由断点复算 %.4f 与台账 %.3f 不符' % (fb_sl, BOOK['fb_beta'])

    # ---------- 绘图 ----------
    fig, axes = plt.subplots(1, 2, figsize=(10.9, 5.8))
    ysat = 10 ** plat
    xs1 = np.logspace(-3, np.log10(BP), 40)
    xs2 = np.logspace(np.log10(BP), np.log10(3), 60)

    for ax, (nm, sel, bw, be) in zip(axes, PAN):
        q = d[d.spt.isin(sel)]
        ax.errorbar(q.Roc, q.RHa, xerr=q.sRoc, yerr=q.sRHa, fmt='o', ms=3.0, lw=0,
                    elinewidth=0.35, alpha=0.5, color='#1f4fd8', capsize=0, zorder=2)
        # 红线：全体单样本拟合（两面板同一条，不画面板自己的线）
        ax.plot(xs1, np.full_like(xs1, ysat), c='C3', lw=1.9, zorder=3)
        ax.plot(xs2, ysat / BP ** BOOK['beta'] * xs2 ** BOOK['beta'], c='C3', lw=1.9, zorder=3)
        ax.axvline(BP, c='C3', ls=':', lw=0.9, alpha=0.7, zorder=1)
        ax.set_xscale('log'); ax.set_yscale('log')
        ax.set_xlim(1e-3, 3); ax.set_ylim(1e-8, 1e-2)
        ax.set_xlabel(r'$R_{\rm o} = P_{\rm rot}/\tau$', fontsize=10)
        ax.set_ylabel(r"$R'_{\rm H\alpha}$", fontsize=10)
        ax.set_title(u'%s  (n=%d)' % (nm, len(q)), fontsize=10)
        ax.text(0.035, 0.965, u'panel fit: \u03b2 = \u2212%.3f \u00b1 %.3f' % (abs(bw), be),
                transform=ax.transAxes, va='top', fontsize=8.0,
                bbox=dict(fc='white', ec='C3', lw=0.8, pad=3), zorder=5)
        ax.tick_params(direction='in', top=True, right=True, labelsize=8.5)

    # ---------- 标题与页眉（v2.1：去复现备注；补 σ_int 与 ML） ----------
    fig.suptitle('LAMOST DR13 M dwarfs: chromospheric activity vs. Rossby number',
                 fontsize=10.8, y=0.990)
    fig.text(0.5, 0.958,
             u'red lines: single all-sample fit (\u03b2 = \u2212%.3f \u00b1 %.3f, fixed $R_{\\rm o,sat}$ = %.3f, '
             u'$\\sigma_{\\rm int}$ = %.2f dex; CONSERVATIVE LOWER BOUND; '
             u'least-biased high-S/N half: \u2212%.3f \u00b1 %.3f)'
             % (abs(BOOK['beta']), BOOK['beta_err'], BP, BOOK['sig_int'],
                abs(BOOK['least_biased']), BOOK['least_biased_err']),
             ha='center', va='top', fontsize=8.4, color='#8b0000')
    fig.text(0.5, 0.934,
             u'panel fits (annotations only): \u2212%.3f \u00b1 %.3f (M0\u2013M3), '
             u'\u2212%.3f \u00b1 %.3f (M4\u2013M6),  \u0394\u03b2 = %.3f \u00b1 %.3f'
             % (abs(BOOK['b_m03']), BOOK['b_m03_err'], abs(BOOK['b_m46']), BOOK['b_m46_err'],
                BOOK['db'], BOOK['db_err']),
             ha='center', va='top', fontsize=8.0, color='0.25')
    fig.text(0.5, 0.910,
             u'free breakpoint: \u03b2(OLS) = \u2212%.3f \u00b1 %.3f, \u03b2(ML) = \u2212%.3f;  '
             u'$R_{\\rm o,sat}$ = %.3f (OLS; 68%%: %.3f\u2013%.3f) / %.3f (ML)'
             % (abs(BOOK['fb_beta']), BOOK['fb_beta_err'], abs(BOOK['fb_ml']),
                BP, BOOK['ro68'][0], BOOK['ro68'][1], BOOK['ro_ml']),
             ha='center', va='top', fontsize=8.0, color='0.25')

    foot = ('Sample: LAMOST DR13 M dwarfs with VSX/Fetherolf periods (3\u2033 match, n=%s).\n'
            'Ro > 0 and R\u2032H\u03b1 > 0 leave %s; removing alias periods, ruwe \u2265 1.4 (the only binary proxy used), M3/M4 border stars, '
            'and Ro > 3 leaves n=%s fitted (12 dM7\u2013dM8 fall outside the panels).\n'
            'Errors: EW + 10%% \u03c7(Teff); period precision (VSX 7.5%%, Fetherolf 3%%) + 10%% M/\u03c4. '
            'Plateau drawn as a single constant inside Ro < 0.132.'
            % ('{:,}'.format(BOOK['n_period']), '{:,}'.format(BOOK['n_step1']),
               '{:,}'.format(BOOK['n_fit'])))
    fig.text(0.5, 0.010, foot, ha='center', va='bottom', fontsize=6.2, color='0.3', linespacing=1.6)
    fig.tight_layout(rect=(0, 0, 1, 0.885))
    fig.subplots_adjust(left=0.062, right=0.985, bottom=0.172, top=0.839, wspace=0.18)

    # 写出 Ro 已修正（−0.30 口径）的逐星表，避免后续再被 −0.31 列带偏
    # 不覆盖台账钉住的权威逐星表（sha256[:16] = ab5c8345d144e71c），另存一份重校表
    out_csv = os.path.join(ROOT, '数据', '图5_逐星样本_严格3340行_⑤_tau030_s240recheck.csv')
    d2 = d.copy(); d2['Ro'], d2['sRo'] = d2.Roc, d2['sRoc']
    d2.drop(columns=['Roc', 'sRoc']).to_csv(out_csv, index=False)
    print('已写出 −0.30 口径逐星表 -> %s' % out_csv)


    # ---- 版式自检：页眉/标题、脚注/x 轴标签 不得重叠 ----
    fig.canvas.draw(); r = fig.canvas.get_renderer()
    def bb(o):
        b = o.get_window_extent(renderer=r).transformed(fig.transFigure.inverted())
        return (round(b.y0,4), round(b.y1,4))
    ftxt = [t for t in fig.texts]
    print('  [版式] xlabel1 %s  xlabel2 %s  脚注 %s  页眉L1 %s L2 %s L3 %s'
          % (bb(axes[0].xaxis.label), bb(axes[1].xaxis.label), bb(ftxt[0]),
             bb(ftxt[1]), bb(ftxt[2]), bb(ftxt[3])))
    print('  [版式] 面板标题 %s  ylabel %s  脚注 %s' % (bb(axes[0].title), bb(axes[0].yaxis.label), bb(ftxt[-1])))
    _xl = bb(axes[0].xaxis.label)[0]
    assert bb(ftxt[-1])[1] < _xl - 0.004, \
        '脚注与 x 轴标签重叠：脚注上沿 %.4f，x 轴标签下沿 %.4f' % (bb(ftxt[-1])[1], _xl)
    assert bb(axes[0].title)[1] < bb(ftxt[-2])[0], '页眉第三行与面板标题重叠'

    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    fig.savefig(OUT, dpi=200); plt.close(fig)
    print('已出图 -> %s' % OUT)
    print('图面值：β=%.3f±%.3f | 面板 %.3f±%.3f / %.3f±%.3f | Δβ=%.3f±%.3f | 自由断点 %.3f±%.3f'
          % (BOOK['beta'], BOOK['beta_err'], BOOK['b_m03'], BOOK['b_m03_err'],
             BOOK['b_m46'], BOOK['b_m46_err'], BOOK['db'], BOOK['db_err'],
             BOOK['fb_beta'], BOOK['fb_beta_err']))


if __name__ == '__main__':
    main()
