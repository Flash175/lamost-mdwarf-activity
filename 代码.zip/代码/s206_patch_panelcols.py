# -*- coding: utf-8 -*-
"""给面板拟合表补 N 与口径列"""
import io, sys
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
P = 'repro/src/s189_fig5_official_v4.py'
s = open(P, encoding='utf-8').read()
OLD = "pd.DataFrame([dict(panel=k, n=v[0], beta_ols=v[1], beta_ols_err=v[2], beta_ml=v[4], sigma_int=v[6],"
NEW = ("pd.DataFrame([dict(panel=k, 口径='⑤ 严格样本', "
       "清洗项='nss=0;去别名(0.5/1/2d±5%+VSX/TESS交叉验证);ruwe<1.4(保留缺值);去M3/M4边界;Ro<=3', "
       "n=v[0], beta_ols=v[1], beta_ols_err=v[2], beta_ml=v[4], sigma_int=v[6],")
if OLD in s and '清洗项' not in s:
    s = s.replace(OLD, NEW, 1)
    s = s.replace("              full_n=len(strict),", "              full_n_all=len(A), full_n_strict=len(strict),", 1)
    open(P, 'w', encoding='utf-8').write(s); print('  s189 已加 口径/N 列')
else:
    print('  s189 已有列或锚点未匹配')
