# -*- coding: utf-8 -*-
"""s245：`附_坪区恒定检验.png` 重绘（附录 §11 用）。

背景：归档图（2026-10-22 12:36）的坪区成员数是 **1,281 + 1,065 = 2,346**，
用的是 CSV 里 **τ = −0.31 旧口径的 Ro 列**；现行 −0.30 口径下应为
**1,287 + 1,065 = 2,352**，再加坪区内 8 颗 dM7 才等于台账/正文的 **2,360**。
（差 14 = 6（口径）+ 8（面板外 dM7–dM8）——这正好解释了「2,346 vs 2,360」的 14 颗缺口。）

斜率与 F 值按 −0.30 重算后与 `图05_Methods文字` §11 表逐位一致：
  全体 n=2,360 +0.0015±0.0296（RSS 725.9→725.9，F=0.00，p=0.96）
  M0–M3 n=1,287 +0.3497±0.0502（455.1→438.5，F=48.6，p=5×10⁻¹²）
  M4–M6 n=1,065 −0.1964±0.0380（266.0→259.4，F=26.7，p=3×10⁻⁷）

输出：图/附_坪区恒定检验.png（旧图留为 `图/旧版_附_坪区恒定检验_20261022_1236.png`）
"""
import io, os, sys
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
import numpy as np, pandas as pd
from scipy import stats
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
SAMPLE = os.path.join(ROOT, '数据', '图5_逐星样本_严格3340行_⑤.csv')
OUT = os.path.join(ROOT, '图', '附_坪区恒定检验.png')

BP, TAU_C2 = 0.135, -0.30
PAN = [('M0–M3', ['dM0', 'dM1', 'dM2', 'dM3']),
       ('M4–M6', ['dM4', 'dM5', 'dM6'])]
EXP = {'M0–M3': (1287, 0.3497, 0.0502, 48.6),
       'M4–M6': (1065, -0.1964, 0.0380, 26.7)}   # 与 Methods §11 表对照，出图前断言


def fit(x, y):
    n = len(x)
    sl, ic = np.polyfit(x, y, 1)
    rss1 = ((y - (sl * x + ic)) ** 2).sum()
    rss0 = ((y - y.mean()) ** 2).sum()
    F = (rss0 - rss1) / (rss1 / (n - 2))
    se = (y - (sl * x + ic)).std(ddof=2) / np.sqrt(((x - x.mean()) ** 2).sum())
    return sl, se, F, stats.f.sf(F, 1, n - 2), rss0, rss1


def main():
    d = pd.read_csv(SAMPLE)
    d = d[(d.Ro > 0) & (d.RHa > 0) & (d.P > 0) & (d.M > 0)].copy()
    d['Ro30'] = d.P / 10 ** (2.33 - 1.50 * d.M + TAU_C2 * d.M ** 2)
    # 本检验的坪区按 Ro ≤ 0.135 划（与 Methods §11 表一致）；主拟合的固定断点是 0.132，两者差 0.003、
    # ΔRSS < 0.05 在数值上不可区分，但非饱和段星数随断点变：0.132 → 819/187，0.135 → 796/180（见台账 §七。）
    plat = d[d.Ro30 <= BP]

    fig, axes = plt.subplots(1, 2, figsize=(10.4, 4.5))
    for ax, (nm, sel) in zip(axes, PAN):
        q = plat[plat.spt.isin(sel)]
        x, y = np.log10(q.Ro30.values), np.log10(q.RHa.values)
        sl, se, F, p, rss0, rss1 = fit(x, y)
        nE, slE, seE, FE = EXP[nm]
        assert len(x) == nE, '%s 坪区 N=%d 与 Methods 表 %d 不符' % (nm, len(x), nE)
        assert abs(sl - slE) < 5e-4, '%s 斜率 %.4f 与 Methods 表 %.4f 不符' % (nm, sl, slE)
        assert abs(F - FE) < 0.15, '%s F=%.2f 与 Methods 表 %.1f 不符' % (nm, F, FE)
        print('%s n=%d slope=%+.4f±%.4f F=%.1f p=%.1e  (台账 %+.4f±%.4f, F=%.1f)'
              % (nm, len(x), sl, se, F, p, slE, seE, FE))

        # 四分位分箱中位数
        edges = np.quantile(x, [0, .25, .5, .75, 1])
        bx, by, be = [], [], []
        for i in range(4):
            m = (x >= edges[i]) & (x <= edges[i + 1]) if i == 3 else (x >= edges[i]) & (x < edges[i + 1])
            if m.sum() < 5:
                continue
            bx.append(np.median(x[m])); by.append(np.median(y[m]))
            be.append(y[m].std(ddof=1) / np.sqrt(m.sum()))
        ax.errorbar(bx, by, yerr=be, fmt='o', ms=5, color='#1f4fd8', ecolor='#1f4fd8',
                    elinewidth=0.9, capsize=2.4, label='binned median', zorder=4)
        xs = np.linspace(x.min(), x.max(), 50)
        ax.plot(xs, sl * xs + (y.mean() - sl * x.mean()), c='C3', lw=1.6,
                label=u'linear fit: slope %+.2f \u00b1 %.2f' % (sl, se), zorder=3)
        ax.axhline(y.mean(), c='0.45', ls='--', lw=1.1, label='constant plateau', zorder=2)
        ax.set_xlabel(u'Ro (plateau region, Ro \u2264 %.3f)' % BP, fontsize=9.5)
        ax.set_ylabel(u"log R'$_{\\rm H\\alpha}$", fontsize=9.5)
        ax.set_title(u'%s: N=%d' % (nm, len(x)), fontsize=10)
        ax.tick_params(direction='in', top=True, right=True, labelsize=8.5)
        ax.grid(alpha=0.22, lw=0.4)
        ax.legend(fontsize=7.6, loc='lower right', frameon=True, framealpha=0.9)

    xa = np.log10(plat.Ro30.values); ya = np.log10(plat.RHa.values)
    sla, sea, Fa, pa, r0a, r1a = fit(xa, ya)
    print('全体 n=%d slope=%+.4f±%.4f F=%.2f p=%.2f' % (len(xa), sla, sea, Fa, pa))
    assert len(xa) == 2360 and abs(sla - 0.0015) < 5e-4

    foot = ('M0\u2013M3: slope +%.2f \u00b1 %.2f (F-test vs. constant, p = 5\u00d710$^{-12}$);  '
            'M4\u2013M6: slope \u2212%.2f \u00b1 %.2f (p = 3\u00d710$^{-7}$).\n'
            'The full sample is flat only because the two opposite tilts cancel (slope %+.4f \u00b1 %.3f, N = %d, '
            u'including the 8 dM7\u2013dM8 stars inside the plateau \u2014 all of them dM7, which fall outside the two panels).' % (0.35, 0.05, 0.20, 0.04, sla, sea, len(xa)))
    fig.text(0.5, 0.012, foot, ha='center', va='bottom', fontsize=6.6, color='0.3', linespacing=1.7)
    fig.tight_layout(rect=(0, 0.07, 1, 1))
    fig.savefig(OUT, dpi=200); plt.close(fig)
    print('已出图 -> %s' % OUT)


if __name__ == '__main__':
    main()
