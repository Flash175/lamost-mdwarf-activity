# -*- coding: utf-8 -*-
"""s568：检查 dM 星表里的 logg/teff 哨兵值（-9999），并核对此前「22/68 logg<3.5」的说法。"""
import io, sys
import numpy as np, pandas as pd
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
from astropy.coordinates import SkyCoord
import astropy.units as un

cat = pd.read_csv('data/lamost/dr13/dr13_mstellar_dM.csv', low_memory=False,
                  usecols=['uid','subclass','class','teff','logg','ewha','ewha_err','snrr','ra','dec',
                           'gaia_source_id','gaia_g_mean_mag'])
print('总行数 %d；class 唯一值 %s' % (len(cat), cat['class'].unique()[:5]))
print('logg == -9999 的条数: %d (%.2f%%)' % ((cat.logg == -9999).sum(), 100*(cat.logg == -9999).mean()))
print('teff == -9999 的条数: %d (%.2f%%)' % ((cat.teff == -9999).sum(), 100*(cat.teff == -9999).mean()))
valid = cat[(cat.logg > 0) & (cat.teff > 0)]
print('去掉哨兵后 %d 条；logg 分位 %s' % (len(valid),
      {q: round(float(valid.logg.quantile(q)), 2) for q in [0.01, 0.5, 0.99]}))
print('真实 logg < 3.5 的条数: %d (%.3f%%)' % ((valid.logg < 3.5).sum(), 100*(valid.logg < 3.5).mean()))

# 2D 与 6D 的 >400 pc 档
cat2 = cat[(cat.ewha > -20) & (cat.ewha <= 50) & (cat.ewha_err > 0) & (cat.ewha_err <= 5)].copy()
cat2['active'] = (cat2.ewha >= 0.75) & (cat2.ewha > 3*cat2.ewha_err)
cat2['gaia_source_id'] = pd.to_numeric(cat2.gaia_source_id, errors='coerce')
g = pd.read_csv('data/gaia/gaia_dr3_mstars.csv', low_memory=False,
                usecols=['source_id','parallax','parallax_error','pmra','pmdec','radial_velocity','ruwe'])
m = cat2.merge(g, left_on='gaia_source_id', right_on='source_id', how='inner')
m = m[(m.parallax > 0.2) & (m.parallax/m.parallax_error > 5) & (m.ruwe < 1.4)].copy()
m['rv'] = m.radial_velocity
u = m.sort_values('ewha', ascending=False).drop_duplicates('uid').copy()
d = 1000.0/u.parallax.values
sc = SkyCoord(ra=u.ra.values*un.deg, dec=u.dec.values*un.deg, distance=d*un.pc, frame='icrs')
u['absz'] = np.abs(d*np.sin(np.deg2rad(sc.galactic.b.deg)))
u = u[u.absz <= 3000].copy()
far = u[u.absz > 400]
print('\n=== 2D 档 |>400 pc| ===')
print('  n=%d，活动 %d' % (len(far), far.active.sum()))
print('  logg == -9999 : %d' % int((far.logg == -9999).sum()))
print('  0<logg<3.5   : %d' % int(((far.logg > 0) & (far.logg < 3.5)).sum()))
print('  logg>=3.5    : %d' % int((far.logg >= 3.5).sum()))
print('  活动星里 logg==-9999: %d / %d' % (int((far[far.active].logg == -9999).sum()), int(far.active.sum())))

six = u[np.isfinite(u.rv) & (np.abs(u.rv) < 500)].copy()
c6 = SkyCoord(ra=six.ra.values*un.deg, dec=six.dec.values*un.deg,
              distance=(1000.0/six.parallax.values)*un.pc,
              pm_ra_cosdec=six.pmra.values*un.mas/un.yr, pm_dec=six.pmdec.values*un.mas/un.yr,
              radial_velocity=six.rv.values*un.km/un.s, frame='icrs')
gc = c6.transform_to('galactocentric')
six = six.assign(vx=gc.velocity.d_x.to(un.km/un.s).value, vy=gc.velocity.d_y.to(un.km/un.s).value,
                 vz=gc.velocity.d_z.to(un.km/un.s).value, zgc=np.abs(gc.z.to(un.kpc).value)*1000)
six = six[six.zgc <= 3000]
f6 = six[six.zgc > 400]
print('\n=== 6D 档 |z_gc|>400 pc| ===')
print('  n=%d，活动 %d' % (len(f6), f6.active.sum()))
print('  logg == -9999 : %d（活动里 %d）' % (int((f6.logg == -9999).sum()), int((f6[f6.active].logg == -9999).sum())))
print('  0<logg<3.5   : %d（活动里 %d）' % (int(((f6.logg > 0) & (f6.logg < 3.5)).sum()), int((f6[f6.active].logg > 0).sum() and ((f6[f6.active].logg > 0) & (f6[f6.active].logg < 3.5)).sum())))
print('  logg>=3.5    : %d' % int((f6.logg >= 3.5).sum()))
print('  活动星 teff==-9999: %d' % int((f6[f6.active].teff == -9999).sum()))
print('s568 完成')
