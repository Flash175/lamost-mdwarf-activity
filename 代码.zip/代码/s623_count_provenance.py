
import pandas as pd, numpy as np
P = r'C:\Users\lingz\OneDrive\Desktop\复现老师工作\data\lamost\dr13\dr13_mstellar_dM.csv'
cols = ['uid','designation','subclass','ewha','ewha_err','teff','logg','gaia_source_id','gaia_g_mean_mag']
d = pd.read_csv(P, usecols=cols, low_memory=False)
print('rows', len(d), '| uid', d.uid.nunique(), '| designation', d.designation.nunique())
print('subclass top:'); print(d.subclass.value_counts().head(12).to_string())
print('\nfinite teff:', int(d.teff.notna().sum()), '| finite logg:', int(d.logg.notna().sum()))
ew = d[(d.ewha>-20)&(d.ewha<=50)&(d.ewha_err>0)&(d.ewha_err<=5)]
print('EW gate: spectra', len(ew), '| uid', ew.uid.nunique(), '| designation', ew.designation.nunique())
for name, s in [('EW gate', ew)]:
    print('  %-22s finite teff %d | teff+logg %d' % (name, s.teff.notna().sum(), (s.teff.notna()&s.logg.notna()).sum()))
# candidates for 958,988 spectra / 785,152 stars
cands = {
 'all rows': d,
 'EW gate': ew,
 'finite teff': d[d.teff.notna()],
 'finite teff & logg': d[d.teff.notna() & d.logg.notna()],
 'EW gate & finite teff': ew[ew.teff.notna()],
 'EW gate & finite teff & logg': ew[ew.teff.notna() & ew.logg.notna()],
 'logg>=3.5': d[d.logg>=3.5],
 'logg>=4.0': d[d.logg>=4.0],
 'EW gate & logg>=4.0': ew[ew.logg>=4.0],
}
print('\n%-32s %10s %10s %10s' % ('selection','spectra','uid','designation'))
for k, s in cands.items():
    print('%-32s %10d %10d %10d' % (k, len(s), s.uid.nunique(), s.designation.nunique()))
