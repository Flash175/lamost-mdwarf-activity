# -*- coding: utf-8 -*-
"""s577: 压线带（EW 在阈值附近）占多少？误杀对活动比例的影响上限。
用目录 EW 全局分布估计「压线带」比例，再乘 s575/s576 的通过率得到偏差上限。"""
import io, sys, os
import numpy as np, pandas as pd
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
OUT = r'C:\Users\lingz\Desktop\复现老师工作\APJS\多个图及讨论'
cat = pd.read_csv('data/lamost/dr13/dr13_mstellar_dM.csv', low_memory=False,
                  usecols=['ewha','ewha_err','snrr'])
cat = cat[(cat.ewha > -20) & (cat.ewha <= 50) & (cat.ewha_err > 0) & (cat.ewha_err <= 5) & (cat.snrr > 0)]
n = len(cat)
print('样本 %d 条' % n)
bands = [(0.5,0.6),(0.6,0.7),(0.7,0.8),(0.8,0.9),(0.9,1.0),(1.0,1.2)]
rows=[]
for a,b in bands:
    m = ((cat.ewha>=a)&(cat.ewha<b)).sum()
    rows.append(dict(band='%.1f-%.1f' % (a,b), n=int(m), pct=100*m/n))
    print('  EW %.1f-%.1f A : %7d 条  %5.2f%%' % (a,b,m,100*m/n))
T = pd.DataFrame(rows)
T.to_csv(os.path.join(OUT,'ew_threshold_band.csv'), index=False, encoding='utf-8')
txt = open(os.path.join(OUT,'ew_threshold_band.csv'), encoding='utf-8').read()
open(os.path.join(OUT,'ew_threshold_band.csv'),'w',encoding='utf-8-sig').write(
    '# 目录 EW(Ha) 在阈值 0.75 A 附近的分布：用于估计「压线带」比例\n'
    '# 样本：dr13_mstellar_dM.csv 通过 EW 闸门的 %d 条谱（未加 |Z| 筛选）\n'
    '# 生成脚本：代码/s577_threshold_band.py\n' % n + txt)
band = ((cat.ewha>=0.5)&(cat.ewha<1.0)).sum()/n
near = ((cat.ewha>=0.65)&(cat.ewha<0.85)).sum()/n
print('\n0.5-1.0 A 带：%.2f%%（§4 的「半数误杀」最多影响 %.2f pp）' % (100*band, 100*band*0.5))
print('0.65-0.85 A 带：%.2f%%（最多影响 %.2f pp）' % (100*near, 100*near*0.5))
print('对照：100-200 pc 与 <100 pc 的活动比例差 10.9 pp；200-400 pc 与 <100 pc 差 16.0 pp')
