# -*- coding: utf-8 -*-
"""s600：用 LAMOST 管线 RV 重建 6D 样本，重做「活动星是否更冷」的分片比较

样本：2D 样本 ∩ (LAMOST z 有效, σ_rv = c·z_err < 20 km/s, |RV| < 500 km/s)
速度：astropy 标准 Galactocentric 变换取垂直分量 v_z
统计：25 pc 细片，活动/非活动各算 σ(vz)（std 与 MAD 两套估计量），给 Δσ 与显著性
输出：多个图及讨论/kinematics_lamost_byslice.csv
"""
import io, sys, os
import numpy as np, pandas as pd
from astropy.coordinates import SkyCoord, Galactocentric
import astropy.units as un

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
BASE = r'C:\Users\lingz\OneDrive\Desktop\复现老师工作'
OUT = r'C:\Users\lingz\Desktop\复现老师工作\APJS\多个图及讨论'
C_KMS = 299792.458

cat = pd.read_csv(os.path.join(BASE,'data','lamost','dr13','dr13_mstellar_dM.csv'), low_memory=False,
                  usecols=['obsid','uid','subclass','ewha','ewha_err','snrr','z','z_err',
                           'ra','dec','gaia_source_id','gaia_g_mean_mag'])
cat = cat[(cat.ewha > -20) & (cat.ewha <= 50) & (cat.ewha_err > 0) & (cat.ewha_err <= 5)].copy()
cat['active'] = (cat.ewha >= 0.75) & (cat.ewha > 3*cat.ewha_err)
cat['gaia_source_id'] = pd.to_numeric(cat.gaia_source_id, errors='coerce')
g = pd.read_csv(os.path.join(BASE,'data','gaia','gaia_dr3_mstars.csv'), low_memory=False,
                usecols=['source_id','parallax','parallax_error','pmra','pmdec','ruwe'])
m = cat.merge(g, left_on='gaia_source_id', right_on='source_id', how='inner')
m = m[(m.parallax > 0.2) & (m.parallax/m.parallax_error > 5) & (m.ruwe < 1.4)].copy()
u = m.sort_values('ewha', ascending=False).drop_duplicates('uid').copy()
u['MG'] = u.gaia_g_mean_mag.values - 5*np.log10(np.clip(1000.0/u.parallax.values, 1, None)) + 5
u = u[u.MG >= 6].copy()
u['rv'] = C_KMS*u.z
u['sig_rv'] = C_KMS*u.z_err.abs()
u = u[(u.z != 0) & (u.z_err > 0) & np.isfinite(u.rv) & (u.sig_rv < 20) & (u.rv.abs() < 500)].copy()
print('LAMOST-RV 样本：%d 颗（σ_rv<20、|RV|<500）' % len(u))

d_pc = 1000.0/u.parallax.values
sc = SkyCoord(ra=u.ra.values*un.deg, dec=u.dec.values*un.deg,
              distance=(d_pc/1000.0)*un.kpc,
              pm_ra_cosdec=u.pmra.values*un.mas/un.yr,
              pm_dec=u.pmdec.values*un.mas/un.yr,
              radial_velocity=u.rv.values*un.km/un.s, frame='icrs')
gc = sc.transform_to(Galactocentric())
u['absz'] = np.abs(d_pc*np.sin(np.deg2rad(sc.galactic.b.deg)))
u['vz'] = gc.velocity.d_z.to(un.km/un.s).value
u = u[np.isfinite(u.vz)].copy()
print('变换成功 %d 颗；vz 中位 %.1f km/s，稳健散布 %.1f km/s'
      % (len(u), np.median(u.vz), 1.4826*np.median(np.abs(u.vz - np.median(u.vz)))))

def stats(v):
    n = len(v)
    if n < 30: return np.nan, np.nan, np.nan
    s = np.std(v, ddof=1)
    mad = 1.4826*np.median(np.abs(v - np.median(v)))
    return s, mad, np.sqrt(2.0/(n-1))*s

rows = []
edges = list(range(0, 601, 25))
for lo in edges:
    hi = lo + 25
    s = u[(u.absz >= lo) & (u.absz < hi)]
    a = s[s.active]; i = s[~s.active]
    if len(a) < 50 or len(i) < 50: continue
    sa, ma, sea = stats(a.vz.values); si, mi, sei = stats(i.vz.values)
    d_std = sa - si; se_std = np.sqrt(sea**2 + sei**2)
    d_mad = ma - mi; se_mad = 1.16*np.sqrt((ma**2/(2*(len(a)-1))) + (mi**2/(2*(len(i)-1))))
    rows.append(dict(z_lo=lo, z_hi=hi, n=len(s), n_act=len(a), n_inact=len(i),
                     sig_std_act=sa, sig_std_inact=si, d_std=d_std, sig_d_std=d_std/se_std if se_std else np.nan,
                     sig_mad_act=ma, sig_mad_inact=mi, d_mad=d_mad, sig_d_mad=d_mad/se_mad if se_mad else np.nan))
T = pd.DataFrame(rows)
print('\n分片结果（25 pc，仅列 n_act/n_inact ≥ 50 的片）：')
print(T[['z_lo','n','n_act','n_inact','d_std','sig_d_std','d_mad','sig_d_mad']]
      .to_string(index=False, float_format=lambda x: '%.2f' % x))
both_neg = T[(T.d_std < 0) & (T.d_mad < 0) & (T.sig_d_std.abs() > 3) & (T.sig_d_mad.abs() > 3)]
print('\n两种估计量一致为负且均 >3σ 的片：%d 个' % len(both_neg))
if len(both_neg):
    print('  |Z| 范围：%d–%d pc；Δσ_std 从 %.2f 到 %.2f km/s；Δσ_MAD 从 %.2f 到 %.2f'
          % (both_neg.z_lo.min(), both_neg.z_hi.max(), both_neg.d_std.min(), both_neg.d_std.max(),
             both_neg.d_mad.min(), both_neg.d_mad.max()))
fp = os.path.join(OUT, 'kinematics_lamost_byslice.csv')
T.to_csv(fp, index=False, encoding='utf-8')
txt = open(fp, encoding='utf-8').read()
hdr = ('# s600：用 LAMOST 管线 RV（σ_rv<20、|RV|<500）重建 6D 样本后，活动 vs 非活动的 σ(vz) 差分（25 pc 细片）\n'
       '# d_std / d_mad = σ_act − σ_inact（负值表示活动星更冷）；sig_d_* 为对应显著性\n'
       '# vz 取 astropy 标准 Galactocentric 的 d_z 分量；生成脚本：代码/s600_kinematics_lamost_rv.py\n')
open(fp, 'w', encoding='utf-8-sig').write(hdr + txt)
print('\n写出 kinematics_lamost_byslice.csv（%d 行）' % len(T))
