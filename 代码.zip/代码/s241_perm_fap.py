# -*- coding: utf-8 -*-
"""对关键星做置换 bootstrap FAP（破坏时间结构），核对解析 FAP 是否过松"""
import io, os, re, sys
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
import numpy as np, pandas as pd
from scipy.signal import lombscargle
SRC = 'data/raw/ib2025/tableb1_time_series.dat'
rows = []
for line in open(SRC, encoding='utf-8', errors='replace'):
    if len(line.strip()) < 10: continue
    m = re.match(r'^(.{10})(\s*\d+\.?\d*)\s+(.*)$', line.rstrip('\n'))
    if not m: continue
    try: rows.append((m.group(1).strip(), float(m.group(2)), float(m.group(3).strip().split()[-1])))
    except Exception: pass
t = pd.DataFrame(rows, columns=['star','hjd','val'])
FREQ = np.linspace(1/25.0, 1/2.0, 12000)
W = 2*np.pi*FREQ
def peak_power(x, y):
    y = y - y.mean()
    p = lombscargle(x, y, W, normalize=True)
    i = int(np.argmax(p))
    return float(p[i]), 1/FREQ[i]
TARGETS = ['GJ 205', 'GJ 699', 'GJ 876', 'GJ 674', 'GJ 79', 'GJ 273']
res = []
rng = np.random.default_rng(20261021)
for star in TARGETS:
    g = t[t.star == star].sort_values('hjd')
    x = (g.hjd.values - g.hjd.min())/365.25; y = g.val.values
    if len(x) < 15: continue
    pk, P = peak_power(x, y)
    nperm = 1000
    null = np.empty(nperm)
    for k in range(nperm):
        null[k] = peak_power(x, rng.permutation(y))[0]
    bfap = float((null >= pk).mean())
    res.append(dict(star=star, N=len(x), baseline_yr=round(float(x.max()), 1), P_yr=round(P, 3),
                    power=round(pk, 4), perm_FAP=bfap, nperm=nperm))
    print('   %-8s N=%3d base=%4.1f yr  P=%.2f yr  power=%.3f  置换 FAP=%.4f' % (star, len(x), x.max(), P, pk, bfap))
R = pd.DataFrame(res)
R.to_csv('data/processed/dr13/ib2025_permutation_fap.csv', index=False)
print('\n判定（IB2025 门槛 bootstrap FAP<=0.001 且 P<=base/2）：')
R['pass'] = (R.perm_FAP <= 0.001) & (R.P_yr <= R.baseline_yr/2)
print(R.to_string(index=False))
