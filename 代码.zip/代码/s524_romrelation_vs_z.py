
# -*- coding: utf-8 -*-
"""把 |Z| 接到 3,340 颗样本上，检验 Ro–活动关系是否随银盘高度变化。"""
import io, sys
import numpy as np, pandas as pd
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
from astropy.coordinates import SkyCoord
import astropy.units as un

P5 = 'repro/_zipcheck/图五及相关数据/数据'
A = pd.read_csv(P5 + '/图5_逐星样本_严格3340行_⑤_tau030.csv')
cat = pd.read_csv('data/lamost/dr13/dr13_mstellar_dM.csv', low_memory=False,
                  usecols=['designation','ra','dec','gaia_source_id'])
cat = cat.drop_duplicates('designation')
S = A.merge(cat, on='designation', how='left')
print('⑤ 表 %d 颗，匹配到坐标 %d 颗' % (len(A), S.ra.notna().sum()))
g = pd.read_csv('data/gaia/gaia_dr3_mstars.csv', low_memory=False,
                usecols=['source_id','parallax','parallax_error','ruwe']).rename(columns={'ruwe':'ruwe_gaia'})
S['gaia_source_id'] = pd.to_numeric(S.gaia_source_id, errors='coerce')
M = S.merge(g, left_on='gaia_source_id', right_on='source_id', how='left')
M = M[(M.parallax > 0.2) & (M.parallax/M.parallax_error > 5) & (M.ruwe_gaia < 1.4)].copy()
print('视差>0.2mas 且 >5σ、ruwe<1.4 后 %d 颗' % len(M))
c = SkyCoord(ra=M.ra.values*un.deg, dec=M.dec.values*un.deg,
             distance=(1000.0/M.parallax.values)*un.pc, frame='icrs')
M['z_pc'] = c.transform_to('galactocentric').z.to(un.kpc).value*1000
M['absz'] = np.abs(M.z_pc)
M['x'] = np.log10(M.Ro); M['y'] = np.log10(M.RHa)
EARLY = ['dM0','dM1','dM2','dM3']; LATE = ['dM4','dM5','dM6']
BP = 0.132; SEED = 20261023

def beta(x, y, bp=BP):
    u = x > np.log10(bp)
    return np.polyfit(x[u], y[u], 1)[0] if u.sum() >= 20 else np.nan

def boot(d, nb=2000):
    rng = np.random.default_rng(SEED); out = np.empty(nb); n = len(d)
    x, y = d.x.values, d.y.values
    for k in range(nb):
        i = rng.integers(0, n, n); out[k] = beta(x[i], y[i])
    return np.nanstd(out)

med = M.absz.median()
print('\n|Z| 中位 = %.0f pc；分层结果（固定断点 0.132）：' % med)
for nm, sel in (('低 |Z| 半', M.absz <= med), ('高 |Z| 半', M.absz > med)):
    d = M[sel]
    e, l = d[d.spt.isin(EARLY)], d[d.spt.isin(LATE)]
    be, bl = beta(e.x.values, e.y.values), beta(l.x.values, l.y.values)
    print('  %-10s n=%4d (\|Z\| 中位 %.0f pc)  β(全) = %+.3f ± %.3f' % (nm, len(d), d.absz.median(), beta(d.x.values, d.y.values), boot(d)))
    print('             M0–M3 %+.3f (n=%d) | M4–M6 %+.3f (n=%d) | Δβ = %+.3f' % (be, len(e), bl, len(l), bl-be))

print('\nΔβ 的 bootstrap 误差（每半各 2,000 次）：')
rng0 = np.random.default_rng(SEED)
for nm, sel in (('低 |Z| 半', M.absz <= med), ('高 |Z| 半', M.absz > med)):
    d = M[sel]; e, l = d[d.spt.isin(EARLY)], d[d.spt.isin(LATE)]
    rng = np.random.default_rng(SEED + 1)
    de = np.empty(2000); dl = np.empty(2000)
    for k in range(2000):
        ie = rng.integers(0, len(e), len(e)); il = rng.integers(0, len(l), len(l))
        de[k] = beta(e.x.values[ie], e.y.values[ie]); dl[k] = beta(l.x.values[il], l.y.values[il])
    db = dl - de
    print('  %-10s Δβ = %+.3f ± %.3f （%.2fσ）  [n_late=%d]'
          % (nm, np.nanmean(db), np.nanstd(db), abs(np.nanmean(db))/np.nanstd(db), len(l)))
