
# -*- coding: utf-8 -*-
"""重绘图 1（200–400 pc 起用空心/断线）与图 2（图例写清 3×σ(EW) ≤ 0.75 Å）。"""
import io, os, sys
import numpy as np, pandas as pd
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
OUT = r'C:\Users\lingz\Desktop\复现老师工作\APJS\多个图及讨论'
T1 = pd.read_csv(os.path.join(OUT,'新图_活动率与运动学_按Z分箱.csv'), comment='#')
lab = ['<100','100-200','200-400','>400']; x = np.arange(len(lab))
rel = T1.n.values >= 1000            # 只把 <100/100-200/200-400 视为可用
fig, ax = plt.subplots(1, 2, figsize=(11, 4.2))
for xi in range(len(lab)):
    ax[0].bar(xi, T1.active_frac_pct[xi], color='#c0392b' if rel[xi] else '#bdc3c7',
              alpha=.9 if rel[xi] else .7, hatch='' if rel[xi] else '//')
    ax[0].text(xi, T1.active_frac_pct[xi]+0.4, '%.1f%%\nn=%d' % (T1.active_frac_pct[xi], T1.n[xi]),
               ha='center', fontsize=7)
ax[0].set_xticks(x); ax[0].set_xticklabels(lab); ax[0].set_xlabel('|Z|  (pc)')
ax[0].set_ylabel('Active fraction (%)'); ax[0].set_ylim(0, max(T1.active_frac_pct)*1.3)
ax[0].set_title('Active fraction vs Galactic height (LAMOST DR13)')
# 右图：仅在可用档连线；200–400 与 >400 用空心、虚线不连
ax[1].plot(x[:3], T1.svz_act[:3], 'o-', color='#c0392b', label='active')
ax[1].plot(x[:3], T1.svz_inact[:3], 's-', color='#2c3e50', label='inactive')
ax[1].plot(x[2], T1.svz_act[2], 'o', mfc='none', mec='#c0392b', ms=10, mew=2,
           label='active (n=512, unreliable)')
ax[1].plot(x[3], T1.svz_act[3], 'o', mfc='none', mec='#c0392b', ms=8)
ax[1].plot(x[3], T1.svz_inact[3], 's', mfc='none', mec='#2c3e50', ms=8)
ax[1].set_xticks(x); ax[1].set_xticklabels(lab); ax[1].set_xlabel('|Z|  (pc)')
ax[1].set_ylabel('sigma(vz)  (km/s)'); ax[1].set_title('Kinematic heating: sigma(vz) vs |Z|')
ax[1].legend(fontsize=7)
plt.tight_layout(); plt.savefig(os.path.join(OUT,'新图1_活动率与运动学随银盘高度.png'), dpi=200); plt.close()

# 图 2：图例改清楚
T2 = pd.read_csv(os.path.join(OUT,'新图_活动率与亚型_SN匹配.csv'), comment='#')
xs = np.arange(len(T2)); w = 0.27
fig, ax = plt.subplots(figsize=(7.6, 4.6))
ax.bar(xs-w, T2.frac_all_pct, w, label='all spectra', color='#7f8c8d')
ax.bar(xs,   T2.frac_sn36_pct, w, label='S/N 3-6 (matched)', color='#c0392b')
ax.bar(xs+w, T2.frac_sn612_pct, w, label='S/N 6-12 (matched)', color='#2980b9')
ax.plot(xs, T2.detectable_pct, 'k^--', ms=5, lw=1,
        label='detectable: 3 x sigma(EW) <= 0.75 A')
ax.set_xticks(xs); ax.set_xticklabels(T2.subtype)
ax.set_xlabel('Spectral subtype'); ax.set_ylabel('Active fraction (%)')
ax.set_title('Cool-end decline is a detection effect'); ax.legend(fontsize=8)
plt.tight_layout(); plt.savefig(os.path.join(OUT,'新图2_活动率与亚型_SN匹配.png'), dpi=200); plt.close()
print('图 1、图 2 已重绘')
