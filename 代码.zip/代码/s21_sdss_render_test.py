# -*- coding: utf-8 -*-
"""SDSS 板渲染对照实验：找出能复现论文 Fig2 右板外观的绘制方式。
论文右板实测：整体红色像素仅 4.9%，赤道带是一条实心红带，北天大块偏蓝。"""
import io, os, sys
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from PIL import Image
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

sdss = pd.read_csv("data/vizier/aj141_97_sdss_dwarfs.csv", low_memory=False)
ra = sdss["RAJ2000"].to_numpy(float); de = sdss["DEJ2000"].to_numpy(float)
w = pd.to_numeric(sdss["W(Ha)"], errors="coerce").to_numpy(float)
act = (w >= 0.75)
print(f"SDSS 行 {len(sdss):,} 活动 {int(act.sum()):,} ({100*act.mean():.1f}%)", flush=True)

RA_C, FIGW, DPI = 180.0, 6.8, 170        # 与 figures/paperA_fig2 同尺寸
os.makedirs("figures/_tmp", exist_ok=True)

def render(tag, order, size, alpha=1.0, single=False):
    fig = plt.figure(figsize=(FIGW, 4.2))
    ax = fig.add_subplot(1, 1, 1, projection="mollweide")
    x = -np.radians(ra - RA_C); y = np.radians(de)
    if single:
        ax.scatter(x, y, s=size, c=np.where(act, "red", "blue"), alpha=alpha, lw=0)
    else:
        for who in order:
            m = act if who == "red" else ~act
            ax.scatter(x[m], y[m], s=size, c=who, alpha=alpha, lw=0)
    ax.grid(False); ax.set_xticklabels([])
    fig.subplots_adjust(left=0.02, right=0.98, top=0.96, bottom=0.04)
    p = f"figures/_tmp/sdss_{tag}.png"
    fig.savefig(p, dpi=DPI); plt.close(fig)

    a = np.asarray(Image.open(p).convert("RGB")).astype(int)
    H, W, _ = a.shape
    r, g, b = a[:, :, 0], a[:, :, 1], a[:, :, 2]
    colored = (a.max(2) - a.min(2) > 40) & (a.min(2) < 235)
    red = colored & (r > b + 20)
    # 区域：赤道带（图中心附近 ±2° → |y| 小）与北天大块
    yy = np.linspace(0, 1, H)[:, None] * np.ones((1, W))
    band = colored & (np.abs(np.arange(H)[:, None] - H * 0.5) < H * 0.02)
    def sub(m):
        c = int((colored & m).sum()); rr = int((red & m).sum())
        return f"{rr:,}/{c:,}={100*rr/max(c,1):.1f}%"
    print(f"{tag:22s} 整体红 {sub(np.ones_like(colored, bool)):22s}", flush=True)
    return p

cases = [
    ("blue_then_red_s2.6", ["blue", "red"], 2.6, 0.9, False),
    ("red_then_blue_s2.6", ["red", "blue"], 2.6, 0.9, False),
    ("blue_then_red_s1.0", ["blue", "red"], 1.0, 1.0, False),
    ("red_then_blue_s1.0", ["red", "blue"], 1.0, 1.0, False),
    ("single_file_order", [], 2.6, 0.9, True),
    ("blue_then_red_s6",   ["blue", "red"], 6.0, 0.9, False),
]
paths = {}
for tag, order, size, al, single in cases:
    paths[tag] = render(tag, order, size, al, single)
print("临时图:", " ".join(paths.values()))
