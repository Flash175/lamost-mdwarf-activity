# -*- coding: utf-8 -*-
"""开工探测：能用的外部周期源（VizieR ZTF / ASAS-SN）、已装包、网络可达性"""
import io, sys, json, time
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
for mod in ('lightkurve', 'astropy', 'astroquery', 'requests'):
    try:
        m = __import__(mod); print('  已安装 %-12s %s' % (mod, getattr(m, '__version__', '?')))
    except Exception as e:
        print('  未安装 %-12s (%s)' % (mod, type(e).__name__))
import requests
TAP = 'https://tapvizier.cds.unistra.fr/TAPVizieR/tap/sync'
H = {'User-Agent': 'repro-mstars/1.0'}
# 1) 可达性 + 目录元信息
q0 = "SELECT TOP 3 table_name FROM TAP_SCHEMA.tables WHERE table_name LIKE '%249/18%'"
try:
    r = requests.post(TAP, data={'REQUEST': 'doQuery', 'LANG': 'ADQL', 'FORMAT': 'csv', 'QUERY': q0}, timeout=60, headers=H)
    print('  VizieR TAP 状态 %s，返回前 200 字节：%r' % (r.status_code, r.text[:200]))
except Exception as e:
    print('  VizieR TAP 不可达：%s' % type(e).__name__)
# 2) 试 ZTF 周期表对 GJ 876（22:53:16.7 -14:15:49）做 60" 锥形搜索
q1 = ("SELECT TOP 5 * FROM \"J/ApJS/249/18/table2\" "
      "WHERE 1=CONTAINS(POINT('ICRS',RAJ2000,DEJ2000),CIRCLE('ICRS',343.319,-14.264,0.0167))")
try:
    r = requests.post(TAP, data={'REQUEST': 'doQuery', 'LANG': 'ADQL', 'FORMAT': 'csv', 'QUERY': q1}, timeout=90, headers=H)
    print('  ZTF 锥形查询状态 %s，行数 %d' % (r.status_code, max(0, len(r.text.strip().splitlines())-1)))
    print('  ' + '\n  '.join(r.text.strip().splitlines()[:4]))
except Exception as e:
    print('  ZTF 查询失败：%s' % type(e).__name__)
