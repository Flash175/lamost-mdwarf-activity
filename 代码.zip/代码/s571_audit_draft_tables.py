# -*- coding: utf-8 -*-
"""s571：把中文稿里的表格数字与交付 CSV 逐格对比，报告不一致。"""
import io, sys, os, re
import numpy as np, pandas as pd
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
OUT = r'C:\Users\lingz\Desktop\复现老师工作\APJS\多个图及讨论'
DRAFT = os.path.join(OUT, '新一节_银盘示踪_中文草稿.md')
text = open(DRAFT, encoding='utf-8').read()
lines = text.split('\n')

def num(s):
    s = s.replace('**','').replace('%','').replace(',','').replace('×','').strip()
    s = s.replace('−','-').replace('–','-').replace('—','-')
    m = re.search(r'-?\d+(?:\.\d+)?', s)
    return float(m.group()) if m else None

def table_after(key, maxrows=40):
    for i, l in enumerate(lines):
        if key in l:
            rows = []
            for j in range(i+2, min(i+2+maxrows, len(lines))):
                if not lines[j].startswith('|'):
                    break
                rows.append([x.strip() for x in lines[j].strip().strip('|').split('|')])
            return rows
    return []

issues = []
def cmp(tag, label, a, b, tol, unit=''):
    if a is None or b is None: issues.append('%s | %s | 缺值 a=%s b=%s' % (tag, label, a, b)); return
    if abs(a-b) > tol: issues.append('%s | %s | 草案 %.3f%s vs CSV %.3f%s' % (tag, label, a, unit, b, unit))

# ---------- §1 主表 ----------
A = pd.read_csv(os.path.join(OUT,'far400_2d_audit.csv'), comment='#').set_index('zbin')
rows = table_after('| 星数 | 活动星数 |')
labels = ['<100','100-200','200-400','400-600','600-1000','>1000']
print('§1 主表行数', len(rows))
for r, lb in zip(rows, labels):
    if lb not in A.index: continue
    q = A.loc[lb]
    cmp('§1主表', lb+' n', num(r[1]), float(q['n']), 0.5)
    cmp('§1主表', lb+' n_act', num(r[2]), float(q['n_act']), 0.5)
    cmp('§1主表', lb+' frac', num(r[3]), float(q['frac']), 0.02)
    w = r[4].replace('**','').split('–')
    cmp('§1主表', lb+' lo', num(w[0]), float(q['lo']), 0.02)
    cmp('§1主表', lb+' hi', num(w[1]), float(q['hi']), 0.02)
    cmp('§1主表', lb+' |Z|med', num(r[5]), float(q['absz_med']), 1.0)
    cmp('§1主表', lb+' dM0%', num(r[6]), float(q['dm0_share']), 0.1)

# ---------- §1 分层表 ----------
S = pd.read_csv(os.path.join(OUT,'far400_subtype_table.csv'), comment='#')
R = pd.read_csv(os.path.join(OUT,'subtype_decline_ratio.csv'), comment='#').set_index('subtype')
rows = table_after('| 亚型 | < 100 pc | 100–200 pc | 200–400 pc | 降幅 |')
print('§1 分层表行数', len(rows))
for r in rows:
    sp = r[0]
    for k, binname in enumerate(['<100','100-200','200-400']):
        q = S[(S.subtype == sp) & (S.zbin == binname)]
        if len(q) == 0: continue
        cmp('§1分层', sp+' '+binname+' frac', num(r[1+k]), float(q.frac.iloc[0]), 0.05)
        cmp('§1分层', sp+' '+binname+' n', num(r[1+k].split('（')[1]) if '（' in r[1+k] else None,
            float(q.n.iloc[0]), 0.5)
    if sp in R.index:
        cmp('§1分层', sp+' ratio', num(r[4]), float(R.loc[sp,'ratio']), 0.02)

# ---------- §1 重加权表 ----------
W = pd.read_csv(os.path.join(OUT,'reweight_by_bin.csv'), comment='#').set_index('zbin')
rows = table_after('| 档 (pc) | n | 实测合并 |')
print('§1 重加权表行数', len(rows))
for r in rows:
    lb = r[0].replace(' ','')
    if lb not in W.index: continue
    q = W.loc[lb]
    cmp('§1重加权', lb+' n', num(r[1]), float(q.n), 0.5)
    cmp('§1重加权', lb+' 实测', num(r[2]), float(q.frac_raw), 0.02)
    cmp('§1重加权', lb+' 重加权', num(r[3]), float(q.frac_rw), 0.02)
    ci = r[4].split('–')
    cmp('§1重加权', lb+' ci_lo', num(ci[0]), float(q.rw_lo), 0.02)
    cmp('§1重加权', lb+' ci_hi', num(ci[1]), float(q.rw_hi), 0.02)
    cmp('§1重加权', lb+' kish', num(r[5]), float(q.kish_neff), 1.0)
    cmp('§1重加权', lb+' binom', num(r[6]), float(q.binom_neff), 1.0)

# ---------- §2 细片表 ----------
K = pd.read_csv(os.path.join(OUT,'kinematic_diff_errors.csv'), comment='#')
rows = table_after('| 细片 (pc) | n(活动/非活动) |')
print('§2 细片表行数', len(rows))
for r in rows:
    sl = r[0].replace(' ','')
    q = K[K.slice == sl]
    if len(q) == 0: continue
    q = q.iloc[0]
    ns = r[1].split('/')
    cmp('§2细片', sl+' n_act', num(ns[0]), float(q.n_act), 0.5)
    cmp('§2细片', sl+' n_inact', num(ns[1]), float(q.n_inact), 0.5)
    cmp('§2细片', sl+' d_std', num(r[2]), float(q.d_std), 0.02)
    cmp('§2细片', sl+' se_std', num(r[3]), float(q.se_std), 0.02)
    cmp('§2细片', sl+' d_mad', num(r[5]), float(q.d_mad), 0.02)
    cmp('§2细片', sl+' se_mad', num(r[6]), float(q.se_mad), 0.02)

# ---------- §3 冷端表 ----------
Cd = pd.read_csv(os.path.join(OUT,'coolend_sn_cuts_with_n.csv'), comment='#')
rows = table_after('| 亚型 | 星数 | 全样本活动率 | Wilson 95% |')
print('§3 冷端表行数', len(rows))
for r in rows:
    sp = r[0]
    q = Cd[(Cd.subtype == sp) & (Cd.cut == 'all')]
    if len(q) == 0: continue
    q = q.iloc[0]
    cmp('§3冷端', sp+' n', num(r[1]), float(q.n), 0.5)
    cmp('§3冷端', sp+' frac', num(r[2]), float(q.frac), 0.05)
    w = r[3].split('–')
    cmp('§3冷端', sp+' lo', num(w[0]), float(q.lo), 0.05)
    cmp('§3冷端', sp+' hi', num(w[1]), float(q.hi), 0.05)

# ---------- §9 K/M 表 ----------
KK = pd.read_csv(os.path.join(OUT,'新图3_K与M活动比例.csv'), comment='#')
rows = table_after('| 亚型 | 样本 | n（**条谱，未去重**） |')
print('§9 K/M 表行数', len(rows))
for r in rows:
    sp = r[0]
    q = KK[KK.spt == sp]
    if len(q) == 0: continue
    q = q.iloc[0]
    cmp('§9K/M', sp+' n', num(r[2]), float(q.n), 0.5)
    cmp('§9K/M', sp+' frac', num(r[3]), float(q.frac), 0.05)
    cmp('§9K/M', sp+' n_sn', num(r[4]), float(q.n_sn), 0.5)
    cmp('§9K/M', sp+' frac_sn', num(r[5]), float(q.frac_sn), 0.05)

# ---------- §11 Teff 表 ----------
T4 = pd.read_csv(os.path.join(OUT,'新图4_Teff轴_K与M_清理后.csv'), comment='#').set_index('teff_ctr')
rows = table_after('| Teff (K) | K 活动比例 | n(K，条谱) |')
print('§11 Teff 表行数', len(rows))
for r in rows:
    t = num(r[0])
    if t is None or int(t) not in T4.index: continue
    q = T4.loc[int(t)]
    if pd.notna(q.frac_K): cmp('§11Teff', '%d K frac_K' % t, num(r[1]), float(q.frac_K), 0.05)
    cmp('§11Teff', '%d n_K' % t, num(r[2]), float(q.n_K), 0.5)
    if pd.notna(q.frac_M): cmp('§11Teff', '%d frac_M' % t, num(r[3]), float(q.frac_M), 0.05)
    cmp('§11Teff', '%d n_M' % t, num(r[4]), float(q.n_M), 0.5)

# ---------- 附录 A.1 / A.3 ----------
H = pd.read_csv(os.path.join(OUT,'holdout_prediction.csv'), comment='#')
rows = table_after('| 档 (pc) | 外推预测 | 实测（Wilson 95%） |')
print('附录 A.1 行数', len(rows))
for r in rows:
    lb = r[0].replace(' ','')
    q = H[(H.kind == 'merged') & (H.zbin == lb)]
    if len(q) == 0: continue
    q = q.iloc[0]
    cmp('A.1', lb+' pred', num(r[1]), float(q.pred), 0.02)
    cmp('A.1', lb+' meas', num(r[2]), float(q.meas), 0.02)
    cmp('A.1', lb+' ratio', num(r[4]), float(q.ratio), 0.02)

G = pd.read_csv(os.path.join(OUT,'highsn_far_bins.csv'), comment='#').set_index('zbin')
rows = table_after('| 档 (pc) | 全样本重加权 | S/N ≥ 15 重加权 |')
print('附录 A.3 行数', len(rows))
for r in rows:
    lb = r[0].replace(' ','')
    if lb not in G.index: continue
    q = G.loc[lb]
    cmp('A.3', lb+' rw_all', num(r[1]), float(q.rw_all), 0.02)
    cmp('A.3', lb+' rw_hi', num(r[2]), float(q.rw_hi), 0.02)
    cmp('A.3', lb+' n_hi', num(r[2]), None, 0)  # placeholder

print('\n===== 不一致清单（%d 条）=====' % len(issues))
for s in issues[:60]: print('  ' + s)
if not issues: print('  无')
