# -*- coding: utf-8 -*-
"""
s228_diag_free_bp_and_plateau.py —— 两项诊断

1) 面板"自由断点"的两套数值之辨：RSS(bp) 剖面是否存在双极小（0.047 / 0.114），
   401 点网格上哪个是全局最优；bootstrap 断点分布的中位落在哪支。
2) 坪区（Ro<0.135）：三种成分（M0–M3 / M4–M6 / dM7–dM8）的 Simpson 精确分解，
   −0.30 与 −0.31 两种 τ 约定各算一次，判定 +0.0003 / +0.0030 分别属于哪套。
"""
import numpy as np, pandas as pd

D = "C:/Users/lingz/Desktop/APJS/图五及相关数据/数据/"
d5 = pd.read_csv(D + "图5_逐星样本_严格3340行_⑤.csv")
d5 = d5[(d5.RHa > 0) & (d5.P > 0) & (d5.M > 0)].copy()
d5["pan"] = np.where(d5.spt.isin(["dM0", "dM1", "dM2", "dM3"]), "M0M3",
             np.where(d5.spt.isin(["dM4", "dM5", "dM6"]), "M4M6", "late"))


def setro(d, c):
    d = d.copy()
    d["Ro"] = d.P / 10 ** (2.33 - 1.50 * d.M + c * d.M ** 2)
    return d


def rss_at(x, y, rs):
    s, u = x <= rs, x > rs
    if s.sum() < 20 or u.sum() < 20:
        return np.inf
    r = ((y[s] - y[s].mean()) ** 2).sum()
    sl, ic = np.polyfit(x[u], y[u], 1)
    return r + ((y[u] - (sl * x[u] + ic)) ** 2).sum()


print("=" * 78)
print("1) 自由断点 RSS 剖面（τ = −0.30）")
d = setro(d5, -0.30)
for k in ("M0M3", "M4M6"):
    q = d[d.pan == k]
    x, y = np.log10(q.Ro.values), np.log10(q.RHa.values)
    grid = np.linspace(-2.4, -0.3, 1101)   # 宽域：bp ∈ [4e-3, 0.5]
    r2 = np.array([rss_at(x, y, g) for g in grid])
    # 找局部极小
    loc = [i for i in range(1, len(grid) - 1) if r2[i] < r2[i - 1] and r2[i] < r2[i + 1]]
    loc.sort(key=lambda i: r2[i])
    print("  %s n=%d  全局最优 bp=%.4f (RSS=%.3f)" % (k, len(q), 10 ** grid[np.argmin(r2)], r2.min()))
    for i in loc[:3]:
        print("     局部极小 bp=%.4f  RSS=%.3f  ΔRSS=%.2f" % (10 ** grid[i], r2[i], r2[i] - r2.min()))
    for probe in (0.046, 0.050, 0.114):
        j = np.argmin(np.abs(10 ** grid - probe))
        print("     probe bp=%.3f -> RSS=%.3f" % (10 ** grid[j], r2[j]))

print()
print("  bootstrap 断点中位（2000 次，宽域 401 网格）")
rng = np.random.default_rng(20261022)
for k in ("M0M3", "M4M6"):
    q = d[d.pan == k]
    x, y = np.log10(q.Ro.values), np.log10(q.RHa.values)
    bps = []
    for _ in range(2000):
        s = rng.integers(0, len(x), len(x))
        gg = np.linspace(-2.4, -0.3, 401)
        rr = np.array([rss_at(x[s], y[s], g) for g in gg])
        bps.append(10 ** gg[np.argmin(rr)])
    bps = np.array(bps)
    print("     %s 中位=%.4f  16–84%%=%.3f–%.3f  落在<0.08 的比例=%.1f%%"
          % (k, np.median(bps), np.percentile(bps, 16), np.percentile(bps, 84),
             100 * (bps < 0.08).mean()))

print()
print("=" * 78)
print("2) 坪区 Simpson 分解（三分组，含 dM7–dM8）")
for c in (-0.30, -0.31):
    dd = setro(d5, c)
    plat = dd[dd.Ro < 0.135]
    x, y = np.log10(plat.Ro.values), np.log10(plat.RHa.values)
    Sxx = ((x - x.mean()) ** 2).sum()
    Sxy = ((x - x.mean()) * (y - y.mean())).sum()
    tot = Sxy / Sxx
    win = btw = 0.0
    detail = []
    for k in ("M0M3", "M4M6", "late"):
        q = plat[plat.pan == k]
        xq, yq = np.log10(q.Ro.values), np.log10(q.RHa.values)
        win += ((xq - xq.mean()) * (yq - yq.mean())).sum()
        btw += len(q) * (xq.mean() - x.mean()) * (yq.mean() - y.mean())
        detail.append("%s n=%d β=%+.3f" % (k, len(q), np.polyfit(xq, yq, 1)[0] if len(q) > 5 else np.nan))
    print("  τ=%+.2f  N_plat=%d  全体 OLS=%+.6f" % (c, len(plat), tot))
    print("        %s" % " | ".join(detail))
    print("        组内=%+.6f  组间=%+.6f  和=%+.6f  残差=%.2e"
          % (win / Sxx, btw / Sxx, (win + btw) / Sxx, (win + btw) / Sxx - tot))
