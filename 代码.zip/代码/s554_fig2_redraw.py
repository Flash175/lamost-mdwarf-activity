# -*- coding: utf-8 -*-
"""s554：只重绘图 2（读已存的 CSV，不重算），n 标签压缩为 k 表示。"""
import io, sys, os
import numpy as np, pandas as pd
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
OUT = r'C:\Users\lingz\Desktop\复现老师工作\APJS\多个图及讨论'
F2 = pd.read_csv(os.path.join(OUT, '新图2_数据_分亚型SN匹配.csv'), comment='#')
P = F2.pivot(index='subtype', columns='cut', values=['frac','lo','hi','n'])
P = P.reindex(['dM0','dM1','dM2','dM3','dM4','dM5','dM6','dM7','dM8'])

def nfmt(n):
    n = int(n)
    return ('%dk' % round(n/1000)) if n >= 10000 else str(n)

xs = np.arange(len(P)); w = 0.27
fig, ax = plt.subplots(figsize=(8.2, 4.9))
for j, (tag, col, lab) in enumerate([('all','#7f8c8d','2D sample (one spectrum per star)'),
                                     ('sn36','#c0392b','S/N 3-6'),
                                     ('sn612','#2980b9','S/N 6-12')]):
    f = P['frac'][tag].values; lo = P['lo'][tag].values; hi = P['hi'][tag].values
    ax.bar(xs + (j-1)*w, f, w, color=col, label=lab, yerr=np.vstack([f-lo, hi-f]),
           capsize=2, ecolor='#444444')
det = [F2[(F2.subtype == sp) & (F2.cut == 'all')].detect_pct.values[0] for sp in P.index]
ax.plot(xs, det, 'k^--', ms=5, lw=1, label='detectable: 3 x sigma(EW) <= 0.75 A')
for i in range(len(P)):
    ax.text(xs[i], 104, 'n=%s' % nfmt(P['n']['all'].values[i]), ha='center', fontsize=7.5, color='#333333')
ax.set_xticks(xs); ax.set_xticklabels(P.index)
ax.set_xlabel('Spectral subtype'); ax.set_ylabel('Active fraction (%)')
ax.set_ylim(0, 112)
ax.set_title('Active fraction by subtype: 2D sample versus S/N-matched', fontsize=10, pad=26)
ax.legend(fontsize=8, loc='lower center', bbox_to_anchor=(0.5, 1.02), ncol=4, framealpha=0.9)
plt.tight_layout(); plt.savefig(os.path.join(OUT, '新图2_活动率与亚型_SN匹配.png'), dpi=200); plt.close()
print('图 2 已重绘（n 用 k 压缩，误差棒为 Wilson 95%）')
