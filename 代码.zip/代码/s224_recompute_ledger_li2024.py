# -*- coding: utf-8 -*-
"""s224：按 Li et al. (2024) 印刷式 τ（−0.30）重算台账 §2–§4 的全部斜率

输出与 fig5_final_numbers.md 的 §2/§3/§4 一一对应，便于逐行替换。
"""
import io, sys
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
import numpy as np, pandas as pd

d = pd.read_csv('../数据/图5_逐星样本_严格3340行_⑤.csv')
d = d[(d.RHa > 0) & (d.P > 0) & (d.M > 0)].copy()
d['pan'] = np.where(d.spt.isin(['dM0', 'dM1', 'dM2', 'dM3']), 'M0M3',
                    np.where(d.spt.isin(['dM4', 'dM5', 'dM6']), 'M4M6', 'o'))
COEF = -0.30
d['Ro'] = d.P.values / 10 ** (2.33 - 1.50 * d.M.values + COEF * d.M.values ** 2)
x = np.log10(d.Ro.values)
y = np.log10(d.RHa.values)

def sl(xx, yy):
    return np.polyfit(xx, yy, 1)[0]

def boot(mask, n=2000, seed=20261022):
    rng = np.random.default_rng(seed)
    idx = np.where(mask)[0]
    out = [sl(x[s], y[s]) for s in (rng.choice(idx, len(idx), replace=True) for _ in range(n))]
    return float(np.std(out, ddof=1))

print('n =', len(d), ' 面板:', d.pan.value_counts().to_dict())
print()
print('=== §3 三档断点（固定断点，只拟合斜率）===')
print('%-8s %-6s %-18s %-18s %-18s' % ('sample', 'n', 'bp=0.100', 'bp=0.120', 'bp=0.135 (adopted)'))
for nm, mask in (('全体', np.ones(len(d), bool)), ('M0–M3', (d.pan == 'M0M3').values),
                 ('M4–M6', (d.pan == 'M4M6').values)):
    cells = []
    for bp in (0.100, 0.120, 0.135):
        m = mask & (x > np.log10(bp))
        cells.append('%.3f ± %.3f' % (sl(x[m], y[m]), boot(m)))
    print('%-8s %-6d %-18s %-18s %-18s' % (nm, mask.sum(), *cells))

print()
print('=== §4 分面板（固定断点 0.135）===')
m1 = (d.pan == 'M0M3').values & (x > np.log10(0.135))
m2 = (d.pan == 'M4M6').values & (x > np.log10(0.135))
b1, b2 = sl(x[m1], y[m1]), sl(x[m2], y[m2])
print('M0–M3  β = %.3f ± %.3f  (n_fit=%d)' % (b1, boot(m1), m1.sum()))
print('M4–M6  β = %.3f ± %.3f  (n_fit=%d)' % (b2, boot(m2), m2.sum()))
# Δβ 的 bootstrap（同一重抽样内相减）
rng = np.random.default_rng(20261022)
i1, i2 = np.where(m1)[0], np.where(m2)[0]
dd = []
for _ in range(2000):
    s1 = rng.choice(i1, len(i1), replace=True)
    s2 = rng.choice(i2, len(i2), replace=True)
    dd.append(sl(x[s2], y[s2]) - sl(x[s1], y[s1]))
print('Δβ = %.4f ± %.4f  → %.3fσ' % (b2 - b1, np.std(dd, ddof=1), abs(b2 - b1) / np.std(dd, ddof=1)))

print()
print('=== §2 自由断点 OLS（全体）===')
best = None
for rs in np.linspace(-1.1, -0.4, 401):
    s, u = x <= rs, x > rs
    if s.sum() < 20 or u.sum() < 20:
        continue
    rss = ((y[s] - y[s].mean()) ** 2).sum()
    q = np.polyfit(x[u], y[u], 1)
    rss += ((y[u] - (q[0] * x[u] + q[1])) ** 2).sum()
    if best is None or rss < best[0]:
        best = (rss, rs, q[0])
print('Ro_sat = %.4f   β = %.3f' % (10 ** best[1], best[2]))
mu = x > best[1]
print('自由断点 β 的 bootstrap ± %.3f' % boot(mu))
