# -*- coding: utf-8 -*-
"""下载 Fetherolf+2023 (ApJS 268,4) 自转/变光周期星表（论文A §2.3 用的就是它）。"""
import io, os, sys, time
import requests
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")
TAP = "https://tapvizier.cds.unistra.fr/TAPVizieR/tap/sync"
H = {"User-Agent": "Mozilla/5.0 (reproduction-pipeline)"}
PAGE = 50000

def q(query, maxrec=PAGE, tries=4):
    for i in range(tries):
        try:
            r = requests.post(TAP, data={"REQUEST": "doQuery", "LANG": "ADQL", "FORMAT": "csv",
                                         "QUERY": query, "MAXREC": str(maxrec)}, timeout=300, headers=H)
            if r.status_code == 200 and "<VOTABLE" not in r.text[:200] and r.text.strip():
                return r.text
            print("   retry:", r.status_code, r.text[:100].replace("\n", " "), flush=True)
        except Exception as e:
            print("   retry:", type(e).__name__, str(e)[:80], flush=True)
        time.sleep(5)
    return None

os.makedirs("data/vizier", exist_ok=True)
total = None
for t, name in [("J/ApJS/268/4/table1", "apjs268_4_table1.csv"),
                ("J/ApJS/268/4/table2", "apjs268_4_table2.csv")]:
    st = q(f'SELECT COUNT(*) AS n FROM "{t}"', maxrec=1)
    if not st:
        print(f"{t}: 计数失败，跳过"); continue
    n = int(st.splitlines()[1].split(",")[0].strip().strip('"'))
    print(f"{t}: {n:,} 行 -> {name}", flush=True)
    out = os.path.join("data/vizier", name)
    if os.path.exists(out) and sum(1 for _ in open(out, encoding="utf-8", errors="replace")) - 1 >= n:
        print("   已存在且完整，跳过")
        continue
    first = True
    written = 0
    with open(out, "w", encoding="utf-8", newline="") as fh:
        lo = 0
        while lo < n:
            hi = lo + PAGE
            txt = q(f'SELECT * FROM "{t}" WHERE recno > {lo} AND recno <= {hi}')
            if txt is None:
                print("   分页失败，停止", flush=True); break
            lines = txt.splitlines()
            if first:
                fh.write(lines[0] + "\n"); first = False
            body = lines[1:]
            fh.write("\n".join(body) + "\n")
            written += len(body)
            lo = hi
            print(f"   {written:,}/{n:,}", flush=True)
    print(f"   写出 {written:,} 行 -> {out}", flush=True)
