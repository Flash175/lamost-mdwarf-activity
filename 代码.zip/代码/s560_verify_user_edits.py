# -*- coding: utf-8 -*-
"""s560：核对用户改动涉及的 6 个数字。"""
import io, sys, os
import numpy as np, pandas as pd
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
OUT = r'C:\Users\lingz\Desktop\复现老师工作\APJS\多个图及讨论'

def wilson(k, n, z=1.96):
    p = k/n; d = 1+z*z/n; c = (p+z*z/(2*n))/d
    h = z*np.sqrt(p*(1-p)/n + z*z/(4*n*n))/d
    return 100*(c-h), 100*(c+h)

# (1) χ²：整数计数 vs 未四舍五入
K = pd.read_csv(os.path.join(OUT, '新图3_K与M活动比例.csv'), comment='#')
K = K[K.kind == 'K']
n = K.n.values.astype(float); fr = K.frac.values/100.0
for tag, k in (('整数计数', np.round(n*fr)), ('未四舍五入', n*fr)):
    pbar = k.sum()/n.sum()
    chi = float((((k-n*pbar)**2)/(n*pbar*(1-pbar))).sum())
    from math import lgamma, exp
    dof = len(n)-1
    # p 值：卡方生存函数（正则化不完全 gamma 的简单实现）
    x = chi/2.0; a = dof/2.0
    # 用级数/连分式太麻烦，这里用 scipy（若可用）
    try:
        from scipy.stats import chi2
        pv = chi2.sf(chi, dof)
    except Exception:
        pv = np.nan
    print('  χ²（%s）= %.2f / %d dof，p = %.2g' % (tag, chi, dof, pv))

# (2) >1000 档 Wilson 宽度
lo, hi = wilson(215, 1600)
print('\n  >1000 pc：13.44%%  Wilson %.2f–%.2f  宽度 %.2f 个百分点' % (lo, hi, hi-lo))

# (3) dM6 对 200-400→>400 的贡献
C = pd.read_csv(os.path.join(OUT, 'reweight_composition.csv'), comment='#')
A = C[C.zbin == '200-400'].set_index('subtype'); B = C[C.zbin == '>400'].set_index('subtype')
for sp in ['dM5', 'dM6']:
    w = A.loc[sp, 'weight_pct']/100.0
    print('  %s 贡献 = %.4f x (%.2f - %.2f) = %+.3f pp' % (sp, w, B.loc[sp,'frac'], A.loc[sp,'frac'], w*(B.loc[sp,'frac']-A.loc[sp,'frac'])))

# (4) 亚型不在 dM0-dM8 的谱数（EW 闸门后）
SUBS = ['dM%d' % i for i in range(9)]
cat = pd.read_csv('data/lamost/dr13/dr13_mstellar_dM.csv', low_memory=False,
                  usecols=['uid','subclass','teff','ewha','ewha_err','gaia_source_id'])
g2 = cat[(cat.ewha > -20) & (cat.ewha <= 50) & (cat.ewha_err > 0) & (cat.ewha_err <= 5)]
other = g2[~g2.subclass.isin(SUBS)]
print('\n  EW 闸门 2 后：%d 条谱；不在 dM0–dM8 的 %d 条（1,016,104 - 本表 M 侧 1,015,955 = %d）'
      % (len(g2), len(other), 1016104-1015955))
print('  这些谱的 subclass 取值：', other.subclass.value_counts().head(8).to_dict())

# (5) M 侧 Teff 覆盖与 §11 的 9,383
g = pd.read_csv('data/gaia/gaia_dr3_mstars.csv', low_memory=False, usecols=['source_id','ruwe'])
g2 = g2.copy(); g2['gaia_source_id'] = pd.to_numeric(g2.gaia_source_id, errors='coerce')
m = g2.merge(g, left_on='gaia_source_id', right_on='source_id', how='inner')
m = m[m.ruwe < 1.4]
print('\n  M 侧（EW 闸门 2 + ruwe<1.4）共 %d 条谱' % len(m))
for lo, hi in [(0,3100),(3100,4200),(4200,6000),(6000,99999)]:
    s = m[(m.teff >= lo) & (m.teff < hi)]
    print('    Teff %5d–%5d：%6d 条（%.2f%%）' % (lo, min(hi,99999), len(s), 100*len(s)/len(m)))

# (6) 固定亚型的 Teff 偏移
u = m.sort_values('ewha', ascending=False).drop_duplicates('uid')
print('\n  固定亚型的 Teff 中位偏移（相对 <100 pc 档；用日心 |Z| 近似按 teff 无关，这里直接按 m 的全样本分档不可行）')
print('  说明：分档需距离，见 s556 输出；此处仅打印全样本各亚型 Teff 中位：')
print('   ' + ' '.join('%s=%.0f' % (sp, u[u.subclass==sp].teff.median()) for sp in SUBS if len(u[u.subclass==sp])>50))
print('s560 完成')
