# -*- coding: utf-8 -*-
"""Fig. 2：Teff–EW(Hα) 密度图（论文口径：2D 样本 637,973 颗，判据 EW>=0.75 Å 且 >3σ）。
色标为对数密度；vmax 取 99.5 百分位以保留平缓区的层次。"""
import os
import numpy as np, pandas as pd
import matplotlib; matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import LogNorm

BASE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(BASE, "数据", "金属度_清洁样本_637973.csv")
FIG = os.path.join(BASE, "figures", "fig_teffew.png")

d = pd.read_csv(DATA, low_memory=False, encoding="utf-8-sig", comment="#",
                usecols=["teff", "ewha", "ewha_err", "active"])
d = d[np.isfinite(d.teff) & np.isfinite(d.ewha)]   # 哨兵 Teff=-9999 落在坐标范围外，不影响绘图
y = np.clip(d.ewha.values, -3, 12)
print("N =", len(d), "| active =", int(d.active.sum()), "| %.2f per cent" % (100*d.active.mean()))

cnt = np.histogram2d(d.teff.values, y, bins=150)[0]
fig, ax = plt.subplots(figsize=(7.4, 5.2))
hb = ax.hexbin(d.teff.values, y, gridsize=150, bins="log", cmap="viridis",
               mincnt=1, linewidths=0, vmin=1,
               vmax=max(2.0, float(np.percentile(cnt[cnt > 0], 99.5))))
ax.axhline(0.75, color="#d62728", lw=1.8, zorder=5, label=r"EW(H$\alpha$) = 0.75 $\AA$")
ax.set_xlim(3000, 4400); ax.set_ylim(-3, 12)
ax.set_xlabel(r"$T_{\rm eff}$ (K)"); ax.set_ylabel(r"EW(H$\alpha$) ($\AA$)")
ax.legend(fontsize=8, loc="upper right")
cb = plt.colorbar(hb, ax=ax, pad=0.01); cb.set_label("stars per cell (log)", fontsize=8)
cb.ax.tick_params(labelsize=7)
plt.tight_layout(); plt.savefig(FIG, dpi=300); plt.close()
print("written", FIG, os.path.getsize(FIG)//1024, "KB")
