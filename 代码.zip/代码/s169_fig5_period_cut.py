# -*- coding: utf-8 -*-
"""按 M 矮星物理合理的周期窗口裁剪后再拟合（P∈[0.1,30] d，Ro≤3，仅 ROT），并出图。"""
import io, os, sys
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
import numpy as np, pandas as pd
from scipy.spatial import cKDTree
sys.path.insert(0, 'repro/src')
from common import activity as A
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt

cat = pd.read_csv('data/lamost/dr13/dr13_mstellar_dM.csv', low_memory=False,
                  usecols=['uid','designation','ewha','ewha_err','teff','ra','dec','gaia_source_id'])
for c in ('ewha','ewha_err','teff','ra','dec'): cat[c] = pd.to_numeric(cat[c], errors='coerce')
cat['ewha_err'] = cat.ewha_err.abs()
cat = cat[(cat.ewha > -20) & (cat.ewha <= 50) & (cat.ewha_err > 0) & (cat.ewha_err <= 5)]
star = cat.loc[cat.groupby('uid').ewha.idxmax()].dropna(subset=['ra','dec']).copy()

v = pd.read_csv('repro/_vsx/VSX_catalog_sample.csv', low_memory=False, usecols=['Type','Period','RAJ2000','DEJ2000'])
v['Period'] = pd.to_numeric(v.Period, errors='coerce')
v = v[v.Period.gt(0) & v.RAJ2000.notna() & v.DEJ2000.notna()]
v = v[v.Type.astype(str).str.upper().str.contains('ROT')]
def uv(ra, dec):
    ra = np.radians(np.asarray(ra, float)); dec = np.radians(np.asarray(dec, float))
    return np.column_stack([np.cos(dec)*np.cos(ra), np.cos(dec)*np.sin(ra), np.sin(dec)])
tree = cKDTree(uv(star.ra.values, star.dec.values))
d, i = tree.query(uv(v.RAJ2000.values, v.DEJ2000.values), k=1, distance_upper_bound=np.radians(3/3600))
ok = np.isfinite(d) & (i < len(star))
m = pd.DataFrame({'idx': i[ok], 'P': v.Period.values[ok]}).drop_duplicates('idx')
vsx = star.iloc[m.idx.values].copy(); vsx['P'] = m.P.values; vsx['src'] = 'VSX'
fet = pd.read_csv('data/processed/dr13/dr13_fig5_sample.csv', low_memory=False, usecols=['designation','P'])
fet['designation'] = fet.designation.astype(str)
f = star[star.designation.astype(str).isin(set(fet.designation)) & ~star.uid.isin(set(vsx.uid))].merge(
    fet.drop_duplicates('designation'), on='designation', how='inner')
f['src'] = 'Fetherolf'
cols = ['uid','designation','ewha','teff','P','src','gaia_source_id']
g = pd.concat([vsx[cols], f[cols]], ignore_index=True)
fl = pd.read_csv('data/gaia/gaia_flame_mass.csv', low_memory=False, usecols=['source_id','mass_flame'])
fl['sid'] = fl.source_id.astype('int64').astype(str)
g['sid'] = g.gaia_source_id.astype(str).str.split('.').str[0]
g = g.merge(fl[['sid','mass_flame']], on='sid', how='left')
cds = pd.read_csv('data/vizier/apjs274_36_mdwarfs.csv', low_memory=False, usecols=lambda c: c in {'Mstar','Teff'})
cds = cds[(cds.Teff > 2800) & (cds.Teff < 4600) & (cds.Mstar > 0.05) & (cds.Mstar < 0.8)]
coef = np.polyfit(cds.Teff, cds.Mstar, 2)
g['M'] = g.mass_flame
msk = g.M.isna(); g.loc[msk, 'M'] = np.clip(np.polyval(coef, g.loc[msk, 'teff']), 0.08, 0.75)
g['tau'] = 10 ** (2.33 - 1.5*g.M - 0.30*g.M**2)
g['Ro'] = g.P / g.tau
c2 = pd.read_csv('data/vizier/apjs274_36_mdwarfs.csv', low_memory=False, usecols=lambda c: c in {'EWHa','RHa','Teff'})
c2 = c2[(c2.EWHa > 0.1) & (c2.RHa > 0) & (c2.Teff > 2800) & (c2.Teff < 4600)].copy()
c2['chi'] = c2.RHa / c2.EWHa
bins = np.arange(2800, 4601, 100); cent = 0.5*(bins[1:]+bins[:-1]); c2['b'] = np.digitize(c2.Teff, bins)
chi_med = np.array([c2.loc[c2.b == i, 'chi'].median() for i in range(1, len(bins))])
g['RHa'] = np.interp(g.teff, cent, chi_med) * g.ewha
pos = g[(g.Ro > 0) & (g.RHa > 0)].copy()
print('未裁剪：%d 颗（Ro 最大 %.1f）' % (len(pos), pos.Ro.max()))
for tag, q in [('P∈[0.1,30]', pos[(pos.P >= 0.1) & (pos.P <= 30)]),
               ('P∈[0.1,30] & Ro≤3', pos[(pos.P >= 0.1) & (pos.P <= 30) & (pos.Ro <= 3)]),
               ('P≤15 & Ro≤1.5', pos[(pos.P <= 15) & (pos.Ro <= 1.5)])]:
    if len(q) < 50: continue
    f5 = A.fit_saturation(q.Ro.values, q.RHa.values, n_boot=100)
    h = q[q.Ro > f5.ro_sat]
    sl = np.polyfit(np.log10(h.Ro), np.log10(h.RHa), 1)[0] if len(h) > 20 else np.nan
    print('  %-22s n=%5d  Ro %.3f–%.2f  Ro_sat=%.3f ± %.3f  β(bootstrap)=%.3f ± %.3f  β(直拟)=%.3f'
          % (tag, len(q), q.Ro.min(), q.Ro.max(), f5.ro_sat, f5.ro_sat_err, f5.slope, f5.slope_err, sl))
# 用"P∈[0.1,30] & Ro≤3"出图
q = pos[(pos.P >= 0.1) & (pos.P <= 30) & (pos.Ro <= 3)]
f5 = A.fit_saturation(q.Ro.values, q.RHa.values, n_boot=200)
fig, ax = plt.subplots(figsize=(5.4, 4.6))
ax.scatter(q.Ro, q.RHa, s=6, c=np.where(q.src == 'VSX', '#d95f02', '#1f4fd8'), lw=0, alpha=0.75)
ysat = np.median(q.RHa[q.Ro <= f5.ro_sat])
xs1 = np.logspace(np.log10(q.Ro.min()), np.log10(f5.ro_sat), 40)
xs2 = np.logspace(np.log10(f5.ro_sat), np.log10(min(q.Ro.max(), 3)), 40)
ax.plot(xs1, np.full_like(xs1, ysat), c='red', lw=2)
ax.plot(xs2, ysat/f5.ro_sat**f5.slope*xs2**f5.slope, c='red', lw=2)
ax.set_xscale('log'); ax.set_yscale('log'); ax.set_xlim(1e-3, 3); ax.set_ylim(1e-8, 1e-2)
ax.set_xlabel('Ro'); ax.set_ylabel(r"R'$_{\rm H\alpha}$")
ax.text(0.04, 0.97, 'ROT only, P∈[0.1,30] d, Ro≤3\nslope=%.2f±%.2f  Ro_sat=%.2f\nN=%d (VSX %d / Fetherolf %d)'
        % (f5.slope, f5.slope_err, f5.ro_sat, len(q), int((q.src=='VSX').sum()), int((q.src=='Fetherolf').sum())),
        transform=ax.transAxes, va='top', fontsize=8, bbox=dict(fc='white', ec='red', pad=3))
ax.tick_params(direction='in', top=True, right=True, labelsize=9)
fig.tight_layout(); os.makedirs('figures', exist_ok=True)
o = 'figures/dr13_fig5_rha_rossby_rot_cut.png'; fig.savefig(o, dpi=170); plt.close(fig)
print('图 ->', o)
