
# -*- coding: utf-8 -*-
"""看 stellar 表的列，并统计 K 型矮星数量。"""
import io, os, sys
import requests, pandas as pd
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
BASE = 'https://www.lamost.org/openapi'; token = open('extract/lamost_token.txt').read().strip()
def q(sql, timeout=90):
    r = requests.get(f'{BASE}/dr13/v1.0/sql', params={'sql': sql, 'output.fmt': 'csv', 'token': token}, timeout=timeout)
    return r.text
head = q("select * from stellar limit 2")
print('前两行：')
for line in head.splitlines()[:3]: print('  ' + line[:400])
try:
    df = pd.read_csv(io.StringIO(head.lstrip('\ufeff')))
    print('\n列：', list(df.columns))
except Exception as e:
    print('解析失败', e)
for cond in ("subclass like 'K%'", "subclass like 'K%' and logg > 3.5", "subclass like 'K%' and logg > 3.5 and teff between 3900 and 5500"):
    t = q('select count(*) as n from stellar where ' + cond)
    print('%-62s -> %s' % (cond, t.strip().replace('\n', ' ')[:60]))
