# -*- coding: utf-8 -*-
"""统一 bootstrap 次数后，更新文档中的面板误差数值"""
import io, glob, os, sys
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
FILES = ([r'C:\Users\lingz\Desktop\复现老师工作\文档\%s' % f for f in ('图05_Methods文字_中英文.md', '交付说明.md', '口径假设台账.md')]
         + [r'C:\Users\lingz\Desktop\复现老师工作\说明.md', r'C:\Users\lingz\Desktop\复现老师工作\复现报告.md',
            r'C:\Users\lingz\Desktop\APJS\图五及相关数据\README.md',
            r'C:\Users\lingz\Desktop\APJS\图五及相关数据\方法说明\图05_Methods文字_中英文.md',
            r'C:\Users\lingz\Desktop\APJS\图五及相关数据\方法说明\交付说明_全量.md',
            r'C:\Users\lingz\Desktop\APJS\图五及相关数据\方法说明\口径假设台账_全量.md'])
PAIRS = [('±0.085', '±0.101'), ('± 0.085', '± 0.101'), ('0.085（M0–M3', '0.101（M0–M3'),
         ('±0.204', '±0.199'), ('± 0.204', '± 0.199'), ('0.204 的 bootstrap', '0.199 的 bootstrap'),
         ('±0.13~0.20', '±0.10~0.20'),
         ('| 2,083 | -0.935 | 0.085 | 1,245 | -0.702 | 0.204 |', '| 2,083 | -0.935 | 0.101 | 1,245 | -0.702 | 0.199 |'),
         ('| 2,859 | -0.911 | 0.129 | 1,735 | -0.753 | 0.127 |', '| 2,859 | -0.911 | 0.129 | 1,735 | -0.753 | 0.127 |')]
n = 0
for p in FILES:
    if not os.path.exists(p): continue
    s = open(p, encoding='utf-8').read(); o = s
    for a, b in PAIRS: s = s.replace(a, b)
    if s != o:
        open(p, 'w', encoding='utf-8').write(s); n += 1; print('  更新', os.path.basename(p))
print('  共 %d 个文件' % n)
print('  复核：仍含 0.085 / 0.204 的文档行')
for p in FILES:
    if not os.path.exists(p): continue
    for i, l in enumerate(open(p, encoding='utf-8').read().splitlines(), 1):
        if '0.085' in l or '0.204' in l: print('   %s:%d %s' % (os.path.basename(p), i, l.strip()[:110]))
