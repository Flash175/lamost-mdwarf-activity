# -*- coding: utf-8 -*-
"""s611：重导图16（15 个 |Z| 段 × M0-M7+），只修版式——底部注记被裁切。

做法：读取 repro/src/s112_dr13_fig12_14_16.py 源码，仅在内存里改两处版式参数后执行，
      数据与统计逻辑一字未改（Hβ 分层估计仍走 s151_hb_stratified）：
        fig.text(0.5, 0.004, ...)                -> fig.text(0.5, 0.014, ...)
        fig.tight_layout(rect=(0, 0.008, 1, 1))  -> fig.tight_layout(rect=(0, 0.026, 1, 1))
然后调用其 load_samples()/fig16()，把结果复制进 APJS 图包（旧版入 _旧版）。
"""
from __future__ import annotations

import io
import os
import shutil
import sys

import matplotlib
matplotlib.use("Agg")
import matplotlib as mpl

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

BASE = "C:/Users/lingz/OneDrive/Desktop/复现老师工作"
FIG = "C:/Users/lingz/Desktop/复现老师工作/APJS/图五及相关数据"
SRC = BASE + "/repro/src/s112_dr13_fig12_14_16.py"


def main():
    os.chdir(BASE)
    with open(SRC, "r", encoding="utf-8") as f:
        src = f.read()
    old1 = "fig.text(0.5, 0.004,"
    new1 = "fig.text(0.5, 0.014,"
    old2 = "fig.tight_layout(rect=(0, 0.008, 1, 1))"
    new2 = "fig.tight_layout(rect=(0, 0.026, 1, 1))"
    assert old1 in src and old2 in src, "版式锚点未找到"
    src = src.replace(old1, new1).replace(old2, new2)
    print("版式补丁：%s -> %s ；%s -> %s" % (old1, new1, old2, new2))

    # 底部注记原为中文，DejaVu Serif 无 CJK 字形，会渲成豆腐块 —— 改写为英文（同义，不改数值）
    import re as _re
    pat = _re.compile(r'fig\.text\(0\.5, 0\.014,.*?ha="center", fontsize=7\)', _re.S)
    note = ('fig.text(0.5, 0.014, "Open grey circles: cells with n<%d (mostly M6/M7 at |Z| > 300 pc), '
            'indicative only; error bars = Wilson 95%% CI" % SMALL_N, ha="center", fontsize=7)')
    src, k = pat.subn(note, src)
    assert k == 1, "注记替换失败（命中 %d 次）" % k
    print("注记改为英文（原中文在 DejaVu Serif 下无字形）")

    mod = {"__name__": "s112_patched", "__file__": SRC}
    exec(compile(src, SRC, "exec"), mod)
    mpl.rcParams.update({"font.family": "serif", "axes.linewidth": 0.8, "font.size": 9})
    sd = mod["load_samples"]()
    mod["fig16"](sd)

    src_png = os.path.join(BASE, "figures", "dr13_fig16_active_vs_Ztype.png")
    out = FIG + "/图_20261103/新图/新图_图16_重导_注记完整.png"
    shutil.copy2(src_png, out)
    print("写出 %s（%d B）" % (out, os.path.getsize(out)))
    for dst in [FIG + "/图_20261103/图/图16_活动比例与Z分块_dr13_fig16_active_vs_Ztype.png",
                FIG + "/图_20261104/图/图16_活动比例与Z分块_dr13_fig16_active_vs_Ztype.png"]:
        if os.path.exists(dst):
            old = os.path.join(os.path.dirname(dst), "_旧版")
            os.makedirs(old, exist_ok=True)
            shutil.move(dst, os.path.join(old, "图16_旧版_注记裁切_%d.png" % int(os.path.getmtime(dst))))
            shutil.copy2(out, dst)
            print("替换 %s（现 %d B）" % (dst, os.path.getsize(dst)))


if __name__ == "__main__":
    main()
