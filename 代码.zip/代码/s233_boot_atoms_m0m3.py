# -*- coding: utf-8 -*-
"""s233: M0–M3 bootstrap 的离散原子表，检验 47.5% 与 38.6% 的分歧是否只由参考点估计决定。"""
import numpy as np, pandas as pd
exec(open("s232_boot_rosat_dist.py", encoding="utf-8").read().split('if __name__')[0])
d = pd.read_csv(D + "图5_逐星样本_严格3340行_⑤.csv")
d = d[(d.RHa > 0) & (d.P > 0) & (d.M > 0)]
d["pan"] = np.where(d.spt.isin(["dM0","dM1","dM2","dM3"]), "M0M3",
             np.where(d.spt.isin(["dM4","dM5","dM6"]), "M4M6", "late"))
d["Ro"] = d.P / 10**(2.33 - 1.50*d.M + (-0.30)*d.M**2)
q = d[d.pan == "M0M3"]
x, y = np.log10(q.Ro.values), np.log10(q.RHa.values)
rng = np.random.default_rng(20261022)
N = 2000
bps = np.array([BPS[np.argmin(rss_profile(x[s], y[s]))] for s in
                (rng.integers(0, len(x), len(x)) for _ in range(N))])
print("N=%d 个重抽样，按取值聚合（前 12 个原子）：" % N)
v, c = np.unique(np.round(bps, 4), return_counts=True)
for j in np.argsort(-c)[:12]:
    print("   bp=%.4f  %5.1f%%" % (v[j], 100*c[j]/N))
print()
for ref in (0.045, 0.0463, 0.0464, 0.046):
    print("P(bp > %.4f) = %.1f%%" % (ref, 100*(bps > ref).mean()))
print("P(bp > 0.09)  = %.1f%%   （= 上支总质量）" % (100*(bps > 0.09).mean()))
print("P(bp > 0.11)  = %.1f%%" % (100*(bps > 0.11).mean()))
print("上支取值集合:", np.unique(np.round(bps[bps > 0.09], 4))[:15])
