# -*- coding: utf-8 -*-
"""s569：用 Gaia 绝对星等 M_G 做去巨星——logg 有 1.57% 缺失哨兵，不能靠它。
M 矮星典型 M_G ≈ +8 ~ +16；巨星 M_G ≈ 0 ~ +1；亚巨星 ~ +2 ~ +3。
本脚本给出：各 |Z| 档里 M_G < 6 的「亮天体」比例，以及去掉它们后的活动比例。
"""
import io, sys, os
import numpy as np, pandas as pd
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
from astropy.coordinates import SkyCoord
import astropy.units as un
OUT = r'C:\Users\lingz\Desktop\复现老师工作\APJS\多个图及讨论'

def wilson(k, n, z=1.96):
    if n == 0: return (np.nan, np.nan)
    p = k/n; d = 1+z*z/n; c = (p+z*z/(2*n))/d
    h = z*np.sqrt(p*(1-p)/n + z*z/(4*n*n))/d
    return 100*(c-h), 100*(c+h)

def save(df, name, comments):
    fp = os.path.join(OUT, name); df.to_csv(fp, index=False, encoding='utf-8')
    txt = open(fp, encoding='utf-8').read()
    with open(fp, 'w', encoding='utf-8-sig') as f:
        f.write('\n'.join('# ' + c for c in comments) + '\n' + txt)
    print('  写出 %s（%d 行）' % (name, len(df)))

cat = pd.read_csv('data/lamost/dr13/dr13_mstellar_dM.csv', low_memory=False,
                  usecols=['uid','subclass','teff','logg','ewha','ewha_err','snrr','ra','dec',
                           'gaia_source_id','gaia_g_mean_mag'])
cat = cat[(cat.ewha > -20) & (cat.ewha <= 50) & (cat.ewha_err > 0) & (cat.ewha_err <= 5)].copy()
cat['active'] = (cat.ewha >= 0.75) & (cat.ewha > 3*cat.ewha_err)
cat['gaia_source_id'] = pd.to_numeric(cat.gaia_source_id, errors='coerce')
g = pd.read_csv('data/gaia/gaia_dr3_mstars.csv', low_memory=False,
                usecols=['source_id','parallax','parallax_error','ruwe'])
m = cat.merge(g, left_on='gaia_source_id', right_on='source_id', how='inner')
m = m[(m.parallax > 0.2) & (m.parallax/m.parallax_error > 5) & (m.ruwe < 1.4)].copy()
u = m.sort_values('ewha', ascending=False).drop_duplicates('uid').copy()
d = 1000.0/u.parallax.values
sc = SkyCoord(ra=u.ra.values*un.deg, dec=u.dec.values*un.deg, distance=d*un.pc, frame='icrs')
u['absz'] = np.abs(d*np.sin(np.deg2rad(sc.galactic.b.deg)))
u['MG'] = u.gaia_g_mean_mag.values - 5*np.log10(np.clip(d, 1, None)) + 5
u = u[u.absz <= 3000].copy()
print('2D 样本 %d 颗；M_G 中位 %.2f（1%%–99%% 分位 %.1f–%.1f）'
      % (len(u), u.MG.median(), u.MG.quantile(0.01), u.MG.quantile(0.99)))
print('M_G < 6（巨星/亚巨星/亮端误分类）的条数 %d（%.2f%%）' % ((u.MG < 6).sum(), 100*(u.MG < 6).mean()))

rows = []
print('\n 档         n       M_G中位   亮天体(<6)  活动%%(全)  活动%%(去亮天体)  去掉的活明星')
for lb, zl, zh in [('<100',0,100),('100-200',100,200),('200-400',200,400),('400-600',400,600),('600-1000',600,1000),('>400',400,3000)]:
    s = u[(u.absz >= zl) & (u.absz < zh)]
    bright = s[s.MG < 6]
    clean = s[s.MG >= 6]
    f_all = 100*s.active.mean(); f_cl = 100*clean.active.mean()
    lo, hi = wilson(int(clean.active.sum()), len(clean))
    print('  %-8s %6d   %6.2f     %5d (%4.2f%%)  %6.2f     %6.2f [%.2f,%.2f]     %d'
          % (lb, len(s), s.MG.median(), len(bright), 100*len(bright)/len(s), f_all, f_cl, lo, hi, int(bright.active.sum())))
    rows.append(dict(zbin=lb, n=len(s), MG_med=float(s.MG.median()), n_bright=len(bright),
                     frac_bright=100*len(bright)/len(s), frac_all=f_all, n_clean=len(clean),
                     frac_clean=f_cl, lo=lo, hi=hi, n_act_bright=int(bright.active.sum())))
save(pd.DataFrame(rows), 'giant_cut_by_MG.csv', [
    '用 Gaia 绝对星等 M_G 去巨星：M_G < 6 视为亮天体（巨星/亚巨星/误分类），M 矮星典型 M_G ≈ +8 至 +16',
    'frac_all 为全样本活动比例；frac_clean 为 M_G >= 6 后的活动比例（Wilson 95%）',
    'logg 有 1.57% 的 -9999 哨兵，不能作为去巨星依据；本表改用光度',
    '生成脚本：代码/s569_giant_cut_by_absolute_mag.py'])
print('s569 完成')
