# -*- coding: utf-8 -*-
"""图 5 脚注补一句 Ro_sat 的 τ 口径依赖

【已作废 · 勿重跑】s189 内的 τ 系数已统一为 −0.30（Li 印刷式），本脚本要匹配的旧脚注
（"log tau = ... - 0.31M^2 (as printed by Li et al. 2024)"）已不存在，且该标注有误。
"""
import io, sys
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
P = 'repro/src/s189_fig5_official_v4.py'
s = open(P, encoding='utf-8').read()
OLD = """        "Removed: Gaia non_single_star != 0, alias periods within 5%% of 0.5/1/2 d, M3/M4 border stars, Ro > 3 \""""
if OLD not in s:
    print('  !! 锚点未匹配，改用整段替换')
OLD2 = """FOOT = ("Sample: LAMOST DR13 M dwarfs with VSX ROT or Fetherolf+2023 periods (3 arcsec match, n=%d).\\n"
        "Removed: Gaia non_single_star != 0, alias periods within 5%% of 0.5/1/2 d, M3/M4 border stars, Ro > 3 "
        "(fitted n=%d).  Error bars: period precision (VSX 7.5%%, Fetherolf 3%%) + 10%% mass/tau; "
        "R'Halpha from EW error + 10%% chi(Teff).") % (len(A), len(strict))"""
NEW2 = """FOOT = ("Sample: LAMOST DR13 M dwarfs with VSX ROT or Fetherolf+2023 periods (3 arcsec match, n=%d). "
        "Removed: Gaia non_single_star != 0, alias periods within 5%% of 0.5/1/2 d, M3/M4 border stars, Ro > 3 "
        "(fitted n=%d).\\n"
        "Error bars: period precision (VSX 7.5%%, Fetherolf 3%%) + 10%% mass/tau; R'Halpha from EW error + 10%% chi(Teff).  "
        "Tau convention: log tau = 2.33 - 1.50M - 0.31M^2 (as printed by Li et al. 2024); with +0.31 the saturation "
        "point moves from 0.137 to 0.087 while the slope changes by only 0.04.") % (len(A), len(strict))"""
if OLD2 in s:
    s = s.replace(OLD2, NEW2, 1)
    open(P, 'w', encoding='utf-8').write(s); print('  已改两面板脚注')
else:
    print('  !! FOOT 段未匹配')
