# -*- coding: utf-8 -*-
"""P_cyc–P_rot 图（用 activity_cycle_data_complete.csv，20 颗 M 矮星文献值）+ 太阳参考点"""
import io, os, sys
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
import numpy as np, pandas as pd
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt

d = pd.read_csv('data/raw/activity_cycle_data_complete.csv')
d['P_cyc'] = pd.to_numeric(d.P_cyc_yr, errors='coerce')          # '>10' -> NaN
d['lim'] = d.P_cyc_yr.astype(str).str.startswith('>')
d['ProT'] = pd.to_numeric(d.P_rot_days, errors='coerce')
ok = d.dropna(subset=['P_cyc', 'ProT'])
lim = d[d.lim & d.ProT.notna()]
print('可画点 %d 个；下限点（>10 yr）%d 个；缺 P_rot 的 %d 个' % (len(ok), len(lim), int(d.ProT.isna().sum())))
print('SpType 取值：', d.SpType.astype(str).value_counts().to_dict())

fig, ax = plt.subplots(figsize=(6.2, 4.8))
srcs = ok.Source.astype(str).unique()
colors = {'HADES_VII': '#1f4fd8', 'SM2016': '#d95f02'}
for s in srcs:
    q = ok[ok.Source.astype(str) == s]
    ax.errorbar(q.ProT, q.P_cyc, xerr=pd.to_numeric(q.P_rot_err_days, errors='coerce'),
                yerr=pd.to_numeric(q.P_cyc_err_yr, errors='coerce'), fmt='o', ms=6,
                color=colors.get(s, '0.4'), capsize=2, lw=0.9, label=s)
    for _, r in q.iterrows():
        ax.annotate(str(r.Star), (r.ProT, r.P_cyc), textcoords='offset points', xytext=(5, 4), fontsize=6.5)
if len(lim):
    ax.scatter(lim.ProT, np.full(len(lim), 20.0), marker='v', s=45, color='0.5')
    for _, r in lim.iterrows():
        ax.annotate(str(r.Star), (r.ProT, 20.0), textcoords='offset points', xytext=(5, -10), fontsize=6.5, color='0.4')
    ax.text(0.02, 0.10, 'triangles: lower limits only (>10 yr; plotted at 20 yr)', transform=ax.transAxes, fontsize=6.5, color='0.4')
# 太阳
ax.scatter([25.4], [11.0], marker='*', s=220, color='goldenrod', edgecolor='k', lw=0.6, zorder=5)
ax.annotate('Sun (P_rot=25.4 d, P_cyc=11 yr)', (25.4, 11.0), xytext=(-92, 12), textcoords='offset points', fontsize=7.5)
ax.set_xscale('log'); ax.set_yscale('log')
ax.set_xlabel('P$_{rot}$ (days)', fontsize=11); ax.set_ylabel('P$_{cyc}$ (years)', fontsize=11)
ax.set_xlim(1.5, 260); ax.set_ylim(1.2, 40)
ax.grid(alpha=0.25, which='both', lw=0.4)
ax.tick_params(direction='in', top=True, right=True, labelsize=9)
ax.legend(fontsize=8, loc='upper left', title='source', title_fontsize=7)
ax.set_title('Activity cycle vs rotation period (M dwarfs, literature sample, N=%d)' % len(ok), fontsize=9.5)
fig.text(0.5, 0.01, 'Data: activity_cycle_data_complete.csv (HADES VII, SM2016). '
                    'Subtype split (M0-M3 / M4-M6) is NOT possible: 18/20 entries give SpType only as "M".',
         ha='center', fontsize=6.3, color='0.3')
fig.tight_layout(rect=(0, 0.04, 1, 1))
os.makedirs('figures', exist_ok=True)
o = 'figures/dr13_figPcyc_Prot.png'; fig.savefig(o, dpi=170); plt.close(fig)
print('图 ->', o)
corr = np.corrcoef(np.log10(ok.ProT), np.log10(ok.P_cyc))[0, 1]
print('log P_cyc vs log P_rot 相关系数 r = %.2f（n=%d）' % (corr, len(ok)))
