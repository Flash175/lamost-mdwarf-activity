
# -*- coding: utf-8 -*-
"""活动–运动学：以 Hα 活动为年龄代理，检验速度弥散随 |Z| 的增长与活动/非活动的差别。"""
import io, sys
import numpy as np, pandas as pd
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')

CAT = 'data/lamost/dr13/dr13_mstellar_dM.csv'
GAI = 'data/gaia/gaia_dr3_mstars.csv'
cat = pd.read_csv(CAT, low_memory=False,
                  usecols=['obsid','uid','subclass','teff','ewha','ewha_err','z','snrr','ra','dec','gaia_source_id'])
cat = cat[(cat.ewha > -20) & (cat.ewha <= 50) & (cat.ewha_err > 0) & (cat.ewha_err <= 5)]
cat['active'] = (cat.ewha >= 0.75) & (cat.ewha > 3*cat.ewha_err)
print('目录（量程闸门后）光谱数 %d，星数 %d，其中活动 %.1f%%' % (len(cat), cat.uid.nunique(), 100*cat.active.mean()))

g = pd.read_csv(GAI, low_memory=False, usecols=['source_id','parallax','parallax_error','pmra','pmdec','radial_velocity','ruwe'])
cat['gaia_source_id'] = pd.to_numeric(cat.gaia_source_id, errors='coerce')
m = cat.merge(g, left_on='gaia_source_id', right_on='source_id', how='inner')
print('与 Gaia 匹配 %d 条' % len(m))
m = m[(m.parallax > 0.2) & (m.parallax/m.parallax_error > 5) & (m.ruwe < 1.4)]
print('视差>0.2mas 且 >5σ、ruwe<1.4 后 %d 条，%d 颗星' % (len(m), m.uid.nunique()))

# 逐星取一条（最强历元）以去重
m['absz'] = np.nan
m['dist_pc'] = 1000.0/m.parallax
m['rv'] = m.z.fillna(0)*299792.458
u = m.sort_values('ewha', ascending=False).drop_duplicates('uid').copy()
print('逐星去重后 %d 颗' % len(u))

ra = np.radians(u.ra.values); dec = np.radians(u.dec.values)
d = u.dist_pc.values/1000.0
pma = u.pmra.values; pmd = u.pmdec.values
rv = u.rv.values
# 银道坐标与 UVW（简化公式，太阳运动 (11.1, 12.24, 7.25) km/s）
l = np.arctan2(-np.sin(ra)*0.0548755604 - np.sin(dec)*np.cos(ra)*0.8734370902 + np.sin(dec)*np.sin(ra)*0.4838350155,
                np.cos(ra)*0.8734370902 + 0.0)
b = np.arcsin(np.sin(dec)*0.4941094279 + 0.0 + np.cos(dec)*np.sin(ra)*(-0.4448296300) + np.cos(dec)*np.cos(ra)*0.7469822445)
# 速度分量（"自转 + 天球切向"），k=4.74047
k = 4.74047
vl = k*pma/ (u.parallax.values)      # km/s，银经方向近似用 ra 方向代替（简化，仅作统计）
vb = k*pmd/ (u.parallax.values)
U = -vl - 11.1; V = -vb - 12.24; W = rv - 7.25
u['U'], u['V'], u['W'] = U, V, W
u['z_pc'] = d*1000*np.sin(b)
print('\n（注：此处 UVW 用赤经方向的简化切向速度，仅作组间比较的相对量）')
for nm, sel in (('活动', u.active), ('非活动', ~u.active)):
    s = u[sel]
    print('%s：n=%5d  σ_U=%.1f  σ_V=%.1f  σ_W=%.1f km/s  |Z| 中位=%.0f pc'
          % (nm, len(s), s.U.std(), s.V.std(), s.W.std(), np.abs(s.z_pc).median()))
print('\n按 |Z| 分层（活动 vs 非活动，σ_W）：')
u['zbin'] = pd.cut(np.abs(u.z_pc), [0, 100, 200, 400, 2000], labels=['<100', '100-200', '200-400', '>400'])
for b_ in u.zbin.cat.categories:
    s = u[u.zbin == b_]
    a, i = s[s.active], s[~s.active]
    print('  |Z| %-8s 活动 n=%4d σ_W=%.1f | 非活动 n=%4d σ_W=%.1f | 活动比例 %.1f%%'
          % (b_, len(a), a.W.std() if len(a) > 20 else np.nan, len(i), i.W.std() if len(i) > 20 else np.nan, 100*s.active.mean()))
