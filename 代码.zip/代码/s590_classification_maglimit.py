# -*- coding: utf-8 -*-
"""s590：把「分类」与「星等限选择」这两条从口头声明变成检验

背景：§8.2 把远档残差「归入分类与星等限选择」，但此前只有间接证据——
 (a) 星等：s527 的 G 匹配在固定 |Z| 下把近档选成晚型、远档选成早型，匹配后 27.6% → 6.2% 反而更陡，
     该检验放大组成效应，只能作辅助（台账 §14.4）；
 (b) 分类：只量化了 Teff 中位随 |Z| 上移，并用一次替代计算给出 1.96 → 2.22。

本脚本补两个**非退化**的检验：
 A. 星等限：在固定亚型与固定 |Z| 下，活动率是否还依赖 G？(logit: spline(z) + 亚型FE + a_G·(G-17))
    ——若 a_G ≈ 0，则星等限只通过亚型组成起作用，不构成额外偏置；
 B. 分类：按 Teff 重新指派亚型（映射用 <100 pc 档的逐亚型 Teff 中位），重算亚型内部降幅，
    与原标签下的降幅对照，看「标签漂移」能解释多少。

输入：data/lamost/dr13/dr13_mstellar_dM.csv + data/gaia/gaia_dr3_mstars.csv
输出：多个图及讨论/lnf_gresidual.csv、subtype_retype.csv
"""
import io, sys, os
import numpy as np, pandas as pd
from scipy.optimize import minimize
from scipy.special import expit
from astropy.coordinates import SkyCoord
import astropy.units as un

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
OUT = r'C:\Users\lingz\Desktop\复现老师工作\APJS\多个图及讨论'

def save(df, name, comments):
    fp = os.path.join(OUT, name)
    df.to_csv(fp, index=False, encoding='utf-8')
    txt = open(fp, encoding='utf-8').read()
    with open(fp, 'w', encoding='utf-8-sig') as f:
        f.write('\n'.join('# ' + c for c in comments) + '\n' + txt)
    print('  写出 %s（%d 行）' % (name, len(df)))

def wilson(k, n, z=1.96):
    if n == 0: return (np.nan, np.nan)
    p = k/n; d = 1 + z*z/n; c = (p + z*z/(2*n))/d
    h = z*np.sqrt(p*(1-p)/n + z*z/(4*n*n))/d
    return (100*(c-h), 100*(c+h))

cat = pd.read_csv('data/lamost/dr13/dr13_mstellar_dM.csv', low_memory=False,
                  usecols=['uid','subclass','teff','ewha','ewha_err','snrr',
                           'ra','dec','gaia_source_id','gaia_g_mean_mag'])
cat = cat[(cat.ewha > -20) & (cat.ewha <= 50) & (cat.ewha_err > 0) & (cat.ewha_err <= 5)].copy()
cat['active'] = (cat.ewha >= 0.75) & (cat.ewha > 3*cat.ewha_err)
cat['gaia_source_id'] = pd.to_numeric(cat.gaia_source_id, errors='coerce')
g = pd.read_csv('data/gaia/gaia_dr3_mstars.csv', low_memory=False,
                usecols=['source_id','parallax','parallax_error','ruwe'])
m = cat.merge(g, left_on='gaia_source_id', right_on='source_id', how='inner')
m = m[(m.parallax > 0.2) & (m.parallax/m.parallax_error > 5) & (m.ruwe < 1.4)].copy()
u = m.sort_values('ewha', ascending=False).drop_duplicates('uid').copy()
u['MG'] = u.gaia_g_mean_mag.values - 5*np.log10(np.clip(1000.0/u.parallax.values, 1, None)) + 5
u = u[u.MG >= 6].copy()
d_pc = 1000.0/u.parallax.values
sc = SkyCoord(ra=u.ra.values*un.deg, dec=u.dec.values*un.deg, distance=d_pc*un.pc, frame='icrs')
u['absz'] = np.abs(d_pc*np.sin(np.deg2rad(sc.galactic.b.deg)))
u = u[u.absz <= 3000].copy()
u['subc'] = u.subclass.astype(str)
print('样本 %d 颗，活动率 %.3f%%' % (len(u), 100*u.active.mean()))

# ---------- A. 固定亚型与 |Z| 后的残余星等依赖 ----------
print('\n=== A. 固定亚型+固定 |Z|，活动率是否还依赖 G ===')
subs = [s for s in sorted(u.subc.unique()) if (u.subc == s).sum() >= 500]
uu = u[u.subc.isin(subs)].copy()
z = uu.absz.values/1000.0; y = uu.active.values.astype(float)
G = pd.to_numeric(uu.gaia_g_mean_mag, errors='coerce').values
G = np.where(np.isfinite(G), G, np.nanmedian(G)) - 17.0
sdum = np.column_stack([(uu.subc.values == s).astype(float) for s in subs[1:]])
rows = []
for tag, extra, nm in [('R0 样条+亚型FE', [], 'none'),
                       ('R1 +G', [G], 'G'),
                       ('R2 +MG', [pd.to_numeric(uu.MG, errors='coerce').values - 9.0], 'MG')]:
    cols = [np.ones_like(z), z]
    for k0 in (0.05, 0.1, 0.2, 0.4, 0.6, 1.0):
        cols.append(np.clip(z-k0, 0, None))
    for j in range(sdum.shape[1]):
        cols.append(sdum[:, j])
    for e in extra:
        cols.append(np.nan_to_num(e, nan=0.0))
    X = np.column_stack(cols)
    def nll(b):
        p = expit(np.clip(X @ b, -30, 30))
        return -float((y*np.log(np.clip(p,1e-12,1)) + (1-y)*np.log(np.clip(1-p,1e-12,1))).sum())
    def gr(b):
        p = expit(np.clip(X @ b, -30, 30))
        return -(X.T @ (y - p))
    b0 = np.zeros(X.shape[1]); b0[0] = np.log(max(y.mean(),1e-6)/(1-max(y.mean(),1e-6)))
    r = minimize(nll, b0, method='BFGS', jac=gr, options=dict(maxiter=4000, gtol=1e-9))
    beta = r.x
    # 数值 Hessian 只对最后一个（星等）系数取标准误
    if extra:
        h = 1e-4; i = len(beta)-1
        d = np.zeros(len(beta)); d[i] = h
        g1 = gr(beta+d); g0 = gr(beta)
        sec = (g1[i]-g0[i])/h
        se = np.sqrt(1.0/max(sec, 1e-12))
        a = beta[i]
        print('  %-14s a = %+.4f ± %.4f /mag  → OR/0.5 mag = %.3f ；1 mag 改变活动率倍数 %.2f'
              % (tag, a, se, np.exp(0.5*a), np.exp(a)))
        rows.append(dict(model=tag, coef=a, se=se, or_per_half_mag=float(np.exp(0.5*a)),
                         factor_per_mag=float(np.exp(a)), n=int(len(uu)), aic=float(2*len(beta)+2*r.fun)))
    else:
        print('  %-14s 基准（无星等项）AIC = %.1f' % (tag, 2*len(beta)+2*r.fun))
        rows.append(dict(model=tag, coef=np.nan, se=np.nan, or_per_half_mag=np.nan,
                         factor_per_mag=np.nan, n=int(len(uu)), aic=float(2*len(beta)+2*r.fun)))
save(pd.DataFrame(rows), 'lnf_gresidual.csv', [
    's590-A：logit + 样条(|Z|) + 亚型FE (+ G 或 M_G)；检验固定亚型与 |Z| 后是否还有残余星等依赖',
    'coef 为每星等的 logit 系数；factor_per_mag = exp(coef)；G 以 17 等为原点，M_G 以 9 等为原点',
    '生成脚本：代码/s590_classification_maglimit.py'])

# ---------- B. 按 Teff 重新指派亚型 ----------
print('\n=== B. 按 Teff 重新指派亚型后，亚型内部降幅还剩多少 ===')
inner = u[u.absz < 100]
med = inner.groupby('subc').teff.median().dropna()
med = med[med.index.isin(subs)]
print('  <100 pc 档的逐亚型 Teff 中位：', ' '.join('%s %.0f' % (k, v) for k, v in med.items()))
def retype(t):
    if not np.isfinite(t): return None
    return min(med.index, key=lambda s: abs(t - med[s]))
u2 = u[u.subc.isin(subs)].copy()
u2['sub_new'] = [retype(t) for t in pd.to_numeric(u2.teff, errors='coerce').values]
rows2 = []
for sp in subs:
    a = u2[(u2.subc == sp) & (u2.absz < 100)]
    b = u2[(u2.subc == sp) & (u2.absz >= 200) & (u2.absz < 400)]
    a2 = u2[(u2.sub_new == sp) & (u2.absz < 100)]
    b2 = u2[(u2.sub_new == sp) & (u2.absz >= 200) & (u2.absz < 400)]
    if min(len(a), len(b), len(a2), len(b2)) == 0: continue
    f1, f2 = 100*a.active.mean(), 100*b.active.mean()
    g1, g2 = 100*a2.active.mean(), 100*b2.active.mean()
    print('  %-4s 原标签 %5.2f%% → %5.2f%%（%.2f×，n=%d/%d） | 按 Teff 重指派 %5.2f%% → %5.2f%%（%.2f×，n=%d/%d）'
          % (sp, f1, f2, f1/f2 if f2 else np.nan, len(a), len(b), g1, g2, g1/g2 if g2 else np.nan, len(a2), len(b2)))
    rows2.append(dict(subtype=sp, f_inner_label=f1, f_far_label=f2, ratio_label=f1/f2 if f2 else np.nan,
                      n_inner_label=len(a), n_far_label=len(b),
                      f_inner_retype=g1, f_far_retype=g2, ratio_retype=g1/g2 if g2 else np.nan,
                      n_inner_retype=len(a2), n_far_retype=len(b2)))
save(pd.DataFrame(rows2), 'subtype_retype.csv', [
    's590-B：按 <100 pc 档逐亚型 Teff 中位重新指派亚型（最近邻），比较原标签与重指派下的 200–400 pc 降幅',
    'ratio_label / ratio_retype = f(<100 pc) / f(200–400 pc)',
    '生成脚本：代码/s590_classification_maglimit.py'])
print('\ns590 完成')
