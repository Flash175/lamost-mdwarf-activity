# -*- coding: utf-8 -*-
"""s555：P0-1 复核——200 pc 以外到底是平台还是上升？
 1) 分亚型对比（<100 / 200-400 / 400-600 / 600-1000 / >400）
 2) 各远档对 <100 pc 组成的重加权值（含 bootstrap 95% 与 Kish 有效样本量）
 3) 固定亚型的 Teff / G / S/N 中位随 |Z| 的变化（选择系统检查）
"""
import io, sys, os
import numpy as np, pandas as pd
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
from astropy.coordinates import SkyCoord
import astropy.units as un

OUT = r'C:\Users\lingz\Desktop\复现老师工作\APJS\多个图及讨论'
rng = np.random.default_rng(20261027)

def wilson(k, n, z=1.96):
    if n == 0: return (np.nan, np.nan)
    p = k/n; d = 1 + z*z/n
    c = (p + z*z/(2*n))/d
    h = z*np.sqrt(p*(1-p)/n + z*z/(4*n*n))/d
    return (100*(c-h), 100*(c+h))

def save(df, name, comments):
    fp = os.path.join(OUT, name)
    df.to_csv(fp, index=False, encoding='utf-8')
    txt = open(fp, encoding='utf-8').read()
    with open(fp, 'w', encoding='utf-8-sig') as f:
        f.write('\n'.join('# ' + c for c in comments) + '\n' + txt)
    print('  写出 %s（%d 行）' % (name, len(df)))

cat = pd.read_csv('data/lamost/dr13/dr13_mstellar_dM.csv', low_memory=False,
                  usecols=['uid','subclass','teff','logg','ewha','ewha_err','snrr','ra','dec',
                           'gaia_source_id','gaia_g_mean_mag'])
cat = cat[(cat.ewha > -20) & (cat.ewha <= 50) & (cat.ewha_err > 0) & (cat.ewha_err <= 5)].copy()
cat['active'] = (cat.ewha >= 0.75) & (cat.ewha > 3*cat.ewha_err)
cat['gaia_source_id'] = pd.to_numeric(cat.gaia_source_id, errors='coerce')
g = pd.read_csv('data/gaia/gaia_dr3_mstars.csv', low_memory=False,
                usecols=['source_id','parallax','parallax_error','ruwe'])
m = cat.merge(g, left_on='gaia_source_id', right_on='source_id', how='inner')
m = m[(m.parallax > 0.2) & (m.parallax/m.parallax_error > 5) & (m.ruwe < 1.4)].copy()
u = m.sort_values('ewha', ascending=False).drop_duplicates('uid').copy()
# [giant-cut]
u['MG'] = u.gaia_g_mean_mag.values - 5*np.log10(np.clip(1000.0/u.parallax.values, 1, None)) + 5
u = u[u.MG >= 6].copy()
d = 1000.0/u.parallax.values
sc = SkyCoord(ra=u.ra.values*un.deg, dec=u.dec.values*un.deg, distance=d*un.pc, frame='icrs')
u['absz_pc'] = np.abs(d*np.sin(np.deg2rad(sc.galactic.b.deg)))
u = u[u.absz_pc <= 3000].copy()

BINS = [('<100', 0, 100), ('100-200', 100, 200), ('200-400', 200, 400),
        ('400-600', 400, 600), ('600-1000', 600, 1000), ('>400', 400, 3000), ('>1000', 1000, 3000)]
SUBS = ['dM0','dM1','dM2','dM3','dM4','dM5','dM6']

# ---------- 1. 分亚型 × 分档 ----------
rows = []
for lb, zl, zh in BINS:
    s = u[(u.absz_pc >= zl) & (u.absz_pc < zh)]
    for sp in SUBS:
        q = s[s.subclass == sp]
        if len(q) < 20: continue
        k, n = int(q.active.sum()), len(q); lo, hi = wilson(k, n)
        rows.append(dict(zbin=lb, subtype=sp, n=n, n_act=k, frac=100*k/n, lo=lo, hi=hi,
                         teff_med=float(q.teff.median()), g_med=float(q.gaia_g_mean_mag.median()),
                         snr_med=float(q.snrr.median())))
T = pd.DataFrame(rows)
print('=== 1. 分亚型 × 分档 ===')
P = T.pivot(index='subtype', columns='zbin', values='frac')[['<100','200-400','400-600','600-1000','>400']]
print(P.to_string(float_format=lambda x: '%.2f'))
print('\n各档 n：')
print(T.pivot(index='subtype', columns='zbin', values='n')[['<100','200-400','400-600','600-1000','>400']].fillna(0).astype(int).to_string())
save(T, 'far400_subtype_table.csv', [
    '>400 pc 的 2D 档分亚型明细（回答 P0-1）：<100 / 200-400 / 400-600 / 600-1000 / >400 / >1000',
    'frac 为百分数、lo/hi 为 Wilson 95%；teff_med/g_med/snr_med 为该格中位（选择系统检查）',
    'active = EW(Ha)>=0.75 A 且 >3sigma；2D 样本 639,702 颗（每星最大 EW 谱）',
    '生成脚本：代码/s555_reweight_by_bin.py'])

# ---------- 2. 重加权（对 <100 pc 组成）+ bootstrap + Kish n_eff ----------
base = u[u.absz_pc < 100]
w = base.subclass.value_counts(normalize=True)
print('\n=== 2. 对 <100 pc 组成的重加权（含 bootstrap 95%% 与有效样本量）===')
print('  <100 pc 权重：', {k: round(100*v, 1) for k, v in w.items() if k in SUBS})
res = []
for lb, zl, zh in [('200-400',200,400), ('400-600',400,600), ('600-1000',600,1000), ('>1000',1000,3000), ('>400',400,3000)]:
    s = u[(u.absz_pc >= zl) & (u.absz_pc < zh)]
    fr = s.groupby('subclass').active.agg(['mean','size'])
    common = [k for k in w.index if k in fr.index]
    ww = (w[common]/w[common].sum())
    rw = float((ww*fr.loc[common,'mean']).sum()*100)
    # Kish 有效样本量
    neff = float((ww.values**2*fr.loc[common,'size'].values).sum() and
                 (ww.values*fr.loc[common,'size'].values).sum()**2 /
                 (ww.values**2*fr.loc[common,'size'].values).sum())
    # bootstrap：在远档内按亚型分层重抽
    boot = []
    for _ in range(500):
        vals = []
        for sp in common:
            q = s[s.subclass == sp]
            idx = rng.integers(0, len(q), len(q))
            vals.append(ww[sp]*q.active.values[idx].mean())
        boot.append(100*np.sum(vals))
    boot = np.array(boot)
    print('  %-9s n=%6d 实测 %5.2f%%  重加权 %5.2f%%  95%%(bootstrap) [%.2f, %.2f]  有效 n=%.0f'
          % (lb, len(s), 100*s.active.mean(), rw, np.percentile(boot,2.5), np.percentile(boot,97.5), neff))
    res.append(dict(zbin=lb, n=len(s), frac_raw=100*s.active.mean(), frac_rw=rw,
                    rw_lo=float(np.percentile(boot,2.5)), rw_hi=float(np.percentile(boot,97.5)),
                    n_eff=neff))
R = pd.DataFrame(res)
save(R, 'reweight_by_bin.csv', [
    '各远档对 <100 pc 亚型组成的重加权活动比例（回答 P0-1）',
    'rw_lo/rw_hi 为 500 次分层 bootstrap 的 95% 区间（仅统计误差）；n_eff 为 Kish 有效样本量',
    '<100 pc 参考值 23.82%；200-400 pc 实测 7.80% / 重加权 12.18%',
    '生成脚本：代码/s555_reweight_by_bin.py'])

# ---------- 3. 固定亚型的选择系统检查 ----------
print('\n=== 3. 固定亚型：Teff / G / S/N 中位随 |Z| 的变化 ===')
for sp in ['dM0','dM2','dM4','dM5']:
    line = '  %-4s' % sp
    for lb, zl, zh in [('<100',0,100), ('200-400',200,400), ('400-600',400,600), ('600-1000',600,1000)]:
        q = u[(u.subclass == sp) & (u.absz_pc >= zl) & (u.absz_pc < zh)]
        line += '  | %s: Teff %.0f G %.2f S/N %.1f (n=%d)' % (lb, q.teff.median(), q.gaia_g_mean_mag.median(), q.snrr.median(), len(q))
    print(line)
print('\n整体 Teff 中位：', {lb: round(float(u[(u.absz_pc>=zl)&(u.absz_pc<zh)].teff.median()),0) for lb,zl,zh in BINS})
print('s555 完成')
