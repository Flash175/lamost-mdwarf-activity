# -*- coding: utf-8 -*-
"""修变量名冲突：分面板循环里的 ro1 覆盖了整体拟合的 ro1（导致 full_ro_sat_ols 与单面板图 knee 取值错）"""
import io, sys
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
P = 'repro/src/s189_fig5_official_v4.py'
s = open(P, encoding='utf-8').read()
OLD = """    ro1, p1 = ols(q); rm1, p2, si1 = ml(q)
    e1 = boot(q, n=120)
    res[nm] = (len(q), p1, e1, ro1, p2, rm1, si1)
    print('  %s: n=%d  beta(OLS)=%.3f+-%.3f  Ro_sat(OLS)=%.3f | beta(ML)=%.3f  Ro_sat(ML)=%.3f  sigma_int=%.2f'
          % (nm, len(q), p1, e1, ro1, p2, rm1, si1))"""
if OLD not in s:
    OLD = OLD.replace('beta', 'β').replace('sigma_int', 'σ_int').replace('+-', '±')
NEW = """    p_ro, p_b = ols(q); p_ro_ml, p_b_ml, si1 = ml(q)
    e1 = boot(q, n=120)
    res[nm] = (len(q), p_b, e1, p_ro, p_b_ml, p_ro_ml, si1)
    print('  %s: n=%d  beta(OLS)=%.3f+-%.3f  Ro_sat(OLS)=%.3f | beta(ML)=%.3f  Ro_sat(ML)=%.3f  sigma_int=%.2f'
          % (nm, len(q), p_b, e1, p_ro, p_b_ml, p_ro_ml, si1))"""
NEW = NEW.replace('beta', 'β').replace('sigma_int', 'σ_int').replace('+-', '±')
if OLD in s:
    s = s.replace(OLD, NEW, 1); print('  已修变量冲突')
else:
    old2 = '    ro1, p1 = ols(q); rm1, p2, si1 = ml(q)'
    if old2 in s:
        s = s.replace(old2, '    p_ro, p_b = ols(q); p_ro_ml, p_b_ml, si1 = ml(q)', 1)
        s = s.replace('res[nm] = (len(q), p1, e1, ro1, p2, rm1, si1)', 'res[nm] = (len(q), p_b, e1, p_ro, p_b_ml, p_ro_ml, si1)', 1)
        s = s.replace('% (nm, len(q), p1, e1, ro1, p2, rm1, si1))', '% (nm, len(q), p_b, e1, p_ro, p_b_ml, p_ro_ml, si1))', 1)
        print('  已修变量冲突（分段替换）')
    else:
        print('  !! 未找到目标行')
open(P, 'w', encoding='utf-8').write(s)
for i, l in enumerate(open(P, encoding='utf-8').read().splitlines(), 1):
    if 145 <= i <= 156: print('   %3d %s' % (i, l))
