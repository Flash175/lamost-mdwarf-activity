# -*- coding: utf-8 -*-
"""解析 Ibañez Bustos 2025 的 Table B1 时间序列，用 Lomb-Scargle 自算活动周期（3-19 yr 区间）"""
import io, os, re, sys
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
import numpy as np, pandas as pd
from scipy.signal import lombscargle

SRC = r'C:\Users\lingz\.dsh-community\attachments\v1\files\31\31afcd15d6f6354f1aaff218069e1030f10d7983a87b4efd8b3ac878bde8b2e4\tableb1.dat.txt'
rows = []
for line in open(SRC, encoding='utf-8', errors='replace'):
    if len(line.strip()) < 10: continue
    m = re.match(r'^(.{10})(\s*\d+\.?\d*)\s+(.*)$', line.rstrip('\n'))
    if not m: continue
    star = m.group(1).strip(); jd = float(m.group(2)); rest = m.group(3).strip()
    val = rest.split()[-1]
    try: rows.append((star, jd, float(val)))
    except Exception: pass
t = pd.DataFrame(rows, columns=['star', 'hjd', 'val'])
print('解析到 %d 个观测点，%d 颗星' % (len(t), t.star.nunique()))
print('每星点数 中位 %.0f  最少 %d  最多 %d' % (t.groupby('star').size().median(), t.groupby('star').size().min(), t.groupby('star').size().max()))
base = (t.groupby('star').hjd.max() - t.groupby('star').hjd.min())/365.25
print('时间基线（年）中位 %.1f  最短 %.1f  最长 %.1f' % (base.median(), base.min(), base.max()))
out = []
for star, g in t.groupby('star'):
    g = g.sort_values('hjd')
    x = (g.hjd.values - g.hjd.min())/365.25
    y = g.val.values
    if len(x) < 15 or x.max() < 5: continue
    y = y - y.mean()
    if not np.isfinite(y).all() or y.std() == 0: continue
    f = np.linspace(1/25.0, 1/0.5, 20000)      # 周期 0.5 - 25 yr
    p = lombscargle(x, y, f*2*np.pi, normalize=True)
    i = int(np.argmax(p)); pk = float(p[i]); P = 1.0/f[i]
    N = len(x)
    fap = (1.0 - pk) ** ((N - 3)/2.0)          # 标准 LS 虚警概率近似
    # 次峰：避开主峰 ±10%
    mask = np.abs(f - f[i]) > 0.1*f[i]
    j = int(np.argmax(np.where(mask, p, -1))); P2 = 1.0/f[j]; pk2 = float(p[j])
    out.append(dict(star=star, N=N, baseline_yr=round(float(x.max()), 1), P_yr=round(P, 2),
                    power=round(pk, 3), FAP=fap, P2_yr=round(P2, 2), power2=round(pk2, 3)))
r = pd.DataFrame(out).sort_values('P_yr')
os.makedirs('data/processed/dr13', exist_ok=True)
r.to_csv('data/processed/dr13/ib2025_periodogram_selfcomputed.csv', index=False)
print('\n=== 自算结果（按周期排序，前 20）===')
pd.set_option('display.width', 200)
print(r.head(20).to_string(index=False))
print('\n探测统计：FAP<0.01 有 %d 颗；FAP<0.05 有 %d 颗；3-19 yr 内且 FAP<0.05 有 %d 颗'
      % (int((r.FAP < 0.01).sum()), int((r.FAP < 0.05).sum()), int(((r.P_yr >= 3) & (r.P_yr <= 19) & (r.FAP < 0.05)).sum())))
# 与我们已有 P_rot 的交集
cyc = pd.read_csv('data/raw/activity_cycle_data_complete.csv')
have = set(cyc.Star.astype(str).str.replace(' ', '').str.upper())
r['k'] = r.star.str.replace(' ', '').str.upper()
inter = r[r.k.isin(have)]
print('\n与现有 P_rot 表可配对的星：')
print(inter[['star', 'N', 'baseline_yr', 'P_yr', 'FAP']].to_string(index=False) if len(inter) else '   无')
