# -*- coding: utf-8 -*-
"""重绘附录图 附_IB2025_自算周期_FAP.png（22 星解析 FAP 分布）。

投稿包自包含版本：只读本包 数据/ 下的两张表，不碰 OneDrive。
与 s226/s227/s228 三代脚本的最终渲染参数逐项对齐，默认输出与现行 PNG 逐像素一致。

用法
    python 代码/s248_redraw_ib2025_fap.py                  # 中性标题（**默认 = 定稿图**）
    python 代码/s248_redraw_ib2025_fap.py --legacy-title   # 旧标题（含作废论断，仅供对照，不得投稿）

为什么默认改成中性标题（2026-10-23 10:55 拍板）：旧图大标题「20 of 22 stars show FAP < 0.05」
正是 Methods §七 L161 已标明「基于解析 FAP、偏宽松、**已作废**」的论断。图注只能解释它、
不能覆盖它，而审稿人先读图题、后读图注——图面残留比文档措辞风险更直接。中性版
「analytic FAP of the best Lomb-Scargle peak (22 stars)」不丢任何物理信息（星数、口径、
方法、判据全在），且与标题下第二行「filled: FAP < 0.01 …」仍自洽。

默认与定稿图逐像素一致是本包的硬约束，故**不保留「默认出旧标题」这条路**；旧标题只能
显式加 `--legacy-title` 复现，且脚本会打警告。`--neutral-title` 仍被接受（空操作），
以免旧命令行报错。
"""
import io, os, sys, argparse
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DATA = os.path.join(ROOT, '数据')
FIG = os.path.join(ROOT, '图')
OUT = os.path.join(FIG, '附_IB2025_自算周期_FAP.png')

FAP_SHOW = 0.05     # 入图的解析 FAP 上限（整张图的可视门槛）
FAP_FILL = 0.01     # 实心标记门槛
FAP_STRICT = 1e-3   # 严格置换判据：置换 FAP <= 0.1%
RATIO_MAX = 0.75    # 严格判据的基线占比上限
SPAN = (3, 19)      # IB2025 正文报的周期范围（阴影）

ap = argparse.ArgumentParser()
ap.add_argument('--neutral-title', action='store_true',
                help='（已升为默认，保留此开关仅为兼容旧命令行，无实际作用）')
ap.add_argument('--legacy-title', action='store_true',
                help='复现 2026-10-23 之前的旧标题（含已作废论断 "20 of 22"，仅供对照，不得投稿）')
args = ap.parse_args()
legacy_title = args.legacy_title and not args.neutral_title
if args.legacy_title and args.neutral_title:
    print('  [warn] --legacy-title 与 --neutral-title 同时给出，按中性标题执行')

# ---------------------------------------------------------------- 读表
r = pd.read_csv(os.path.join(DATA, 'IB2025_时间序列自算周期_22星.csv'))
q = pd.read_csv(os.path.join(DATA, 'IB2025_周期质量表_置换FAP.csv'))

det = r[r.FAP < FAP_SHOW].sort_values('P_yr', ascending=False).reset_index(drop=True)

# ---------------------------------------------------------------- 断言
assert len(r) == 22, '可分析星应为 22 颗，实为 %d' % len(r)
assert len(det) == 20, '解析 FAP<0.05 应为 20 颗，实为 %d' % len(det)
assert int((det.FAP < FAP_FILL).sum()) == 19, '实心标记应为 19 颗'
# 3–19 yr 计数有两个口径，不可混：无条件全样本 vs 旧论断口径（FAP<0.05 且落在 3–19）
n_in_all = int(((r.P_yr >= SPAN[0]) & (r.P_yr <= SPAN[1])).sum())
n_in_det = int(((det.P_yr >= SPAN[0]) & (det.P_yr <= SPAN[1])).sum())
assert n_in_all == 17, '无条件落在 3–19 yr 应为 17 颗（22 星全样本），实为 %d' % n_in_all
assert n_in_det == 15, 'FAP<0.05 且落在 3–19 yr 应为 15 颗（旧论断口径），实为 %d' % n_in_det
assert len(det) < len(r), '应恰有 2 颗被 FAP>0.05 挡在图外'

# 本图数据必须与正文所用的质量表同源（星名、周期、解析 FAP 三列逐行对齐）
m = r.merge(q[['star', 'P_yr', 'FAP', 'base_ratio']], on='star', suffixes=('', '_q'), how='outer',
            indicator=True)
assert (m._merge == 'both').all(), '两表星名不一致：%s' % list(m[m._merge != 'both'].star)
assert np.allclose(m.P_yr, m.P_yr_q, atol=5e-3), '两表周期不一致'
assert np.allclose(np.log10(m.FAP), np.log10(m.FAP_q), atol=1e-6), '两表解析 FAP 不一致'

# 严格置换判据：6 颗被检、3 颗通过，且通过者恰为 GJ 273 / GJ 876 / GJ 205
perm = q[q.perm_FAP.notna()]
strict = perm[perm.perm_FAP <= FAP_STRICT]
assert len(perm) == 6, '置换检验星数应为 6，实为 %d' % len(perm)
assert len(strict) == 3, '严格判据通过数应为 3，实为 %d' % len(strict)
assert set(strict.star) == {'GJ 273', 'GJ 876', 'GJ 205'}, '通过者名单不符：%s' % list(strict.star)
assert (strict.base_ratio <= RATIO_MAX).all(), '通过者的基线占比应 <= 0.75'
assert set(q[(q.FAP < FAP_FILL) & (q.base_ratio <= RATIO_MAX)].star) >= set(strict.star)

# pass=True 的 11 行 = 3 严格 + 8 仅宽松；GJ 699 解析过宽松线但置换 0.027 被否，不在其中
passed = q[q['pass']]
loose = q[(q.FAP < FAP_FILL) & (q.base_ratio <= RATIO_MAX)]
assert len(passed) == 11, 'pass=True 应为 11 行，实为 %d' % len(passed)
assert len(loose) == 12, '宽松判据应为 12 颗，实为 %d' % len(loose)
assert set(passed.star) == set(loose.star) - {'GJ 699'}, 'pass=True 与「宽松 12 颗 − GJ 699」不一致'
assert 'GJ 699' not in set(passed.star), 'GJ 699 置换被否，不得计入 pass=True'
r699 = q[q.star == 'GJ 699'].iloc[0]
assert r699.FAP < FAP_FILL and r699.base_ratio <= RATIO_MAX and r699.perm_FAP > FAP_STRICT, \
    'GJ 699 应为「过解析、过宽松、被置换否决」的反例'

# 图面点全部落在坐标域内（对数轴出界会被裁掉，却仍留在图例/刻度里）
assert det.P_yr.min() > 1.9 and det.P_yr.max() < 32, '有点落在 xlim 之外'

# ---------------------------------------------------------------- 绘图
fig, ax = plt.subplots(figsize=(6.8, 5.2))
ax.axvspan(SPAN[0], SPAN[1], color='#dfe9ff', zorder=0)
y = np.arange(len(det))
ax.errorbar(det.P_yr, y, xerr=np.abs(det.P2_yr - det.P_yr), fmt='none',
            elinewidth=0.7, ecolor='0.65', zorder=2)
ax.scatter(det.P_yr, y, s=34, c=np.where(det.FAP < FAP_FILL, '#1f4fd8', 'white'),
           edgecolor='#1f4fd8', lw=1.0, zorder=3)
ax.set_yticks(y)
ax.set_yticklabels(['%s  (N=%d, %.0f yr)' % (s, n, b)
                    for s, n, b in zip(det.star, det.N, det.baseline_yr)], fontsize=7.2)
ax.set_xscale('log')
ax.set_xlim(1.9, 32)
ax.xaxis.set_major_locator(mticker.FixedLocator([2, 3, 5, 10, 20]))
ax.xaxis.set_major_formatter(mticker.FixedFormatter(['2', '3', '5', '10', '20']))
ax.xaxis.set_minor_formatter(mticker.NullFormatter())
ax.text(0.02, 0.02, 'shaded: 3-19 yr (range reported by Ibanez Bustos et al. 2025)',
        transform=ax.transAxes, fontsize=7, color='0.35')
ax.set_xlabel('P$_{cyc}$ (yr) — our Lomb-Scargle recomputation', fontsize=10)

if legacy_title:
    line1 = ('Ibanez Bustos et al. (2025) Table B1: %d of %d stars show FAP < 0.05'
             % (len(det), len(r)))
    print('  [warn] 旧标题模式：图面含已作废论断（Methods §七 L161），仅供对照，不得投稿')
else:
    # 中性标题：用拍板时的原话 "analytic FAP of the best LS peak (22 stars)"。
    # 注意不能写全 "Lomb-Scargle"——实测标题会横向溢出到 x1=1.04（见下方 bbox 断言）；
    # 保持 9 pt / 两行不变，则 tight_layout 留给标题的高度不变，绘图区逐像素不动。
    line1 = ('Ibanez Bustos et al. (2025) Table B1: analytic FAP of the best '
             'LS peak (%d stars)' % len(r))
ax.set_title(line1 + '\nfilled: FAP < 0.01;  horizontal bars: separation from the secondary peak',
             fontsize=9)

ax.tick_params(direction='in', top=True, right=True, labelsize=8)
ax.grid(alpha=0.25, axis='x', lw=0.4)
ax.set_ylim(-0.8, len(det) - 0.2)
fig.text(0.5, 0.012,
         'Recomputed by us from the published time series (2,806 points, 33 stars; '
         'Lomb-Scargle, 2-25 yr, baseline >= 8 yr).\n'
         'These are OUR estimates, not the values published by the authors.',
         ha='center', fontsize=6.5, color='0.3', linespacing=1.5)
fig.tight_layout(rect=(0, 0.075, 1, 1))

# ---------------------------------------------------------------- 版式断言
fig.canvas.draw()
ren = fig.canvas.get_renderer()
ft = [t for t in fig.texts][-1]
fb = ft.get_window_extent(renderer=ren).transformed(fig.transFigure.inverted())
xb = ax.xaxis.label.get_window_extent(renderer=ren).transformed(fig.transFigure.inverted())
tb = ax.title.get_window_extent(renderer=ren).transformed(fig.transFigure.inverted())
assert fb.y1 < xb.y0 - 0.004, '脚注压 xlabel：foot.y1=%.4f xlabel.y0=%.4f' % (fb.y1, xb.y0)
assert fb.x0 > 0.0 and fb.x1 < 1.0, '脚注横向溢出：%.4f-%.4f' % (fb.x0, fb.x1)
assert tb.y1 < 0.995, '标题触顶：%.4f' % tb.y1
assert tb.x0 > 0.0 and tb.x1 < 1.0, '标题横向溢出：%.4f-%.4f' % (tb.x0, tb.x1)
if not legacy_title:
    assert 'show FAP' not in ax.get_title(), '中性标题里混入了已作废论断（Methods §七 L161）'
    assert '%d stars)' % len(r) in ax.get_title(), '中性标题缺星数（应含 "%d stars)"）' % len(r)
print('bbox  foot.y1=%.4f < xlabel.y0=%.4f ; foot x %.4f-%.4f ; title x %.4f-%.4f y1=%.4f'
      % (fb.y1, xb.y0, fb.x0, fb.x1, tb.x0, tb.x1, tb.y1))

fig.savefig(OUT, dpi=180)
plt.close(fig)

# 若复现工程目录存在，同步一份镜像（不存在则跳过）
mirror = os.path.join(os.path.dirname(os.path.dirname(ROOT)), '复现老师工作', '图', '对照与备选')
if os.path.isdir(mirror):
    import shutil
    shutil.copy2(OUT, os.path.join(mirror, os.path.basename(OUT)))
    print('  已同步镜像:', mirror)

print('入图 %d 颗（解析 FAP<%.2f）；实心 %d 颗；落在 3–19 yr：无条件 %d 颗 / FAP<0.05 且 3–19（旧论断口径）%d 颗'
      % (len(det), FAP_SHOW, int((det.FAP < FAP_FILL).sum()), n_in_all, n_in_det))
print('严格置换：%d 颗被检、%d 颗通过（%s）'
      % (len(perm), len(strict), ' / '.join(sorted(strict.star))))
print('pass=True %d 行 = 严格 %d + 仅宽松 %d；GJ 699（解析 FAP %.4f / 置换 %.3f）被置换否决，不计入'
      % (len(passed), len(strict), len(passed) - len(strict), r699.FAP, r699.perm_FAP))
print('  标题模式:', 'legacy（含作废论断，不得投稿）' if legacy_title else 'neutral（定稿）')
print('  输出:', OUT)
