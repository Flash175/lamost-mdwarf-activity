
import pandas as pd, numpy as np
D = r'C:\Users\lingz\Desktop\复现老师工作\APJS\多个图及讨论'
SUB = ['dM0','dM1','dM2','dM3','dM4','dM5','dM6']
cl = pd.read_csv(D + r'\金属度_清洁样本_637973.csv', low_memory=False,
                 usecols=['uid','subclass','absz','active','ruwe'])
cl = cl[cl.subclass.isin(SUB)]
def seq(s, near=(0,100), far=(200,400)):
    a = s[(s.absz>near[0])&(s.absz<=near[1])]; b = s[(s.absz>far[0])&(s.absz<=far[1])]
    rows=[]
    for st in SUB:
        x, y = a[a.subclass==st], b[b.subclass==st]
        rows.append(dict(st=st, na=len(x), nb=len(y), fa=x.active.mean(), fb=y.active.mean()))
    t = pd.DataFrame(rows).set_index('st'); t['wa']=t.na/t.na.sum(); t['wb']=t.nb/t.nb.sum()
    fn, ff = (t.wa*t.fa).sum(), (t.wb*t.fb).sum()
    within = float((t.wb*(t.fa-t.fb)).sum())     # far weights
    comp   = float((t.fa*(t.wa-t.wb)).sum())     # near fractions
    return 100*(fn-ff), 100*within, 100*comp, 100*within/(fn-ff)
print('validation vs paper (10.63 / 5.40 for 200-400; 7.69 / 3.21 for 100-200):')
for far in [(100,200),(200,400)]:
    Dp, wi, co, sh = seq(cl, (0,100), far)
    print('  far %s: D=%.2f within=%.2f comp=%.2f share=%.1f%%' % (far, Dp, wi, co, sh))
print('\ntiers:')
rows=[]
for tier, lim in [('ruwe<1.4',1.4),('ruwe<1.3',1.3),('ruwe<1.2',1.2),('ruwe<1.1',1.1)]:
    s = cl[cl.ruwe<lim]
    Dp, wi, co, sh = seq(s, (0,100), (200,400))
    rows.append(dict(tier=tier, n=len(s), D=Dp, within=wi, comp=co, share=sh))
print(pd.DataFrame(rows).round(3).to_string(index=False))
