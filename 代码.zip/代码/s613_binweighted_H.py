# -*- coding: utf-8 -*-
"""s613：三档二项加权指数拟合——正文 §2.9 的 H = 192 ± 1.5 pc（名义值）落档。

口径（与台账 §六十 / L1403 一致）：
  三档 f = 23.81 / 12.90 / 7.78%（<100 / 100–200 / 200–400 pc），z 取档中位 50 / 150 / 300 pc，
  权重 = 1/σ²(ln f)，σ(ln f) = sqrt((1−p)/(n·p))，p 为活动比例、n 为该档星数。
"""
import io, os, sys
import numpy as np

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")
DATA = r"C:\Users\lingz\Desktop\复现老师工作\APJS\多个图及讨论"

z = np.array([50.0, 150.0, 300.0])
p = np.array([0.2381, 0.1290, 0.0778])
n = np.array([177128, 170974, 191179])

y = np.log(p)
s = np.sqrt((1 - p) / (n * p))
w = 1.0 / s**2
W = np.diag(w)
X = np.column_stack([np.ones_like(z), z])
beta, *_ = np.linalg.lstsq(X * np.sqrt(w)[:, None], y * np.sqrt(w), rcond=None)
cov = np.linalg.inv(X.T @ W @ X)
se = np.sqrt(np.diag(cov))
b = beta[1]
H = -1.0 / b
H_se = abs(se[1] / b**2)
chi2 = float(((y - X @ beta) ** 2 * w).sum())
print("a = %.6f ± %.6f" % (beta[0], se[0]))
print("b = %.6f ± %.6f /pc" % (b, se[1]))
print("H = %.1f ± %.1f pc；χ² = %.1f（dof = 1）" % (H, H_se, chi2))

out = os.path.join(DATA, "binweighted_H.csv")
with open(out, "w", encoding="utf-8") as f:
    f.write("# s613：三档二项加权指数拟合（正文 §2.9 的 H = 192 ± 1.5 pc 名义值）\n")
    f.write("# 三档 z 中位 50/150/300 pc，p = 23.81/12.90/7.78%%，n = 177,128/170,974/191,179\n")
    f.write("# 权重 = 1/sigma^2(ln f)，sigma = sqrt((1-p)/(n*p))\n")
    f.write("# 生成脚本：代码/s613_binweighted_H.py\n")
    f.write("term,coef,se\n")
    f.write("a,%.8f,%.8f\n" % (beta[0], se[0]))
    f.write("b_per_pc,%.8f,%.8f\n" % (b, se[1]))
    f.write("H_pc,%.2f,%.2f\n" % (H, H_se))
    f.write("chi2,%.2f,\n" % chi2)
print("写出", out, os.path.getsize(out), "B")
