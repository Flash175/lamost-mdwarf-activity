# -*- coding: utf-8 -*-
"""s596：远档「标签漂移」能不能用现有谱直接检验——先把覆盖率算出来

问题：§3.3 的标签漂移结论（远档 dM4 实为 dM2 一类）目前建立在**目录 Teff 中位**上。
若要用谱重新定亚型，必须先知道：各 |Z| 档里有多少比例的星已经有本地谱（data/lrs/dr13 + dr13_rest），
以及这些星的 S/N 分布是否够做谱型判定。

输出：多个图及讨论/spectra_coverage_by_zbin.csv
"""
import io, sys, os
import numpy as np, pandas as pd
from astropy.coordinates import SkyCoord
import astropy.units as un

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
OUT = r'C:\Users\lingz\Desktop\复现老师工作\APJS\多个图及讨论'
BASE = r'C:\Users\lingz\OneDrive\Desktop\复现老师工作'

cat = pd.read_csv(os.path.join(BASE, 'data', 'lamost', 'dr13', 'dr13_mstellar_dM.csv'),
                  low_memory=False, usecols=['obsid','uid','subclass','teff','ewha','ewha_err','snrr',
                                             'ra','dec','gaia_source_id','gaia_g_mean_mag'])
cat = cat[(cat.ewha > -20) & (cat.ewha <= 50) & (cat.ewha_err > 0) & (cat.ewha_err <= 5)].copy()
cat['active'] = (cat.ewha >= 0.75) & (cat.ewha > 3*cat.ewha_err)
cat['gaia_source_id'] = pd.to_numeric(cat.gaia_source_id, errors='coerce')
g = pd.read_csv(os.path.join(BASE, 'data', 'gaia', 'gaia_dr3_mstars.csv'), low_memory=False,
                usecols=['source_id','parallax','parallax_error','ruwe'])
m = cat.merge(g, left_on='gaia_source_id', right_on='source_id', how='inner')
m = m[(m.parallax > 0.2) & (m.parallax/m.parallax_error > 5) & (m.ruwe < 1.4)].copy()
u = m.sort_values('ewha', ascending=False).drop_duplicates('uid').copy()
u['MG'] = u.gaia_g_mean_mag.values - 5*np.log10(np.clip(1000.0/u.parallax.values, 1, None)) + 5
u = u[u.MG >= 6].copy()
d_pc = 1000.0/u.parallax.values
sc = SkyCoord(ra=u.ra.values*un.deg, dec=u.dec.values*un.deg, distance=d_pc*un.pc, frame='icrs')
u['absz'] = np.abs(d_pc*np.sin(np.deg2rad(sc.galactic.b.deg)))
u = u[u.absz <= 3000].copy()

have = set()
for sub in ['lrs/dr13', 'lrs/dr13_rest']:
    dd = os.path.join(BASE, 'data', sub)
    if os.path.isdir(dd):
        with os.scandir(dd) as it:
            for e in it:
                if e.name.endswith('.csv.gz') and e.stat().st_size > 500:
                    have.add(e.name[:-7])
print('本地谱文件合计 %d 条（dr13 + dr13_rest）' % len(have))
u['has_spec'] = u.obsid.astype(str).isin(have)
print('2D 样本 %d 颗；其中 %d 颗的 obsid 有本地谱（%.1f%%）'
      % (len(u), int(u.has_spec.sum()), 100*u.has_spec.mean()))

BINS = [(0,100,'<100'),(100,200,'100-200'),(200,400,'200-400'),(400,600,'400-600'),
        (600,1000,'600-1000'),(1000,3000,'>1000')]
rows = []
for lo, hi, nm in BINS:
    q = u[(u.absz > lo) & (u.absz <= hi)]
    if len(q) == 0: continue
    sub = q[q.has_spec]
    print('  %-9s 星数 %6d  有谱 %6d（%5.1f%%）  有谱者 S/N 中位 %5.1f  |  全档 S/N 中位 %5.1f'
          % (nm, len(q), len(sub), 100*len(sub)/len(q),
             np.nanmedian(sub.snrr) if len(sub) else np.nan, np.nanmedian(q.snrr)))
    rows.append(dict(zbin=nm, n_stars=len(q), n_with_spec=len(sub), frac_with_spec=100*len(sub)/len(q),
                     snr_med_with_spec=float(np.nanmedian(sub.snrr)) if len(sub) else np.nan,
                     snr_med_all=float(np.nanmedian(q.snrr))))
    # 远档细分：dM4 / dM5
    if nm in ('400-600', '600-1000'):
        for sp in ('dM4', 'dM5', 'dM2'):
            z = q[q.subclass == sp]
            if len(z) == 0: continue
            zs = z[z.has_spec]
            print('      %s: %4d 颗，有谱 %4d（%5.1f%%），有谱者 S/N 中位 %.1f'
                  % (sp, len(z), len(zs), 100*len(zs)/len(z), np.nanmedian(zs.snrr) if len(zs) else np.nan))
            rows.append(dict(zbin='%s/%s' % (nm, sp), n_stars=len(z), n_with_spec=len(zs),
                             frac_with_spec=100*len(zs)/len(z),
                             snr_med_with_spec=float(np.nanmedian(zs.snrr)) if len(zs) else np.nan,
                             snr_med_all=float(np.nanmedian(z.snrr))))
T = pd.DataFrame(rows)
fp = os.path.join(OUT, 'spectra_coverage_by_zbin.csv')
T.to_csv(fp, index=False, encoding='utf-8')
txt = open(fp, encoding='utf-8').read()
hdr = ('# s596：各 |Z| 档（及 400 pc 以外按亚型）的本地谱覆盖率与 S/N，用于判断能否做「按光谱重定亚型」\n'
       '# 本地谱 = data/lrs/dr13（154,309 条存档） + data/lrs/dr13_rest（本次下载）；只统计 >500 B 的文件\n'
       '# 生成脚本：代码/s596_spectra_coverage.py\n')
open(fp, 'w', encoding='utf-8-sig').write(hdr + txt)
print('\n写出 spectra_coverage_by_zbin.csv（%d 行）' % len(T))
