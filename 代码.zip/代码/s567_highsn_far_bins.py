# -*- coding: utf-8 -*-
"""s567：远档「选择系统 vs 真实老年活动基线」的判决实验。
只取高信噪比（S/N >= 15）子样本，按 <100 pc 的亚型组成重加权，
看远档的本征活动率是否朝 P1 预测（2.85% / 1.00%）塌下来。
"""
import io, sys, os
import numpy as np, pandas as pd
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
from astropy.coordinates import SkyCoord
import astropy.units as un
OUT = r'C:\Users\lingz\Desktop\复现老师工作\APJS\多个图及讨论'
SUBS = ['dM0','dM1','dM2','dM3','dM4','dM5','dM6','dM7','dM8']

def save(df, name, comments):
    fp = os.path.join(OUT, name); df.to_csv(fp, index=False, encoding='utf-8')
    txt = open(fp, encoding='utf-8').read()
    with open(fp, 'w', encoding='utf-8-sig') as f:
        f.write('\n'.join('# ' + c for c in comments) + '\n' + txt)
    print('  写出 %s（%d 行）' % (name, len(df)))

def wilson(k, n, z=1.96):
    if n == 0: return (np.nan, np.nan)
    p = k/n; d = 1+z*z/n; c = (p+z*z/(2*n))/d
    h = z*np.sqrt(p*(1-p)/n + z*z/(4*n*n))/d
    return 100*(c-h), 100*(c+h)

cat = pd.read_csv('data/lamost/dr13/dr13_mstellar_dM.csv', low_memory=False,
                  usecols=['uid','subclass','teff','ewha','ewha_err','snrr','ra','dec',
                           'gaia_source_id','gaia_g_mean_mag'])
cat = cat[(cat.ewha > -20) & (cat.ewha <= 50) & (cat.ewha_err > 0) & (cat.ewha_err <= 5)].copy()
cat['active'] = (cat.ewha >= 0.75) & (cat.ewha > 3*cat.ewha_err)
cat['gaia_source_id'] = pd.to_numeric(cat.gaia_source_id, errors='coerce')
g = pd.read_csv('data/gaia/gaia_dr3_mstars.csv', low_memory=False,
                usecols=['source_id','parallax','parallax_error','ruwe'])
m = cat.merge(g, left_on='gaia_source_id', right_on='source_id', how='inner')
m = m[(m.parallax > 0.2) & (m.parallax/m.parallax_error > 5) & (m.ruwe < 1.4)].copy()
u = m.sort_values('ewha', ascending=False).drop_duplicates('uid').copy()
# [giant-cut] 去巨星：M_G >= 6（M 矮星 +8~+16；切口同时含亚巨星与误分类早型矮星）
u['MG'] = u.gaia_g_mean_mag.values - 5*np.log10(np.clip(1000.0/u.parallax.values, 1, None)) + 5
u = u[u.MG >= 6].copy()
d = 1000.0/u.parallax.values
sc = SkyCoord(ra=u.ra.values*un.deg, dec=u.dec.values*un.deg, distance=d*un.pc, frame='icrs')
u['absz'] = np.abs(d*np.sin(np.deg2rad(sc.galactic.b.deg)))
u = u[u.absz <= 3000].copy()
u['sp'] = np.where(u.subclass.isin(SUBS), u.subclass, 'other')
plane = u[u.absz < 100]
w = plane.sp.value_counts(normalize=True)

BINS = [('<100',0,100), ('100-200',100,200), ('200-400',200,400), ('400-600',400,600), ('600-1000',600,1000)]
rows = []
print('=== 只取 S/N >= 15（并给出全样本作对照）===')
print(' 档         n(全)  活动%%(全)   n(SNR15)  活动%%(SNR15)   重加权(全)  重加权(SNR15)   Teff中位(全/SNR15)')
for lb, zl, zh in BINS:
    s = u[(u.absz >= zl) & (u.absz < zh)]
    hi = s[s.snrr >= 15]
    def rw(df):
        q = df.groupby('sp').active.agg(['mean','size'])
        common = [k for k in w.index if k in q.index]
        ww = w[common]/w[common].sum()
        return 100*float((ww*q.loc[common,'mean']).sum())
    f_all, f_hi = 100*s.active.mean(), 100*hi.active.mean()
    lo1, hi1 = wilson(int(s.active.sum()), len(s)); lo2, hi2 = wilson(int(hi.active.sum()), len(hi))
    rw_all, rw_hi = rw(s), rw(hi)
    print('  %-9s %6d  %5.2f%%   %6d   %5.2f%% [%.1f,%.1f]   %6.2f      %6.2f        %.0f / %.0f'
          % (lb, len(s), f_all, len(hi), f_hi, lo2, hi2, rw_all, rw_hi, s.teff.median(), hi.teff.median()))
    rows.append(dict(zbin=lb, n_all=len(s), frac_all=f_all, lo_all=lo1, hi_all=hi1,
                     n_hi=len(hi), frac_hi=f_hi, lo_hi=lo2, hi_hi=hi2,
                     rw_all=rw_all, rw_hi=rw_hi,
                     teff_all=float(s.teff.median()), teff_hi=float(hi.teff.median()),
                     g_all=float(s.gaia_g_mean_mag.median()), g_hi=float(hi.gaia_g_mean_mag.median()),
                     snr_all=float(s.snrr.median()), snr_hi=float(hi.snrr.median())))
T = pd.DataFrame(rows)
save(T, 'highsn_far_bins.csv', [
    '判决实验：远档只取 S/N>=15 的子样本，看本征活动率是否朝 P1 预测（2.85%/1.00%）塌下来',
    'frac_all/rw_all = 全样本的合并值与「按 <100 pc 组成重加权」值；frac_hi/rw_hi 为 S/N>=15 子样本的同口径值',
    'lo_hi/hi_hi 为 S/N>=15 子样本的 Wilson 95%；teff/g/snr 中位用于检查选择系统是否仍在',
    '生成脚本：代码/s567_highsn_far_bins.py'])

# 逐亚型：远档里 S/N>=15 的 dM0/dM2 还有多少
print('\n=== 远档各亚型在 S/N>=15 下的活动率（只列 n>=50）===')
rows = []
for lb, zl, zh in [('400-600',400,600), ('600-1000',600,1000)]:
    s = u[(u.absz >= zl) & (u.absz < zh)]
    hi = s[s.snrr >= 15]
    for sp in SUBS:
        q = hi[hi.sp == sp]
        if len(q) < 50: continue
        lo, hh = wilson(int(q.active.sum()), len(q))
        qa = s[s.sp == sp]
        print('  %-7s %-4s n(SNR15)=%5d 活动 %5.1f%% [%.1f,%.1f]   （全样本 %5.1f%%, n=%d）'
              % (lb, sp, len(q), 100*q.active.mean(), lo, hh, 100*qa.active.mean(), len(qa)))
        rows.append(dict(zbin=lb, subtype=sp, n_hi=len(q), frac_hi=100*q.active.mean(), lo=lo, hi=hh,
                         n_all=len(qa), frac_all=100*qa.active.mean()))
save(pd.DataFrame(rows), 'highsn_far_subtype.csv', [
    '远档在 S/N>=15 子样本下、逐亚型的活动率（只列 n>=50 的格），与全样本同格对照',
    '用途：判断「高 S/N 截断后活动率是否塌下来」，避免组成混杂',
    '生成脚本：代码/s567_highsn_far_bins.py'])
print('s567 完成')
