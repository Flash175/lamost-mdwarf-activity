
# -*- coding: utf-8 -*-
"""看门狗：等 K 型试点下载完成后自动出 v2（不动原图，只写 多个图及讨论 下的新图3）。"""
import io, os, subprocess, sys, time
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
DIR = r'data/lrs/ktype_pilot'
LOG = r'extract/ktype_watch.log'
TARGET = 6112

def n_files():
    try:
        return sum(1 for e in os.scandir(DIR) if e.name.endswith('.csv.gz'))
    except FileNotFoundError:
        return 0

def log(m):
    line = '[%s] %s' % (time.strftime('%H:%M:%S'), m)
    print(line, flush=True)
    open(LOG, 'a', encoding='utf-8').write(line + '\n')

log('看门狗启动，等待 K 型下载（目标 %d）' % TARGET)
last, stall = n_files(), 0
log('当前 %d' % last)
for _ in range(36*30):            # 最长 18 小时（每 120 s 一轮）
    time.sleep(120)
    cur = n_files()
    log('进度 %d / %d' % (cur, TARGET))
    if cur >= TARGET:
        log('已下齐，开始出 v2'); break
    if cur == last:
        stall += 1
        if stall >= 8:            # 16 分钟无增长 → 认为停机，用现有数据出 v2
            log('16 分钟无新增，按现有数据出 v2'); break
    else:
        stall, last = 0, cur
subprocess.run([sys.executable, 'repro/src/s533_ktype_ew.py'], capture_output=True)
r = subprocess.run([sys.executable, 'repro/src/s536_km_v2.py'], capture_output=True, text=True, encoding='utf-8', errors='replace')
log('v2 退出码 %d' % r.returncode)
log((r.stdout or '')[-800:])
r2 = subprocess.run([sys.executable, 'repro/src/s538_update_draft_v2.py'], capture_output=True, text=True, encoding='utf-8', errors='replace')
log('草稿更新退出码 %d' % r2.returncode)
log((r2.stdout or '')[-400:])
