
# -*- coding: utf-8 -*-
"""s630：六因素分解的诊断与替代方案（pooled LPM 之外）
(1) 清洗留存瀑布，核对计划里的 463,231 基准；
(2) 三个版本的分配：A 合并样本 LPM(已跑)、B 分箱系数 + Oaxaca（endowment/coefficient）、C logit 对照；
(3) 输出 多因素_诊断.csv / 多因素_方案对比.csv 与审核备忘。
"""
import os, sys, io, json, itertools, math
import numpy as np, pandas as pd
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
D = r'C:\Users\lingz\Desktop\复现老师工作\APJS\多个图及讨论'
main = pd.read_csv(os.path.join(D,'金属度_清洁样本_637973.csv'), low_memory=False)
sb1  = pd.read_csv(os.path.join(D,'RV变星_SB1候选_多历元.csv'), low_memory=False)

# ---------- 1. retention waterfall
steps = [('主表', len(main))]
d = main.copy()
def rec(tag, s): steps.append((tag, len(s))); return s
d = rec('去掉 SB1 候选', d[~d.uid.isin(set(sb1.uid))])
for c in ['teff','logg','m_h','snru']:
    d = rec('去掉 %s 哨兵/缺失' % c, d[pd.to_numeric(d[c], errors='coerce').notna() & (pd.to_numeric(d[c], errors='coerce')!=-9999)])
d = rec('teff 2000-4500', d[(d.teff>=2000)&(d.teff<=4500)])
d = rec('logg 3-6', d[(d.logg>=3)&(d.logg<=6)])
d = rec('|m_h|<1', d[d.m_h.abs()<1])
d = rec('snru>0 (含 0 值的排除)', d[d.snru>0])
d = rec('snru<100', d[d.snru<100])
d = rec('mh_ok', d[d.mh_ok==True])
d = rec('dist_pc>0', d[d.dist_pc>0])
d = rec('0<absz<=400', d[(d.absz>0)&(d.absz<=400)])
print('\n=== retention waterfall ===')
prev = None
for tag, n in steps:
    print('  %-26s %7d  %s' % (tag, n, '' if prev is None else '(-%d)' % (prev-n)))
    prev = n
print('  plan benchmark (7 covariates valid) 463,231 ; our final', len(d))
# how many stars have snru==0 and would otherwise pass?
q = main.copy()
q = q[~q.uid.isin(set(sb1.uid))]
for c in ['teff','logg','m_h']:
    q = q[(pd.to_numeric(q[c], errors='coerce')!=-9999)]
q = q[(q.teff>=2000)&(q.teff<=4500)&(q.logg>=3)&(q.logg<=6)&(q.m_h.abs()<1)]
q = q[(q.mh_ok==True)&(q.dist_pc>0)&(q.absz>0)&(q.absz<=400)]
print('  of those, snru==0:', int((q.snru==0).sum()), '| snru>0:', int((q.snru>0).sum()), '| total', len(q))
steps_df = pd.DataFrame(steps, columns=['step','n'])
steps_df.to_csv(os.path.join(D,'多因素_清洗留存.csv'), index=False, encoding='utf-8-sig')

# ---------- 2. sample for the decompositions (snru>0 required)
d['active'] = ((d.ewha>=0.75)&(d.ewha>3*d.ewha_err)).astype(float)
d['zb3'] = pd.cut(d.absz, [0,100,200,400], labels=['<100','100-200','200-400'])
SUBS = ['dM0','dM1','dM2','dM3','dM4','dM5','dM6']
DUM = pd.get_dummies(d.subclass, prefix='s', drop_first=True).astype(float)
for c, nm in [('teff','F2'),('logg','F3'),('m_h','F4')]:
    v = pd.to_numeric(d[c]); d[nm] = v - v.mean()
d['F2'] = d.F2/1000.0
lv = np.log10(d.snru); d['F5'] = lv - lv.mean()
ld = np.log10(d.dist_pc); d['F6'] = ld - ld.mean()
X = pd.concat([DUM, d[['F2','F3','F4','F5','F6']]], axis=1)
blocks = {'F1': list(DUM.columns), 'F2':['F2'], 'F3':['F3'], 'F4':['F4'], 'F5':['F5'], 'F6':['F6']}
y = d.active.values
masks = {b: (d.zb3.values==b) for b in ['<100','100-200','200-400']}
f = {b: y[m].mean()*100 for b,m in masks.items()}
OBS = {'100-200': f['<100']-f['100-200'], '200-400': f['<100']-f['200-400']}
print('\nbin rates (%%):', {k: round(v,2) for k,v in f.items()}, '| observed D:', {k: round(v,2) for k,v in OBS.items()})

def ols(cols, rows):
    A = np.column_stack([np.ones(rows.sum())] + [X[c].values[rows] for c in cols])
    beta, *_ = np.linalg.lstsq(A, y[rows], rcond=None)
    return beta
cols_all = [c for k in blocks for c in blocks[k]]
# ---------- 3. Oaxaca: endowment vs coefficient, factor-wise endowment
rows=[]
for b in ['100-200','200-400']:
    rn, rf = masks['<100'], masks[b]
    bn = ols(cols_all, rn); bf = ols(cols_all, rf)
    An = np.column_stack([np.ones(rn.sum())] + [X[c].values[rn] for c in cols_all])
    Af = np.column_stack([np.ones(rf.sum())] + [X[c].values[rf] for c in cols_all])
    fhat_n, fhat_f = 100*An.mean(axis=0), 100*Af.mean(axis=0)
    dx = fhat_n - fhat_f
    end_f = float(dx@bf); coef_f = float(fhat_n@(bn-bf))
    end_n = float(dx@bn); coef_n = float(fhat_f@(bn-bf))
    print('\nbin %s: observed %.2f | Oaxaca endowment(β_far) %.2f + coefficient %.2f = %.2f' % (b, OBS[b], end_f, coef_f, end_f+coef_f))
    print('        variant β_near: endowment %.2f + coefficient %.2f = %.2f' % (end_n, coef_n, end_n+coef_n))
    # factor-wise endowment with β_far, Shapley over blocks on the linear predictor difference
    K=6; keys=list(blocks.keys()); phi={k:0.0 for k in keys}; cache={}
    for r in range(K+1):
        for S in itertools.combinations(keys, r):
            cs=[c for k in S for c in blocks[k]]
            vn = sum(fhat_n[1+i]*bf[1+i] for i,c in enumerate(cols_all) if c in cs)
            vf = sum(fhat_f[1+i]*bf[1+i] for i,c in enumerate(cols_all) if c in cs)
            cache[frozenset(S)] = vn-vf
    for k in keys:
        others=[x for x in keys if x!=k]
        for r in range(len(others)+1):
            for S in itertools.combinations(others, r):
                w=math.factorial(len(S))*math.factorial(K-len(S)-1)/math.factorial(K)
                phi[k]+=w*(cache[frozenset(tuple(sorted(S+(k,))))]-cache[frozenset(S)])
    for k in keys:
        rows.append(dict(bin=b, scheme='Oaxaca_endowment_beta_far', factor=k, pp=phi[k]))
    rows.append(dict(bin=b, scheme='Oaxaca_endowment_beta_far', factor='SUM_endowment', pp=sum(phi.values())))
    rows.append(dict(bin=b, scheme='Oaxaca_endowment_beta_far', factor='OBSERVED_D', pp=OBS[b]))
    rows.append(dict(bin=b, scheme='Oaxaca_endowment_beta_far', factor='COEFFICIENT_TERM', pp=coef_f))
    rows.append(dict(bin=b, scheme='Oaxaca_endowment_beta_near', factor='SUM_endowment', pp=end_n))
    rows.append(dict(bin=b, scheme='Oaxaca_endowment_beta_near', factor='COEFFICIENT_TERM', pp=coef_n))
    rows.append(dict(bin=b, scheme='Oaxaca_endowment_beta_near', factor='OBSERVED_D', pp=OBS[b]))
    print('        factor-wise endowment (β_far): ' + ', '.join('%s %+.2f' % (k, phi[k]) for k in keys))
pd.DataFrame(rows).round(4).to_csv(os.path.join(D,'多因素_方案对比.csv'), index=False, encoding='utf-8-sig')
print('\nwrote 多因素_方案对比.csv and 多因素_清洗留存.csv')
