# -*- coding: utf-8 -*-
"""s588：给拟合函数做一次完整的性能体检

指标（逐星 637,973 颗，与 s586 同口径但保留全部亚型用于评估）：
  1) 拟合优度：nll、AIC、McFadden R²、Tjur R²、Brier、AUC
  2) 校准：按预测 p 的十分位做 Hosmer-Lemeshow（HL 统计量与 p 值）
  3) 结构校准：六个 |Z| 档 + 逐亚型 × 六档（最大偏差、RMS）
  4) 与「线性 logit / 指数」对照，量化换函数带来的增益
输出：多个图及讨论/lnf_fit_diagnostics.csv、lnf_fit_calib_subtype.csv
"""
import io, sys, os
import numpy as np, pandas as pd
from scipy.optimize import minimize
from scipy.special import expit
from scipy.stats import chi2
from astropy.coordinates import SkyCoord
import astropy.units as un

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
OUT = r'C:\Users\lingz\Desktop\复现老师工作\APJS\多个图及讨论'

def save(df, name, comments):
    fp = os.path.join(OUT, name)
    df.to_csv(fp, index=False, encoding='utf-8')
    txt = open(fp, encoding='utf-8').read()
    with open(fp, 'w', encoding='utf-8-sig') as f:
        f.write('\n'.join('# ' + c for c in comments) + '\n' + txt)
    print('  写出 %s（%d 行）' % (name, len(df)))

cat = pd.read_csv('data/lamost/dr13/dr13_mstellar_dM.csv', low_memory=False,
                  usecols=['uid','subclass','teff','ewha','ewha_err','snrr',
                           'ra','dec','gaia_source_id','gaia_g_mean_mag'])
cat = cat[(cat.ewha > -20) & (cat.ewha <= 50) & (cat.ewha_err > 0) & (cat.ewha_err <= 5)].copy()
cat['active'] = (cat.ewha >= 0.75) & (cat.ewha > 3*cat.ewha_err)
cat['gaia_source_id'] = pd.to_numeric(cat.gaia_source_id, errors='coerce')
g = pd.read_csv('data/gaia/gaia_dr3_mstars.csv', low_memory=False,
                usecols=['source_id','parallax','parallax_error','ruwe'])
m = cat.merge(g, left_on='gaia_source_id', right_on='source_id', how='inner')
m = m[(m.parallax > 0.2) & (m.parallax/m.parallax_error > 5) & (m.ruwe < 1.4)].copy()
u = m.sort_values('ewha', ascending=False).drop_duplicates('uid').copy()
u['MG'] = u.gaia_g_mean_mag.values - 5*np.log10(np.clip(1000.0/u.parallax.values, 1, None)) + 5
u = u[u.MG >= 6].copy()
d_pc = 1000.0/u.parallax.values
sc = SkyCoord(ra=u.ra.values*un.deg, dec=u.dec.values*un.deg, distance=d_pc*un.pc, frame='icrs')
u['absz'] = np.abs(d_pc*np.sin(np.deg2rad(sc.galactic.b.deg)))
u = u[u.absz <= 3000].copy()
u['subc'] = u.subclass.astype(str)
print('样本 %d 颗，活动率 %.3f%%' % (len(u), 100*u.active.mean()))

z = u.absz.values/1000.0; y = u.active.values.astype(float)
lnT = np.log(np.clip(pd.to_numeric(u.teff, errors='coerce').values, 2500, 4500)/3000.0)
subs = sorted(u.subc.unique())
sdum = np.column_stack([(u.subc.values == s).astype(float) for s in subs[1:]])

def build(form):
    cols = [np.ones_like(z), z]; names = ['a','b']
    if form != 'lin':
        for k0 in (0.05, 0.1, 0.2, 0.4, 0.6, 1.0):
            cols.append(np.clip(z-k0, 0, None)); names.append('h%.2f' % k0)
    if 'teff' in form:
        cols.append(lnT); names.append('lnTeff')
    if 'fe' in form:
        for j, s in enumerate(subs[1:]):
            cols.append(sdum[:, j]); names.append('fe_'+s)
    return np.column_stack(cols), names

def fit(X):
    def nll(b):
        p = expit(np.clip(X @ b, -30, 30))
        return -float((y*np.log(np.clip(p,1e-12,1)) + (1-y)*np.log(np.clip(1-p,1e-12,1))).sum())
    def gr(b):
        p = expit(np.clip(X @ b, -30, 30))
        return -(X.T @ (y - p))
    b0 = np.zeros(X.shape[1]); b0[0] = np.log(max(y.mean(),1e-6)/(1-max(y.mean(),1e-6)))
    return minimize(nll, b0, method='BFGS', jac=gr, options=dict(maxiter=4000, gtol=1e-9))

def auc(y_, p_):
    order = np.argsort(p_); ranks = np.empty(len(p_), float)
    ranks[order] = np.arange(1, len(p_)+1)
    # 处理并列：按均值秩
    s = pd.Series(p_); r = s.rank().values
    n1 = y_.sum(); n0 = len(y_) - n1
    return float((r[y_ == 1].sum() - n1*(n1+1)/2)/(n1*n0))

bins = [(0,100,'<100'),(100,200,'100-200'),(200,400,'200-400'),(400,600,'400-600'),
        (600,1000,'600-1000'),(1000,3000,'>1000')]
rows, srows = [], []
for form, tag in [('lin','L1 线性 logit（指数等价）'), ('spline','L2 样条 logit'),
                  ('spline_teff','L3 样条+lnTeff'), ('spline_fe','L4b 样条+亚型FE')]:
    X, names = build(form)
    r = fit(X); p = expit(np.clip(X @ r.x, -30, 30))
    nll0 = -float((y*np.log(y.mean()) + (1-y)*np.log(1-y.mean())).sum())
    mc = 1 - r.fun/nll0
    tjur = float(p[y == 1].mean() - p[y == 0].mean())
    brier = float(((p - y)**2).mean())
    a = auc(y, p)
    aic = 2*X.shape[1] + 2*r.fun
    # HL 十分位
    q = pd.qcut(p, 10, labels=False, duplicates='drop')
    hl = 0.0; g_ = pd.DataFrame({'q': q, 'p': p, 'y': y}).groupby('q').agg(n=('y','size'), ps=('p','mean'), ys=('y','sum'))
    for _, row in g_.iterrows():
        exp_ = row.n * row.ps
        hl += (row.ys - exp_)**2/(exp_*(1-row.ps)) + ((row.n-row.ys) - row.n*(1-row.ps))**2/(row.n*(1-row.ps)*(1-row.ps)) if False else (row.ys - exp_)**2/(row.n*row.ps*(1-row.ps))
    hl_p = float(chi2.sf(hl, len(g_)-2))
    # 六档结构校准
    rms = 0.0; mx = 0.0
    for lo_, hi_, nm in bins:
        s = (u.absz.values > lo_) & (u.absz.values <= hi_)
        pr = 100*p[s].mean(); me = 100*y[s].mean(); d_ = pr-me
        rms += d_**2; mx = max(mx, abs(d_))
        srows.append(dict(model=tag, kind='zbin', subtype='ALL', zbin=nm, n=int(s.sum()),
                          obs=me, pred=pr, diff_pp=d_))
    rms = np.sqrt(rms/len(bins))
    # 逐亚型 × 六档（只报 ALL 之外的中等以上格子）
    for sp in subs:
        for lo_, hi_, nm in bins:
            sel = (u.subc.values == sp) & (u.absz.values > lo_) & (u.absz.values <= hi_)
            if sel.sum() < 200: continue
            pr = 100*p[sel].mean(); me = 100*y[sel].mean()
            srows.append(dict(model=tag, kind='subtype', subtype=sp, zbin=nm, n=int(sel.sum()),
                              obs=me, pred=pr, diff_pp=pr-me))
    print('\n%-24s AIC %.1f | McFadden %.4f | Tjur %.3f | Brier %.4f | AUC %.4f | HL %.1f (p=%.1e)'
          % (tag, aic, mc, tjur, brier, a, hl, hl_p))
    print('    六档：RMS %.2f pp，最大 %.2f pp' % (rms, mx))
    rows.append(dict(model=tag, n_par=X.shape[1], nll=r.fun, aic=aic, mcfadden=mc, tjur=tjur,
                     brier=brier, auc=a, hl_stat=hl, hl_p=hl_p, zbin_rms_pp=rms, zbin_max_pp=mx))
save(pd.DataFrame(rows), 'lnf_fit_diagnostics.csv', [
    's588：拟合函数性能体检（逐星 637,973 颗，logit 连接）',
    'mcfadden = 1 - nll/nll_null；tjur = mean(p|active) - mean(p|inactive)；brier = mean((p-y)^2)',
    'hl_stat/hl_p = Hosmer-Lemeshow 十分位校准检验（dof = 8）',
    'zbin_rms_pp / zbin_max_pp = 六个 |Z| 档「预测均值 - 实测」的 RMS 与最大绝对偏差（百分点）',
    '生成脚本：代码/s588_fit_diagnostics.py'])
save(pd.DataFrame(srows), 'lnf_fit_calib_subtype.csv', [
    's588：六个 |Z| 档（kind=zbin）与逐亚型×六档（kind=subtype，n>=200）的观测/预测/差值',
    'diff_pp = pred - obs（百分点）；生成脚本：代码/s588_fit_diagnostics.py'])
print('\ns588 完成')
