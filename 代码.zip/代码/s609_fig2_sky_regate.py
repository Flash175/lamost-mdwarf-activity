# -*- coding: utf-8 -*-
"""s609：按正文 §1 口径重画图02 左板（EW 闸门后 759,607 颗 uid），右板 SDSS 标注为外部样本。

左板：DR13 dM 目录，闸门 (ewha > -20) & (ewha <= 50) & (ewha_err > 0) & (ewha_err <= 5)，
      每 uid 取 EW(Ha) 最大的一次观测，活动 = EW >= 0.75 A 且 EW > 3 sigma。
右板：West 等（2011, AJ 141, 97）DR7 M 矮星星表（外部样本），活动 = W(Ha) >= 0.75 A。
版式、点径、叠放顺序、figsize/dpi 全部沿用 s16_paperA_fig2.py，不改动。
"""
from __future__ import annotations

import io
import os
import shutil
import sys

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

BASE = "C:/Users/lingz/OneDrive/Desktop/复现老师工作"
FIG = "C:/Users/lingz/Desktop/复现老师工作/APJS/图五及相关数据"
SIZE = 1.2


def draw(ax, ra_deg, dec_deg, active, title, order, size=SIZE):
    lon = np.radians(((np.asarray(ra_deg, float) + 180.0) % 360.0) - 180.0)
    lat = np.radians(np.asarray(dec_deg, float))
    act = np.asarray(active, bool)
    for who in order:
        m = act if who == "red" else ~act
        ax.scatter(lon[m], lat[m], s=size, c=who, alpha=0.9, lw=0, label=who)
    ax.grid(True, lw=0.3, color="0.75")
    ax.set_xticklabels([])
    ax.tick_params(labelsize=6)
    ax.set_title(title, fontsize=9, pad=6)
    ax.text(0.985, 0.985, "blue inactive M-type stellar\nred active M-type stellar",
            transform=ax.transAxes, ha="right", va="top", fontsize=6.5, color="blue",
            linespacing=1.4, bbox=dict(fc="white", ec="0.8", lw=0.4, pad=1.2))


def main():
    lam = pd.read_csv(BASE + "/data/lamost/dr13/dr13_mstellar_dM.csv", low_memory=False,
                      usecols=["uid", "ewha", "ewha_err", "ra", "dec"])
    lam["ewha"] = pd.to_numeric(lam.ewha, errors="coerce")
    lam["ewha_err"] = pd.to_numeric(lam.ewha_err, errors="coerce").abs()
    g = lam[(lam.ewha > -20) & (lam.ewha <= 50) & (lam.ewha_err > 0) & (lam.ewha_err <= 5)]
    print("闸门后光谱 %s（应 1,016,104）；uid %s（应 759,607）" % (format(len(g), ","), format(g.uid.nunique(), ",")))
    ps = g.dropna(subset=["ra", "dec"]).sort_values("ewha", ascending=False).drop_duplicates("uid")
    act = ((ps.ewha >= 0.75) & (ps.ewha > 3 * ps.ewha_err)).to_numpy()
    print("LAMOST(DR13 §1 口径): 星 %s，活动 %s（%.2f%%）" % (format(len(ps), ","), format(int(act.sum()), ","), 100 * act.mean()))

    sdss = pd.read_csv(BASE + "/data/vizier/aj141_97_sdss_dwarfs.csv", low_memory=False,
                       usecols=lambda c: c in {"RAJ2000", "DEJ2000", "W(Ha)"})
    sdss["WHa"] = pd.to_numeric(sdss["W(Ha)"], errors="coerce")
    sdss = sdss.dropna(subset=["RAJ2000", "DEJ2000"])
    act_s = (sdss["WHa"] >= 0.75).to_numpy()
    print("SDSS(West+2011, 外部): 行 %s，活动 %s（%.2f%%）" % (format(len(sdss), ","), format(int(act_s.sum()), ","), 100 * act_s.mean()))

    fig = plt.figure(figsize=(13.5, 4.2))
    draw(fig.add_subplot(1, 2, 1, projection="mollweide"), ps["ra"], ps["dec"], act,
         "LAMOST DR13 activity distribution of M-type stars (N=%s, active=%.1f%%)" % (format(len(ps), ","), 100 * act.mean()),
         ["blue", "red"])
    draw(fig.add_subplot(1, 2, 2, projection="mollweide"), sdss["RAJ2000"], sdss["DEJ2000"], act_s,
         "SDSS DR7 activity distribution of M dwarfs, external sample: West+2011 (N=%s, active=%.1f%%)" % (format(len(sdss), ","), 100 * act_s.mean()),
         ["red", "blue"], size=2.0)
    fig.tight_layout()
    out = FIG + "/图_20261103/新图/新图_图02_正文口径_759607星.png"
    fig.savefig(out, dpi=170)
    plt.close(fig)
    print("写出 %s（%d B）" % (out, os.path.getsize(out)))

    for dst in [FIG + "/图/图02_全天分布_paperA_fig2_sky_distribution.png",
                FIG + "/图_20261104/图/图02_全天分布_paperA_fig2_sky_distribution.png"]:
        if os.path.exists(dst):
            old = os.path.join(os.path.dirname(dst), "_旧版")
            os.makedirs(old, exist_ok=True)
            shutil.move(dst, os.path.join(old, "图02_旧口径_712381_%d.png" % int(os.path.getmtime(dst))))
            shutil.copy2(out, dst)
            print("替换 %s（现 %d B）" % (dst, os.path.getsize(dst)))


if __name__ == "__main__":
    main()
