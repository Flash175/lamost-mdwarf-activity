# -*- coding: utf-8 -*-
"""s594：若把第三判据也用上，活动率与 |Z| 趋势会怎么移动

第三判据（线心峰高 > 3×线外噪声）的不合格率随 |Z| 变化：<100 / 100–200 / 200–400 / >400 pc
为 13.1% / 22.2% / 36.4% / 36.8%（s565，2,500 条活动谱抽样）。
若把该判据加进活动定义，落在这批不合格谱里的「活动星」会被改判为非活动，
故各档活动率近似乘以 (1 − 不合格率)：

    f_new(bin) ≈ f_old(bin) × (1 − p_fail(bin))

本脚本给出该反事实表、新的降幅比值，以及「地板」形状是否改变。
注意：p_fail 来自**活动富集**的 2,500 条抽样，是近似；仅用于量化方向与量级。
输出：多个图及讨论/criterion3_corrected_fractions.csv
"""
import io, sys, os
import numpy as np, pandas as pd
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
OUT = r'C:\Users\lingz\Desktop\复现老师工作\APJS\多个图及讨论'

A = pd.read_csv(os.path.join(OUT, 'far400_2d_audit.csv'), comment='#').set_index('zbin')
f = A['frac'].astype(float)
# 第三判据不合格率（s565）：>400 pc 合并给 36.8%，这里对 400–600 / 600–1000 / >1000 都用 36.8%
pfail = {'<100': 0.131, '100-200': 0.222, '200-400': 0.364,
         '400-600': 0.368, '600-1000': 0.368, '>1000': 0.368}
rows = []
for zb in f.index:
    p = pfail[zb]
    rows.append(dict(zbin=zb, n=int(A.loc[zb, 'n']), f_two_criteria=float(f[zb]),
                     fail_rate_c3=p, f_with_c3=float(f[zb])*(1-p)))
T = pd.DataFrame(rows)
print(T.to_string(index=False, float_format=lambda x: '%.2f' % x))

def ratio(a, b):
    return T.set_index('zbin').loc[a, 'f_two_criteria']/T.set_index('zbin').loc[b, 'f_two_criteria'], \
           T.set_index('zbin').loc[a, 'f_with_c3']/T.set_index('zbin').loc[b, 'f_with_c3']

print('\n降幅（<100 pc ÷ 目标档）：')
for zb in ['100-200', '200-400', '400-600', '600-1000']:
    r2, r3 = ratio('<100', zb)
    print('  ÷%-9s 两判据 %.2f×  →  加第三判据 %.2f×' % (zb, r2, r3))
r2, r3 = ratio('400-600', '600-1000')
print('\n「地板」形状（400–600 ÷ 600–1000）：两判据 %.3f，加第三判据 %.3f（<1 表示回升）' % (r2, r3))
r2b, r3b = ratio('200-400', '400-600')
print('外盘相对内盘（200–400 ÷ 400–600）：两判据 %.2f×，加第三判据 %.2f×' % (r2b, r3b))

fp = os.path.join(OUT, 'criterion3_corrected_fractions.csv')
T.to_csv(fp, index=False, encoding='utf-8')
txt = open(fp, encoding='utf-8').read()
hdr = ('# s594：把第三判据（峰高 > 3σ 线外噪声）也加进活动定义后的反事实活动率\n'
       '# f_new ≈ f_old × (1 − p_fail)，p_fail 取 s565 的逐档不合格率（活动富集 2,500 条抽样）\n'
       '# 用途：量化「换判据口径会移动多少」，不作为最终采用值\n'
       '# 生成脚本：代码/s594_criterion3_corrected.py\n')
open(fp, 'w', encoding='utf-8-sig').write(hdr + txt)
print('\n写出 criterion3_corrected_fractions.csv（%d 行）' % len(T))
