
# -*- coding: utf-8 -*-
"""K+M 活动比例联合图（v1，K 侧为当前已下载子样本）。"""
import io, os, subprocess, sys
import numpy as np, pandas as pd
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
OUT = r'C:\Users\lingz\Desktop\复现老师工作\APJS\多个图及讨论'
# 1) 先跑 K 侧测量
subprocess.run([sys.executable, 'repro/src/s533_ktype_ew.py'], capture_output=True)
K = pd.read_csv('data/processed/dr13/ktype_pilot_ew.csv')
# 2) M 侧（目录值）
cat = pd.read_csv('data/lamost/dr13/dr13_mstellar_dM.csv', low_memory=False,
                  usecols=['subclass','ewha','ewha_err'])
cat = cat[(cat.ewha > -20) & (cat.ewha <= 50) & (cat.ewha_err > 0) & (cat.ewha_err <= 5)].copy()
cat['active'] = (cat.ewha >= 0.75) & (cat.ewha > 3*cat.ewha_err)
rows = []
for sp in ['K0','K1','K2','K3','K4','K5','K6','K7']:
    s = K[K.subclass == sp]
    if len(s) >= 20:
        rows.append(dict(spt=sp, kind='K (this work)', n=len(s), frac=100*s.active.mean()))
for sp in ['dM0','dM1','dM2','dM3','dM4','dM5','dM6','dM7','dM8']:
    s = cat[cat.subclass == sp]
    if len(s) >= 50:
        rows.append(dict(spt=sp, kind='M (catalogue)', n=len(s), frac=100*s.active.mean()))
T = pd.DataFrame(rows)
T.to_csv(os.path.join(OUT, '新图3_K与M活动比例_v1.csv'), index=False, encoding='utf-8-sig')
print(T.to_string(index=False))
xs = np.arange(len(T))
colors = ['#8e44ad']*sum(T.kind.str.startswith('K')) + ['#c0392b']*sum(T.kind.str.startswith('M'))
fig, ax = plt.subplots(figsize=(8.6, 4.6))
ax.plot(xs, T.frac, 'o-', color='#2c3e50', lw=1.4, ms=6, zorder=3)
for xi, (f, k) in enumerate(zip(T.frac, T.kind)):
    ax.plot(xi, f, 'o', color='#8e44ad' if k.startswith('K') else '#c0392b', ms=7, zorder=4)
for xi, (f, n) in enumerate(zip(T.frac, T.n)):
    ax.text(xi, f+1.6, '%d' % n, ha='center', fontsize=6, color='#555')
ax.set_xticks(xs); ax.set_xticklabels(T.spt, rotation=45)
ax.set_ylabel('Active fraction (%)'); ax.set_xlabel('Spectral subtype')
ax.set_title('Active fraction across the K/M transition (numbers = stars per bin)')
ax.axvline(sum(T.kind.str.startswith('K'))-0.5, color='#999', ls='--', lw=1)
ax.text(sum(T.kind.str.startswith('K'))-0.45, ax.get_ylim()[1]*0.92, 'K  |  M', fontsize=8, color='#666')
plt.tight_layout(); plt.savefig(os.path.join(OUT, '新图3_K与M活动比例_v1.png'), dpi=200); plt.close()
print('\n图与 CSV 已写入', OUT)
print('K 侧样本量合计:', int(T[T.kind.str.startswith('K')].n.sum()), '（下载仍在进行）')
