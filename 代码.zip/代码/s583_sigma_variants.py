# -*- coding: utf-8 -*-
"""s583：s582 年龄模型的四种 σ(vz) 处理对照（把正文 caveat 里的区间落成 CSV）。

处理：
  nominal —— 保留 421.8 pc 实测锚点（s582 的实际做法，正文主数字）
  lnz     —— 弃用该锚点，按 ≤232.6 pc 两点的 ln z 外推（s582 sigma_at 的外推段约定）
  linz    —— 弃用该锚点，按 ≤232.6 pc 两点的 z 线性外推
  freeze  —— 弃用该锚点，σ 冻结在 232.6 pc 的 22.49 km/s

输出：多个图及讨论/avr_model_sigma_variants.csv
"""
import io
import os
import sys

import numpy as np
import pandas as pd

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")
OUT = r"C:\Users\lingz\Desktop\复现老师工作\APJS\多个图及讨论"

d6 = pd.read_csv(os.path.join(OUT, "新图1_数据_6D分箱.csv"), comment="#")
z6 = d6["zmed_inact"].values
s6 = d6["svz_inact"].values
m = np.isfinite(z6) & np.isfinite(s6)
z6, s6 = z6[m], s6[m]

B = pd.read_csv(os.path.join(OUT, "新图1_数据_2D分箱.csv"), comment="#")
zb = dict(zip(B.zbin, B.absz_med))
fb = dict(zip(B.zbin, B.frac / 100.0))
R = pd.read_csv(os.path.join(OUT, "reweight_composition.csv"), comment="#")
share = {z: R[R.zbin == z].set_index("subtype").n / R[R.zbin == z].n.sum() for z in R.zbin.unique()}
TAU = {"dM0": 0.8, "dM1": 0.4, "dM2": 1.2, "dM3": 2.0, "dM4": 4.5, "dM5": 7.0, "dM6": 7.0, "dM7": 8.0, "dM8": 8.0}
BINS = ["<100", "100-200", "200-400", "400-600", "600-1000"]


P_GLOBAL = np.polyfit(np.log(z6[:-1]), s6[:-1], 1)          # 全局 ln z 最小二乘
P_ENDS = np.polyfit(np.log([z6[0], z6[-2]]), [s6[0], s6[-2]], 1)  # 首末两点 ln z


def make_sigma(kind):
    if kind == "lnz_fit":
        return lambda z: float(np.polyval(P_GLOBAL, np.log(z)))
    if kind == "lnz_ends":
        return lambda z: float(np.polyval(P_ENDS, np.log(z)))
    zz, ss = (z6, s6) if kind == "nominal" else (z6[:-1], s6[:-1])
    def f(z):
        if kind == "freeze":
            return float(ss[-1]) if z > zz[-1] else float(np.interp(np.log(z), np.log(zz), ss))
        if z <= zz[-1]:
            return float(np.interp(np.log(z), np.log(zz), ss))
        if kind == "linz":
            b = (ss[-1] - ss[-2]) / (zz[-1] - zz[-2])
            return float(ss[-1] + b * (z - zz[-1]))
        b = (ss[-1] - ss[-2]) / (np.log(zz[-1]) - np.log(zz[-2]))
        return float(ss[-1] + b * (np.log(z) - np.log(zz[-1])))
    return f


def run(kind, beta=0.45):
    sig = make_sigma(kind)
    sref = sig(zb["<100"])

    def pred(t):
        return {k: sum(w * float(np.exp(-t * (sig(z) / sref) ** (1.0 / beta) / TAU.get(s, 8.0)))
                        for s, w in share[k].items()) for k, z in zb.items() if k in share}

    lo, hi = 0.05, 20.0
    for _ in range(80):
        mid = 0.5 * (lo + hi)
        if pred(mid)["<100"] > fb["<100"]:
            lo = mid
        else:
            hi = mid
    t0 = 0.5 * (lo + hi)
    P = pred(t0)
    return t0, sig, {k: fb[k] / P[k] for k in BINS}


rows = []
print("%-8s %8s %8s %8s  比值" % ("处理", "t_ref", "σ(475)", "σ(687)"))
for kind, lab in [("nominal", "名义"), ("lnz_fit", "全局lnz拟合"), ("lnz_ends", "首末两点lnz"),
                  ("lnz", "末两点lnz"), ("linz", "末两点z线性"), ("freeze", "冻结232.6")]:
    t0, sig, r = run(kind)
    print("%-8s %8.3f %8.2f %8.2f  %s" % (lab, t0, sig(474.9), sig(687.5),
                                          " / ".join("%.2f" % r[k] for k in BINS[1:])))
    rows.append(dict(sigma_treatment=kind, t_ref_Gyr=round(t0, 3), sigma_475=round(sig(474.9), 2),
                     sigma_687=round(sig(687.5), 2),
                     ratio_100_200=round(r["100-200"], 3), ratio_200_400=round(r["200-400"], 3),
                     ratio_400_600=round(r["400-600"], 3), ratio_600_1000=round(r["600-1000"], 3)))

path = os.path.join(OUT, "avr_model_sigma_variants.csv")
with open(path, "w", encoding="utf-8") as f:
    f.write("# s583：s582 年龄模型在四种 σ(vz) 处理下的远档比值（正文 §4.1 (iv) 的区间来源）\n")
    f.write("# nominal = 含 421.8 pc 锚点（正文主数字）；lnz / linz = 弃用该点后按 <=232.6 pc 两点外推；freeze = 冻结在 232.6 pc\n")
    f.write("# τ 取 West 等（2008, AJ 135, 785, Table 2）逐型值；β = 0.45（基准），t_ref 由 <100 pc 档定标\n")
    f.write("# 生成脚本：代码/s583_sigma_variants.py\n")
    pd.DataFrame(rows).to_csv(f, index=False)
print("写出", path, os.path.getsize(path), "B")
