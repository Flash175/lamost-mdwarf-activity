﻿# -*- coding: utf-8 -*-
"""s583b: 阶跃形式与 tau 缩放的复算（原编号 s584，因与拟合形式系列 s584_starlevel_logit_z / s584_far1000_diagnose 重号，2026-11-07 改名）

回答正文 §4.1 的两个问题：
  ①「改用 exp(-t/tau) 是不是必需的平滑」——把 West 的阶跃形式按原样实现
     （P = sum_s w_s * Phi((tau_s - t)/sigma_tau)，Phi 为标准正态生存函数，
      即 tau 服从 N(tau_s, sigma_tau) 时活动星的比例），同样用 <100 pc 定标，
     看是否仍能解出 t_ref；
  ②「tau 的绝对标度是否与 t_ref 简并」——把全部 tau 同乘 lambda，检验
     t_ref 是否同乘 lambda、四个档的比值是否不变；
     以及阶跃形式在 sigma_tau 固定时是否破坏该简并。

数据、sigma(vz) 曲线、亚型组成与 tau 全部沿用 s582，不引入新输入。
输出 avr_model_stepform.csv（供正文与台账引用）。
"""
import io, sys, os
import numpy as np, pandas as pd
from scipy.stats import norm
from scipy.optimize import minimize

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
OUT = r'C:\Users\lingz\Desktop\复现老师工作\APJS\多个图及讨论'

# ---- 与 s582 完全一致的输入 ----
d6 = pd.read_csv(os.path.join(OUT, '新图1_数据_6D分箱.csv'), comment='#')
z6 = d6['zmed_inact'].values; s6 = d6['svz_inact'].values
keep = np.isfinite(z6) & np.isfinite(s6)
z6, s6 = z6[keep], s6[keep]

B = pd.read_csv(os.path.join(OUT, '新图1_数据_2D分箱.csv'), comment='#')
zb = dict(zip(B.zbin, B.absz_med)); fb = dict(zip(B.zbin, B.frac / 100.0))

R = pd.read_csv(os.path.join(OUT, 'reweight_composition.csv'), comment='#')
share = {z: R[R.zbin == z].set_index('subtype').n / R[R.zbin == z].n.sum()
         for z in R.zbin.unique()}

TAU = {'dM0': 0.8, 'dM1': 0.4, 'dM2': 1.2, 'dM3': 2.0,
       'dM4': 4.5, 'dM5': 7.0, 'dM6': 7.0, 'dM7': 8.0, 'dM8': 8.0}

BINS = ['<100', '100-200', '200-400', '400-600', '600-1000']
BETA = 0.45
SREF = None


def sigma_at(z):
    """与 s582 第 31-32 行相同的 log z 内插/末两点外推。"""
    if z <= z6[-1]:
        return float(np.interp(np.log(z), np.log(z6), s6))
    slope = (s6[-1] - s6[-2]) / (np.log(z6[-1]) - np.log(z6[-2]))
    dz = np.log(z) - np.log(z6[-1])
    return float(s6[-1] + slope * dz)


def ages(t_ref):
    """各档年龄 t = t_ref * (sigma/sigma_ref)^(1/beta)。"""
    return {b: t_ref * (sigma_at(zb[b]) / SREF) ** (1.0 / BETA) for b in BINS}


def p_exp(t_ref, lam=1.0):
    t = ages(t_ref)
    return {b: sum(w * float(np.exp(-t[b] / (lam * TAU[s])))
            for s, w in share[b].items()) for b in BINS}


def p_step(t_ref, sig=1.0, lam=1.0):
    """阶跃 + tau 的高斯散布：P(T > t) = Phi((lam*tau_s - t)/sig)。"""
    t = ages(t_ref)
    return {b: sum(w * float(norm.sf((t[b] - lam * TAU[s]) / sig))
            for s, w in share[b].items()) for b in BINS}


def calibrate(fun):
    """用 <100 pc 档解 t_ref（与 s582 相同的二分法）。"""
    target = fb['<100']
    lo, hi = 1e-3, 80.0
    for _ in range(200):
        mid = 0.5 * (lo + hi)
        if fun(mid)['<100'] > target:
            lo = mid
        else:
            hi = mid
    return 0.5 * (lo + hi)


def ratios(t_ref, fun):
    p = fun(t_ref)
    return [fb[b] / p[b] for b in BINS]


SREF = sigma_at(zb['<100'])
print('sigma_ref = %.2f km/s（<100 pc 档中位 %.1f pc）' % (SREF, zb['<100']))

rows = []

# ① 名义：指数式
t_exp = calibrate(lambda t: p_exp(t))
r_exp = ratios(t_exp, lambda t: p_exp(t))
rows.append(dict(model='exp', lam=1.0, sigma_tau_Gyr=np.nan, t_ref_Gyr=t_exp,
                 ratio=dict(zip(BINS, r_exp))))
print('\n[exp]              t_ref = %.4f Gyr  比值 1.00 / %.2f / %.2f / %.2f / %.2f'
      % (t_exp, r_exp[1], r_exp[2], r_exp[3], r_exp[4]))

# ② 阶跃 + 1 Gyr 散布（West 2006 的原样实现）
t_step = calibrate(lambda t: p_step(t, 1.0))
r_step = ratios(t_step, lambda t: p_step(t, 1.0))
rows.append(dict(model='step', lam=1.0, sigma_tau_Gyr=1.0, t_ref_Gyr=t_step,
                 ratio=dict(zip(BINS, r_step))))
print('[step, sigma=1]    t_ref = %.4f Gyr  比值 1.00 / %.2f / %.2f / %.2f / %.2f'
      % (t_step, r_step[1], r_step[2], r_step[3], r_step[4]))

# ③ 指数式下 tau 整体缩放：t_ref 同乘 lambda，比值不变
print('\n[exp] tau 整体缩放 lambda：')
r_lam = {}
for lam in (0.8, 1.0, 1.2, 1.5, 3.0):
    t = calibrate(lambda tt, l=lam: p_exp(tt, l))
    r = ratios(t, lambda tt, l=lam: p_exp(tt, l))
    r_lam[lam] = r
    rows.append(dict(model='exp_scaled', lam=lam, sigma_tau_Gyr=np.nan,
                     t_ref_Gyr=t, ratio=dict(zip(BINS, r))))
    print('   lambda=%4.2f  t_ref=%7.4f Gyr  比值 %s'
          % (lam, t, ' / '.join('%.3f' % x for x in r[1:])))
d_max = max(abs(a - b) for a, b in zip(r_lam[1.5], r_lam[3.0]))
print('   lambda=1.5 与 lambda=3.0 的四个比值最大差 = %.3e（浮点舍入量级）' % d_max)

# ④ 阶跃形式：tau 整体放大 1.5 倍而 sigma_tau 固定 -> 简并破坏
t_s15 = calibrate(lambda t: p_step(t, 1.0, 1.5))
r_s15 = ratios(t_s15, lambda t: p_step(t, 1.0, 1.5))
rows.append(dict(model='step_tau1.5_sig1', lam=1.5, sigma_tau_Gyr=1.0,
                 t_ref_Gyr=t_s15, ratio=dict(zip(BINS, r_s15))))
print('\n[step] tau*1.5, sigma_tau=1 固定  t_ref = %.4f Gyr  比值 1.00 / %.2f / %.2f / %.2f / %.2f'
      % (t_s15, r_s15[1], r_s15[2], r_s15[3], r_s15[4]))

# ⑤ 阶跃形式：sigma_tau 同比例放大 -> 简并恢复
t_s15b = calibrate(lambda t: p_step(t, 1.5, 1.5))
r_s15b = ratios(t_s15b, lambda t: p_step(t, 1.5, 1.5))
rows.append(dict(model='step_tau1.5_sig1.5', lam=1.5, sigma_tau_Gyr=1.5,
                 t_ref_Gyr=t_s15b, ratio=dict(zip(BINS, r_s15b))))
print('[step] tau*1.5, sigma_tau*1.5  t_ref = %.4f Gyr  比值 1.00 / %.2f / %.2f / %.2f / %.2f'
      % (t_s15b, r_s15b[1], r_s15b[2], r_s15b[3], r_s15b[4]))

# ⑥ 把寿命比例整体扭曲为 tau_s^gamma，只拟合 (t_ref, gamma)
def p_gamma(t_ref, g):
    t = ages(t_ref)
    return {b: sum(w * float(np.exp(-t[b] / (TAU[s] ** g)))
            for s, w in share[b].items()) for b in BINS}


def rms_log(t_ref, g):
    p = p_gamma(t_ref, g)
    return float(np.sqrt(np.mean([np.log(p[b] / fb[b]) ** 2 for b in BINS])))


best = None
for t0 in (1.0, 2.0, 3.0, 6.0, 12.0):
    for g0 in (0.2, 0.33, 0.5, 0.8, 1.0, 1.3):
        r = minimize(lambda v: rms_log(v[0], v[1]), [t0, g0], method='Nelder-Mead',
                     options=dict(xatol=1e-10, fatol=1e-12, maxiter=5000))
        if best is None or r.fun < best.fun:
            best = r
t_gam, g_gam = best.x
p_gam = p_gamma(t_gam, g_gam)
rows_g = dict(model='exp_gamma_fit', lam=np.nan, sigma_tau_Gyr=np.nan,
              gamma=g_gam, rms_log=rms_log(t_gam, g_gam), t_ref_Gyr=t_gam,
              ratio=dict(zip(BINS, [fb[b] / p_gam[b] for b in BINS])))
rows.append(rows_g)
print('\n[exp, gamma free]  gamma = %.3f  t_ref = %.3f Gyr  RMS(log) = %.3f  预测/观测 = %s'
      % (g_gam, t_gam, rms_log(t_gam, g_gam),
         ' / '.join('%.2f' % (p_gam[b] / fb[b]) for b in BINS)))
p1 = p_gamma(t_gam, 1.0)
rows_g1 = dict(model='exp_gamma1_same_t', lam=np.nan, sigma_tau_Gyr=np.nan,
               gamma=1.0, rms_log=rms_log(t_gam, 1.0), t_ref_Gyr=t_gam,
               ratio=dict(zip(BINS, [fb[b] / p1[b] for b in BINS])))
rows.append(rows_g1)
print('[exp, gamma=1 固定同一 t_ref]  RMS(log) = %.3f' % rms_log(t_gam, 1.0))

# ---- 写表 ----
tab = []
for r in rows:
    d = dict(model=r['model'], lam=r['lam'], sigma_tau_Gyr=r['sigma_tau_Gyr'],
             gamma=r.get('gamma', np.nan), rms_log=r.get('rms_log', np.nan),
             t_ref_Gyr=r['t_ref_Gyr'])
    for b, v in r['ratio'].items():
        d['ratio_' + b] = v
    tab.append(d)
T = pd.DataFrame(tab)[['model', 'lam', 'sigma_tau_Gyr', 'gamma', 'rms_log',
                       't_ref_Gyr'] + ['ratio_' + b for b in BINS]]
fp = os.path.join(OUT, 'avr_model_stepform.csv')
T.to_csv(fp, index=False, encoding='utf-8')
txt = open(fp, encoding='utf-8').read()
open(fp, 'w', encoding='utf-8-sig').write(
    '# 阶跃形式与 tau 缩放的复算（s583b），输入与 s582 完全相同（6D sigma(vz) 曲线、2D 分档、'
    'reweight_composition.csv、West 2008 Table 2 的 tau）\n'
    '# model: exp=名义指数式; step=阶跃+tau 高斯散布(sigma_tau_Gyr); exp_scaled=指数式下 tau 整体乘 lam; '
    'step_tau1.5_sig1=阶跃、tau 乘 1.5 而 sigma_tau 固定; step_tau1.5_sig1.5=两者同乘 1.5; '
    'exp_gamma_fit=把寿命比例扭曲为 tau^gamma 后只拟合 (t_ref, gamma); '
    'exp_gamma1_same_t=gamma=1 但 t_ref 固定在拟合值\n'
    '# exp / step / exp_scaled / step_tau* 各行用 <100 pc 档定标 P=23.81%，ratio 为 观测/预测，ratio_<100 恒为 1.00；\n'
    '# exp_gamma_fit / exp_gamma1_same_t 两行是五档联合拟合，未固定 <100 档，ratio_<100 不为 1；beta=0.45\n'
    '# exp_gamma_fit 的 gamma 为 0.328、RMS(log)=0.111、预测/观测 = 0.85/1.07/1.13/1.05/0.89（正文取 0.33）\n'
    '# 生成脚本：代码/s583b_stepform_tau_scan.py' + chr(10) + txt)
print('\n写出 avr_model_stepform.csv')

