
# -*- coding: utf-8 -*-
"""s627：用 LAMOST 多历元 RV 标记 SB1 候选，检验亚型内降幅是否受双星影响。
口径：论文 2D 样本 → 对 uid 有多条谱的星算 RV 变异性（两个判据）→ 剔除后重算降幅。
输出：多个图及讨论/RV变星_剔除检验.csv
"""
import os, sys, io
import numpy as np, pandas as pd
from astropy.coordinates import SkyCoord
import astropy.units as u
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
OD = r'C:\Users\lingz\OneDrive\Desktop\复现老师工作\data'
OUTD = r'C:\Users\lingz\Desktop\复现老师工作\APJS\多个图及讨论'
SUB = ['dM0','dM1','dM2','dM3','dM4','dM5','dM6']

d = pd.read_csv(os.path.join(OD,'lamost','dr13','dr13_mstellar_dM.csv'),
                usecols=['uid','subclass','ewha','ewha_err','z','z_err','snrz','gaia_source_id','gaia_g_mean_mag','ra','dec'],
                low_memory=False)
d = d[(d.ewha>-20)&(d.ewha<=50)&(d.ewha_err>0)&(d.ewha_err<=5)].copy()
g = pd.read_csv(os.path.join(OD,'gaia','gaia_dr3_mstars.csv'),
                usecols=['source_id','parallax','parallax_error','ruwe','phot_g_mean_mag'], low_memory=False)
d = d.merge(g, left_on='gaia_source_id', right_on='source_id', how='inner')
d = d[(d.parallax>0.2)&(d.parallax/d.parallax_error>5)&(d.ruwe<1.4)].copy()
print('spectra after gates:', len(d), '| uid', d.uid.nunique())

# ---- RV variability on the multi-epoch spectra, BEFORE de-duplication
rv = d[(d.z.notna()) & (d.z_err.notna()) & (d.z_err>0) & (d.snrz>=5)].copy()
rv['rv'] = 299792.458*rv.z; rv['rv_err'] = 299792.458*rv.z_err
grp = rv.groupby('uid')
stat = grp.agg(n_ep=('rv','size'), rv_med=('rv','median'), rv_min=('rv','min'), rv_max=('rv','max'),
               err_med=('rv_err','median'))
stat['ptp'] = stat.rv_max - stat.rv_min
def chi2_red(t):
    if len(t) < 2: return np.nan
    s = np.sqrt(t.rv_err.values**2 + 1.0**2)
    r = t.rv.values
    return float(np.sum(((r - r.mean())/s)**2)/(len(r)-1))
chi = rv.groupby('uid').apply(chi2_red, include_groups=False)
stat['chi2_red'] = chi
multi = stat[stat.n_ep>=2]
print('stars with >=2 usable epochs:', len(multi), '(%.1f%% of %d)' % (100*len(multi)/d.uid.nunique(), d.uid.nunique()))
flagA = multi[(multi.chi2_red>3)]
flagB = multi[(multi.ptp>10) & (multi.ptp>5*multi.err_med)]
print('flagged chi2_red>3:', len(flagA), '| flagged ptp>10 & >5err:', len(flagB), '| union:', len(set(flagA.index)|set(flagB.index)))

# ---- 2D sample (paper definition), then mark flags
u2 = d.sort_values('ewha', ascending=False).drop_duplicates('uid').copy()
u2['MG'] = u2.gaia_g_mean_mag.values - 5*np.log10(np.clip(1000.0/u2.parallax.values,1,None)) + 5
u2 = u2[u2.MG>=6].copy()
u2['dist_pc'] = 1000.0/u2.parallax.values
sc = SkyCoord(ra=u2.ra.values*u.deg, dec=u2.dec.values*u.deg, distance=u2.dist_pc.values*u.pc, frame='icrs')
u2['absz'] = np.abs(u2.dist_pc.values*np.sin(np.deg2rad(sc.galactic.b.deg)))
u2 = u2[(u2.absz>0)&(u2.absz<=3000)].copy()
u2['active'] = ((u2.ewha>=0.75)&(u2.ewha>3*u2.ewha_err)).astype(int)
u2 = u2[u2.subclass.isin(SUB)].copy()
print('2D sample (dM0-dM6):', len(u2), '| active', int(u2.active.sum()))
u2['n_ep_rv'] = u2.uid.map(multi.n_ep)
u2['sb1_A'] = u2.uid.isin(set(flagA.index))
u2['sb1_B'] = u2.uid.isin(set(flagB.index))
u2['sb1'] = u2.uid.isin(set(flagA.index)|set(flagB.index))
print('of the 2D sample: multi-epoch %d, SB1(A) %d, SB1(B) %d, SB1 union %d' % (
    int(u2.n_ep_rv.notna().sum()), int(u2.sb1_A.sum()), int(u2.sb1_B.sum()), int(u2.sb1.sum())))

def declines(s, tag):
    near = s[s.absz<=100]; far = s[(s.absz>200)&(s.absz<=400)]
    r = dict(tag=tag, n=len(s), n_near=len(near), n_far=len(far),
             D_pp=100*(near.active.mean()-far.active.mean()))
    for st in SUB:
        a, b2 = near[near.subclass==st], far[far.subclass==st]
        r['d_'+st] = 100*(a.active.mean()-b2.active.mean()) if len(a)>30 and len(b2)>30 else np.nan
    return r
rows = [declines(u2, 'all (baseline)'),
        declines(u2[~u2.sb1], 'SB1 candidates removed'),
        declines(u2[u2.n_ep_rv.notna()], 'multi-epoch only'),
        declines(u2[u2.n_ep_rv.notna() & ~u2.sb1], 'multi-epoch, SB1 removed'),
        declines(u2[u2.n_ep_rv.isna()], 'single-epoch only')]
A = pd.DataFrame(rows)
pd.set_option('display.width', 200)
print('\n=== subtype declines (<100 -> 200-400 pc), pp ===')
print(A.round(2).to_string(index=False))
A.to_csv(os.path.join(OUTD,'RV变星_剔除检验.csv'), index=False, encoding='utf-8-sig')
# also save the SB1 candidate list for the archive
stat.loc[sorted(set(flagA.index)|set(flagB.index))].to_csv(os.path.join(OUTD,'RV变星_SB1候选_多历元.csv'), encoding='utf-8-sig')
print('\nSB1 candidate table rows:', len(set(flagA.index)|set(flagB.index)))
