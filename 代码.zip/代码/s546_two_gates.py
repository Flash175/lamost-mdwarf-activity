
# -*- coding: utf-8 -*-
"""两关检验：①亚型×|Z| 的探测效应与 S/N 匹配；②单历元 vs 最大 EW；③|Z| 用银纬/银心 z 核对。"""
import io, sys
import numpy as np, pandas as pd
from astropy.coordinates import SkyCoord
import astropy.units as un
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')

cat = pd.read_csv('data/lamost/dr13/dr13_mstellar_dM.csv', low_memory=False,
                  usecols=['uid','subclass','teff','ewha','ewha_err','snrr','ra','dec','gaia_source_id'])
cat = cat[(cat.ewha > -20) & (cat.ewha <= 50) & (cat.ewha_err > 0) & (cat.ewha_err <= 5)].copy()
cat['active'] = (cat.ewha >= 0.75) & (cat.ewha > 3*cat.ewha_err)
nep = cat.groupby('uid').size().rename('n_ep').reset_index()
# 每星：最大 EW 与 中位 EW 两条记录
g_max = cat.sort_values('ewha', ascending=False).drop_duplicates('uid')
g_med = cat.groupby('uid').agg(subclass=('subclass','first'), teff=('teff','median'),
                               ewha=('ewha','median'), ewha_err=('ewha_err','median'),
                               snrr=('snrr','median'), ra=('ra','first'), dec=('dec','first'),
                               gaia_source_id=('gaia_source_id','first')).reset_index()
for d_, nm in ((g_max,'max'), (g_med,'med')):
    d_['active'] = (d_.ewha >= 0.75) & (d_.ewha > 3*d_.ewha_err)
    d_.rename(columns={'active': 'active_'+nm}, inplace=True)
g = g_max.merge(g_med[['uid','ewha','ewha_err','snrr','active_med']], on='uid', suffixes=('','_m'))
g = g.merge(nep, on='uid', how='left')
print('逐星:', len(g), '| 单历元占比 %.1f%%' % (100*(g.n_ep == 1).mean()))

gg = pd.read_csv('data/gaia/gaia_dr3_mstars.csv', low_memory=False,
                 usecols=['source_id','parallax','parallax_error','ruwe'])
gg['sid'] = pd.to_numeric(gg.source_id, errors='coerce')
g['sid'] = pd.to_numeric(g.gaia_source_id, errors='coerce')
M = g.merge(gg[['sid','parallax','parallax_error','ruwe']], on='sid', how='left')
M = M[(M.parallax > 0.2) & (M.parallax/M.parallax_error > 5) & (M.ruwe < 1.4)].copy()
c = SkyCoord(ra=M.ra.values*un.deg, dec=M.dec.values*un.deg, distance=(1000.0/M.parallax.values)*un.pc, frame='icrs')
gc = c.transform_to('galactocentric')
M['Z_gc'] = np.abs(gc.z.to(un.kpc).value*1000)
b = c.galactic.b.to(un.deg).value
M['Z_b'] = np.abs((1000.0/M.parallax.values)*np.sin(np.radians(b)))
M['Z_dec'] = np.abs((1000.0/M.parallax.values)*np.sin(np.radians(M.dec.values)))   # 错误做法，仅作对比
print('\n|Z| 三种算法对比（中位，pc）：银心 z %.0f | 银纬 %.0f | 赤纬(错) %.0f'
      % (M.Z_gc.median(), M.Z_b.median(), M.Z_dec.median()))
print('银纬与银心 z 的一致性: 相关系数 %.4f，中位相对差 %.1f%%'
      % (np.corrcoef(M.Z_b, M.Z_gc)[0,1], 100*np.median(np.abs(M.Z_b-M.Z_gc)/M.Z_gc)))

M['zb'] = pd.cut(M.Z_b, [0,100,200,400,3000], labels=['<100','100-200','200-400','>400'])
print('\n=== ① 每格：n、S/N 中位、可检出比例、活动率（max-EW 定义）===')
rows = []
for sp in ['dM0','dM1','dM2','dM3','dM4','dM5','dM6']:
    s = M[M.subclass == sp]
    for zb in ['<100','100-200','200-400']:
        q = s[s.zb == zb]
        if len(q) < 50: continue
        det = 100*(q.ewha_err*3 <= 0.75).mean()
        rows.append(dict(subclass=sp, zb=zb, n=len(q), snr_med=q.snrr.median(),
                         det_pct=det, fact=100*q.active_max.mean(), nep_med=q.n_ep.median()))
T1 = pd.DataFrame(rows)
print(T1.round(2).to_string(index=False))
T1.to_csv('data/processed/dr13/check_cells_subtype_Z.csv', index=False, encoding='utf-8-sig')

print('\n=== ② 亚型内部 S/N 匹配（10–30）后的 f_act(|Z|) ===')
rows2 = []
for sp in ['dM0','dM1','dM2','dM3','dM4','dM5','dM6']:
    s = M[(M.subclass == sp) & (M.snrr >= 10) & (M.snrr <= 30)]
    line = '  %-4s' % sp
    rec = dict(subclass=sp)
    for zb in ['<100','100-200','200-400']:
        q = s[s.zb == zb]
        if len(q) >= 50:
            line += '  %s %5.1f%% (n=%5d)' % (zb, 100*q.active_max.mean(), len(q))
            rec[zb] = 100*q.active_max.mean(); rec['n_'+zb] = len(q)
        else:
            line += '  %s    --   (n=%5d)' % (zb, len(q)); rec[zb] = np.nan
    print(line); rows2.append(rec)
pd.DataFrame(rows2).to_csv('data/processed/dr13/check_snmatched_subtype_Z.csv', index=False, encoding='utf-8-sig')

print('\n=== ③ 只取单历元星（n_ep = 1）后的 f_act(|Z|) ===')
one = M[M.n_ep == 1]
rows3 = []
for sp in ['dM0','dM1','dM2','dM3','dM4','dM5','dM6']:
    s = one[one.subclass == sp]
    line = '  %-4s' % sp
    for zb in ['<100','100-200','200-400']:
        q = s[s.zb == zb]
        if len(q) >= 50: line += '  %s %5.1f%% (n=%5d)' % (zb, 100*q.active_max.mean(), len(q))
        else: line += '  %s    --   (n=%5d)' % (zb, len(q))
    print(line)
print('\n=== 各 |Z| 档的历元数分布 ===')
for zb in ['<100','100-200','200-400']:
    s = M[M.zb == zb]
    print('  %-8s n=%6d  n_ep 中位 %.0f，均值 %.1f，≥2 的比例 %.1f%%'
          % (zb, len(s), s.n_ep.median(), s.n_ep.mean(), 100*(s.n_ep >= 2).mean()))
