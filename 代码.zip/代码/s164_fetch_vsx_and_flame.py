# -*- coding: utf-8 -*-
"""s164: 补两笔小数据 —— ① VSX 变星/周期目录（VizieR B/vsx，供图5 扩周期样本）
                          ② Gaia DR3 FLAME 质量（同 source_id 批量 TAP，替代论文的 TIC 质量）
用法：python s164_fetch_vsx_and_flame.py --part vsx | --part flame"""
from __future__ import annotations
import argparse, io, os, sys, time
from concurrent.futures import ThreadPoolExecutor
import pandas as pd, requests

VIZ = 'https://vizier.cds.unistra.fr/viz-bin/asu-tsv'
TAP = 'https://gea.esac.esa.int/tap-server/tap/sync'
H = {'User-Agent': 'repro-mstars/1.0'}


def vsx(out='data/vizier/b_vsx_variables.tsv'):
    params = {'-source': 'B/vsx/vsx', '-out': 'Name,RAJ2000,DEJ2000,Period,Type,max',
              '-out.max': 'unlimited'}
    t0 = time.time()
    r = requests.get(VIZ, params=params, timeout=1800, headers=H)
    r.raise_for_status()
    open(out, 'w', encoding='utf-8').write(r.text)
    n = sum(1 for _ in open(out, encoding='utf-8', errors='replace')) - 1
    print('VSX 落盘：%s，%d 行，%.1f MB，%.0f s' % (out, n, os.path.getsize(out)/2**20, time.time()-t0))


def flame(ids_file='data/gaia/missing_source_ids.txt', outdir='data/gaia/flame_batches', batch=500, workers=4):
    ids = pd.read_csv('data/lamost/dr13/dr13_mstellar_dM.csv', low_memory=False,
                      usecols=['gaia_source_id']).gaia_source_id.astype(str).str.split('.').str[0]
    ids = sorted({i for i in ids if i.isdigit()})
    os.makedirs(outdir, exist_ok=True)
    chunks = [ids[i:i+batch] for i in range(0, len(ids), batch)]
    print('FLAME：%d 个 source_id，%d 批 × %d' % (len(ids), len(chunks), batch))

    def one(it):
        k, ch = it
        dest = os.path.join(outdir, 'f_%05d.csv' % k)
        if os.path.exists(dest):
            return 0
        q = ('SELECT source_id, mass_flame, teff_gspphot, logg_gspphot FROM gaiadr3.astrophysical_parameters '
             'WHERE source_id IN (%s)' % ','.join(ch))
        for attempt in range(3):
            try:
                r = requests.post(TAP, data={'REQUEST': 'doQuery', 'LANG': 'ADQL', 'FORMAT': 'csv', 'QUERY': q},
                                  timeout=180, headers=H)
                if r.status_code == 200 and ',' in r.text[:300]:
                    open(dest, 'w', encoding='utf-8').write(r.text)
                    return len(r.text.splitlines()) - 1
            except Exception:
                time.sleep(2)
        return -1

    t0 = time.time(); tot = 0
    with ThreadPoolExecutor(max_workers=workers) as ex:
        for k, got in enumerate(ex.map(one, enumerate(chunks)), 1):
            if got > 0: tot += got
            if k % 200 == 0:
                print('   %d/%d 批，累计 %d 行，%.0f s' % (k, len(chunks), tot, time.time()-t0))
    print('FLAME 完成：%d 行，%.0f s -> %s' % (tot, time.time()-t0, outdir))


if __name__ == '__main__':
    ap = argparse.ArgumentParser(); ap.add_argument('--part', required=True)
    a = ap.parse_args()
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
    if a.part == 'vsx': vsx()
    else: flame()
