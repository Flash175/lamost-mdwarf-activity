# -*- coding: utf-8 -*-
"""s582: 把「活动率随 |Z| 下降 = 年龄效应」做成可检验的模型匹配
模型：① 用我们自己的 6D 非活动星 sigma(vz)-|Z| 关系，按 AVR 形式 sigma ∝ t^beta 反演相对年龄（Aumer et al. 2016 的形式）；
     ② 用 West 等（2008, AJ 135, 785, Table 2）的逐型活动寿命 tau（M0-M7 为实测；M8 无实测，沿用 M7）；
     ③ 预测各 |Z| 档的活动比例 P = sum_s w_s * exp(-t/tau_s)，用 <100 pc 档定标一个参数 t_ref，
        再看其余四档能否被同一模型复现。
注意：West 的 tau 是阶跃寿命（恒星出生后 tau 年内活动），本脚本用 exp(-t/tau) 作其平滑近似；
      阶跃形式在「每档只取一个中位年龄」下不可用（预测随 t 跳变，无法匹配观测的连续比例）。"""
import io, sys, os
import numpy as np, pandas as pd
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
OUT = r'C:\Users\lingz\Desktop\复现老师工作\APJS\多个图及讨论'
# 6D 非活动星的 sigma(vz) 与 |Z| 中位
d6 = pd.read_csv(os.path.join(OUT,'新图1_数据_6D分箱.csv'), comment='#')
z6 = d6['zmed_inact'].values; s6 = d6['svz_inact'].values
keep = np.isfinite(z6) & np.isfinite(s6)
z6, s6 = z6[keep], s6[keep]
print('6D 非活动星 sigma(vz) 随 |Z|：')
for a,b in zip(z6, s6): print('   z=%.1f pc  sigma=%.2f km/s' % (a,b))
# 2D 分档的 |Z| 中位与观测活动比例
B = pd.read_csv(os.path.join(OUT,'新图1_数据_2D分箱.csv'), comment='#')
zb = dict(zip(B.zbin, B.absz_med)); fb = dict(zip(B.zbin, B.frac/100.0))
# 亚型组成
R = pd.read_csv(os.path.join(OUT,'reweight_composition.csv'), comment='#')
share = {z: R[R.zbin==z].set_index('subtype').n / R[R.zbin==z].n.sum() for z in R.zbin.unique()}
# 100-200 pc 档现已由 s556_finalize_tables.py 写入 reweight_composition.csv，
# 用实测组成替代此前的 <100 pc 代填（2026-11-06 修正）
# tau：West et al. (2008) Table 2 的逐型实测活动寿命（Gyr）：M0 0.8, M1 0.4, M2 1.2, M3 2.0,
#      M4 4.5, M5 7.0, M6 7.0, M7 8.0；M8 无实测，沿用 M7 的 8.0（2026-11-06 由内插值改为实测值）
TAU = {'dM0':0.8,'dM1':0.4,'dM2':1.2,'dM3':2.0,'dM4':4.5,'dM5':7.0,'dM6':7.0,'dM7':8.0,'dM8':8.0}
def sigma_at(z):            # 用 6D 点做线性内插/外推（log z）
    return float(np.interp(np.log(z), np.log(z6), s6)) if z <= z6[-1] else float(s6[-1] + (s6[-1]-s6[-2])/(np.log(z6[-1])-np.log(z6[-2]))*(np.log(z)-np.log(z6[-1])))
def predict(t_ref, beta, tau=TAU):
    zref = zb['<100']; sref = sigma_at(zref)
    out = {}
    for k, z in zb.items():
        if k not in share: continue
        t = t_ref * (sigma_at(z)/sref)**(1.0/beta)
        P = sum(w*float(np.exp(-t/tau[s])) for s, w in share[k].items())
        out[k] = (t, P)
    return out
print('\n各 2D 档的 |Z| 中位与观测活动比例：')
for k in ['<100','100-200','200-400','400-600','600-1000']:
    print('   %-9s z=%6.1f pc  frac=%.2f%%  sigma=%.2f' % (k, zb[k], 100*fb[k], sigma_at(zb[k])))
rows = []
# 2026-11-06：β 改为文献输入而非调参——基准 0.45，并报 0.45–0.53（σ(vz) 的观测 βz 区间）
for beta in (0.30, 0.40, 0.45, 0.50, 0.53):
    # 用 <100 pc 定标：解出使 P(<100)=观测值的 t_ref（二分法）
    lo, hi = 0.05, 20.0
    for _ in range(80):
        mid = 0.5*(lo+hi)
        if predict(mid, beta)['<100'][1] > fb['<100']: lo = mid
        else: hi = mid
    tfit = 0.5*(lo+hi)
    pr = predict(tfit, beta)
    for k in ['<100','100-200','200-400','400-600','600-1000']:
        rows.append(dict(beta=beta, t_ref_fit=tfit, zbin=k, z_med=zb[k], sigma=sigma_at(zb[k]),
                         t_model_Gyr=pr[k][0], pred_pct=100*pr[k][1], obs_pct=100*fb[k],
                         ratio_obs_pred=fb[k]/pr[k][1] if pr[k][1] > 0 else np.nan))
T = pd.DataFrame(rows)
fp = os.path.join(OUT,'avr_model_match.csv')
T.to_csv(fp, index=False, encoding='utf-8')
txt = open(fp, encoding='utf-8').read()
open(fp,'w',encoding='utf-8-sig').write(
 '# AVR 模型匹配：用 sigma(vz)-|Z| 反演年龄，再用 West 的活动寿命预测活动比例\n'
 '# beta 为 AVR 斜率 sigma ∝ t^beta，作文献输入：历史区间 0.25-0.6，基准 0.45（Hipparcos/GCS 的 βz≈0.45-0.53，Holmberg et al. 2009 测量、Aumer et al. 2016 转引）；t_ref_fit 为用 <100 pc 档定标出的年龄尺度（与 beta 无关）\n'
 '# tau 取 West et al. (2008) Table 2 的逐型实测值（Gyr）：M0 0.8, M1 0.4, M2 1.2, M3 2.0, M4 4.5, M5 7.0, M6 7.0, M7 8.0；M8 无实测，沿用 M7 的 8.0\n'
 '# West 的 tau 为阶跃活动寿命（出生后 tau 年内活动），此处用 exp(-t/tau) 作平滑近似；阶跃形式在每档单一中位年龄下不可用\n'
 '# 生成脚本：代码/s582_avr_model_match.py' + chr(10) + txt)
print('\n=== 模型匹配（基准 beta = 0.45）===')
q = T[(T.beta==0.45)]
for _, r in q.iterrows():
    print('  %-9s z=%6.1f  t=%5.2f Gyr  预测 %5.1f%%  观测 %5.1f%%  观测/预测 %.2f'
          % (r.zbin, r.z_med, r.t_model_Gyr, r.pred_pct, r.obs_pct, r.ratio_obs_pred))
print('\n=== 三档 beta 的观测/预测比（<100 pc 定标，故该档恒为 1）===')
P = T.pivot_table(index='zbin', columns='beta', values='ratio_obs_pred')
order = ['<100','100-200','200-400','400-600','600-1000']
print(P.loc[order].to_string(float_format=lambda x: '%.2f' % x))
print('\n写出 avr_model_match.csv')
