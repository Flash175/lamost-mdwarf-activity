# -*- coding: utf-8 -*-
"""s573：把「去巨星」写进样本定义（M_G >= 6 且屏蔽 -9999），重算核心数字并与现口径对比。"""
import io, sys, os
import numpy as np, pandas as pd
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
from astropy.coordinates import SkyCoord
import astropy.units as un
OUT = r'C:\Users\lingz\Desktop\复现老师工作\APJS\多个图及讨论'
SUBS = ['dM0','dM1','dM2','dM3','dM4','dM5','dM6','dM7','dM8']
rng = np.random.default_rng(20261028)

def wilson(k, n, z=1.96):
    if n == 0: return (np.nan, np.nan)
    p = k/n; d = 1+z*z/n; c = (p+z*z/(2*n))/d
    h = z*np.sqrt(p*(1-p)/n + z*z/(4*n*n))/d
    return 100*(c-h), 100*(c+h)

def save(df, name, comments):
    fp = os.path.join(OUT, name); df.to_csv(fp, index=False, encoding='utf-8')
    txt = open(fp, encoding='utf-8').read()
    with open(fp, 'w', encoding='utf-8-sig') as f:
        f.write('\n'.join('# ' + c for c in comments) + '\n' + txt)
    print('  写出 %s（%d 行）' % (name, len(df)))

cat = pd.read_csv('data/lamost/dr13/dr13_mstellar_dM.csv', low_memory=False,
                  usecols=['uid','subclass','teff','logg','ewha','ewha_err','snrr','ra','dec',
                           'gaia_source_id','gaia_g_mean_mag'])
cat = cat[(cat.ewha > -20) & (cat.ewha <= 50) & (cat.ewha_err > 0) & (cat.ewha_err <= 5)].copy()
cat['active'] = (cat.ewha >= 0.75) & (cat.ewha > 3*cat.ewha_err)
cat['gaia_source_id'] = pd.to_numeric(cat.gaia_source_id, errors='coerce')
g = pd.read_csv('data/gaia/gaia_dr3_mstars.csv', low_memory=False,
                usecols=['source_id','parallax','parallax_error','pmra','pmdec','radial_velocity','ruwe'])
m = cat.merge(g, left_on='gaia_source_id', right_on='source_id', how='inner')
m = m[(m.parallax > 0.2) & (m.parallax/m.parallax_error > 5) & (m.ruwe < 1.4)].copy()
m['rv'] = m.radial_velocity
u = m.sort_values('ewha', ascending=False).drop_duplicates('uid').copy()
d = 1000.0/u.parallax.values
sc = SkyCoord(ra=u.ra.values*un.deg, dec=u.dec.values*un.deg, distance=d*un.pc, frame='icrs')
u['absz'] = np.abs(d*np.sin(np.deg2rad(sc.galactic.b.deg)))
u['MG'] = u.gaia_g_mean_mag.values - 5*np.log10(np.clip(d, 1, None)) + 5
u = u[u.absz <= 3000].copy()
u0 = u.copy()                                  # 现口径（不去巨星）
u1 = u[u.MG >= 6].copy()                        # 去巨星口径
print('现口径 %d 颗 → 去巨星后 %d 颗（剔除 %d，%.2f%%）'
      % (len(u0), len(u1), len(u0)-len(u1), 100*(1-len(u1)/len(u0))))

rows = []
print('\n 档          现 n / 现活动%      去巨星 n / 活动%      Δ活动(pp)')
for lb, zl, zh in [('<100',0,100),('100-200',100,200),('200-400',200,400),('400-600',400,600),('600-1000',600,1000)]:
    a = u0[(u0.absz >= zl) & (u0.absz < zh)]; b = u1[(u1.absz >= zl) & (u1.absz < zh)]
    fa, fb = 100*a.active.mean(), 100*b.active.mean()
    lo, hi = wilson(int(b.active.sum()), len(b))
    print('  %-9s %6d / %5.2f%%      %6d / %5.2f%%  [%.2f,%.2f]   %+.2f'
          % (lb, len(a), fa, len(b), fb, lo, hi, fb-fa))
    rows.append(dict(zbin=lb, n_now=len(a), frac_now=fa, n_cut=len(b), frac_cut=fb, lo=lo, hi=hi, delta=fb-fa))

# 分层与重加权（去巨星口径）
plane = u1[u1.absz < 100]
w = plane.subclass.value_counts(normalize=True)
print('\n 亚型   现 <100 / 200-400       去巨星 <100 / 200-400    比值(现→去)')
sub = []
for sp in SUBS:
    a0 = u0[(u0.subclass == sp) & (u0.absz < 100)]; a1 = u1[(u1.subclass == sp) & (u1.absz < 100)]
    b0 = u0[(u0.subclass == sp) & (u0.absz >= 200) & (u0.absz < 400)]
    b1 = u1[(u1.subclass == sp) & (u1.absz >= 200) & (u1.absz < 400)]
    if len(a0) < 30 or len(b0) < 30: continue
    f0 = 100*a0.active.mean()/max(100*b0.active.mean(), 1e-9)
    f1 = 100*a1.active.mean()/max(100*b1.active.mean(), 1e-9)
    print('  %-4s %5.2f%% / %5.2f%%          %5.2f%% / %5.2f%%        %.2f → %.2f'
          % (sp, 100*a0.active.mean(), 100*b0.active.mean(), 100*a1.active.mean(), 100*b1.active.mean(), f0, f1))
    sub.append(dict(subtype=sp, near_now=100*a0.active.mean(), far_now=100*b0.active.mean(),
                    near_cut=100*a1.active.mean(), far_cut=100*b1.active.mean(), ratio_now=f0, ratio_cut=f1))

def rw(df, zl, zh):
    s = df[(df.absz >= zl) & (df.absz < zh)]
    q = s.groupby('subclass').active.agg(['mean','size'])
    common = [k for k in w.index if k in q.index]
    ww = w[common]/w[common].sum()
    return 100*float((ww*q.loc[common,'mean']).sum())
print('\n 重加权（对 <100 pc 组成）：')
for lb, zl, zh in [('200-400',200,400), ('400-600',400,600), ('600-1000',600,1000)]:
    print('  %-9s 现 %.2f%% → 去巨星 %.2f%%' % (lb, rw(u0, zl, zh), rw(u1, zl, zh)))

# 6D
six0 = u0[np.isfinite(u0.rv) & (np.abs(u0.rv) < 500)].copy()
c6 = SkyCoord(ra=six0.ra.values*un.deg, dec=six0.dec.values*un.deg,
              distance=(1000.0/six0.parallax.values)*un.pc,
              pm_ra_cosdec=six0.pmra.values*un.mas/un.yr, pm_dec=six0.pmdec.values*un.mas/un.yr,
              radial_velocity=six0.rv.values*un.km/un.s, frame='icrs')
gc = c6.transform_to('galactocentric')
six0 = six0.assign(zgc=np.abs(gc.z.to(un.kpc).value)*1000)
six0 = six0[six0.zgc <= 3000]
six1 = six0[six0.MG >= 6]
print('\n6D：现口径 %d 颗 → 去巨星 %d 颗（剔除 %d）' % (len(six0), len(six1), len(six0)-len(six1)))
print('  其中 <100 pc：%d → %d；200-400 pc：%d → %d'
      % (int((six0.zgc < 100).sum()), int((six1.zgc < 100).sum()),
         int(((six0.zgc >= 200) & (six0.zgc < 400)).sum()), int(((six1.zgc >= 200) & (six1.zgc < 400)).sum())))

T = pd.DataFrame(rows); save(T, 'bins_with_giant_cut.csv', [
    '把「去巨星」（$M_G \\ge 6$）写进样本定义后的核心数字，与现口径并列',
    'frac_now / n_now 为现口径（未去巨星）；frac_cut / n_cut 为去巨星后；delta 为活动比例变化（百分点）',
    '生成脚本：代码/s573_sample_with_giant_cut.py'])
T2 = pd.DataFrame(sub); save(T2, 'subtype_with_giant_cut.csv', [
    '分亚型的近/远活动比例与降幅，现口径与去巨星口径并列',
    '生成脚本：代码/s573_sample_with_giant_cut.py'])
print('s573 完成')
