# -*- coding: utf-8 -*-
"""s564：用内盘三档拟合、外盘两档做留出检验（预测）。
模型：ln f = a + b*z（每档 |Z| 中位为自变量），逐亚型与合并值各做一遍。
输出 predicted vs measured，并给出比值与显著性。
"""
import io, sys, os
import numpy as np, pandas as pd
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
OUT = r'C:\Users\lingz\Desktop\复现老师工作\APJS\多个图及讨论'
BS = chr(92)

def save(df, name, comments):
    fp = os.path.join(OUT, name); df.to_csv(fp, index=False, encoding='utf-8')
    txt = open(fp, encoding='utf-8').read()
    with open(fp, 'w', encoding='utf-8-sig') as f:
        f.write('\n'.join('# ' + c for c in comments) + '\n' + txt)
    print('  写出 %s（%d 行）' % (name, len(df)))

def wilson(k, n, z=1.96):
    p = k/n; d = 1+z*z/n; c = (p+z*z/(2*n))/d
    h = z*np.sqrt(p*(1-p)/n + z*z/(4*n*n))/d
    return 100*(c-h), 100*(c+h)

A = pd.read_csv(os.path.join(OUT, 'far400_2d_audit.csv'), comment='#')
S = pd.read_csv(os.path.join(OUT, 'far400_subtype_table.csv'), comment='#')
zc = dict(zip(A.zbin, A.absz_med))

inner = ['<100', '100-200', '200-400']
outer = ['400-600', '600-1000']

rows = []
def fit_predict(xs, ys):
    b, a = np.polyfit(xs, ys, 1)
    return a, b

# 合并值
ys = np.log(A.set_index('zbin').loc[inner, 'frac'].values/100.0)
xs = np.array([zc[b] for b in inner], float)
a, b = fit_predict(xs, ys)
print('=== 合并值：ln f = %.4f %+.6f * z ===' % (a, b))
for lb in outer:
    pred = 100*np.exp(a + b*zc[lb])
    meas = float(A.set_index('zbin').loc[lb, 'frac'])
    lo, hi = wilson(int(A.set_index('zbin').loc[lb, 'n_act']), int(A.set_index('zbin').loc[lb, 'n']))
    print('  %-10s z=%.0f  pred=%.2f%%  meas=%.2f%% [%.2f, %.2f]  比值 %.2f'
          % (lb, zc[lb], pred, meas, lo, hi, meas/pred))
    rows.append(dict(kind='merged', subtype='all', zbin=lb, z_med=zc[lb], pred=pred,
                     meas=meas, lo=lo, hi=hi, ratio=meas/pred))

# 逐亚型
print('\n=== 逐亚型：内盘三档拟合 → 外盘预测 ===')
for sp in ['dM0','dM1','dM2','dM3','dM4','dM5']:
    q = S[S.subtype == sp].set_index('zbin')
    if not all(k in q.index for k in inner+outer): continue
    xs = np.array([zc[b] for b in inner], float); ys = np.log(q.loc[inner,'frac'].values/100.0)
    a, b = fit_predict(xs, ys)
    line = '  %-4s' % sp
    for lb in outer:
        pred = 100*np.exp(a + b*zc[lb]); meas = float(q.loc[lb,'frac'])
        n = int(q.loc[lb,'n'])
        lo, hi = wilson(int(q.loc[lb,'n_act']), n) if 'n_act' in q.columns else (np.nan, np.nan)
        line += '  | %s pred %.2f meas %.2f (n=%d) 比值 %.2f' % (lb, pred, meas, n, meas/pred if pred>0 else np.nan)
        rows.append(dict(kind='subtype', subtype=sp, zbin=lb, z_med=zc[lb], pred=pred,
                         meas=meas, lo=lo, hi=hi, ratio=meas/pred if pred>0 else np.nan))
    print(line)
save(pd.DataFrame(rows), 'holdout_prediction.csv', [
    '留出检验：用 <100 / 100–200 / 200–400 pc 三档拟合 ln f = a + b·z，预测 400–600 与 600–1000 pc，再与实测比较',
    'pred/meas 为百分数；lo/hi 为实测值的 Wilson 95%；ratio = meas/pred',
    '若 ratio >> 1，说明外盘活动率高于「内盘年龄序列」的外推 → 外盘不是内盘趋势的延续',
    '生成脚本：代码/s564_holdout_prediction.py'])
print('\ns564 完成')
