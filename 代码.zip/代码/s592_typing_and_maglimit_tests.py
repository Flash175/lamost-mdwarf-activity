# -*- coding: utf-8 -*-
"""s592：分类通道与星等限通道的正面检验

分类通道（两个独立做法）：
 C1 干净分类子集：只留 |Teff − 该亚型 <100 pc 中位| <= 100 K 的星，重算亚型内 <100 → 200–400 pc 降幅；
    若降幅仍在，说明不是标签混杂造成的。
 C2 Teff 匹配：把 200–400 pc 档的 Teff 分布重加权到 <100 pc 档（±150 K，5 箱），算匹配后的活动率。

星等限通道（两个独立做法）：
 M1 完整性受限：只留 G <= 16.5 / <= 17.0，看六档活动率与远档/近档比。
 M2 谁在承载依赖：G = M_G + 5 log10 d − 5，三者只有两个独立。逐个组合比较 AIC，判定依赖落在
    「距离（巡天深度）」还是「本征光度（恒星性质）」上。为提速，M2 用 200,000 颗随机子样本。

输出：多个图及讨论/typing_tests.csv、maglimit_tests.csv
"""
import io, sys, os
import numpy as np, pandas as pd
from scipy.optimize import minimize
from scipy.special import expit
from astropy.coordinates import SkyCoord
import astropy.units as un

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
OUT = r'C:\Users\lingz\Desktop\复现老师工作\APJS\多个图及讨论'

def save(df, name, comments):
    fp = os.path.join(OUT, name)
    df.to_csv(fp, index=False, encoding='utf-8')
    txt = open(fp, encoding='utf-8').read()
    with open(fp, 'w', encoding='utf-8-sig') as f:
        f.write('\n'.join('# ' + c for c in comments) + '\n' + txt)
    print('  写出 %s（%d 行）' % (name, len(df)))

cat = pd.read_csv('data/lamost/dr13/dr13_mstellar_dM.csv', low_memory=False,
                  usecols=['uid','subclass','teff','ewha','ewha_err','snrr',
                           'ra','dec','gaia_source_id','gaia_g_mean_mag'])
cat = cat[(cat.ewha > -20) & (cat.ewha <= 50) & (cat.ewha_err > 0) & (cat.ewha_err <= 5)].copy()
cat['active'] = (cat.ewha >= 0.75) & (cat.ewha > 3*cat.ewha_err)
cat['gaia_source_id'] = pd.to_numeric(cat.gaia_source_id, errors='coerce')
g = pd.read_csv('data/gaia/gaia_dr3_mstars.csv', low_memory=False,
                usecols=['source_id','parallax','parallax_error','ruwe'])
m = cat.merge(g, left_on='gaia_source_id', right_on='source_id', how='inner')
m = m[(m.parallax > 0.2) & (m.parallax/m.parallax_error > 5) & (m.ruwe < 1.4)].copy()
u = m.sort_values('ewha', ascending=False).drop_duplicates('uid').copy()
u['MG'] = u.gaia_g_mean_mag.values - 5*np.log10(np.clip(1000.0/u.parallax.values, 1, None)) + 5
u = u[u.MG >= 6].copy()
d_pc = 1000.0/u.parallax.values
sc = SkyCoord(ra=u.ra.values*un.deg, dec=u.dec.values*un.deg, distance=d_pc*un.pc, frame='icrs')
u['absz'] = np.abs(d_pc*np.sin(np.deg2rad(sc.galactic.b.deg)))
u = u[u.absz <= 3000].copy()
u['dist'] = d_pc
u['subc'] = u.subclass.astype(str)
u['teff'] = pd.to_numeric(u.teff, errors='coerce')
u['G'] = pd.to_numeric(u.gaia_g_mean_mag, errors='coerce')
subs = [s for s in sorted(u.subc.unique()) if (u.subc == s).sum() >= 500]
u = u[u.subc.isin(subs)].copy()
print('样本 %d 颗，活动率 %.3f%%' % (len(u), 100*u.active.mean()))

# ---------- 分类通道 ----------
print('\n=== 分类通道 C1：干净分类子集（|Teff − 中位| <= 100 K）===')
rows = []
for sp in subs:
    inner = u[(u.subc == sp) & (u.absz < 100)]
    med = inner.teff.median()
    if not np.isfinite(med): continue
    near_all = inner; far_all = u[(u.subc == sp) & (u.absz >= 200) & (u.absz < 400)]
    near_cl = inner[np.abs(inner.teff - med) <= 100]
    far_cl = far_all[np.abs(far_all.teff - med) <= 100]
    if min(len(near_all), len(far_all), len(near_cl), len(far_cl)) < 50: continue
    f1, f2 = 100*near_all.active.mean(), 100*far_all.active.mean()
    g1, g2 = 100*near_cl.active.mean(), 100*far_cl.active.mean()
    print('  %-4s 全亚型 %5.2f→%5.2f（%.2f×, n=%d/%d）｜干净分类 %5.2f→%5.2f（%.2f×, n=%d/%d）'
          % (sp, f1, f2, f1/f2, len(near_all), len(far_all), g1, g2, g1/g2, len(near_cl), len(far_cl)))
    rows.append(dict(subtype=sp, teff_med=med, test='C1_clean_typing',
                     f_inner=f1, f_far=f2, ratio=f1/f2, n_inner=len(near_all), n_far=len(far_all),
                     f_inner_test=g1, f_far_test=g2, ratio_test=g1/g2,
                     n_inner_test=len(near_cl), n_far_test=len(far_cl)))

print('\n=== 分类通道 C2：Teff 匹配（远档重加权到近档 Teff 分布）===')
for sp in subs:
    inner = u[(u.subc == sp) & (u.absz < 100)]
    far = u[(u.subc == sp) & (u.absz >= 200) & (u.absz < 400)]
    med = inner.teff.median()
    if not np.isfinite(med) or len(far) < 100: continue
    lo, hi, nb = med-150, med+150, 6
    edges = np.linspace(lo, hi, nb+1)
    wi, _ = np.histogram(inner.teff.clip(lo, hi-1e-6), bins=edges)
    wf, _ = np.histogram(far.teff.clip(lo, hi-1e-6), bins=edges)
    if wf.sum() == 0 or wi.sum() == 0: continue
    idx = np.clip(np.digitize(far.teff.values, edges)-1, 0, nb-1)
    p_in = wi/wi.sum(); p_far = wf/wf.sum()
    wgt = np.where(wf[idx] > 0, p_in[idx]/np.maximum(p_far[idx], 1e-12), 0.0)
    wgt = np.nan_to_num(wgt)
    if wgt.sum() == 0: continue
    f_far_raw = 100*far.active.mean()
    f_far_w = 100*(wgt*far.active.values).sum()/wgt.sum()
    f_in = 100*inner.active.mean()
    print('  %-4s 近档 %5.2f%%｜远档原始 %5.2f%%→Teff 匹配 %5.2f%%，降幅 %.2f× → %.2f×'
          % (sp, f_in, f_far_raw, f_far_w, f_in/f_far_raw, f_in/f_far_w))
    rows.append(dict(subtype=sp, teff_med=med, test='C2_teff_matched',
                     f_inner=f_in, f_far=f_far_raw, ratio=f_in/f_far_raw,
                     n_inner=len(inner), n_far=len(far),
                     f_inner_test=f_in, f_far_test=f_far_w, ratio_test=f_in/f_far_w,
                     n_inner_test=len(inner), n_far_test=len(far)))
save(pd.DataFrame(rows), 'typing_tests.csv', [
    's592 分类通道：C1 干净分类子集（|Teff − 亚型中位| <= 100 K）与 C2 Teff 匹配（远档重加权到近档分布）',
    'ratio = f(<100 pc) / f(200–400 pc)；ratio_test 为对应检验下的比值',
    '生成脚本：代码/s592_typing_and_maglimit_tests.py'])

# ---------- 星等限通道 ----------
print('\n=== 星等限通道 M1：G 完整性受限 ===')
rows2 = []
BINS = [(0,100,'<100'),(100,200,'100-200'),(200,400,'200-400'),(400,600,'400-600'),
        (600,1000,'600-1000'),(1000,3000,'>1000')]
for cut in [None, 17.0, 16.5]:
    sel = np.ones(len(u), bool) if cut is None else (u.G.values <= cut)
    tag = 'all' if cut is None else ('G<=%.1f' % cut)
    line = []
    for lo_, hi_, nm in BINS:
        s = sel & (u.absz.values > lo_) & (u.absz.values <= hi_)
        if s.sum() < 50: continue
        f = 100*u.active.values[s].mean()
        line.append('%s %.2f%%(n=%d)' % (nm, f, s.sum()))
        rows2.append(dict(test='M1_%s' % tag, zbin=nm, n=int(s.sum()), frac=f))
    print('  %-7s %s' % (tag, ' | '.join(line)))

print('\n=== 星等限通道 M2：G / M_G / 距离 谁承载依赖（20 万随机子样本）===')
rng = np.random.default_rng(5)
idx = rng.choice(len(u), size=min(200000, len(u)), replace=False)
v = u.iloc[idx]
z = v.absz.values/1000.0; y = v.active.values.astype(float)
G = v.G.values; MG = v.MG.values; lnD = np.log(v.dist.values)
sdum = np.column_stack([(v.subc.values == s).astype(float) for s in subs[1:]])
def fit(cols_extra):
    cols = [np.ones_like(z), z]
    for k0 in (0.05, 0.1, 0.2, 0.4, 0.6, 1.0):
        cols.append(np.clip(z-k0, 0, None))
    for j in range(sdum.shape[1]):
        cols.append(sdum[:, j])
    for e in cols_extra:
        cols.append(e)
    X = np.column_stack(cols)
    def nll(b):
        p = expit(np.clip(X @ b, -30, 30))
        return -float((y*np.log(np.clip(p,1e-12,1)) + (1-y)*np.log(np.clip(1-p,1e-12,1))).sum())
    def gr(b):
        p = expit(np.clip(X @ b, -30, 30))
        return -(X.T @ (y - p))
    b0 = np.zeros(X.shape[1]); b0[0] = np.log(max(y.mean(),1e-6)/(1-max(y.mean(),1e-6)))
    r = minimize(nll, b0, method='BFGS', jac=gr, options=dict(maxiter=3000, gtol=1e-9))
    return X.shape[1], r.fun, r.x
base_k, base_nll, _ = fit([])
print('  基准（样条+亚型FE）AIC = %.1f' % (2*base_k + 2*base_nll))
for tag, extra in [('+G', [G-17]), ('+M_G', [MG-9.47]), ('+ln d', [lnD-6.6]),
                   ('+G +M_G', [G-17, MG-9.47]), ('+ln d +M_G', [lnD-6.6, MG-9.47]),
                   ('+ln d +G', [lnD-6.6, G-17])]:
    k, nll, beta = fit(extra)
    aic = 2*k + 2*nll
    coefs = ' '.join('%+.4f' % b for b in beta[base_k:])
    print('  %-12s AIC = %.1f  ΔAIC = %+8.1f  系数 %s' % (tag, aic, aic-(2*base_k+2*base_nll), coefs))
    rows2.append(dict(test='M2_%s' % tag.strip(), zbin='(subset 200k)', n=int(len(v)),
                      frac=float(aic), aic=float(aic), delta_aic=float(aic-(2*base_k+2*base_nll)),
                      coefs=coefs))
save(pd.DataFrame(rows2), 'maglimit_tests.csv', [
    's592 星等限通道：M1 = G 完整性受限下的六档活动率；M2 = G / M_G / ln d 组合的 AIC 比较（20 万随机子样本）',
    'M1 行的 frac 为活动率百分数；M2 行的 aic/delta_aic/coefs 为模型统计量，frac 列存 AIC 以便单表保存',
    '生成脚本：代码/s592_typing_and_maglimit_tests.py'])
print('\ns592 完成')
