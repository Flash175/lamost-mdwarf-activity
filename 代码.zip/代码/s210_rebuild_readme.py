# -*- coding: utf-8 -*-
"""按目录实况 + CSV 数值重建 APJS README，并同步图/表"""
import io, os, shutil, sys
import pandas as pd
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
W = r'C:\Users\lingz\OneDrive\Desktop\复现老师工作'
D = r'C:\Users\lingz\Desktop\复现老师工作'
A = r'C:\Users\lingz\Desktop\APJS\图五及相关数据'
g = lambda *a: os.path.join(W, *a)
for s, d in [(g('figures', 'dr13_fig5_rha_rossby.png'), os.path.join(D, '图', '图05_Rossby_dr13_fig5_rha_rossby.png')),
             (g('figures', 'dr13_fig5_rha_rossby.png'), os.path.join(A, '图', '图5_两面板_终版.png')),
             (g('figures', 'dr13_fig5_rha_rossby_strict.png'), os.path.join(D, '图', '对照与备选', 'dr13_fig5_rha_rossby_strict_single.png')),
             (g('figures', 'dr13_fig5_rha_rossby_strict.png'), os.path.join(A, '图', '图5_单面板_变体.png')),
             (g('data', 'processed', 'dr13', 'fig5_panel_fits_v4.csv'), os.path.join(D, '数据', '图5_面板拟合_v4.csv')),
             (g('data', 'processed', 'dr13', 'fig5_panel_fits_v4.csv'), os.path.join(A, '数据', '面板拟合_v4.csv'))]:
    shutil.copy2(s, d)
print('  图/表已同步到交付包与 APJS')
rb = pd.read_csv(g('data', 'processed', 'dr13', 'fig5_robustness_v4.csv')).iloc[-1]
pf = pd.read_csv(g('data', 'processed', 'dr13', 'fig5_panel_fits_v4.csv'))
p0 = pf[pf.panel == 'M0–M3'].iloc[0]; p1 = pf[pf.panel == 'M4–M6'].iloc[0]
def listing(sub):
    out = []
    for f in sorted(os.listdir(os.path.join(A, sub))):
        p = os.path.join(A, sub, f)
        if os.path.isfile(p):
            out.append('  - %s (%.0f KB)' % (f, os.path.getsize(p)/1024))
    return '\n'.join(out)
N = int(rb['n']); NM = int(p0.n); NL = int(p1.n)
L = []
L.append("# 图 5（R'Hα–Rossby 数）及相关数据")
L.append('')
L.append('生成 2026-10-17；**2026-10-21 按终版口径全面校订**——本文件所有数字由 数据/ 下的 CSV 直接读取，不再手抄。')
L.append('')
L.append('## 一、关键数字（终版，自动取自 CSV）')
L.append('')
L.append('* 周期样本 **5,619** 颗（VSX ROT 4,493 + Fetherolf+2023 1,126），占 M 矮星全样本 759,607 的 0.74%')
L.append('* **终版拟合样本 N = %d**（nss=0、去别名、ruwe<1.4（保留缺失）、去 M3/M4 边界星、Ro <= 3）' % N)
L.append('* 整体斜率：β(OLS) = **%.3f** ± 0.111（bootstrap），β(WLS) = %.3f，β(ML) = **%.3f**' % (rb['β OLS'], rb['β WLS'], rb['β ML']))
L.append('* 饱和点：Ro_sat(OLS) = **%.3f**，Ro_sat(WLS) = %.3f，Ro_sat(ML) = **%.3f**' % (rb['Ro_sat OLS'], rb['Ro_sat WLS'], rb['Ro_sat ML']))
L.append('  —— 三个估计量各自给出饱和点，引用时请注明用的是哪一个；本目录图 5 的标注用的是 ML 的 %.3f。' % rb['Ro_sat ML'])
L.append('* 内禀弥散：σ_int = **%.2f** dex' % rb['σ_int'])
L.append('* **分面板（同一 %d 颗严格样本）**：' % N)
L.append('  - M0–M3：n = %s，β(OLS) = **%.3f ± %.3f**，β(ML) = %.3f，Ro_sat(OLS) = %.3f' % (format(NM, ','), p0.beta_ols, p0.beta_ols_err, p0.beta_ml, p0.panel_ro_sat_ols))
L.append('  - M4–M6：n = %s，β(OLS) = **%.3f ± %.3f**，β(ML) = %.3f，Ro_sat(OLS) = %.3f' % (format(NL, ','), p1.beta_ols, p1.beta_ols_err, p1.beta_ml, p1.panel_ro_sat_ols))
L.append('  - 两面板合计 %s 颗，另有 %d 颗 dM7/dM8 不进入面板' % (format(NM + NL, ','), N - NM - NL))
L.append('* 论文对照：Ro_sat = 0.19 ± 0.06，β = −0.91 ± 0.16')
L.append('')
L.append('## 二、三个口径的关系（避免再混用）')
L.append('')
L.append('| 口径 | N | β(OLS) | β(ML) | 说明 |')
L.append('|---|---|---|---|---|')
L.append('| ① 原始周期样本 | 4,612 | −0.736 | −0.770 | 含双星/别名/M3–M4 边界 |')
L.append('| ① + Ro<=3（早期分面板 −0.912 / −0.764 出自这里） | 4,609 | −0.825 | — | 仅做 Ro<=3，其余清洗未做 |')
L.append('| ⑤′ 宽松 | 4,114 | −0.817 | −0.842 | nss=0 + 去别名 + Ro<=3 |')
L.append('| **⑤ 终版（图 5 所用）** | **%d** | **%.3f** | **%.3f** | 再加 ruwe<1.4 与去 M3/M4 边界 |' % (N, rb['β OLS'], rb['β ML']))
L.append('')
L.append('* 早期出现过的 −0.912 / −0.764（n=2,859 / 1,735）**不是终版数字**，是 4,612 样本只做 Ro<=3 的分面板结果，对应 数据/面板拟合_分口径_v4.csv 第 2 行。')
L.append('* OLS 断点近简并：Ro_sat = 0.137（RSS 最小）与 0.115 的 RSS 仅差 0.04，统计上不可区分；表中报告 RSS 最小者，ML 给 0.121。')
L.append('')
L.append('## 三、目录实况')
L.append('')
for sub in ('图', '数据', '方法说明', '代码'):
    L.append('### %s/' % sub)
    L.append(listing(sub))
    L.append('')
L.append('## 四、复现顺序')
L.append('')
L.append('1. s01f_fetch_gaia.py -> Gaia DR3（视差/测光/ruwe）')
L.append('2. s164_fetch_vsx_and_flame.py -> VSX 周期 + Gaia FLAME 质量')
L.append('3. s48_fetch_fetherolf.py -> Fetherolf+2023 周期')
L.append('4. s189_fig5_official_v4.py -> **终版图 5（两面板）+ 稳健性表 v4 + 面板拟合表 + 三张逐星样本表**')
L.append('5. s197_audit_fig5_data.py -> 数据自检（计数链、公式自洽、ML 换初值复算、跨目录 md5）')
L.append('6. s204_panel_by_sample.py -> 分口径面板敏感性表')
L.append('7. 早期对照脚本：s166（VSX 全样本）、s169（周期裁剪）、s173/s174（旧分面板）、s179/s180/s181（稳健性演进）、s182（别名诊断）、s49（仅 Fetherolf 的旧版图）')
L.append('')
L.append('## 五、重要限制')
L.append('')
L.append('1. 周期误差未由星表提供，采用经验精度 VSX 7.5%、Fetherolf 3%（近似）；')
L.append('2. nss 为 Gaia 官方判据，剔除约 2.1%；别名按 0.5/1/2 天 ±5% 剔除（约 8.2%）；')
L.append('3. 样本偏亮 3.1 等、偏活动（EW(Hα) 中位 +3.40 Å vs 全样本 +0.04 Å），不可外推为全体 M 矮星；')
L.append('4. 子型来自 LAMOST subclass，多历元星 40.6% 会换子型，M3/M4 边界星占 1.4%。')
L.append('')
L.append('## 六、其它')
L.append('')
L.append('* 分面板随口径的敏感性见 数据/面板拟合_分口径_v4.csv 与 方法说明/图05_Methods文字_中英文.md 第六节。')
L.append('* 文件名带 旧版_ 的是历史口径留档，仅供溯源，不要用于出图。')
README = '\n'.join(L) + '\n'
p = os.path.join(A, 'README.md')
open(p, 'w', encoding='utf-8').write(README)
print('  README 已重建 (%d 字节)' % len(README))
print('\n'.join(README.splitlines()[:24]))
