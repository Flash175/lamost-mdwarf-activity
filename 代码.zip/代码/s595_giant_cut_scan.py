# -*- coding: utf-8 -*-
"""s595：去巨星切口从 M_G>=6 收紧到 >=7 / >=7.5 的影响（六档 + 两档重点）

背景：亮限子样本（M_G < 6、600–1000 pc 仅 361 颗）活动率 15.0%，远高于整档 7.76%；
这 361 颗贴着切口边界，可能是亚巨星/错标污染。本文的去巨星只用绝对星等 M_G >= 6，
本脚本检验「把切口收紧是否会改变六档活动率与地板形状」。
输出：多个图及讨论/giant_cut_threshold_scan.csv
"""
import io, sys, os
import numpy as np, pandas as pd
from astropy.coordinates import SkyCoord
import astropy.units as un

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
OUT = r'C:\Users\lingz\Desktop\复现老师工作\APJS\多个图及讨论'

def wilson(k, n, z=1.96):
    if n == 0: return (np.nan, np.nan)
    p = k/n; d = 1 + z*z/n; c = (p + z*z/(2*n))/d
    h = z*np.sqrt(p*(1-p)/n + z*z/(4*n*n))/d
    return (100*(c-h), 100*(c+h))

cat = pd.read_csv('data/lamost/dr13/dr13_mstellar_dM.csv', low_memory=False,
                  usecols=['uid','subclass','teff','logg','ewha','ewha_err','snrr',
                           'ra','dec','gaia_source_id','gaia_g_mean_mag'])
cat = cat[(cat.ewha > -20) & (cat.ewha <= 50) & (cat.ewha_err > 0) & (cat.ewha_err <= 5)].copy()
cat['active'] = (cat.ewha >= 0.75) & (cat.ewha > 3*cat.ewha_err)
cat['gaia_source_id'] = pd.to_numeric(cat.gaia_source_id, errors='coerce')
g = pd.read_csv('data/gaia/gaia_dr3_mstars.csv', low_memory=False,
                usecols=['source_id','parallax','parallax_error','ruwe'])
m = cat.merge(g, left_on='gaia_source_id', right_on='source_id', how='inner')
m = m[(m.parallax > 0.2) & (m.parallax/m.parallax_error > 5) & (m.ruwe < 1.4)].copy()
u = m.sort_values('ewha', ascending=False).drop_duplicates('uid').copy()
u['MG'] = u.gaia_g_mean_mag.values - 5*np.log10(np.clip(1000.0/u.parallax.values, 1, None)) + 5
d_pc = 1000.0/u.parallax.values
sc = SkyCoord(ra=u.ra.values*un.deg, dec=u.dec.values*un.deg, distance=d_pc*un.pc, frame='icrs')
u['absz'] = np.abs(d_pc*np.sin(np.deg2rad(sc.galactic.b.deg)))
u = u[u.absz <= 3000].copy()
u['subc'] = u.subclass.astype(str)
print('去 |Z|>3 kpc 后 %d 颗' % len(u))

BINS = [(0,100,'<100'),(100,200,'100-200'),(200,400,'200-400'),(400,600,'400-600'),
        (600,1000,'600-1000'),(1000,3000,'>1000')]
rows = []
for cut in [6.0, 6.5, 7.0, 7.5]:
    s = u[u.MG >= cut]
    for lo, hi, nm in BINS:
        q = s[(s.absz > lo) & (s.absz <= hi)]
        if len(q) == 0: continue
        k = int(q.active.sum()); n = len(q); lo_, hi_ = wilson(k, n)
        rem = u[(u.absz > lo) & (u.absz <= hi) & (u.MG < cut)]
        rows.append(dict(MG_cut=cut, zbin=nm, n=n, n_act=k, frac=100*k/n, lo=lo_, hi=hi_,
                         n_removed=len(rem),
                         frac_removed=100*rem.active.mean() if len(rem) else np.nan))
        if cut in (6.0, 7.0) and nm in ('400-600', '600-1000'):
            print('  M_G>=%.1f  %-9s n=%6d 活动 %d → %.2f%% [%.2f, %.2f]；本刀剔除 %d 颗（其活动率 %.2f%%）'
                  % (cut, nm, n, k, 100*k/n, lo_, hi_, len(rem), 100*rem.active.mean() if len(rem) else np.nan))
T = pd.DataFrame(rows)
fp = os.path.join(OUT, 'giant_cut_threshold_scan.csv')
T.to_csv(fp, index=False, encoding='utf-8')
txt = open(fp, encoding='utf-8').read()
hdr = ('# s595：去巨星切口 M_G >= 6 / 6.5 / 7 / 7.5 的敏感性扫描（六档）\n'
       '# n_removed / frac_removed = 该刀从本档剔除的星数与这些星的活动率（若整档全部保留则为被剔掉那部分）\n'
       '# 基线（正文采用）为 M_G >= 6；生成脚本：代码/s595_giant_cut_scan.py\n')
open(fp, 'w', encoding='utf-8-sig').write(hdr + txt)
print('\n写出 giant_cut_threshold_scan.csv（%d 行）' % len(T))
print('\n六档在 M_G>=6 与 >=7 下的活动率对照：')
a = T[T.MG_cut == 6.0].set_index('zbin')['frac']; b = T[T.MG_cut == 7.0].set_index('zbin')['frac']
for nm in a.index:
    if nm in b.index:
        print('  %-9s %.2f%% → %.2f%%（Δ %+.2f pp，剔除 %d 颗）'
              % (nm, a[nm], b[nm], b[nm]-a[nm], int(T[(T.MG_cut==7.0)&(T.zbin==nm)].n_removed.iloc[0])))
