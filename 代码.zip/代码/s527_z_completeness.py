
# -*- coding: utf-8 -*-
"""|Z| 趋势是否受探测效应污染：按 S/N 与星等匹配后重算活动比例。"""
import io, sys
import numpy as np, pandas as pd
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
from astropy.coordinates import SkyCoord
import astropy.units as un
cat = pd.read_csv('data/lamost/dr13/dr13_mstellar_dM.csv', low_memory=False,
                  usecols=['uid','ewha','ewha_err','snrr','ra','dec','gaia_source_id','gaia_g_mean_mag'])
cat = cat[(cat.ewha > -20) & (cat.ewha <= 50) & (cat.ewha_err > 0) & (cat.ewha_err <= 5)].copy()
cat['active'] = (cat.ewha >= 0.75) & (cat.ewha > 3*cat.ewha_err)
cat['gaia_source_id'] = pd.to_numeric(cat.gaia_source_id, errors='coerce')
g = pd.read_csv('data/gaia/gaia_dr3_mstars.csv', low_memory=False,
                usecols=['source_id','parallax','parallax_error','ruwe']).rename(columns={'ruwe':'ruwe_gaia'})
m = cat.merge(g, left_on='gaia_source_id', right_on='source_id', how='inner')
m = m[(m.parallax > 0.2) & (m.parallax/m.parallax_error > 5) & (m.ruwe_gaia < 1.4)]
u = m.sort_values('ewha', ascending=False).drop_duplicates('uid').copy()
c = SkyCoord(ra=u.ra.values*un.deg, dec=u.dec.values*un.deg, distance=(1000.0/u.parallax.values)*un.pc, frame='icrs')
u['absz'] = np.abs(c.transform_to('galactocentric').z.to(un.kpc).value*1000)
u['zb'] = pd.cut(u.absz, [0,100,200,400,3000], labels=['<100','100-200','200-400','>400'])
print('样本 %d 颗' % len(u))
print('\n各 |Z| 档的中位 S/N 与 Gaia G（检验趋势是否被探测效应驱动）：')
for b in ['<100','100-200','200-400','>400']:
    s = u[u.zb == b]
    print('  %-8s n=%6d  S/N 中位 %5.1f  G 中位 %5.1f  活动率 %5.1f%%' % (b, len(s), s.snrr.median(), s.gaia_g_mean_mag.median(), 100*s.active.mean()))
print('\n匹配到 S/N 6-20 且 G 15-17.5 后的活动率：')
q = u[(u.snrr >= 6) & (u.snrr <= 20) & (u.gaia_g_mean_mag >= 15) & (u.gaia_g_mean_mag <= 17.5)]
for b in ['<100','100-200','200-400']:
    s = q[q.zb == b]
    if len(s) < 100: print('  %-8s 样本不足 (%d)' % (b, len(s))); continue
    print('  %-8s n=%6d  S/N 中位 %4.1f  G 中位 %4.1f  活动率 %5.1f%%' % (b, len(s), s.snrr.median(), s.gaia_g_mean_mag.median(), 100*s.active.mean()))
