# -*- coding: utf-8 -*-
"""脚注换行 + 第九节改写为最终版"""
import io, os, shutil, sys, textwrap
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
import numpy as np, pandas as pd
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
W = r'C:\Users\lingz\OneDrive\Desktop\复现老师工作'; D = r'C:\Users\lingz\Desktop\复现老师工作'; A = r'C:\Users\lingz\Desktop\APJS\图五及相关数据'
g = lambda *a: os.path.join(W, *a)
use = pd.read_csv(g('data','processed','dr13','pcyc_vs_prot_expanded.csv'))
lit = pd.read_csv(g('data','raw','activity_cycle_data_complete.csv'))
lit['P_cyc'] = pd.to_numeric(lit.P_cyc_yr, errors='coerce'); lit['ProT'] = pd.to_numeric(lit.P_rot_days, errors='coerce')
ok = lit.dropna(subset=['P_cyc','ProT'])
fig, ax = plt.subplots(figsize=(7.0, 5.4))
ax.errorbar(ok.ProT, ok.P_cyc, yerr=pd.to_numeric(ok.P_cyc_err_yr, errors='coerce'),
            xerr=pd.to_numeric(ok.P_rot_err_days, errors='coerce'), fmt='none', ecolor='0.78', lw=0.7, zorder=2)
ax.scatter(ok.ProT, ok.P_cyc, s=34, c='#1f4fd8', label='literature table (N=%d)' % len(ok), zorder=3)
for s, m, c in (('VSX','o','#d95f02'), ('TESS(ours)','^','#2e8b57')):
    q = use[use.src == s]
    if len(q): ax.scatter(q.P_rot, q.P_yr, s=52, marker=m, facecolors='none', edgecolors=c, lw=1.4,
                          label='recomputed, P$_{rot}$ from %s (N=%d)' % (s, len(q)), zorder=4)
for _, r in use.iterrows():
    ax.annotate(str(r.star), (r.P_rot, r.P_yr), textcoords='offset points', xytext=(6, 3), fontsize=6.2,
                color='#2e8b57' if str(r.src).startswith('TESS') else '#8c3b00')
for _, r in ok.iterrows():
    ax.annotate(str(r.Star), (r.ProT, r.P_cyc), textcoords='offset points', xytext=(5, -9), fontsize=5.9, color='0.4')
ax.scatter([25.4], [11.0], marker='*', s=220, color='goldenrod', edgecolor='k', lw=0.6, zorder=5)
ax.annotate('Sun', (25.4, 11.0), xytext=(7, -9), textcoords='offset points', fontsize=7)
ax.set_xscale('log'); ax.set_yscale('log'); ax.set_xlabel('P$_{rot}$ (days)', fontsize=11); ax.set_ylabel('P$_{cyc}$ (years)', fontsize=11)
ax.set_xlim(1.5, 330); ax.set_ylim(1.5, 34); ax.grid(alpha=0.25, which='both', lw=0.4)
ax.tick_params(direction='in', top=True, right=True, labelsize=9)
ax.legend(fontsize=6.8, loc='upper left', framealpha=0.95)
ax.set_title('Activity cycle vs rotation period: %d literature + %d recomputed points' % (len(ok), len(use)), fontsize=10)
foot = textwrap.fill('Circles: P_rot from VSX (BY/ROT spot modulation, 5 arcsec). Triangles: our Lomb-Scargle P_rot from TESS SPOC light curves '
                     '(peak power >= 0.10, 0.25 < P < 90 d). P_cyc: our Lomb-Scargle on the Ibanez Bustos et al. (2025) Table B1 '
                     '(FAP < 0.05, P_cyc <= 0.95 x baseline).', 118)
fig.text(0.5, 0.012, foot, ha='center', fontsize=6.2, color='0.3', linespacing=1.6)
fig.tight_layout(rect=(0, 0.09, 1, 1))
o = g('figures','dr13_figPcyc_Prot_expanded.png'); fig.savefig(o, dpi=180); plt.close(fig)
for t in (os.path.join(D,'图','对照与备选','附_Pcyc_vs_Prot_扩展_自算.png'), os.path.join(A,'图','附_Pcyc_vs_Prot_扩展_自算.png')):
    shutil.copy2(o, t)
print('  图已重绘同步（脚注换行）')
SEC = """
## 九、扩展 P_cyc–P_rot 样本（最终版，2026-10-21）

**三条取 P_rot 的途径与结果**

| 途径 | 覆盖 | 结果 |
|---|---|---|
| 本地 VSX（5″） | 35 星 → 29 有对应 → 11 带周期 | 质量合格 4 颗（BY 型星斑调制） |
| VizieR ZTF 周期变星表 J/ApJS/249/18 | 35 星逐个 60″ 锥形搜索 | **0 命中**（这批亮星在 ZTF 饱和，未进该表） |
| MAST TESS SPOC 光变曲线（我们自己算 LS） | 缺 P_rot 的 14 星 → 11 星取到并算出周期 | 通过质量筛选 4 颗，其中 **GJ 79** 也有自算周期 → 可用 1 颗 |

最终 **5 个新点**（图：附_Pcyc_vs_Prot_扩展_自算.png；表：Pcyc与Prot_扩展样本.csv）：

| 星 | P_rot (d) | 来源 | P_cyc (yr) | FAP | 基线 (yr) |
|---|---|---|---|---|---|
| GJ 876 | 16.86 | VSX (BY) | 3.32 | 3×10⁻⁷ | 8.9 |
| GJ 79 | 78.46 | TESS 自算 | 5.58 | 0.030 | 18.0 |
| GJ 699 | 130.0 | VSX (BY) | 8.76 | 3×10⁻³ | 16.0 |
| GJ 674 | 33.29 | VSX (BY) | 13.46 | 1×10⁻³ | 15.0 |
| GJ 205 | 33.61 | VSX (BY) | 14.74 | 3×10⁻¹⁰ | 21.0 |

连同文献表 8 点，图上共 **13 点**。

**TESS 那一批的诚实说明**：单扇区、仅做二次多项式去趋势的快速 LS 只给出 4/11 个可信峰（其余峰功率 < 0.05 或落在 100 d 搜索边界，是仪器系统误差与趋势残余，非自转信号）。要真正把这批亮星的 P_rot 定准，需要多扇区合并 + 系统误差不敏感周期图（SPI/GP 去趋势），属于另一项独立工作。

**限制**：BY 型周期是星斑调制，可能混入双星轨道周期；TESS 的 P_rot 是我们的复算值；P_cyc 也是我们的复算值而非 IB2025 发表值。13 点散布仍不足以支持定量关系（r ≈ −0.3），图中仅作存在性展示。
"""
for p in (os.path.join(D,'文档','图05_Methods文字_中英文.md'), os.path.join(A,'方法说明','图05_Methods文字_中英文.md')):
    s = open(p, encoding='utf-8').read()
    i = s.find('## 九、扩展 P_cyc–P_rot 样本')
    if i >= 0:
        s = s[:i] + SEC.lstrip('\n') + '\n'
        open(p, 'w', encoding='utf-8').write(s); print('  第九节已替换为最终版:', p.split('\\')[-3:])
    else:
        open(p, 'w', encoding='utf-8').write(s.rstrip() + '\n' + SEC); print('  第九节已追加:', p.split('\\')[-3:])
