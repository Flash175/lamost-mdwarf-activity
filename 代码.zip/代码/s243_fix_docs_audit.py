# -*- coding: utf-8 -*-
"""按复审意见修文档：Gl273、判据重述、扩展点、-0.742 残留、脚本留档、README"""
import io, os, glob, shutil, sys
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
import numpy as np, pandas as pd
W = r'C:\Users\lingz\OneDrive\Desktop\复现老师工作'; D = r'C:\Users\lingz\Desktop\复现老师工作'; A = r'C:\Users\lingz\Desktop\APJS\图五及相关数据'
g = lambda *a: os.path.join(W, *a)
# 1) 判据改为 0.75 x baseline
q = pd.read_csv(g('data','processed','dr13','ib2025_cycles_quality.csv'))
q['pass'] = np.where(q.perm_FAP.notna(), (q.perm_FAP <= 0.001) & (q.base_ratio <= 0.75), (q.FAP < 0.01) & (q.base_ratio <= 0.75))
q.to_csv(g('data','processed','dr13','ib2025_cycles_quality.csv'), index=False)
vsx = pd.read_csv(g('data','processed','dr13','ib2025_stars_with_prot.csv')); vsx['key'] = vsx.star.str.replace(' ','').str.upper()
vsx['P_vsx'] = np.where(vsx.sep_as < 5, vsx.P_rot, np.nan)
q['key'] = q.star.str.replace(' ','').str.upper()
M = q.merge(vsx[['key','P_vsx']], on='key', how='left')
M['P_rot'] = M.P_vsx; M['src'] = np.where(M.P_vsx.notna(), 'VSX', '')
use = M[M['pass'] & M.P_rot.notna()].copy()
use.to_csv(g('data','processed','dr13','pcyc_vs_prot_expanded.csv'), index=False)
print('入图的复算点 %d：%s' % (len(use), ', '.join(use.star)))
for s, t in [(g('data','processed','dr13','ib2025_cycles_quality.csv'), os.path.join(A,'数据','IB2025_周期质量表_置换FAP.csv')),
             (g('data','processed','dr13','pcyc_vs_prot_expanded.csv'), os.path.join(D,'数据','Pcyc与Prot_扩展样本.csv')),
             (g('data','processed','dr13','pcyc_vs_prot_expanded.csv'), os.path.join(A,'数据','Pcyc与Prot_扩展样本.csv'))]:
    shutil.copy2(s, t)
n_analytic = int(((q.FAP < 0.01) & (q.base_ratio <= 0.75)).sum())
n_perm = int((q.perm_FAP <= 0.001).sum())
# 2) 文档替换
SEC7 = """## 七、IB2025 时间序列复算（2026-10-21，已按复审意见收紧判据）

* Table B1：2,806 点 / 33 星；可分析 22 星（N≥15、基线≥8 yr）。
* 判据分两级：
  - **宽松（解析 FAP<0.01 且 P≤0.75×基线）**：%d 颗；
  - **严格（2000 次内取 1000 次置换 bootstrap FAP≤0.1%%，且 P≤0.75×基线）**：对 6 颗关键星做了置换检验，只有 **%d 颗通过**（GJ 273、GJ 876）。
* 因此"周期在 M 矮星中普遍存在"的表述**必须下调**：可靠的只是"少数星存在显著调制"。此前写的"20/22 检出、15 颗落在 3–19 yr"是基于解析 FAP，偏宽松，已作废。
* 可重复性：GJ 628 自算 9.83 yr vs SM2016 4.4 yr（2.23 倍）；Gl 273 见第八节（跨文献不可比）。
* 文件：数据/IB2025_时间序列自算周期_22星.csv、IB2025_周期质量表_置换FAP.csv、IB2025_置换FAP_6星.csv、IB2025_TableB1_时间序列.dat、IB2025_sources.dat；图：图/附_IB2025_自算周期_FAP.png
""" % (n_analytic, n_perm)
SEC8_ADD = """
### 关于 Gl 273 的更正（2026-10-21 复审）

此前写成"GdS2012 报 3.5 yr，我方复算 3.39 yr，两表一致"——**该比较不成立**：GdS2012 对 Gl 273 明确声明未能拟合出正弦周期（原文：we were not able to properly fit a sinusoidal to the Na I time series），该文的周期拟合只针对 Gl 433（1665 d）。因此不能把 3.5 yr 归给 GdS2012。

现状的正确表述：用 IB2025 Table B1 的时间序列，**S 指数存在显著调制**（我们的 LS 主峰 3.39 yr，置换 bootstrap FAP < 0.1%），但**周期值本身不确定**——次峰 2.78 yr 的功率仅比主峰低 1.5%，两位有效数字都谈不上；IB2025 正文仍把 GJ 273 列为"未检出周期"。故：**调制存在、周期值不入表**，CSV 注释已按此改写。
"""
SEC9 = """## 九、扩展 P_cyc–P_rot 样本（收紧后最终版，2026-10-21）

**判据**：置换 bootstrap FAP ≤ 0.1%（IB2025 标准）且 P_cyc ≤ 0.75×基线（覆盖不少于约 1.3 个周期）。

| 星 | P_rot (d, VSX) | P_cyc (yr) | 置换 FAP | 基线 (yr) | P/base |
|---|---|---|---|---|---|
| GJ 205 | 33.61 | 14.74 | <0.001 | 21.0 | 0.70 |
| GJ 876 | 16.86 | 3.32 | <0.001 | 8.9 | 0.37 |

**被剔除的 3 个此前入选点**：GJ 79（置换 FAP 0.334，完全不显著）、GJ 699（0.027）、GJ 674（0.011，且 13.5 yr 已占基线 0.90）。连同文献表 8 点，图上共 **10 点**。

**与第三方复审的差异（如实记录）**：同一数据在不同去趋势/频率网格下，置换 FAP 会变——对方得 GJ 205/GJ 699 通过、GJ 876 FAP=0.0085；我们得 GJ 205/GJ 876 通过、GJ 699 FAP=0.027。两者交集为 **GJ 205**。因此本图的可靠结论只有：**这两个（乃至一个）点不足以支撑任何 P_cyc–P_rot 关系**，图仅作示意，正文不应据此推断斜率或相关。

**三条取 P_rot 的途径**：VSX（4 颗带周期、5″ 匹配）✓；VizieR ZTF 周期表（35 星全 0 命中，亮星饱和）✗；TESS SPOC 自算（11 星算出、4 星峰功率 ≥0.10，其中仅 GJ 79 同时有周期，但被置换检验否掉）。
"""
MD = [os.path.join(D,'文档','图05_Methods文字_中英文.md'), os.path.join(A,'方法说明','图05_Methods文字_中英文.md')]
for p in MD:
    s = open(p, encoding='utf-8').read()
    i7, i8, i9 = s.find('## 七、'), s.find('## 八、'), s.find('## 九、')
    if i9 > 0:
        s = s[:i9].rstrip() + '\n\n' + SEC9
    else:
        s = s.rstrip() + '\n\n' + SEC9
    if i7 > 0 and i8 > i7:
        s = s[:i7] + SEC7 + '\n' + s[i8:].lstrip('\n')
        s = s.replace('## 八、活动周', '## 八、活动周', 1)
    if '关于 Gl 273 的更正' not in s:
        s = s.rstrip() + '\n' + SEC8_ADD
    s = s.replace('−0.742', '−0.736').replace('-0.742', '-0.736')
    open(p, 'w', encoding='utf-8').write(s)
    print('  已更新:', p.split('\\')[-3:])
for p in (os.path.join(D,'文档','交付说明.md'), os.path.join(D,'说明.md'),
          os.path.join(A,'方法说明','交付说明_全量.md'), os.path.join(A,'方法说明','口径假设台账_全量.md'),
          os.path.join(D,'文档','口径假设台账.md')):
    if not os.path.exists(p): continue
    s = open(p, encoding='utf-8').read(); o = s
    s = s.replace('−0.742', '−0.736').replace('-0.742', '-0.736')
    s = s.replace('Gl 273 的 3.5 yr', 'Gl 273 的周期（原文未拟合）')
    if s != o: open(p, 'w', encoding='utf-8').write(s); print('  残留修正:', os.path.basename(p))
# 3) 脚本留档
for f in sorted(glob.glob(os.path.join(W,'repro','src','s2*.py'))):
    shutil.copy2(f, os.path.join(A,'代码',os.path.basename(f)))
print('  已把 %d 个 s2xx 脚本复制进 APJS 代码目录' % len(glob.glob(os.path.join(W,'repro','src','s2*.py'))))
