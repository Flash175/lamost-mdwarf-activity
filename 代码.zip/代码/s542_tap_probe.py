
import io, sys, urllib.parse, urllib.request
import pandas as pd
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
LAM='https://www.lamost.org/openapi'; token=open('extract/lamost_token.txt').read().strip()
def lam(sql):
    url = LAM + '/dr13/v1.0/sql?' + urllib.parse.urlencode({'sql': sql, 'output.fmt':'csv','token':token})
    return pd.read_csv(io.StringIO(urllib.request.urlopen(url, timeout=180).read().decode('utf-8').lstrip('\ufeff')))
sql = ("select obsid, gaia_source_id from stellar where subclass like 'K%' and logg > 3.8 and teff between 3900 and 5500 "
       "and obsid % 60 = 13 and snrr between 4 and 30 and gaia_g_mean_mag between 14.0 and 18.0 limit 30000")
meta = lam(sql); meta['sid'] = pd.to_numeric(meta.gaia_source_id, errors='coerce')
ids = meta.sid.dropna().astype('int64').unique().tolist()
print('IDs:', len(ids))
def tap(ids_sub):
    q = ("select source_id, ruwe from gaiadr3.gaia_source where source_id in ("
         + ','.join(str(int(i)) for i in ids_sub) + ')')
    url = 'https://gea.esac.esa.int/tap-server/tap/sync?' + urllib.parse.urlencode(
        {'REQUEST':'doQuery','LANG':'ADQL','FORMAT':'csv','QUERY':q})
    return pd.read_csv(io.StringIO(urllib.request.urlopen(url, timeout=180).read().decode('utf-8','replace')))
for n in (100, 200, 500):
    try:
        d = tap(ids[:n]); print('批次 %d → 返回 %d 行（OK）' % (n, len(d)))
        break
    except Exception as e:
        print('批次 %d 失败：%s' % (n, type(e).__name__))
