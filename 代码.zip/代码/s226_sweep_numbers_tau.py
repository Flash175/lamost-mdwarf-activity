# -*- coding: utf-8 -*-
"""s226：把 τ=−0.31 → −0.30 引起的点估计位移，清扫到方法说明与 README

台账 fig5_final_numbers.md 已由 s225 逐行替换（含变更横幅），此处排除以免二次替换。
"""
import io, glob, os, sys
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')

TARGETS = [p for p in glob.glob('../方法说明/*.md') if 'fig5_final_numbers' not in p]
TARGETS.append('../README.md')

# 顺序重要：先长串（带误差）再短串
PAIRS = [
    ('−0.857 ± 0.085', '−0.855 ± 0.085'),
    ('-0.857 ± 0.085', '-0.855 ± 0.085'),
    ('0.857 ± 0.085', '0.855 ± 0.085'),
    ('−0.874 ± 0.098', '−0.872 ± 0.098'),
    ('-0.874 ± 0.098', '-0.872 ± 0.098'),
    ('−0.871 ± 0.174', '−0.872 ± 0.174'),
    ('-0.871 ± 0.174', '-0.872 ± 0.174'),
    ('−0.857', '−0.855'),
    ('-0.857', '-0.855'),
    ('−0.874', '−0.872'),
    ('-0.874', '-0.872'),
    ('−0.871', '−0.872'),
    ('-0.871', '-0.872'),
    ('0.003 ± 0.200', '0.001 ± 0.200'),
    ('0.02σ', '0.005σ'),
]

total = 0
for p in TARGETS:
    if not os.path.exists(p):
        print('跳过（不存在）：', p)
        continue
    s = open(p, encoding='utf-8').read()
    hits = []
    for old, new in PAIRS:
        c = s.count(old)
        if c:
            s = s.replace(old, new)
            hits.append('%s→%s ×%d' % (old, new, c))
            total += c
    if hits:
        open(p, 'w', encoding='utf-8').write(s)
        print('%-42s %s' % (os.path.basename(p), '; '.join(hits)))
    else:
        print('%-42s 无命中' % os.path.basename(p))

print('\n合计替换 %d 处' % total)
