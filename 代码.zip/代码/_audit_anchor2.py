# -*- coding: utf-8 -*-
# 正确的「锚定连续」模型：全体星入拟合；坪区共享高度 h；非饱和段各自斜率、在断点处与 h 相接
import csv, math

BASE = 'C:/Users/lingz/Desktop/复现老师工作/APJS/图五及相关数据'
def load(fn):
    with open(fn, encoding='utf-8-sig') as f:
        return list(csv.DictReader(f))
def panel_of(s):
    if s in ('dM0','dM1','dM2','dM3'): return 'M0-M3'
    if s in ('dM4','dM5','dM6'): return 'M4-M6'
    return 'OTHER'
data = []
for r in load(BASE + '/数据/图5_逐星样本_严格3340行_⑤_tau030.csv'):
    M=float(r['M']); P=float(r['P'])
    Ro30 = P / 10 ** (2.33 - 1.50*M - 0.30*M*M)
    data.append(dict(panel=panel_of(r['spt']), Ro30=Ro30,
                     logRo30=math.log10(Ro30), logRHa=math.log10(float(r['RHa']))))
dA=[d for d in data if d['panel']=='M0-M3']
dB=[d for d in data if d['panel']=='M4-M6']

def solve3(A,y):
    n=3; M=[row[:]+[yy] for row,yy in zip(A,y)]
    for c in range(n):
        p=max(range(c,n), key=lambda r: abs(M[r][c])); M[c],M[p]=M[p],M[c]
        for r in range(c+1,n):
            f=M[r][c]/M[c][c]
            for k in range(c,n+1): M[r][k]-=f*M[c][k]
    x=[0.0]*n
    for r in range(n-1,-1,-1):
        x[r]=(M[r][n]-sum(M[r][k]*x[k] for k in range(r+1,n)))/M[r][r]
    return x

def anchored_shared_plateau(d1, d2, bp1, bp2):
    """坪区共享高度 h；面板p非饱和段: y = h + bp_slope*(x - log bp_p)；含坪区星"""
    l1 = math.log10(bp1); l2 = math.log10(bp2)
    p1 = [d['logRHa'] for d in d1 if d['logRo30'] <= l1]
    s1 = [(d['logRo30'], d['logRHa']) for d in d1 if d['logRo30'] > l1]
    p2 = [d['logRHa'] for d in d2 if d['logRo30'] <= l2]
    s2 = [(d['logRo30'], d['logRHa']) for d in d2 if d['logRo30'] > l2]
    Sx1 = sum(x-l1 for x,_ in s1); Sxx1 = sum((x-l1)**2 for x,_ in s1)
    Sx2 = sum(x-l2 for x,_ in s2); Sxx2 = sum((x-l2)**2 for x,_ in s2)
    Sy = sum(p1)+sum(y for _,y in s1)+sum(p2)+sum(y for _,y in s2)
    Syx1 = sum((x-l1)*y for x,y in s1)
    Syx2 = sum((x-l2)*y for x,y in s2)
    ntot = len(p1)+len(s1)+len(p2)+len(s2)
    A = [[ntot, Sx1, Sx2],
         [Sx1, Sxx1, 0.0],
         [Sx2, 0.0, Sxx2]]
    Y = [Sy, Syx1, Syx2]
    h, b1, b2 = solve3(A, Y)
    rss = sum((y-h)**2 for y in p1) + sum((y-h-b1*(x-l1))**2 for x,y in s1)
    rss += sum((y-h)**2 for y in p2) + sum((y-h-b2*(x-l2))**2 for x,y in s2)
    return h, b1, b2, rss

print('--- 格2 修正：锚定连续(共享坪高) + 固定 0.132 ---')
h,b1,b2,rss = anchored_shared_plateau(dA,dB,0.132,0.132)
print(f'  h={h:.4f} bA={b1:.4f} bB={b2:.4f} Δβ={b1-b2:+.4f} RSS={rss:.2f}')
print(f'  (台账8b: Δβ=-0.63, 4.3σ; 讨论体C1不成立条件: 4.1σ)')

print()
print('--- 格4 修正：锚定连续 + 自由断点（bp_A × bp_B 网格）---')
grid = [-2.4 + i*2.1/1100 for i in range(1101)]
bp_lin = [10**g for g in grid]
best = None
# 两面板断点独立：粗扫 + 细化
for bpa in bp_lin[::10]:
    for bpb in bp_lin[::10]:
        try:
            _,_,_,r = anchored_shared_plateau(dA,dB,bpa,bpb)
            if best is None or r < best[0]:
                h,b1,b2,_ = anchored_shared_plateau(dA,dB,bpa,bpb)
                best = (r,bpa,bpb,b1,b2)
        except Exception:
            pass
r,bpa,bpb,b1,b2 = best
print(f'  粗扫最优: bpA={bpa:.4f} bpB={bpb:.4f} Δβ={b1-b2:+.4f} RSS={r:.2f}')
# 细化
best2 = None
for k in range(-15,16):
    for m in range(-15,16):
        ia = bp_lin.index(bpa) if bpa in bp_lin else None
        # 用对数步进细化
        ba = 10**(math.log10(bpa) + k*0.0009)
        bb = 10**(math.log10(bpb) + m*0.0009)
        try:
            h,b1,b2,r = anchored_shared_plateau(dA,dB,ba,bb)
            if best2 is None or r < best2[0]:
                best2 = (r,ba,bb,b1,b2)
        except Exception:
            pass
r,ba,bb,b1,b2 = best2
print(f'  细化: bpA={ba:.4f} bpB={bb:.4f} Δβ={b1-b2:+.4f} RSS={r:.2f}')
print(f'  (台账8b: ≈1σ, M4-M6 偏好 0.03)')

print()
print('--- 格1/格3 对照（自由截距口径）---')
def ols(xs,ys):
    n=len(xs); xm=sum(xs)/n; ym=sum(ys)/n
    sxx=sum((x-xm)**2 for x in xs); sxy=sum((x-xm)*(y-ym) for x,y in zip(xs,ys))
    b=sxy/sxx; a=ym-b*xm
    rss=sum((y-a-b*x)**2 for x,y in zip(xs,ys))
    return a,b,rss
def rss_at(ds,bp):
    l=math.log10(bp)
    lo=[d['logRHa'] for d in ds if d['logRo30']<=l]
    hi=[(d['logRo30'],d['logRHa']) for d in ds if d['logRo30']>l]
    c=sum(lo)/len(lo)
    _,_,r2=ols([x for x,_ in hi],[y for _,y in hi])
    return sum((y-c)**2 for y in lo)+r2
sA=[d for d in dA if d['logRo30']>math.log10(0.132)]
sB=[d for d in dB if d['logRo30']>math.log10(0.132)]
_,bA,_=ols([d['logRo30'] for d in sA],[d['logRHa'] for d in sA])
_,bB,_=ols([d['logRo30'] for d in sB],[d['logRHa'] for d in sB])
print(f'  格1 自由截距+固定0.132: Δβ={bA-bB:+.4f}')
rA=[rss_at(dA,bp) for bp in bp_lin]; rB=[rss_at(dB,bp) for bp in bp_lin]
iA=int(min(range(len(rA)),key=lambda i:rA[i])); iB=int(min(range(len(rB)),key=lambda i:rB[i]))
sA=[d for d in dA if d['logRo30']>math.log10(bp_lin[iA])]
sB=[d for d in dB if d['logRo30']>math.log10(bp_lin[iB])]
_,bA,_=ols([d['logRo30'] for d in sA],[d['logRHa'] for d in sA])
_,bB,_=ols([d['logRo30'] for d in sB],[d['logRHa'] for d in sB])
print(f'  格3 自由截距+自由断点: Δβ={bA-bB:+.4f} (bpA={bp_lin[iA]:.4f}, bpB={bp_lin[iB]:.4f})')
