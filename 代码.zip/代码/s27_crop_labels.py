import io, sys
from PIL import Image
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")
for src, dst in [("extract/pdf_images/fig2_SDSS_zoom.png", "extract/pdf_images/fig2_SDSS_eq_labels.png"),
                 ("extract/pdf_images/fig2_LAMOST_zoom.png", "extract/pdf_images/fig2_LAMOST_eq_labels.png")]:
    im = Image.open(src)
    W, H = im.size
    c = im.crop((0, int(H * 0.46), W, int(H * 0.58)))
    c = c.resize((c.width * 2, c.height * 2), Image.LANCZOS)
    c.save(dst)
    print(dst, c.size)
