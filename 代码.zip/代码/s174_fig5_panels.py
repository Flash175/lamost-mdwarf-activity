# -*- coding: utf-8 -*-
"""图5（分面板版）：左 M0–M3、右 M4–M6；周期 = VSX(ROT) ∪ Fetherolf，Ro≤3；各面板独立分段回归。"""
import io, os, shutil, sys
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
import numpy as np, pandas as pd
from scipy.spatial import cKDTree
sys.path.insert(0, 'repro/src')
from common import activity as A
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt

cat = pd.read_csv('data/lamost/dr13/dr13_mstellar_dM.csv', low_memory=False,
                  usecols=['uid','designation','subclass','ewha','ewha_err','teff','ra','dec','gaia_source_id'])
for c in ('ewha','ewha_err','teff','ra','dec'): cat[c] = pd.to_numeric(cat[c], errors='coerce')
cat['ewha_err'] = cat.ewha_err.abs()
cat = cat[(cat.ewha > -20) & (cat.ewha <= 50) & (cat.ewha_err > 0) & (cat.ewha_err <= 5)]
star = cat.loc[cat.groupby('uid').ewha.idxmax()].dropna(subset=['ra','dec']).copy()
star['spt'] = star.subclass.astype(str).str.strip()

c2 = pd.read_csv('data/vizier/apjs274_36_mdwarfs.csv', low_memory=False, usecols=lambda c: c in {'EWHa','RHa','Teff','Mstar'})
c3 = c2[(c2.EWHa > 0.1) & (c2.RHa > 0) & (c2.Teff > 2800) & (c2.Teff < 4600)].copy()
c3['chi'] = c3.RHa / c3.EWHa
bins = np.arange(2800, 4601, 100); cent = 0.5*(bins[1:]+bins[:-1]); c3['b'] = np.digitize(c3.Teff, bins)
chi_med = np.array([c3.loc[c3.b == i, 'chi'].median() for i in range(1, len(bins))])
cm = c2[(c2.Teff > 2800) & (c2.Teff < 4600) & (c2.Mstar > 0.05) & (c2.Mstar < 0.8)]
coef = np.polyfit(cm.Teff, cm.Mstar, 2)

# 周期：VSX ROT ∪ Fetherolf
v = pd.read_csv('repro/_vsx/VSX_catalog_sample.csv', low_memory=False, usecols=['Type','Period','RAJ2000','DEJ2000'])
v['Period'] = pd.to_numeric(v.Period, errors='coerce')
v = v[v.Period.gt(0) & v.RAJ2000.notna() & v.DEJ2000.notna()]
v = v[v.Type.astype(str).str.upper().str.contains('ROT')]
def uv(ra, dec):
    ra = np.radians(np.asarray(ra, float)); dec = np.radians(np.asarray(dec, float))
    return np.column_stack([np.cos(dec)*np.cos(ra), np.cos(dec)*np.sin(ra), np.sin(dec)])
tree = cKDTree(uv(star.ra.values, star.dec.values))
dist, idx = tree.query(uv(v.RAJ2000.values, v.DEJ2000.values), k=1, distance_upper_bound=np.radians(3/3600))
ok = np.isfinite(dist) & (idx < len(star))
mm = pd.DataFrame({'idx': idx[ok], 'P': v.Period.values[ok]}).drop_duplicates('idx')
vsx = star.iloc[mm.idx.values].copy(); vsx['P'] = mm.P.values
fet = pd.read_csv('data/processed/dr13/dr13_fig5_sample.csv', low_memory=False, usecols=['designation','P'])
fet['designation'] = fet.designation.astype(str)
f = star[star.designation.astype(str).isin(set(fet.designation)) & ~star.uid.isin(set(vsx.uid))].merge(
    fet.drop_duplicates('designation'), on='designation', how='inner')
allp = pd.concat([vsx[['uid','designation','spt','ewha','teff','P']],
                  f[['uid','designation','spt','ewha','teff','P']]], ignore_index=True)
allp['M'] = np.clip(np.polyval(coef, allp.teff.values), 0.08, 0.75)
allp['Ro'] = allp.P.values / (10 ** (2.33 - 1.5*allp.M.values - 0.30*allp.M.values**2))
allp['RHa'] = np.interp(allp.teff, cent, chi_med) * allp.ewha
d = allp[(allp.Ro > 0) & (allp.RHa > 0) & (allp.Ro <= 3)]
print('入图 %d 颗（VSX %d / Fetherolf %d）' % (len(d), len(vsx), len(f)))

PANELS = [('M0–M3', ['dM0','dM1','dM2','dM3']), ('M4–M6', ['dM4','dM5','dM6'])]
fig, axes = plt.subplots(1, 2, figsize=(10.0, 4.4))
res = {}
for ax, (name, sel) in zip(axes, PANELS):
    q = d[d.spt.isin(sel)]
    f5 = A.fit_saturation(q.Ro.values, q.RHa.values, n_boot=200)
    ax.scatter(q.Ro, q.RHa, s=6, c='#1f4fd8', lw=0, alpha=0.7)
    ysat = np.median(q.RHa[q.Ro <= f5.ro_sat])
    xs1 = np.logspace(np.log10(max(q.Ro.min(), 1e-3)), np.log10(f5.ro_sat), 40)
    xs2 = np.logspace(np.log10(f5.ro_sat), np.log10(min(q.Ro.max(), 3)), 40)
    ax.plot(xs1, np.full_like(xs1, ysat), c='red', lw=2)
    ax.plot(xs2, ysat/f5.ro_sat**f5.slope*xs2**f5.slope, c='red', lw=2)
    ax.set_xscale('log'); ax.set_yscale('log'); ax.set_xlim(1e-3, 3); ax.set_ylim(1e-8, 1e-2)
    ax.set_xlabel('Ro', fontsize=11); ax.set_ylabel(r"R'$_{\rm H\alpha}$", fontsize=11)
    ax.set_title('%s  (n=%d)' % (name, len(q)), fontsize=10)
    ax.text(0.04, 0.97, 'slope = %.2f ± %.2f\nRo$_{sat}$ = %.3f ± %.3f'
            % (f5.slope, f5.slope_err, f5.ro_sat, f5.ro_sat_err),
            transform=ax.transAxes, va='top', fontsize=8, bbox=dict(fc='white', ec='red', pad=3))
    ax.tick_params(direction='in', top=True, right=True, labelsize=8.5)
    res[name] = f5
fig.text(0.5, 0.015, 'Periods: VSX (ROT) + Fetherolf+2023, 3" cross-match, Ro<=3; M from Teff-M fit; tau = Wright+2018; '
                     'R\'Ha = chi(Teff)*EW(Ha). Slopes depend on the fitting convention (see ledger).',
         ha='center', fontsize=6.5, color='0.3')
fig.tight_layout(rect=(0, 0.05, 1, 1))
os.makedirs('figures', exist_ok=True)
old = 'figures/dr13_fig5_rha_rossby.png'
if os.path.exists(old) and not os.path.exists('figures/_superseded/dr13_fig5_rha_rossby_fetherolf.png'):
    os.makedirs('figures/_superseded', exist_ok=True)
    shutil.copy2(old, 'figures/_superseded/dr13_fig5_rha_rossby_fetherolf.png')
o = old
fig.savefig(o, dpi=170); plt.close(fig)
print('图 ->', o)
R = r'C:\Users\lingz\Desktop\复现老师工作'
shutil.copy2(o, os.path.join(R, '图', '图05_Rossby_dr13_fig5_rha_rossby.png'))
print('已写入交付包：图/图05_Rossby_dr13_fig5_rha_rossby.png')
