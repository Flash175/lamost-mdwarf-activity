# -*- coding: utf-8 -*-
"""扩展 P_cyc-P_rot（修正列名）"""
import io, os, shutil, sys
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
import numpy as np, pandas as pd
import matplotlib; matplotlib.use('Agg'); import matplotlib.pyplot as plt
W = r'C:\Users\lingz\OneDrive\Desktop\复现老师工作'
D = r'C:\Users\lingz\Desktop\复现老师工作'
A = r'C:\Users\lingz\Desktop\APJS\图五及相关数据'
g = lambda *a: os.path.join(W, *a)
P = pd.read_csv(g('data', 'processed', 'dr13', 'ib2025_periodogram_selfcomputed.csv')).rename(columns={'star': 'star_ib'})
R = pd.read_csv(g('data', 'processed', 'dr13', 'ib2025_stars_with_prot.csv')).rename(columns={'star': 'star_src'})
P['key'] = P.star_ib.str.replace(' ', '').str.upper(); R['key'] = R.star_src.str.replace(' ', '').str.upper()
M = P.merge(R[['key', 'P_rot', 'vsx_type', 'vsx_name', 'sep_as']], on='key', how='left')
M['usable'] = M.P_rot.notna() & (M.FAP < 0.05) & (M.P_yr <= 0.95*M.baseline_yr) & (M.P_yr <= 24.0)
use = M[M.usable].sort_values('P_yr').copy()
out = use[['star_ib', 'P_rot', 'vsx_type', 'vsx_name', 'P_yr', 'P2_yr', 'power', 'FAP', 'N', 'baseline_yr']].rename(columns={'star_ib': 'star'})
out['flag'] = np.where(out.P_yr > 18, 'boundary', 'ok')
out.to_csv(g('data', 'processed', 'dr13', 'pcyc_vs_prot_expanded.csv'), index=False)
print('可用点数 %d：' % len(out)); print(out.round(3).to_string(index=False))
lit = pd.read_csv(g('data', 'raw', 'activity_cycle_data_complete.csv'))
lit['P_cyc'] = pd.to_numeric(lit.P_cyc_yr, errors='coerce'); lit['ProT'] = pd.to_numeric(lit.P_rot_days, errors='coerce')
ok = lit.dropna(subset=['P_cyc', 'ProT'])
fig, ax = plt.subplots(figsize=(6.8, 5.2))
ax.scatter(ok.ProT, ok.P_cyc, s=34, c='#1f4fd8', label='literature table (N=%d)' % len(ok), zorder=3)
ax.errorbar(ok.ProT, ok.P_cyc, yerr=pd.to_numeric(ok.P_cyc_err_yr, errors='coerce'),
            xerr=pd.to_numeric(ok.P_rot_err_days, errors='coerce'), fmt='none', ecolor='0.7', lw=0.7, zorder=2)
ax.scatter(use.P_rot, use.P_yr, s=46, facecolors='none', edgecolors='#d95f02', lw=1.3,
           label='this work: LS on IB2025 B1 x VSX P_rot (N=%d)' % len(use), zorder=4)
for _, r in use.iterrows():
    ax.annotate(str(r.star_ib).replace('GJ ', ''), (r.P_rot, r.P_yr), textcoords='offset points', xytext=(5, 4), fontsize=6.2, color='#8c3b00')
for _, r in ok.iterrows():
    ax.annotate(str(r.Star).replace('GJ ', ''), (r.ProT, r.P_cyc), textcoords='offset points', xytext=(5, -8), fontsize=6.0, color='0.35')
ax.scatter([25.4], [11.0], marker='*', s=220, color='goldenrod', edgecolor='k', lw=0.6, zorder=5)
ax.annotate('Sun', (25.4, 11.0), xytext=(6, -10), textcoords='offset points', fontsize=7)
ax.set_xscale('log'); ax.set_yscale('log')
ax.set_xlabel('P$_{rot}$ (days)', fontsize=11); ax.set_ylabel('P$_{cyc}$ (years)', fontsize=11)
ax.set_xlim(1.5, 300); ax.set_ylim(1.5, 32)
ax.grid(alpha=0.25, which='both', lw=0.4)
ax.tick_params(direction='in', top=True, right=True, labelsize=9)
ax.legend(fontsize=7.2, loc='lower right')
ax.set_title('Activity cycle vs rotation period (M dwarfs)\nfilled: literature table; open: our Lomb-Scargle recomputation', fontsize=9)
fig.text(0.5, 0.012, 'P_rot from VSX (BY/ROT entries = spot modulation); P_cyc from our Lomb-Scargle analysis of the Ibanez Bustos et al. (2025) Table B1 time series.\n'
                     'Points with P_cyc > 0.95 x baseline or at the 25-yr search edge were excluded.', ha='center', fontsize=6.3, color='0.3', linespacing=1.5)
fig.tight_layout(rect=(0, 0.07, 1, 1))
o = g('figures', 'dr13_figPcyc_Prot_expanded.png'); fig.savefig(o, dpi=180); plt.close(fig)
for s, t in [(o, os.path.join(D, '图', '对照与备选', '附_Pcyc_vs_Prot_扩展_自算.png')), (o, os.path.join(A, '图', '附_Pcyc_vs_Prot_扩展_自算.png')),
             (g('data', 'processed', 'dr13', 'pcyc_vs_prot_expanded.csv'), os.path.join(D, '数据', 'Pcyc与Prot_扩展样本.csv')),
             (g('data', 'processed', 'dr13', 'pcyc_vs_prot_expanded.csv'), os.path.join(A, '数据', 'Pcyc与Prot_扩展样本.csv')),
             (g('data', 'processed', 'dr13', 'ib2025_stars_with_prot.csv'), os.path.join(A, '数据', 'IB2025_33星VSX自转周期.csv'))]:
    shutil.copy2(s, t); print('  同步 ->', t.split('\\')[-1])
