# -*- coding: utf-8 -*-
"""比较论文右板与本地新图 SDSS 板的赤道带位置/宽度（验证取向已一致）。"""
import io, sys
import numpy as np
from PIL import Image
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

def band_report(path, box, label):
    a = np.asarray(Image.open(path).convert("RGB").crop(box)).astype(int)
    H, W, _ = a.shape
    colored = (a.max(2) - a.min(2) > 40) & (a.min(2) < 240)
    rows = colored.sum(1)
    y = int(rows.argmax())
    # 该行彩色像素的连续密集段（间隙 <= 20 px）
    xs = np.where(colored[y])[0]
    if len(xs) == 0:
        print(label, "无"); return
    runs, start, prev = [], xs[0], xs[0]
    for x in xs[1:]:
        if x - prev > 20:
            runs.append((start, prev)); start = x
        prev = x
    runs.append((start, prev))
    main = max(runs, key=lambda r: r[1] - r[0])
    # 椭圆宽 = 经度 360°，中心 = 图心
    xc = W / 2.0
    pxdeg = W / 360.0
    print(f"{label}: 最密行 y={y}/{H}（对应 Dec≈{0 if abs(y-H*0.5)<H*0.15 else '?'}）")
    print(f"   连续主段 x {main[0]}..{main[1]} ({main[1]-main[0]} px) → 经度 "
          f"{(main[0]-xc)/pxdeg:+.0f}° .. {(main[1]-xc)/pxdeg:+.0f}°")
    print(f"   该段红色像素占比 {100*((a[y,main[0]:main[1],0]>a[y,main[0]:main[1],2]+20)).mean():.0f}%")

band_report("extract/pdf_images/fig2_SDSS_zoom.png", (0, 0, 1334, 642), "论文右板 SDSS")
band_report("figures/paperA_fig2_sky_distribution.png", (1147, 0, 2295, 714), "本地新图 SDSS 板")
