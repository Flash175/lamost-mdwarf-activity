
# -*- coding: utf-8 -*-
"""冷端活动率下降是探测效应吗？——S/N 匹配检验。"""
import io, sys
import numpy as np, pandas as pd
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
cat = pd.read_csv('data/lamost/dr13/dr13_mstellar_dM.csv', low_memory=False,
                  usecols=['uid','subclass','teff','ewha','ewha_err','snrr'])
cat = cat[(cat.ewha > -20) & (cat.ewha <= 50) & (cat.ewha_err > 0) & (cat.ewha_err <= 5)].copy()
cat['active'] = (cat.ewha >= 0.75) & (cat.ewha > 3*cat.ewha_err)

print('=== A. 全部样本（不控制 S/N）===')
print(' 亚型    n    活动率%%   EWerr中位  S/N中位  可3σ检出EW>=0.75的比例')
for sp in ['dM0','dM1','dM2','dM3','dM4','dM5','dM6','dM7','dM8']:
    s = cat[cat.subclass == sp]
    if len(s) < 50: continue
    det = (s.ewha_err*3 <= 0.75).mean()
    print('  %-4s %6d  %5.1f    %6.3f    %5.1f      %5.1f%%'
          % (sp, len(s), 100*s.active.mean(), s.ewha_err.median(), s.snrr.median(), 100*det))

print('\n=== B. 控制 S/N：只取 S/N_r ∈ [3, 6] ===')
sub = cat[(cat.snrr >= 3) & (cat.snrr <= 6)]
for sp in ['dM0','dM1','dM2','dM3','dM4','dM5','dM6','dM7','dM8']:
    s = sub[sub.subclass == sp]
    if len(s) < 50: continue
    print('  %-4s n=%5d  活动率 %5.1f%%  EWerr中位 %.3f  S/N中位 %.1f'
          % (sp, len(s), 100*s.active.mean(), s.ewha_err.median(), s.snrr.median()))

print('\n=== C. 控制 S/N：S/N_r ∈ [6, 12] ===')
sub = cat[(cat.snrr >= 6) & (cat.snrr <= 12)]
for sp in ['dM0','dM1','dM2','dM3','dM4','dM5','dM6','dM7','dM8']:
    s = sub[sub.subclass == sp]
    if len(s) < 50: continue
    print('  %-4s n=%5d  活动率 %5.1f%%' % (sp, len(s), 100*s.active.mean()))
