# -*- coding: utf-8 -*-
"""统一 bootstrap 次数：面板也改为 200 次"""
import io, sys
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
P = 'repro/src/s189_fig5_official_v4.py'
s = open(P, encoding='utf-8').read()
if 'boot(q, n=120)' in s:
    s = s.replace('boot(q, n=120)', 'boot(q, n=200)'); open(P, 'w', encoding='utf-8').write(s); print('  面板 bootstrap 已改为 200 次')
else:
    print('  已是 200 次或未匹配')
