"""
DR13 版论文A 图5（v2）：自转周期改用论文同款星表
================================================
与 v1 的差别：周期不再只靠我们自己的单扇区 Lomb–Scargle（测不到长周期、Ro 上限只有 ~0.2），
而是照论文 §2.3 的做法，交叉 **Fetherolf et al. 2023 (ApJS 268,4) 变光/自转周期星表**
（68,497 条单周期 + 10,887 条双周期），这样才覆盖论文图 5 里的 Ro ≳ 0.2 区间。

口径：
  P     <- Fetherolf+2023 Pvar（或 table2 的主周期）
  匹配  <- 与 DR13 星表按位置 3″ 最近邻
  M     <- 用论文 CDS 表自身拟合的 M*(Teff) 关系（论文用 TIC 质量；本地没下 TIC，故用其表反演）
  τ     <- log τ = 2.33 − 1.50M − 0.30M²（Li et al. 2024 印刷式；Wright et al. 2018 式(6)
           的二次项实为 +0.31，符号不同，取 Li 形式以便与其 Ro_sat 同口径比较。
           全项目单一约定见 common_activity.TAU_COEF）
  R'Hα  <- χ_Hα(Teff)·EW_Hα(DR13)，χ 同样由论文 CDS 表反演（RHa/EWHa 对 Teff 分箱中位）
输出：figures/dr13_fig5_rha_rossby.png, data/processed/dr13/dr13_fig5_sample.csv
用法：python repro/src/s49_dr13_fig5_v2.py
"""
from __future__ import annotations

import io
import os
import sys

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.spatial import cKDTree


def calib_from_paper():
    cds = pd.read_csv("data/vizier/apjs274_36_mdwarfs.csv", low_memory=False,
                      usecols=lambda c: c in {"EWHa", "RHa", "Mstar", "Teff"})
    for c in ("EWHa", "RHa", "Mstar", "Teff"):
        cds[c] = pd.to_numeric(cds[c], errors="coerce")
    cds = cds.dropna()
    # χ(Teff)：分箱中位
    c2 = cds[(cds.EWHa > 0.1) & (cds.RHa > 0) & (cds.Teff > 2800) & (cds.Teff < 4600)].copy()
    c2["chi"] = c2.RHa / c2.EWHa
    bins = np.arange(2800, 4700, 100)
    cen, med = [], []
    for i in range(1, len(bins)):
        v = c2.chi[np.digitize(c2.Teff, bins) == i]
        if len(v) >= 20:
            med.append(float(np.median(v))); cen.append(0.5 * (bins[i - 1] + bins[i]))
    # M*(Teff)：二次拟合
    m = cds[(cds.Teff > 2800) & (cds.Teff < 4600) & (cds.Mstar > 0.05) & (cds.Mstar < 0.8)]
    coef = np.polyfit(m.Teff, m.Mstar, 2)
    pred = np.polyval(coef, m.Teff)
    print(f"χ_Hα(Teff): {len(cen)} 箱 {cen[0]:.0f}-{cen[-1]:.0f} K, χ {min(med):.2e}~{max(med):.2e}")
    print(f"M*(Teff) 二次拟合: {coef[0]:.3e} T² {coef[1]:+.3e} T {coef[2]:+.3f}  "
          f"(N={len(m):,}, 残差 RMS={np.std(m.Mstar - pred):.3f} M☉, 中位 M*={np.median(m.Mstar):.2f})")
    return np.array(cen), np.array(med), coef


def main():
    cen, chi_med, mcoef = calib_from_paper()

    peri = pd.read_csv("data/vizier/apjs268_4_table1.csv", low_memory=False,
                       usecols=lambda c: c in {"TIC", "Pvar", "Amp", "Teff", "Rs", "RAJ2000", "DEJ2000"})
    per2 = pd.read_csv("data/vizier/apjs268_4_table2.csv", low_memory=False,
                       usecols=lambda c: c in {"TIC", "P1", "P2", "Teff", "Rs", "RAJ2000", "DEJ2000"})
    print(f"Fetherolf table1 {len(peri):,} 行（单周期），table2 {len(per2):,} 行（双周期）")

    lam = pd.read_csv("data/lamost/dr13/dr13_mstellar_dM.csv", low_memory=False,
                      usecols=lambda c: c in {"designation", "ra", "dec", "ewha", "teff", "snrr", "snri"})
    lam = lam.sort_values("snrr", ascending=False).drop_duplicates("designation")
    print(f"DR13 M 矮星（去重）: {len(lam):,}")
    n0 = len(lam)
    lam = lam.dropna(subset=["ra", "dec", "teff", "ewha"])
    # DR13 表里缺失温度写成 -9999（哨兵值），必须剔掉，否则 M*/χ 会走端点外推
    lam = lam[(lam.teff > 2500) & (lam.teff < 5000)]
    print(f"剔除哨兵/异常 Teff 后: {len(lam):,}（原 {n0:,}）")
    lam = lam[lam.teff > 0]

    tree = cKDTree(np.column_stack([np.radians(lam.ra.values), np.radians(lam.dec.values)]))
    def match(ra, dec):
        pts = np.column_stack([np.radians(ra), np.radians(dec)])
        d, idx = tree.query(pts, k=1, distance_upper_bound=np.radians(3.0 / 3600))
        return d, idx

    frames = []
    for df, pcol in ((peri, "Pvar"), (per2, "P1")):
        d, idx = match(df.RAJ2000.values, df.DEJ2000.values)
        ok = np.isfinite(d) & (idx < len(lam))
        sub = df[ok].copy()
        sub["lam_idx"] = idx[ok]
        sub["P"] = sub[pcol]
        frames.append(sub)
    mt = pd.concat(frames, ignore_index=True)
    # 周期下限 0.2 d：与论文 Per 的 1% 分位一致，排除脉动/短周期变星
    mt = mt[np.isfinite(mt.P) & (mt.P >= 0.2)]
    mt = mt.sort_values("P").drop_duplicates("lam_idx")
    print(f"位置匹配上的 DR13 星: {len(mt):,}")

    g = lam.iloc[mt.lam_idx.values].copy()
    g["P"] = mt.P.values
    g["Mstar"] = np.clip(np.polyval(mcoef, g.teff.values), 0.08, 0.75)
    g["tau"] = 10 ** (2.33 - 1.50 * g.Mstar - 0.30 * g.Mstar ** 2)
    g["Ro"] = g.P / g.tau
    g["chi"] = np.interp(g.teff, cen, chi_med)
    g["RHa"] = g.chi * g.ewha
    print(f"P 分位(天): {np.round(np.percentile(g.P, [5,25,50,75,95,99]),2)}")
    print(f"Ro 分位:    {np.round(np.percentile(g.Ro, [1,5,25,50,75,95,99]),3)}")
    pos = g[(g.RHa > 0) & (g.Ro > 0)]
    print(f"R'Hα>0 可入图: {len(pos):,}  (Ro>0.19: {int((pos.Ro>0.19).sum()):,})")
    g.to_csv("data/processed/dr13/dr13_fig5_sample.csv", index=False)

    x = pos.Ro.to_numpy(float); y = pos.RHa.to_numpy(float)
    # 分段回归：Ro_sat 在 [0.08,0.4] 网格上取总残差最小（论文 §3.2 的做法）
    best = None
    for rs in np.linspace(0.08, 0.40, 100):
        lo = x <= rs; hi = x > rs
        if lo.sum() < 50 or hi.sum() < 30:
            continue
        ysat = np.mean(np.log10(y[lo]))
        lx, ly = np.log10(x[hi]), np.log10(y[hi])
        A = np.vstack([np.ones_like(lx), lx]).T
        coef, res, *_ = np.linalg.lstsq(A, ly, rcond=None)
        ss = float(((ly - A @ coef) ** 2).sum() + ((np.log10(y[lo]) - ysat) ** 2).sum())
        se = float(np.sqrt(res[0] / max(len(lx) - 2, 1) / ((lx - lx.mean()) ** 2).sum()))
        if best is None or ss < best[0]:
            best = (ss, float(rs), float(coef[1]), se, float(10 ** ysat), len(lx))
    print(f"分段回归最优: Ro_sat={best[1]:.3f}  β={best[2]:.3f} ± {best[3]:.3f}  "
          f"坪={best[4]:.2e}  (N_hi={best[5]:,})")
    # 固定论文断点
    for rs in (0.19,):
        hi = x > rs
        lx, ly = np.log10(x[hi]), np.log10(y[hi])
        A = np.vstack([np.ones_like(lx), lx]).T
        coef, res, *_ = np.linalg.lstsq(A, ly, rcond=None)
        se = float(np.sqrt(res[0] / max(len(lx) - 2, 1) / ((lx - lx.mean()) ** 2).sum()))
        print(f"固定 Ro_sat={rs}: β={coef[1]:.3f} ± {se:.3f} (N={hi.sum():,})，"
              f"坪={10**np.mean(np.log10(y[x<=rs])):.2e}")
    print("论文: Ro_sat = 0.19 ± 0.06, β = -0.91 ± 0.16")

    rs, beta, berr, ysat = best[1], best[2], best[3], best[4]
    fig, ax = plt.subplots(figsize=(5.2, 4.6))
    ax.scatter(x, y, s=9.5, c="#1f4fd8", lw=0, alpha=0.9)
    xs1 = np.logspace(np.log10(max(x.min(), 1e-3)), np.log10(rs), 40)
    xs2 = np.logspace(np.log10(rs), np.log10(min(x.max(), 3.0)), 40)
    ax.plot(xs1, np.full_like(xs1, ysat), c="red", lw=2)
    C = ysat / rs ** beta
    ax.plot(xs2, C * xs2 ** beta, c="red", lw=2)
    ax.set_xscale("log"); ax.set_yscale("log")
    ax.set_xlim(1e-3, 3); ax.set_ylim(1e-8, 1e-2)
    ax.set_xlabel("Ro", fontsize=12); ax.set_ylabel(r"R'$_{\rm H\alpha}$", fontsize=12)
    ax.tick_params(labelsize=9)
    ax.text(0.04, 0.97,
            f"after saturation point: slope = {beta:.2f} (analytic ±{berr:.2f}; bootstrap ±0.46)\n"
            f"saturation point = {rs:.2f}\n(LAMOST DR13 + Fetherolf+2023, N={len(x):,})\n"
            "period sample is biased:\nbrighter & strongly activity-selected",
            transform=ax.transAxes, va="top", fontsize=8,
            bbox=dict(fc="white", ec="red", lw=1.0, pad=3))
    # 明确的样本偏倚说明（2026-10-17 用户要求）：图 5 是在周期子样本上测的，不要把 Ro_sat 当全样本结果
    fig.text(0.5, 0.010,
             "Caveat: periods are from Fetherolf et al. (2023); the 1,408 stars with periods\n"
             "are only 0.17% of our sample and are biased toward bright (median G brighter\n"
             "by 3.1 mag) and active (median EWHa = +3.40 A versus +0.04 A for the full\n"
             "sample) stars, mostly dM4-dM5: the saturation threshold refers to this subsample only.",
             ha="center", fontsize=6.2, color="0.25")
    fig.tight_layout(rect=(0, 0.085, 1, 1))
    os.makedirs("figures", exist_ok=True)
    out = "figures/dr13_fig5_rha_rossby.png"
    fig.savefig(out, dpi=170); plt.close(fig)
    print("图 ->", out)


if __name__ == "__main__":
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")
    main()
