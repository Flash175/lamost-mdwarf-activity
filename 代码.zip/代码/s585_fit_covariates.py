# -*- coding: utf-8 -*-
"""s585：在 s584 之上问一句「这已经是最优拟合函数了吗」——逐星加协变量

s584 的最优形式（M7 分段线性+亚型FE）偏差/dof 仍有 2.49，说明形式不是瓶颈，
缺的是协变量与似然。本脚本在逐星层面（638k 行，二项似然，log 连接）依次加：
  S1 分段线性 z（不分亚型，全样本边际）
  S2 S1 + ln Teff（把「亚型」换成连续量，检验离散标签是否只是 Teff 的粗化）
  S3 S2 + ln(S/N)（选择效应：外档 S/N 中位 19.7 → 12.3）
  S4 S1 + 亚型FE + ln(S/N)（条件口径，与 S3 对照）
  S5 S3 + 亚型FE（全上）
比较 AIC/BIC 与「六档边际校准残差」（预测均值 vs 实测），后者才是拟合函数的实际用途。

输入：data/lamost/dr13/dr13_mstellar_dM.csv + data/gaia/gaia_dr3_mstars.csv（同 s551/s584 口径）
输出：多个图及讨论/lnf_fit_covariates.csv（模型级）、lnf_fit_calibration.csv（六档校准）
"""
import io, sys, os
import numpy as np, pandas as pd
from scipy.optimize import minimize
from scipy.stats import chi2
from astropy.coordinates import SkyCoord
import astropy.units as un

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
OUT = r'C:\Users\lingz\Desktop\复现老师工作\APJS\多个图及讨论'
CAT = 'data/lamost/dr13/dr13_mstellar_dM.csv'
GAI = 'data/gaia/gaia_dr3_mstars.csv'

def save(df, name, comments):
    fp = os.path.join(OUT, name)
    df.to_csv(fp, index=False, encoding='utf-8')
    txt = open(fp, encoding='utf-8').read()
    with open(fp, 'w', encoding='utf-8-sig') as f:
        f.write('\n'.join('# ' + c for c in comments) + '\n' + txt)
    print('  写出 %s（%d 行）' % (name, len(df)))

cat = pd.read_csv(CAT, low_memory=False,
                  usecols=['uid','subclass','teff','logg','ewha','ewha_err','snrr',
                           'ra','dec','gaia_source_id','gaia_g_mean_mag'])
cat = cat[(cat.ewha > -20) & (cat.ewha <= 50) & (cat.ewha_err > 0) & (cat.ewha_err <= 5)].copy()
cat['active'] = (cat.ewha >= 0.75) & (cat.ewha > 3*cat.ewha_err)
cat['gaia_source_id'] = pd.to_numeric(cat.gaia_source_id, errors='coerce')
g = pd.read_csv(GAI, low_memory=False, usecols=['source_id','parallax','parallax_error','ruwe'])
m = cat.merge(g, left_on='gaia_source_id', right_on='source_id', how='inner')
m = m[(m.parallax > 0.2) & (m.parallax/m.parallax_error > 5) & (m.ruwe < 1.4)].copy()
u = m.sort_values('ewha', ascending=False).drop_duplicates('uid').copy()
u['MG'] = u.gaia_g_mean_mag.values - 5*np.log10(np.clip(1000.0/u.parallax.values, 1, None)) + 5
u = u[u.MG >= 6].copy()
d_pc = 1000.0/u.parallax.values
sc = SkyCoord(ra=u.ra.values*un.deg, dec=u.dec.values*un.deg, distance=d_pc*un.pc, frame='icrs')
u['absz'] = np.abs(d_pc*np.sin(np.deg2rad(sc.galactic.b.deg)))
u = u[u.absz <= 3000].copy()
print('样本 %d 颗，活动率 %.3f%%' % (len(u), 100*u.active.mean()))

z = u.absz.values/1000.0
y = u.active.values.astype(float)
lnT = np.log(np.clip(pd.to_numeric(u.teff, errors='coerce').values, 2500, 4500)/3000.0)
lnS = np.log(np.clip(pd.to_numeric(u.snrr, errors='coerce').values, 1.0, None))
subs = sorted(u.subclass.astype(str).unique())
sdum = np.column_stack([(u.subclass.astype(str).values == s).astype(float) for s in subs[1:]])

def basis(zv, form):
    cols = [np.ones_like(zv)]
    if form in ('exp','exp_flat','exp_teff','exp_teff_snr','exp_fe_snr'):
        cols.append(zv)
    if form in ('spline','spline_teff','spline_teff_snr','spline_fe_snr','spline_all'):
        cols.append(zv)
        for k0 in (0.05, 0.1, 0.2, 0.4, 0.6, 1.0):
            cols.append(np.clip(zv-k0, 0, None))
    return cols

def build(form):
    cols = basis(z, form)
    names = ['a'] + ['z%d' % i for i in range(1, len(cols))]
    if form in ('exp_flat',): pass
    if 'teff' in form or form == 'spline_all':
        cols.append(lnT); names.append('lnTeff')
    if 'snr' in form or form == 'spline_all':
        cols.append(lnS); names.append('lnSNR')
    if 'fe' in form or form == 'spline_all':
        for j, s in enumerate(subs[1:]):
            cols.append(sdum[:, j]); names.append('fe_'+s)
    return np.column_stack(cols), names

def nll(beta, X):
    eta = np.clip(X @ beta, -30, 30)
    p = np.clip(np.exp(eta), 1e-12, 1-1e-12)
    return -float((y*np.log(p) + (1-y)*np.log1p(-p)).sum())

def grad(beta, X):
    eta = np.clip(X @ beta, -30, 30)
    p = np.clip(np.exp(eta), 1e-12, 1-1e-12)
    return -(X.T @ (y - p))

bins = [(0,100,'<100'),(100,200,'100-200'),(200,400,'200-400'),(400,600,'400-600'),
        (600,1000,'600-1000'),(1000,3000,'>1000')]
rows, crows = [], []
for form, tag in [('exp','S0 指数(全样本)'), ('spline','S1 分段线性(全样本)'),
                  ('spline_teff','S2 +lnTeff'), ('spline_teff_snr','S3 +lnTeff+lnSNR'),
                  ('spline_fe_snr','S4 +亚型FE+lnSNR'), ('spline_all','S5 全上')]:
    X, names = build(form)
    b0 = np.zeros(X.shape[1]); b0[0] = np.log(max(y.mean(), 1e-6))
    r = minimize(lambda b: nll(b, X), b0, method='BFGS', jac=lambda b: grad(b, X),
                 options=dict(maxiter=3000, gtol=1e-9))
    beta = r.x
    aic = 2*len(beta) + 2*r.fun
    bic = len(beta)*np.log(len(y)) + 2*r.fun
    eta = np.clip(X @ beta, -30, 30); p = np.exp(eta)
    print('\n%-20s 参数 %2d  nll = %.1f  AIC = %.1f  BIC = %.1f' % (tag, len(beta), r.fun, aic, bic))
    for nm, v in zip(names, beta):
        print('    %-9s %+8.4f' % (nm, v))
    rms = 0.0
    for lo_, hi_, nm in bins:
        s = (u.absz.values > lo_) & (u.absz.values <= hi_)
        pred = 100*p[s].mean(); meas = 100*y[s].mean()
        crows.append(dict(model=tag, zbin=nm, n=int(s.sum()), pred=pred, meas=meas, diff=pred-meas))
        rms += (pred-meas)**2
        print('    %-9s n=%6d pred %6.2f%%  meas %6.2f%%  diff %+5.2f pp' % (nm, s.sum(), pred, meas, pred-meas))
    rms = np.sqrt(rms/len(bins))
    print('    → 六档边际校准 RMS = %.2f pp' % rms)
    rows.append(dict(model=tag, n_par=len(beta), nll=r.fun, aic=aic, bic=bic, calib_rms_pp=rms))
save(pd.DataFrame(rows), 'lnf_fit_covariates.csv', [
    's585：逐星二项似然 log 连接，逐级加协变量；nll 为负对数似然（与 s584 的格级 nll 完全同值，因为二项似然可分解）',
    'calib_rms_pp = 六档（<100 … >1000 pc）预测均值与实测的 RMS 差',
    '生成脚本：代码/s585_fit_covariates.py'])
save(pd.DataFrame(crows), 'lnf_fit_calibration.csv', [
    's585：六个 |Z| 档的边际校准（pred = 档内逐星预测的平均，meas = 实测活动率）',
    '生成脚本：代码/s585_fit_covariates.py'])
print('\ns585 完成')
