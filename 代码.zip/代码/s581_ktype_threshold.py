# -*- coding: utf-8 -*-
"""s581: K 侧的「阈值 vs 分位」对照——0.75 A 对 K 型比对 M 型更严吗？
数据：data/processed/dr13/ktype_pilot_ew.csv（s533 自测 EW 的 K 侧试点谱）。"""
import io, sys, os
import numpy as np, pandas as pd
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
OUT = r'C:\Users\lingz\Desktop\复现老师工作\APJS\多个图及讨论'
p = r'C:\Users\lingz\OneDrive\Desktop\复现老师工作\data\processed\dr13\ktype_pilot_ew.csv'
d = pd.read_csv(p, low_memory=False)
print('列：', list(d.columns)[:12], '… 共', len(d.columns), '列，%d 行' % len(d))
col_sp = 'subclass' if 'subclass' in d.columns else ('spt' if 'spt' in d.columns else None)
col_ew = 'ew' if 'ew' in d.columns else ('ewha' if 'ewha' in d.columns else None)
print('用列：subtype=%s  EW=%s' % (col_sp, col_ew))
if col_sp is None or col_ew is None: raise SystemExit
rows=[]
for s, q in d.groupby(col_sp):
    e = np.asarray(q[col_ew], dtype=float); e = e[np.isfinite(e)]
    if len(e) < 20: continue
    rows.append(dict(subtype=str(s), n=int(len(e)), ew_med=float(np.median(e)),
                     ew_p70=float(np.percentile(e,70)), ew_p80=float(np.percentile(e,80)),
                     ew_p90=float(np.percentile(e,90)), frac_gt_075=100*float((e>=0.75).mean())))
T = pd.DataFrame(rows).sort_values('subtype')
print(T.to_string(index=False, float_format=lambda x: '%.3f' % x))
fp = os.path.join(OUT,'ktype_ew_percentiles.csv')
T.to_csv(fp, index=False, encoding='utf-8')
txt = open(fp, encoding='utf-8').read()
open(fp,'w',encoding='utf-8-sig').write(
 '# K 侧试点谱的 EW(Ha) 分位与「过 0.75 A 的比例」——对照 M 侧说明同一阈值的类型依赖\n'
 '# 数据：data/processed/dr13/ktype_pilot_ew.csv（K0-K7，本文自测 EW，未与 M 侧目录 EW 合并比较）\n'
 '# 生成脚本：代码/s581_ktype_threshold.py' + chr(10) + txt)
print('\n写出 ktype_ew_percentiles.csv')
