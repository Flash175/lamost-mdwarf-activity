# -*- coding: utf-8 -*-
"""s234_round_to_854.py —— β 末位由 −0.855 严格舍入为 −0.854 的一次性工具（**默认只演算，不落盘**）。

背景：固定断点 0.135、τ 二次项 −0.30 的直接复算为 −0.854481，三位严格舍入应为 −0.854；
现稿统一报 −0.855（沿用台账既有末位），差 0.0005 = ±0.085 的 0.6%。

**这不是数值修正，是排版取舍。** 只在作者拍板「改」之后执行，且必须全项目一次到位：
只改一处 = 跨文件不一致，比保留旧值更糟。

用法：
    python s234_round_to_854.py            # 演算：逐处分类（活值 / 历史留痕）
    python s234_round_to_854.py --apply    # 只改「活值」处；留痕处原样保留并列清单

设计要点（v3，2026-10-22 修）：
  1. **不是全局 str.replace，也不是整行过滤，而是逐处（occurrence）判定**。
     v2 的整行过滤会把「含 ML 的整段正文」一并跳过——中文 Discussion 第 5 段、图注正文段、
     Results 草稿主体都同时含 OLS 活值和 ML 对照值，整行跳过 = 漏改正文档最关键的句子。
     现按每个 0.855 出现位置的 ±30 字符局部窗口判定，命中留痕标记才跳过。
  2. **留痕标记**（与代码 `SKIP_MARKS` 逐项一致，共 10 个）：`→`（旧→新对照）、`作废`、`旧`、
     `历史`、`ML`、`0.854`（说明句自指）、`已弃`、`已改`、`曾`、`沿用`。
     台账 §9「−0.857 → −0.855」、「ML β=−0.855 → −0.856」、台账 §2 末位说明句
     （「沿用本表既有末位」、「请一次性把 −0.855 改成 −0.854」）均由此保护。
  3. **状态文件故意不在 TARGETS 内**：`项目状态_勘误与未闭合项.md` 里的 0.855 出现在
     「待拍板 / 两个方案 / 现稿报 −0.855」这类**讨论语境**，机械替换会把事实句改成自相矛盾。
     脚本改为在末尾打印该文件的强制人工清单。
  4. ROOT 校验：目录不存在直接报错退出，不静默返回 0 处。

不处理的对象（脚本只提醒，不代做）：
  1. `图5_两面板_终版.png` 等已烧死的图内像素值——必须重绘；
  2. `s226_sweep_numbers_tau.py` 里 −0.857→−0.855 的批量替换 token——改它等于改历史脚本语义；
  3. `代码/s200/s201/s212/s225` 等历史脚本中的 −0.855 记录——属历史留痕，**不动**。
"""
from __future__ import annotations

import io
import re
import shutil
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent  # 图五及相关数据/

TARGETS = [
    ROOT / "discussion_subsec_rossby_cycle_dynamo.tex",
    ROOT / "discussion_subsec_rossby_cycle_dynamo_中文.md",
    ROOT / "README.md",
    ROOT / "方法说明" / "图05_Methods文字_中英文.md",
    ROOT / "方法说明" / "图05_图注_终版.md",
    ROOT / "方法说明" / "fig5_results_discussion_draft.md",
    ROOT / "方法说明" / "fig5_final_numbers.md",
    ROOT / "方法说明" / "fig5_投稿前核对清单.md",
    ROOT / "方法说明" / "fig5_投稿前核对清单_定稿.md",
]

STATE_DOC = ROOT / "方法说明" / "项目状态_勘误与未闭合项.md"
README = ROOT / "README.md"

OLD, NEW = "0.855", "0.854"
WIN = 30                      # 局部判定窗口（字符）
SKIP_MARKS = ("→", "作废", "旧", "历史", "ML", "0.854", "已弃", "已改", "曾", "沿用")


def marks_at(line: str, i: int):
    """返回该出现位置 ±WIN 窗口内命中的留痕标记。"""
    ctx = line[max(0, i - WIN): i + len(OLD) + WIN]
    return [m for m in SKIP_MARKS if m in ctx]


def snippet(line: str, i: int) -> str:
    a, b = max(0, i - WIN), min(len(line), i + len(OLD) + WIN)
    return ("…" if a else "") + line[a:b].replace("\n", " ").strip() + ("…" if b < len(line) else "")


def main(apply: bool) -> int:
    if not ROOT.exists() or not (ROOT / "方法说明").exists():
        print("错误：ROOT 下找不到 方法说明/ —— 脚本可能被移出了 代码/ 目录。")
        print("      ROOT = %s" % ROOT)
        return 2

    missing = [p for p in TARGETS if not p.exists()]
    live_total = trace_total = 0
    live_files = []
    print("模式：%s\n" % ("APPLY（写盘，仅活值处）" if apply else "DRY-RUN（只演算）"))

    for p in TARGETS:
        if not p.exists():
            continue
        lines = io.open(p, encoding="utf-8").read().splitlines(keepends=True)
        n_live = n_trace = 0
        out_lines = []
        report = []
        for lineno, ln in enumerate(lines, 1):
            starts = [m.start() for m in re.finditer(re.escape(OLD), ln)]
            if not starts:
                out_lines.append(ln)
                continue
            keep, off = [], 0
            for i in starts:
                mk = marks_at(ln, i)
                if mk:
                    n_trace += 1
                    report.append(("✋", lineno, i, ln, mk))
                else:
                    n_live += 1
                    report.append(("✔", lineno, i, ln, []))
                    keep.append((i, i + len(OLD)))
            if apply and keep:
                buf, pos = [], 0
                for a, b in keep:
                    buf.append(ln[pos:a]); buf.append(NEW); pos = b
                buf.append(ln[pos:])
                ln = "".join(buf)
            out_lines.append(ln)
        if n_live or n_trace:
            print("【%s】 活值 %d 处 / 留痕 %d 处" % (p.name, n_live, n_trace))
            for tag, lineno, i, ln, mk in report:
                print("   %s L%-4d %s" % (tag, lineno, snippet(ln, i)))
                if mk:
                    print("        └ 跳过：局部含 %s" % "/".join(mk))
            if n_live:
                live_files.append(p.name)
            live_total += n_live
            trace_total += n_trace
        if apply and n_live:              # 只有活值被改才写盘；纯留痕文件不碰
            bak = p.with_name(p.name + ".bak_855")
            if bak.exists():
                # 重复执行时不覆盖首份备份：首份才是真正的「改前原样」，覆盖即失去回滚窗口
                print("   ↳ 备份已存在，保留首份不覆盖 %s" % bak.name)
            else:
                shutil.copy2(p, bak)      # 可回滚：首次改前的原件留在同名 .bak_855
                print("   ↳ 已备份 %s" % bak.name)
            io.open(p, "w", encoding="utf-8").write("".join(out_lines))

    print("\n" + "-" * 78)
    print("目标清单 %d 个（存在 %d 个，缺失 %d 个）；有活值文件 %d 个"
          % (len(TARGETS), len(TARGETS) - len(missing), len(missing), len(live_files)))
    print("活值 %d 处%s；历史留痕 %d 处（一律不改）"
          % (live_total, "（已写入）" if apply else "（未写盘）", trace_total))
    if missing:
        print("⚠ 缺失文件：" + "; ".join(p.name for p in missing))
    if not apply:
        print("未写盘。确认后加 --apply。")

    if apply and trace_total:
        print("\n⚠ 保留了 %d 处历史留痕（✋）。**请确认这些 ✋ 不是被误判的正文活值**——" % trace_total)
        print("  SKIP_MARKS 含「ML」/「旧」/「历史」，若某段正文在 30 字符窗口内同时提到 OLS 活值与 ML，")
        print("  会被误标 ✋。核对方法：改完后 grep 残留的 0.855，逐条看是否落在正文句里。")

    print("\n" + "=" * 78)
    print("强制人工清单（脚本不做，请你逐项处理）")
    print("=" * 78)
    print("1. 【状态文件】%s" % STATE_DOC.name)
    if STATE_DOC.exists():
        n = io.open(STATE_DOC, encoding="utf-8").read().count(OLD)
        print("   仍有 %d 处 0.855，全在讨论语境，必须手改：" % n)
        print("     · §二 U4 行：「待拍板」→「已闭合（采用 −0.854）」")
        print("     · §三：整节从「两个方案」改写为「执行记录」（删对比表，保留执行日期与处数）")
        print("     · §三「事实」句：末位说明改为「与直接复算 −0.854481 一致」")
    else:
        print("   ⚠ 状态文件不存在，跳过")
    print("2. 【README】§二 表「⑤ 终版」行 OLS 列（现 −0.855）与 §一「β 口径」句——确认是否随本轮一起改")
    print("3. 【图】PNG 需重绘——烧死的旧值以 方法说明/项目状态_勘误与未闭合项.md §二 U3 为准，")
    print("        替换清单见 方法说明/图05_图注_终版.md 的「⚠ 待重绘」段。")
    print("        （脚本内不重复列数值：U3 是现状，改 854 后是目标值，两份清单会各自漂移）")
    print("4. 【口径注】改后与自由断点 −0.853 仅差 0.001，须在台账 §2 补「两口径近乎同值属数值巧合」")
    print("5. 【脚本留痕】s226 的 −0.857→−0.855 token、s200/s201/s212/s225 历史记录，一律不动")
    print("6. 【自检】改完重跑本脚本，应显示「活值 0 处」；残留 0.855 只应出现在留痕行")
    print("7. 【回滚】若误改，原件在同目录 *.bak_855，可直接覆盖回去")
    return 0


if __name__ == "__main__":
    sys.exit(main("--apply" in sys.argv))
