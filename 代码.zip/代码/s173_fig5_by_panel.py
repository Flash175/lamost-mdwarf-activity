# -*- coding: utf-8 -*-
"""图5 分面板：M0–M3 与 M4–M6 各自的 β / Ro_sat（两种周期口径：Fetherolf-only；VSX-ROT∪Fetherolf 且 Ro≤3）"""
import io, sys
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
import numpy as np, pandas as pd
from scipy.spatial import cKDTree
sys.path.insert(0, 'repro/src')
from common import activity as A

cat = pd.read_csv('data/lamost/dr13/dr13_mstellar_dM.csv', low_memory=False,
                  usecols=['uid','designation','subclass','ewha','ewha_err','teff','ra','dec','gaia_source_id'])
for c in ('ewha','ewha_err','teff','ra','dec'): cat[c] = pd.to_numeric(cat[c], errors='coerce')
cat['ewha_err'] = cat.ewha_err.abs()
cat = cat[(cat.ewha > -20) & (cat.ewha <= 50) & (cat.ewha_err > 0) & (cat.ewha_err <= 5)]
star = cat.loc[cat.groupby('uid').ewha.idxmax()].dropna(subset=['ra','dec']).copy()
star['spt'] = star.subclass.astype(str).str.strip()

# χ(Teff) 与 Teff–Mass 标定（同 s49）
c2 = pd.read_csv('data/vizier/apjs274_36_mdwarfs.csv', low_memory=False, usecols=lambda c: c in {'EWHa','RHa','Teff','Mstar'})
c3 = c2[(c2.EWHa > 0.1) & (c2.RHa > 0) & (c2.Teff > 2800) & (c2.Teff < 4600)].copy()
c3['chi'] = c3.RHa / c3.EWHa
bins = np.arange(2800, 4601, 100); cent = 0.5*(bins[1:]+bins[:-1]); c3['b'] = np.digitize(c3.Teff, bins)
chi_med = np.array([c3.loc[c3.b == i, 'chi'].median() for i in range(1, len(bins))])
cm = c2[(c2.Teff > 2800) & (c2.Teff < 4600) & (c2.Mstar > 0.05) & (c2.Mstar < 0.8)]
coef = np.polyfit(cm.Teff, cm.Mstar, 2)

def finish(d):
    d = d.copy()
    d['M'] = np.clip(np.polyval(coef, d.teff.values), 0.08, 0.75)
    d['Ro'] = d.P.values / (10 ** (2.33 - 1.5*d.M.values - 0.30*d.M.values**2))
    d['RHa'] = np.interp(d.teff, cent, chi_med) * d.ewha
    return d[(d.Ro > 0) & (d.RHa > 0)]

# 口径①：Fetherolf
fet = pd.read_csv('data/processed/dr13/dr13_fig5_sample.csv', low_memory=False, usecols=['designation','P'])
fet['designation'] = fet.designation.astype(str)
f = star.merge(fet.drop_duplicates('designation'), on='designation', how='inner')
A1 = finish(f)
# 口径②：VSX ROT ∪ Fetherolf，Ro≤3
v = pd.read_csv('repro/_vsx/VSX_catalog_sample.csv', low_memory=False, usecols=['Type','Period','RAJ2000','DEJ2000'])
v['Period'] = pd.to_numeric(v.Period, errors='coerce')
v = v[v.Period.gt(0) & v.RAJ2000.notna() & v.DEJ2000.notna()]
v = v[v.Type.astype(str).str.upper().str.contains('ROT')]
def uv(ra, dec):
    ra = np.radians(np.asarray(ra, float)); dec = np.radians(np.asarray(dec, float))
    return np.column_stack([np.cos(dec)*np.cos(ra), np.cos(dec)*np.sin(ra), np.sin(dec)])
tree = cKDTree(uv(star.ra.values, star.dec.values))
d, i = tree.query(uv(v.RAJ2000.values, v.DEJ2000.values), k=1, distance_upper_bound=np.radians(3/3600))
ok = np.isfinite(d) & (i < len(star))
mm = pd.DataFrame({'idx': i[ok], 'P': v.Period.values[ok]}).drop_duplicates('idx')
vsx = star.iloc[mm.idx.values].copy(); vsx['P'] = mm.P.values
both = pd.concat([vsx[['uid','designation','spt','ewha','teff','P']],
                  f[~f.uid.isin(set(vsx.uid))][['uid','designation','spt','ewha','teff','P']]], ignore_index=True)
A2 = finish(both); A2 = A2[A2.Ro <= 3]

for tag, d in [('口径① Fetherolf', A1), ('口径② VSX-ROT∪Fet (Ro≤3)', A2)]:
    print('\n== %s ：总 %d 颗 ==' % (tag, len(d)))
    for name, sel in [('M0–M3', ['dM0','dM1','dM2','dM3']), ('M4–M6', ['dM4','dM5','dM6'])]:
        q = d[d.spt.isin(sel)]
        if len(q) < 40:
            print('  %-6s n=%4d 太少，跳过' % (name, len(q))); continue
        f5 = A.fit_saturation(q.Ro.values, q.RHa.values, n_boot=100)
        h = q[q.Ro > f5.ro_sat]
        sl = np.polyfit(np.log10(h.Ro), np.log10(h.RHa), 1)[0] if len(h) > 20 else np.nan
        print('  %-6s n=%4d  Ro %.3f–%.2f  Ro_sat=%.3f ± %.3f  β(bootstrap)=%.3f ± %.3f  β(直拟,n=%d)=%.3f'
              % (name, len(q), q.Ro.min(), q.Ro.max(), f5.ro_sat, f5.ro_sat_err, f5.slope, f5.slope_err, len(h), sl))
