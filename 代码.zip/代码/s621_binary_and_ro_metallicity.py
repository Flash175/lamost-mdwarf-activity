
# -*- coding: utf-8 -*-
"""s621：两件便宜检验
(A) 双星剔除（RUWE 分档）后，亚型内降幅与"亚型内 vs 组成"分解是否稳定
(B) Ro x [Fe/H] 试点：固定亚型、按 m_h 二分，比较非饱和段斜率 beta
输出：多个图及讨论/双星剔除_亚型降幅.csv、金属度_Ro试点.csv
"""
import io, sys, os, json
import numpy as np, pandas as pd
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
D = r'C:\Users\lingz\Desktop\复现老师工作\APJS\多个图及讨论'
PB = r'C:\Users\lingz\Desktop\复现老师工作\APJS\图五及相关数据\数据'
SUB = ['dM0','dM1','dM2','dM3','dM4','dM5','dM6']

cl = pd.read_csv(os.path.join(D,'金属度_清洁样本_637973.csv'), low_memory=False,
                 usecols=['uid','subclass','teff','m_h','m_h_err','absz','active','mh_ok','ruwe','ewha'])
cl = cl[cl.subclass.isin(SUB)].copy()
print('2D sample (dM0-dM6):', len(cl))

def frac(ss): return float(ss.active.mean()) if len(ss) else np.nan

def decompose(s, near='<100', far='200-400'):
    E = {'<100':(0,100),'100-200':(100,200),'200-400':(200,400)}
    a = s[(s.absz>E[near][0])&(s.absz<=E[near][1])]
    b = s[(s.absz>E[far][0])&(s.absz<=E[far][1])]
    rows=[]
    for st in SUB:
        na, nb = len(a[a.subclass==st]), len(b[b.subclass==st])
        rows.append(dict(st=st, n_a=na, n_b=nb, f_a=frac(a[a.subclass==st]), f_b=frac(b[b.subclass==st])))
    t = pd.DataFrame(rows).set_index('st')
    t['w_a'] = t.n_a/t.n_a.sum(); t['w_b'] = t.n_b/t.n_b.sum()
    fn = float((t.w_a*t.f_a).sum()); ff = float((t.w_b*t.f_b).sum())
    within = float((((t.w_a+t.w_b)/2)*(t.f_a-t.f_b)).sum())
    comp   = float((((t.f_a+t.f_b)/2)*(t.w_a-t.w_b)).sum())
    inter  = float((((t.w_a-t.w_b))*(t.f_a-t.f_b)).sum())
    return fn, ff, within, comp, inter, t

rows=[]
for tier, lim in [('all(ruwe<1.4)',1.4), ('ruwe<1.2',1.2), ('ruwe<1.1',1.1)]:
    s = cl[cl.ruwe < lim]
    r = dict(tier=tier, n=len(s))
    for far in ['100-200','200-400']:
        fn, ff, wi, co, it, t = decompose(s, '<100', far)
        r['D_%s_pp'%far] = 100*(fn-ff)
        r['within_%s_pp'%far] = 100*(wi+it/2)
        r['comp_%s_pp'%far] = 100*(co+it/2)
        r['within_share_%s'%far] = 100*(wi+it/2)/(fn-ff)
        if far=='200-400':
            for st in SUB: r['d_%s'%st] = 100*(t.loc[st,'f_a']-t.loc[st,'f_b'])
    rows.append(r)
A = pd.DataFrame(rows)
pd.set_option('display.width', 200)
print('\n=== (A) binary proxy tiers ===')
print(A[['tier','n','D_200-400_pp','within_200-400_pp','comp_200-400_pp','within_share_200-400']].round(3).to_string(index=False))
print('\nper-subtype decline (<100 -> 200-400 pc), pp:')
print(A[['tier']+['d_%s'%s for s in SUB]].round(2).to_string(index=False))
A.to_csv(os.path.join(D,'双星剔除_亚型降幅.csv'), index=False, encoding='utf-8-sig')

# ---------- (B) Ro x [Fe/H] pilot ----------
pe = pd.read_csv(os.path.join(PB,'图5_逐星样本_严格3340行_⑤_tau030.csv'), low_memory=False)
m = pe.merge(cl[['uid','m_h','m_h_err','subclass']], on='uid', how='inner', suffixes=('','_cl'))
m = m[np.isfinite(m.m_h) & (m.m_h_err<=0.25) & (m.Ro>0) & (m.RHa>0)].copy()
print('\nperiodic stars with usable m_h:', len(m))
RS = 0.132
def fit_fixed(d):
    x = np.log10(d.Ro.values); y = np.log10(d.RHa.values)
    lo = x <= np.log10(RS)
    if lo.sum() < 20 or (~lo).sum() < 20: return None
    plat = y[lo].mean(); sl, ic = np.polyfit(x[~lo], y[~lo], 1)
    res = y[~lo] - (sl*x[~lo]+ic); n = (~lo).sum()
    se = float(np.sqrt((res**2).sum()/(n-2)/max(((x[~lo]-x[~lo].mean())**2).sum(),1e-9)))
    return sl, se, int(lo.sum()), int(n)
rows=[]
for st in ['dM0','dM1','dM2','dM3','dM4','dM5']:
    s = m[m.subclass_cl==st] if 'subclass_cl' in m.columns else m[m.subclass==st]
    if len(s) < 200: continue
    med = s.m_h.median()
    lo, hi = s[s.m_h<=med], s[s.m_h>med]
    fl, fh = fit_fixed(lo), fit_fixed(hi)
    if fl is None or fh is None: continue
    db = fh[0]-fl[0]; se = float(np.sqrt(fl[1]**2+fh[1]**2))
    rows.append(dict(subtype=st, n=len(s), mh_split=med,
                     n_low=len(lo), n_high=len(hi), mh_low=float(lo.m_h.median()), mh_high=float(hi.m_h.median()),
                     beta_low=fl[0], beta_low_se=fl[1], beta_high=fh[0], beta_high_se=fh[1],
                     dbeta=db, dbeta_se=se, sigma=abs(db)/se))
B = pd.DataFrame(rows).round(3)
print('\n=== (B) Ro-activity slope by [Fe/H] half (fixed break 0.132) ===')
print(B.to_string(index=False))
B.to_csv(os.path.join(D,'金属度_Ro试点.csv'), index=False, encoding='utf-8-sig')
print('\ncombined |dbeta|/se (weighted by 1/se^2):')
w = 1/B.dbeta_se**2; print('  weighted mean dbeta = %.3f +/- %.3f' % (float((B.dbeta*w).sum()/w.sum()), float(np.sqrt(1/w.sum()))))
