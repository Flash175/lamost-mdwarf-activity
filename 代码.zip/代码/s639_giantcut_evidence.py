# -*- coding: utf-8 -*-
"""s639：2.2 去巨星段的证据复核（2026-11-11 用户指正五条后补算）。

回答四个问题：
 (1) logg 与 teff 的 −9999 哨兵是否同一批行、各多少条；
 (2) 被剔除的 1,729 颗究竟是什么（M_G 与 logg 分布，是否只是巨星）；
 (3) 6D 远档（>400 pc，3 kpc 上限）整档 316 颗里 M_G<6 到底占多少（不只是活动星里的 57/61）；
 (4) RV 窗 G≲16 在远档中位距离上对应什么 M_G。
输出：多个图及讨论/giant_cut_evidence.csv
口径与 s570 一致（EW 门槛 → Gaia 交叉 → 视差/ruwe 筛 → 每星取最大 EW → |Z|≤3 kpc）。
"""
import io, sys, os
import numpy as np, pandas as pd
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
from astropy.coordinates import SkyCoord
import astropy.units as un

OUT = r'C:\Users\lingz\Desktop\复现老师工作\APJS\多个图及讨论'
LIT = 1.0  # 阈值（Å）

cat = pd.read_csv('data/lamost/dr13/dr13_mstellar_dM.csv', low_memory=False,
                  usecols=['uid', 'subclass', 'teff', 'logg', 'ewha', 'ewha_err', 'snrr',
                           'ra', 'dec', 'gaia_source_id', 'gaia_g_mean_mag'])
n_rows = len(cat)
lg = cat.logg.values == -9999
te = cat.teff.values == -9999
print('星表 %d 行 / %d uid' % (n_rows, cat.uid.nunique()))
print('logg -9999 %d (%.3f%%)；teff -9999 %d (%.3f%%)；两列皆缺 %d；只缺 logg %d；只缺 teff %d'
      % (lg.sum(), 100*lg.mean(), te.sum(), 100*te.mean(),
         (lg & te).sum(), (lg & ~te).sum(), (~lg & te).sum()))

c2 = cat[(cat.ewha > -20) & (cat.ewha <= 50) & (cat.ewha_err > 0) & (cat.ewha_err <= 5)].copy()
c2['active'] = (c2.ewha >= 0.75) & (c2.ewha > 3*c2.ewha_err)
for col in ['logg', 'teff']:
    c2.loc[c2[col] == -9999, col] = np.nan
c2['gaia_source_id'] = pd.to_numeric(c2.gaia_source_id, errors='coerce')
g = pd.read_csv('data/gaia/gaia_dr3_mstars.csv', low_memory=False,
                usecols=['source_id', 'parallax', 'parallax_error', 'pmra', 'pmdec',
                         'radial_velocity', 'ruwe'])
m = c2.merge(g, left_on='gaia_source_id', right_on='source_id', how='inner')
m = m[(m.parallax > 0.2) & (m.parallax/m.parallax_error > 5) & (m.ruwe < 1.4)].copy()
m['rv'] = m.radial_velocity
u = m.sort_values('ewha', ascending=False).drop_duplicates('uid').copy()
u['MG'] = u.gaia_g_mean_mag.values - 5*np.log10(np.clip(1000.0/u.parallax.values, 1, None)) + 5
d = 1000.0/u.parallax.values
sc = SkyCoord(ra=u.ra.values*un.deg, dec=u.dec.values*un.deg, distance=d*un.pc, frame='icrs')
u['absz'] = np.abs(d*np.sin(np.deg2rad(sc.galactic.b.deg)))
u = u[u.absz <= 3000].copy()
print('\n2D（去巨星前）%d 颗；M_G<6 的 %d（%.3f%%）' % (len(u), (u.MG < 6).sum(), 100*(u.MG < 6).mean()))

# ---------- 1) 被剔除的是什么 ----------
rem = u[u.MG < 6]
lgv = rem.logg.dropna()
print('\n被剔除的 %d 颗：M_G 中位 %.2f（5–95%% %.2f 至 %.2f，全距 %.2f 至 %.2f）；'
      'logg 有效 %d，中位 %.2f，logg<3.5 的 %d（%.1f%%），logg>4.0 的 %d（%.1f%%）'
      % (len(rem), rem.MG.median(), rem.MG.quantile(.05), rem.MG.quantile(.95),
         rem.MG.min(), rem.MG.max(), len(lgv), lgv.median(),
         (lgv < 3.5).sum(), 100*(lgv < 3.5).mean(), (lgv > 4.0).sum(), 100*(lgv > 4.0).mean()))
kept = u[u.MG >= 6]
print('保留的 %d 颗：M_G 中位 %.2f；logg 中位 %.2f' % (len(kept), kept.MG.median(), kept.logg.median()))

# ---------- 2) 6D 远档 ----------
six = u[np.isfinite(u.rv) & (np.abs(u.rv) < 500)].copy()
c6 = SkyCoord(ra=six.ra.values*un.deg, dec=six.dec.values*un.deg,
              distance=(1000.0/six.parallax.values)*un.pc,
              pm_ra_cosdec=six.pmra.values*un.mas/un.yr, pm_dec=six.pmdec.values*un.mas/un.yr,
              radial_velocity=six.rv.values*un.km/un.s, frame='icrs')
gc = c6.transform_to('galactocentric')
six = six.assign(zgc=np.abs(gc.z.to(un.kpc).value)*1000)
six = six[six.zgc <= 3000]
far = six[(six.absz > 400) & (six.absz <= 3000)]
brt = far[far.MG < 6]
act = far[far.active]
post = far[far.MG >= 6]
print('\n6D 远档（日心 |Z|>400 pc，≤3 kpc）去巨星前 %d 颗 / %d 活动；其中 M_G<6 的 %d（整档 %.1f%%）'
      % (len(far), len(act), len(brt), 100*(far.MG < 6).mean()))
print('  活动星里 M_G<6：%d/%d = %.1f%%；非活动星里 %d/%d = %.1f%%'
      % ((act.MG < 6).sum(), len(act), 100*(act.MG < 6).mean(),
         ((far[~far.active]).MG < 6).sum(), len(far) - len(act), 100*(far[~far.active].MG < 6).mean()))
print('  整档 M_G 中位 %.2f；G 中位 %.2f；G 全距 %.2f–%.2f；距离中位 %.0f pc；G<16 占 %.0f%%'
      % (far.MG.median(), far.gaia_g_mean_mag.median(), far.gaia_g_mean_mag.min(),
         far.gaia_g_mean_mag.max(), (1000.0/far.parallax).median(),
         100*(far.gaia_g_mean_mag < 16).mean()))
print('  剔除后剩 %d 颗 / %d 活动（活动比例 %.1f%%）' % (len(post), post.active.sum(), 100*post.active.mean()))
fz = six[six.zgc > 400]
print('  银心 z 口径同一档：去巨星前 %d 颗 / %d 活动，M_G<6 的 %d（%.1f%%）；剔除后 %d 颗 / %d 活动'
      % (len(fz), fz.active.sum(), (fz.MG < 6).sum(), 100*(fz.MG < 6).mean(),
         (fz.MG >= 6).sum(), fz[fz.MG >= 6].active.sum()))

# ---------- 3) RV 窗对应什么 M_G ----------
dmed = float((1000.0/far.parallax).median())
print('\n距离中位 %.0f pc：G=16 → M_G=%.1f；G=14 → M_G=%.1f；G=18 → M_G=%.1f'
      % (dmed, 16-5*np.log10(dmed)+5, 14-5*np.log10(dmed)+5, 18-5*np.log10(dmed)+5))
print('  同距离上 M 矮星（M_G=+8 / +16）对应 G=%.1f / %.1f' % (8+5*np.log10(dmed)-5, 16+5*np.log10(dmed)-5))

# ---------- 4) 落盘 ----------
rows = [
 dict(item='catalogue_rows', value=n_rows, note='dr13_mstellar_dM.csv 行数'),
 dict(item='sentinel_logg', value=int(lg.sum()), note='logg == -9999'),
 dict(item='sentinel_teff', value=int(te.sum()), note='teff == -9999'),
 dict(item='sentinel_both', value=int((lg & te).sum()), note='两列同一批行'),
 dict(item='sentinel_logg_only', value=int((lg & ~te).sum()), note='只缺 logg'),
 dict(item='sentinel_teff_only', value=int((~lg & te).sum()), note='只缺 teff'),
 dict(item='d2_n_precut', value=len(u), note='2D 去巨星前'),
 dict(item='d2_n_MG_lt6', value=int((u.MG < 6).sum()), note='2D 剔除数'),
 dict(item='d2_MG_lt6_frac_pct', value=round(100*(u.MG < 6).mean(), 4), note=''),
 dict(item='removed_MG_median', value=round(float(rem.MG.median()), 3), note='被剔除者的 M_G 中位'),
 dict(item='removed_logg_valid', value=len(lgv), note='被剔除者 logg 有效条数'),
 dict(item='removed_logg_median', value=round(float(lgv.median()), 3), note=''),
 dict(item='removed_logg_lt35', value=int((lgv < 3.5).sum()), note='真正低重力的（巨星）'),
 dict(item='removed_logg_gt40', value=int((lgv > 4.0).sum()), note='矮星型重力'),
 dict(item='d6_far_precut_n', value=len(far), note='6D 远档去巨星前'),
 dict(item='d6_far_precut_active', value=int(far.active.sum()), note=''),
 dict(item='d6_far_MG_lt6_all', value=int((far.MG < 6).sum()), note='整档 M_G<6（关键：给分母）'),
 dict(item='d6_far_MG_lt6_all_pct', value=round(100*(far.MG < 6).mean(), 2), note=''),
 dict(item='d6_far_MG_lt6_act', value=int((act.MG < 6).sum()), note='活动星里'),
 dict(item='d6_far_MG_lt6_act_pct', value=round(100*(act.MG < 6).mean(), 2), note=''),
 dict(item='d6_far_MG_median', value=round(float(far.MG.median()), 3), note=''),
 dict(item='d6_far_G_median', value=round(float(far.gaia_g_mean_mag.median()), 3), note=''),
 dict(item='d6_far_dist_median_pc', value=round(dmed, 1), note=''),
 dict(item='d6_far_MG_at_G16', value=round(16-5*np.log10(dmed)+5, 2), note='G=16 在中位距离上的 M_G'),
 dict(item='d6_far_MG_at_G14', value=round(14-5*np.log10(dmed)+5, 2), note=''),
 dict(item='d6_far_postcut_n', value=len(post), note='剔除后'),
 dict(item='d6_far_postcut_active', value=int(post.active.sum()), note=''),
 dict(item='d6_far_gc_precut_n', value=len(fz), note='银心 z 口径'),
 dict(item='d6_far_gc_postcut_n', value=int((fz.MG >= 6).sum()), note=''),
 dict(item='d6_far_gc_postcut_active', value=int(fz[fz.MG >= 6].active.sum()), note=''),
]
T = pd.DataFrame(rows)
fp = os.path.join(OUT, 'giant_cut_evidence.csv')
T.to_csv(fp, index=False, encoding='utf-8-sig')
print('\n写出 %s（%d 行）' % (os.path.basename(fp), len(T)))
print('s639 完成')
