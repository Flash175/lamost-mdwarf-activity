# -*- coding: utf-8 -*-
"""清理三份文档里残留的旧句（Ro_sat 0.135 / -0.749 对比）"""
import io, glob, sys
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
OLD = """* 严格样本（nss=0 且经 TESS 交叉验证非别名 且 Ro<=3）共 3,340 颗：beta(OLS) = -0.851、beta(ML) = -0.855、sigma_int = 0.49 dex，
  比未做双星/别名剔除的 -0.749 更接近论文的 -0.91，且 Ro_sat 稳定在 0.135。"""
NEW = """* 严格样本（nss=0、经 VSX/TESS 交叉验证非别名、去 ruwe>=1.4、去 M3/M4 边界、Ro<=3）共 3,340 颗：
  beta(OLS) = -0.851 ± 0.111 (bootstrap)、beta(ML) = -0.855、Ro_sat(OLS) = 0.137、Ro_sat(ML) = 0.121、sigma_int = 0.49 dex，
  与论文 -0.91 ± 0.16 相差约 0.35 sigma；未做任何剔除的原始样本为 -0.736。"""
files = glob.glob(r'C:\Users\lingz\Desktop\复现老师工作\文档\*.md') + glob.glob(r'C:\Users\lingz\Desktop\复现老师工作\*.md') + \
        glob.glob(r'C:\Users\lingz\Desktop\APJS\图五及相关数据\**\*.md', recursive=True)
hit = 0
for p in files:
    s = open(p, encoding='utf-8').read(); o = s
    if OLD in s:
        s = s.replace(OLD, NEW); print('  改写整句:', p.split('\\')[-2:] )
    else:
        s = s.replace('且 Ro_sat 稳定在 0.135。', '且 Ro_sat(OLS) 稳定在 0.137、Ro_sat(ML) 为 0.121。')
        s = s.replace('比未做双星/别名剔除的 -0.749 更接近论文的 -0.91', '比原始未剔除样本的 -0.736 更接近论文的 -0.91')
        if s != o: print('  局部替换:', p.split('\\')[-2:])
    if s != o:
        open(p, 'w', encoding='utf-8').write(s); hit += 1
print('  共修改 %d 个文件' % hit)
print('\n=== 全桌面复查 0.135 / -0.749（应只剩历史记述）===')
import subprocess
for p in files:
    s = open(p, encoding='utf-8').read()
    for tok in ('0.135', '-0.749'):
        if tok in s:
            for i, l in enumerate(s.splitlines(), 1):
                if tok in l: print('   %s:%d  %s' % (p.split('\\')[-1], i, l.strip()[:100]))
