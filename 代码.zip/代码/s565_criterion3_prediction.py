# -*- coding: utf-8 -*-
"""s565：用本地已有光谱预测「若实现第三判据（线高 > 3×线心噪声）」会怎样。
从 data/lrs/dr13_rest 随机抽 N 条 M 矮星谱（obsid 与星表 join 得亚型），
同一 Yi(2014) 窗口算 EW、线外稳健 rms、归一化峰高，然后：
  - 现判据（EW>=0.75 且 >3sigma）判为活动的星里，有多少条**不满足**线高 > 3×噪声
  - 按亚型给出「第三判据造成的活动率下降」
"""
import io, sys, os, gzip, random
import numpy as np, pandas as pd
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
OUT = r'C:\Users\lingz\Desktop\复现老师工作\APJS\多个图及讨论'
DIR = 'data/lrs/dr13'   # 活动星为主的目录（dr13_rest 里 99.99% 是非活动星）
N = 2500
C_L, C_R, LINE = (6555.0, 6560.0), (6570.0, 6575.0), (6557.66, 6571.66)

def save(df, name, comments):
    fp = os.path.join(OUT, name); df.to_csv(fp, index=False, encoding='utf-8')
    txt = open(fp, encoding='utf-8').read()
    with open(fp, 'w', encoding='utf-8-sig') as f:
        f.write('\n'.join('# ' + c for c in comments) + '\n' + txt)
    print('  写出 %s（%d 行）' % (name, len(df)))

def analyse(path, z):
    d = pd.read_csv(gzip.open(path, 'rt'), usecols=['Wavelength', 'Flux'])
    w = d.Wavelength.values/(1.0 + (z if np.isfinite(z) else 0.0)); f = d.Flux.values.astype(float)
    ok = np.isfinite(w) & np.isfinite(f); w, f = w[ok], f[ok]
    if len(w) < 100: return None
    o = np.argsort(w); w, f = w[o], f[o]
    mL = (w >= C_L[0]) & (w <= C_R[0]); mR = (w >= C_R[0]) & (w <= C_R[1])
    if mL.sum() < 2 or mR.sum() < 2: return None
    wl, fl = w[mL].mean(), f[mL].mean(); wr, fr = w[mR].mean(), f[mR].mean()
    if fr == fl: return None
    mm = (fr - fl)/(wr - wl); bb = fl - mm*wl
    g = np.arange(LINE[0], LINE[1] + 1e-9, 0.1)
    fg = np.interp(g, w, f); fc = mm*g + bb
    if np.nanmedian(fc) <= 0: return None
    ew = -np.trapezoid(1.0 - fg/fc, g)
    cont = (w >= 6545) & (w <= 6585) & ~((w >= 6557) & (w <= 6572))
    if cont.sum() < 10: return None
    cm, cb = np.polyfit(w[cont], f[cont], 1)
    res = f[cont] - (cm*w[cont] + cb)
    sig = 1.4826*np.median(np.abs(res - np.median(res)))
    dl = np.median(np.diff(w)); npix = (LINE[1]-LINE[0])/dl
    err = sig/abs(np.nanmedian(fc))*dl*np.sqrt(npix)
    rms_norm = sig/abs(np.nanmedian(fc))          # 归一化连续谱的逐像素噪声
    prof = fg/fc - 1.0
    k = 5
    prof_s = np.convolve(prof, np.ones(k)/k, mode='same')   # 5 像素（0.5 Å）平滑，抗单像素尖峰
    peak = float(np.nanmax(prof_s))          # 归一化峰高（平滑后，相对连续谱）
    return dict(ew=ew, err=err, rms_norm=rms_norm, peak=peak, snr_peak=peak/rms_norm if rms_norm > 0 else np.nan)

cat = pd.read_csv('data/lamost/dr13/dr13_mstellar_dM.csv', low_memory=False,
                  usecols=['obsid','subclass','teff','ewha','ewha_err','snrr','z','class'])
cat = cat[(cat.ewha > -20) & (cat.ewha <= 50) & (cat.ewha_err > 0) & (cat.ewha_err <= 5)].copy()
cat['active_cat'] = (cat.ewha >= 0.75) & (cat.ewha > 3*cat.ewha_err)
have = set(os.path.splitext(os.path.splitext(x)[0])[0] for x in os.listdir(DIR) if x.endswith('.csv.gz'))
cat = cat[cat.obsid.astype(str).isin(have)]
print('星表中在本地有谱的条数：%d（目录 %d 条）' % (len(cat), len(have)))
random.seed(20261028)
sub = cat.sample(n=min(N, len(cat)), random_state=20261028)
rows = []
for _, r in sub.iterrows():
    p = os.path.join(DIR, '%d.csv.gz' % int(r.obsid))
    try:
        d = analyse(p, r.z)
    except Exception:
        d = None
    if d is None: continue
    d.update(obsid=int(r.obsid), subclass=r.subclass, active_cat=bool(r.active_cat),
             ew_cat=r.ewha, snrr=r.snrr,
             active_ew=bool(d['ew'] >= 0.75 and d['ew'] > 3*d['err']),
             pass_c3=bool(np.isfinite(d['snr_peak']) and d['snr_peak'] > 3))
    rows.append(d)
T = pd.DataFrame(rows)
print('成功处理 %d 条谱' % len(T))
T.to_csv(os.path.join(OUT, 'criterion3_sample.csv'), index=False, encoding='utf-8')
print('\n=== 第三判据的影响（在现判据判为活动的谱中）===')
print(' 亚型  活动(cat)  n   其中不满足第三判据   比例')
for sp in ['dM0','dM1','dM2','dM3','dM4','dM5','dM6','dM7','dM8']:
    q = T[(T.subclass == sp) & T.active_cat]
    if len(q) < 20: continue
    fail = (~q.pass_c3).sum()
    print('  %-4s %6d  %5d      %5d            %5.1f%%' % (sp, len(T[T.subclass==sp]), len(q), fail, 100*fail/len(q)))
act = T[T.active_cat]
print('\n 合计：活动谱 %d 条，其中不满足第三判据 %d 条（%.1f%%）→ 活动比例将按此比例下降'
      % (len(act), (~act.pass_c3).sum(), 100*(~act.pass_c3).mean()))
print(' 对照：非活动谱 %d 条中，有 %d 条其实通过第三判据（%.1f%%，即假阴性）'
      % (len(T[~T.active_cat]), T[~T.active_cat].pass_c3.sum(), 100*T[~T.active_cat].pass_c3.mean()))
print('s565 完成')
