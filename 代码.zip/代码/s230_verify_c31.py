# -*- coding: utf-8 -*-
"""s230: 复核 +0.31 口径下的自由断点 β、OLS/ML 饱和点（供台账 R4 引用）。"""
import numpy as np, pandas as pd
src = open("s227_recompute_all_tau030.py", encoding="utf-8").read().split('print("=" * 78)')[0]
exec(src)
D = "C:/Users/lingz/Desktop/APJS/图五及相关数据/数据/"
d = pd.read_csv(D + "图5_逐星样本_严格3340行_⑤.csv")
d = d[(d.RHa > 0) & (d.P > 0) & (d.M > 0)]
y = np.log10(d.RHa.values)
for c, lab in ((-0.30, "Li -0.30"), (+0.31, "W18 +0.31")):
    R = ro(d.M.values, d.P.values, c)
    x = np.log10(R)
    rs_o, b_o = free_bp_ols(x, y)
    rs_m, b_m, si = ml_fit(x, y, d.sRHa.values)
    # 固定断点 0.135
    s135 = np.polyfit(x[x > np.log10(0.135)], y[x > np.log10(0.135)], 1)[0]
    print("%-11s 自由断点 OLS: Ro_sat=%.4f β=%.4f | ML: Ro_sat=%.4f β=%.4f σ_int=%.3f | 固定0.135 β=%.4f"
          % (lab, rs_o, b_o, rs_m, b_m, si, s135))
