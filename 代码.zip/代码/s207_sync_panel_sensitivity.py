# -*- coding: utf-8 -*-
"""同步分口径面板表 + 把敏感性分析写进方法说明"""
import io, os, shutil, sys
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
import pandas as pd
W = r'C:\Users\lingz\OneDrive\Desktop\复现老师工作'
D = r'C:\Users\lingz\Desktop\复现老师工作'
A = r'C:\Users\lingz\Desktop\APJS\图五及相关数据'
g = lambda *a: os.path.join(W, *a)
CP = [(g('figures', 'dr13_fig5_rha_rossby.png'), os.path.join(D, '图', '图05_Rossby_dr13_fig5_rha_rossby.png')),
      (g('figures', 'dr13_fig5_rha_rossby.png'), os.path.join(A, '图', '图5_两面板_终版.png')),
      (g('data', 'processed', 'dr13', 'fig5_panel_fits_v4.csv'), os.path.join(D, '数据', '图5_面板拟合_v4.csv')),
      (g('data', 'processed', 'dr13', 'fig5_panel_fits_v4.csv'), os.path.join(A, '数据', '面板拟合_v4.csv')),
      (g('data', 'processed', 'dr13', 'fig5_panel_by_sample_v4.csv'), os.path.join(D, '数据', '图5_面板拟合_分口径_v4.csv')),
      (g('data', 'processed', 'dr13', 'fig5_panel_by_sample_v4.csv'), os.path.join(A, '数据', '面板拟合_分口径_v4.csv'))]
for s, d in CP:
    shutil.copy2(s, d); print('  同步 ->', d.replace('C:\\Users\\lingz\\Desktop\\', ''))
t = pd.read_csv(g('data', 'processed', 'dr13', 'fig5_panel_by_sample_v4.csv'))
L = ['', '## 六、分面板结果对各清洗口径的敏感性（2026-10-21 补充）', '',
     '两个面板始终使用**同一份样本、同一套判据**（各自在该子集上单独拟合），下表列出判据严格程度变化时两面板斜率如何移动：', '',
     '| 样本口径 | 清洗项 | N(M0–M3) | β(M0–M3) | ±boot | N(M4–M6) | β(M4–M6) | ±boot |',
     '|---|---|---|---|---|---|---|---|']
for _, r in t.iterrows():
    L.append('| %s | %s | %s | %.3f | %.3f | %s | %.3f | %.3f |' % (
        r['口径'], r['清洗项'], format(int(r.n_M0M3), ','), r.beta_M0M3, r.beta_M0M3_boot,
        format(int(r.n_M4M6), ','), r.beta_M4M6, r.beta_M4M6_boot))
L += ['', '**要点**',
      '* 早型面板稳：β 在 −0.84 ~ −0.94 之间摆动，全程与 Li 等（2024）的 −0.91 ± 0.16 相容。',
      '* 晚型面板敏感：β 从 −0.67（仅 Ro≤3）到 −0.75（去别名/nss 后）再到 −0.70（全清洗），极差 0.08，bootstrap 误差 ±0.13~0.20，方向始终显著为负但明显比早型平。',
      '* 早期出现的 −0.912 / −0.764 对应上表第 2 行（4,612 原始样本 + 仅 Ro≤3），并非终版严格样本；终版图 5 用最后一行（⑤，N=3,340）。',
      '* 求解器差异也会带来约 0.01 的抖动：早期用共享的 fit_saturation（分段 + 200 次 bootstrap），终版用 401 点网格分段 OLS/ML。',
      '', '**正文可用句（中文）**：由于晚型星（M4–M6）样本较小、周期测量更困难，我们单独检验了样本口径的影响：仅做 Ro≤3 裁剪时两面板斜率为 −0.91 ± 0.13（M0–M3）与 −0.75 ± 0.13（M4–M6）；施加全部清洗（nss=0、去别名、ruwe<1.4、去 M3/M4 边界）后为 −0.94 ± 0.10 与 −0.70 ± 0.20。可见早型星的饱和后斜率稳定在 −0.84 ~ −0.94，与文献 −0.91 ± 0.16 一致；晚型星对样本口径更敏感，但始终显著为负。',
      '', '**Sentence for the paper (English)**: Because the late-type (M4-M6) subsample is smaller and its rotation periods are harder to measure, we tabulated the sensitivity to the sample definition. With only the Ro <= 3 cut the post-saturation slopes are -0.91 +/- 0.13 (M0-M3) and -0.75 +/- 0.13 (M4-M6); after applying all de-binarisation, de-aliasing, ruwe and M3/M4-border cuts they become -0.94 +/- 0.10 and -0.70 +/- 0.20. The early-type slope is therefore stable at -0.84 to -0.94, consistent with -0.91 +/- 0.16 from Li et al. (2024), while the late-type slope is more sensitive to the sample definition yet always significantly negative.',
      '']
BLK = '\n'.join(L)
for p in (os.path.join(D, '文档', '图05_Methods文字_中英文.md'), os.path.join(A, '方法说明', '图05_Methods文字_中英文.md')):
    s = open(p, encoding='utf-8').read()
    if '六、分面板结果对各清洗口径的敏感性' in s:
        print('  已有该节', os.path.basename(p)); continue
    open(p, 'w', encoding='utf-8').write(s.rstrip() + '\n' + BLK)
    print('  已追加敏感性一节 ->', p.replace('C:\\Users\\lingz\\Desktop\\', ''))
rm = os.path.join(A, 'README.md'); s = open(rm, encoding='utf-8').read()
if '分口径' not in s:
    open(rm, 'w', encoding='utf-8').write(s.rstrip() + '\n\n> 分面板结果随口径的敏感性见 数据/面板拟合_分口径_v4.csv 与 方法说明/图05_Methods文字_中英文.md 第六节。\n')
    print('  README 已加索引')
print('\n=== 面板拟合表（含口径/N 列）===')
print(pd.read_csv(g('data', 'processed', 'dr13', 'fig5_panel_fits_v4.csv')).to_string(index=False))
