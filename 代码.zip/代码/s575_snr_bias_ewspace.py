# -*- coding: utf-8 -*-
"""s575：低 S/N 会不会抬高测得的活动比例？——在 EW 空间做解析式注入-回收

不重读谱：用 s566 已存的 5,999 条本地谱的 (EW, sigma(EW), 目录 S/N)，先定出 sigma(EW) ∝ 1/S/N 的系数，
再对每条谱的真实 EW 叠加相应噪声，按「EW >= 0.75 A 且 EW > 3sigma」判活动，得到
  ① 给定真实 EW 的回收率随 S/N 的响应表；
  ② 固定真实活动率时，测得活动比例相对真值的偏差；
  ③ 用 §1 各 |Z| 档的目录 S/N 中位，把该偏差套到实测活动比例上，看远档的「额外活跃」能否由低 S/N 解释。
"""
import io, sys, os
import numpy as np, pandas as pd
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
OUT = r'C:\Users\lingz\Desktop\复现老师工作\APJS\多个图及讨论'
T = pd.read_csv(os.path.join(OUT, 'criterion3_by_zb_sample.csv'), comment='#')
T = T[np.isfinite(T.ew) & np.isfinite(T.err) & (T.err > 0) & np.isfinite(T.snrr) & (T.snrr > 0)].copy()
k = T.err.values*T.snrr.values
K = float(np.median(k))
print('样本 %d 条；sigma(EW) x S/N 的中位 = %.3f A' % (len(T), K))
print('原生 S/N 中位 %.1f，sigma(EW) 中位 %.3f A，本地 EW 中位 %.2f A' % (T.snrr.median(), T.err.median(), T.ew.median()))

def save(df, name, comments):
    fp = os.path.join(OUT, name); df.to_csv(fp, index=False, encoding='utf-8')
    txt = open(fp, encoding='utf-8').read()
    with open(fp, 'w', encoding='utf-8-sig') as f:
        f.write('\n'.join('# ' + c for c in comments) + '\n' + txt)
    print('  写出 %s（%d 行）' % (name, len(df)))

def save_txt(lines, name):
    fp = os.path.join(OUT, name)
    open(fp, 'w', encoding='utf-8').write('\n'.join(lines) + '\n')
    print('  写出 %s' % name)

SNRS = np.array([40, 30, 20, 15, 12, 10, 8, 6, 5, 4, 3, 2.5, 2.0])
RNG = np.random.default_rng(20261029)
NSIM = 400

def pass_prob(ew_true, snr):
    """对给定真实 EW 与目标 S/N，返回通过率（蒙特卡洛）"""
    sig = K/snr
    e = ew_true[:, None] + RNG.normal(0.0, sig, size=(len(ew_true), NSIM))
    ok = (e >= 0.75) & (e > 3*sig)
    return ok.mean()

# ① 响应表：真实 EW 网格
grid = np.array([0.75, 1.0, 1.5, 2.0, 3.0, 5.0, 10.0])
rows = []
for g in grid:
    for S in SNRS:
        ew = np.full(200, g)
        rows.append(dict(ew_true=g, snr=float(S), sigma=K/S, pass_pct=100*pass_prob(ew, S)))
A = pd.DataFrame(rows)
save(A, 'snr_recovery_response.csv', [
    '给定真实 EW(Ha) 时，在不同 S/N 下通过「EW>=0.75 A 且 EW>3sigma」的概率（蒙特卡洛 200x400）',
    'sigma(EW) = K / (S/N)，K 由本地 5,999 条谱的 err x snrr 中位得到（见下）',
    'K = %.3f A；sigma 列为该 S/N 对应的 sigma(EW)' % K,
    '生成脚本：代码/s575_snr_bias_ewspace.py'])

# ② 固定真实活动率下的偏差（真活动谱的 EW 用本地实测活动的 EW 分布）
act_ew = T[T.active_cat].ew.values
ina_ew = T[~T.active_cat].ew.values
rows = []
for S in SNRS:
    pa = pass_prob(act_ew, S); pi = pass_prob(ina_ew, S)
    for f_true in (0.05, 0.078, 0.20, 0.50):
        f_meas = f_true*pa + (1-f_true)*pi
        rows.append(dict(snr=float(S), f_true=f_true, pass_act=100*pa, pass_inact=100*pi,
                         f_meas=100*f_meas, bias_pp=100*(f_meas-f_true), ratio=f_meas/f_true))
B = pd.DataFrame(rows)
save(B, 'snr_bias_vs_true_fraction.csv', [
    '固定真实活动率 f_true 时，测得活动比例随 S/N 的偏差（bias_pp 为百分点，ratio 为测得/真值）',
    'pass_act 为本地实测活动谱（EW>=0.75）在给 S/N 下的通过率，pass_inact 为非活动谱的误判率',
    'sigma(EW) = K/S，K = %.3f A；据此可判断低 S/N 是压低还是抬高测得的活动比例' % K,
    '生成脚本：代码/s575_snr_bias_ewspace.py'])

# ③ 套到 §1 各档
bins = [('<100', 19.67, 23.81), ('100-200', 17.54, 12.90), ('200-400', 15.49, 7.78),
        ('400-600', 13.90, 6.65), ('600-1000', 12.27, 7.76)]
lines = []
lines.append('# 低 S/N 对测得活动比例的预测（s575）')
lines.append('')
lines.append('sigma(EW) = %.3f / (S/N)；真活动谱 EW 用本地实测分布（n=%d），真非活动谱 n=%d' % (K, len(act_ew), len(ina_ew)))
lines.append('')
lines.append('| |Z| 档 | 目录 S/N 中位 | 实测活动比例 | 活动谱通过率 | 非活动误判率 | 若 f_true 使实测值成立的解 | 相对 <100 pc 的纯 S/N 效应 |')
lines.append('|---|---|---|---|---|---|---|')
ref = None
for lb, s, fobs in bins:
    pa = pass_prob(act_ew, s); pi = pass_prob(ina_ew, s)
    # 解 f_true: fobs = f_true*pa + (1-f_true)*pi
    ft = (fobs/100 - pi)/(pa - pi) if pa != pi else np.nan
    if ref is None:
        ref = (pa, pi)
        rel = '—（基准）'
    else:
        rel = '%+.2f pp（纯 S/N 会造成的变化）' % (100*((ft*pa + (1-ft)*pi) - (ft*ref[0] + (1-ft)*ref[1])))
    lines.append('| %s | %.1f | %.2f%% | %.1f%% | %.2f%% | f_true = %.2f%% | %s |'
                 % (lb, s, fobs, 100*pa, 100*pi, 100*ft, rel))
lines.append('')
lines.append('注：通过率用本地 EW 分布（把本地 EW 当作真值）；若本地 EW 与目录 EW 存在零点差，第三列的 f_true 只具相对意义。')
save_txt(lines, 'snr_bias_summary.md')

print('\n=== 真实 EW 的回收率（%）===')
print('  EW(A)  ' + '  '.join('%5.1f' % s for s in SNRS))
for g in grid:
    q = A[A.ew_true == g]
    print('  %5.2f  ' % g + '  '.join('%5.1f' % v for v in q.pass_pct.values))

print('\n=== 固定真实活动率 7.8% 时的测得值 ===')
for _, r in B[(B.f_true == 0.078)].iterrows():
    print('  S/N %5.1f  测得 %5.2f%%  比值 %.3f' % (r.snr, r.f_meas, r.ratio))

print('\n=== 套到 §1 各档 ===')
for l in lines: print(l)
print('s575 完成')
