# -*- coding: utf-8 -*-
"""s602：第三判据（峰高 > 3×线外噪声）在**全量谱**上的分档复核

此前 s565/s566 用的是 data/lrs/dr13（154,309 条、90.1% 为活动星，活动富集），
且只抽 2,498 条。剩余谱下齐后可从 dr13_rest（99.99% 非活动）抽样本重测，
检验「不合格率随 |Z| 上升」是否只存在于活动富集样本里。

判据实现（与 s565 同口径）：5 像素平滑后的 Hα 窗口内峰高，除以线外稳健 rms，> 3 即通过。
输出：多个图及讨论/criterion3_full_spectra.csv
"""
import io, sys, os, gzip
import numpy as np, pandas as pd

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
BASE = r'C:\Users\lingz\OneDrive\Desktop\复现老师工作'
OUT = r'C:\Users\lingz\Desktop\复现老师工作\APJS\多个图及讨论'
LINE = (6557.66, 6571.66); CONT = (6545.0, 6585.0); EXCL = (6557.0, 6572.0)

def wilson(k, n, z=1.96):
    if n == 0: return (np.nan, np.nan)
    p = k/n; d = 1 + z*z/n; c = (p + z*z/(2*n))/d
    h = z*np.sqrt(p*(1-p)/n + z*z/(4*n*n))/d
    return (100*(c-h), 100*(c+h))

paths = {}
for sub in ['lrs/dr13','lrs/dr13_rest']:
    dd = os.path.join(BASE,'data',sub)
    with os.scandir(dd) as it:
        for e in it:
            if e.name.endswith('.csv.gz') and e.stat().st_size > 500:
                paths[e.name[:-7]] = (e.path, sub.split('/')[-1])

cat = pd.read_csv(os.path.join(BASE,'data','lamost','dr13','dr13_mstellar_dM.csv'), low_memory=False,
                  usecols=['obsid','uid','subclass','ewha','ewha_err','snrr','z','z_err','ra','dec','gaia_source_id'])
cat['active'] = (cat.ewha >= 0.75) & (cat.ewha > 3*cat.ewha_err)
cat['obsid_s'] = cat.obsid.astype(str)
cat = cat[cat.obsid_s.isin(paths)].copy()
cat['src'] = cat.obsid_s.map(lambda x: paths[x][1])
cat['path'] = cat.obsid_s.map(lambda x: paths[x][0])
# |Z| 用 Gaia 视差
g = pd.read_csv(os.path.join(BASE,'data','gaia','gaia_dr3_mstars.csv'), low_memory=False,
                usecols=['source_id','parallax','parallax_error','ruwe'])
cat['gaia_source_id'] = pd.to_numeric(cat.gaia_source_id, errors='coerce')
cat = cat.merge(g, left_on='gaia_source_id', right_on='source_id', how='inner')
cat = cat[(cat.parallax > 0.2) & (cat.parallax/cat.parallax_error > 5) & (cat.ruwe < 1.4)].copy()
d_pc = 1000.0/cat.parallax.values
cat['absz'] = np.abs(d_pc*np.sin(np.deg2rad(cat.dec.values*0 + np.arcsin(0))))  # placeholder
# 用银道坐标
from astropy.coordinates import SkyCoord
import astropy.units as un
sc = SkyCoord(ra=cat.ra.values*un.deg, dec=cat.dec.values*un.deg, distance=d_pc*un.pc, frame='icrs')
cat['absz'] = np.abs(d_pc*np.sin(np.deg2rad(sc.galactic.b.deg)))
BINS = [(0,100,'<100'),(100,200,'100-200'),(200,400,'200-400'),(400,600,'400-600'),
        (600,1000,'600-1000'),(1000,3000,'>1000')]
cat['zbin'] = pd.cut(cat.absz, [0,100,200,400,600,1000,3000], labels=[b[2] for b in BINS])
rows = []
for src in ['dr13','dr13_rest']:
    for lo, hi, nm in BINS:
        pool = cat[(cat.src == src) & (cat.zbin == nm)]
        if len(pool) == 0: continue
        take = pool.sample(min(250, len(pool)), random_state=13)
        ok = 0; tot = 0
        for _, r in take.iterrows():
            try:
                with gzip.open(r.path, 'rt', encoding='utf-8', errors='replace') as fh:
                    d = pd.read_csv(fh)
                w = d.Wavelength.values.astype(float); f = d.Flux.values.astype(float)
                m = np.isfinite(w) & np.isfinite(f)
                w, f = w[m], f[m]
                o = np.argsort(w); w, f = w[o], f[o]
                fs = pd.Series(f).rolling(5, center=True, min_periods=3).mean().values
                lin = (w >= LINE[0]) & (w <= LINE[1])
                cont = (w >= CONT[0]) & (w <= CONT[1]) & ~((w >= EXCL[0]) & (w <= EXCL[1]))
                if lin.sum() < 5 or cont.sum() < 10: continue
                base = np.nanmedian(fs[cont])
                rms = 1.4826*np.median(np.abs(fs[cont] - base))
                if rms <= 0: continue
                tot += 1
                if (np.nanmax(fs[lin]) - base) > 3*rms: ok += 1
            except Exception:
                continue
        if tot == 0: continue
        lo_, hi_ = wilson(ok, tot)
        rows.append(dict(src=src, zbin=nm, n=tot, n_pass=ok, pass_pct=100*ok/tot, lo=lo_, hi=hi_))
        print('  %-11s %-9s n=%4d 通过 %3d（%5.1f%% [%.1f, %.1f]）' % (src, nm, tot, ok, 100*ok/tot, lo_, hi_))
T = pd.DataFrame(rows)
fp = os.path.join(OUT, 'criterion3_full_spectra.csv')
T.to_csv(fp, index=False, encoding='utf-8')
txt = open(fp, encoding='utf-8').read()
hdr = ('# s602：第三判据（5 像素平滑峰高 > 3×线外稳健 rms）在两个谱目录上的分档通过率\n'
       '# dr13 = 旧存档（活动富集，90.1% 活动）；dr13_rest = 本次下载（99.99% 非活动）\n'
       '# 每格最多抽 250 条；生成脚本：代码/s602_criterion3_full_spectra.py\n')
open(fp, 'w', encoding='utf-8-sig').write(hdr + txt)
print('\n写出 criterion3_full_spectra.csv（%d 行）' % len(T))
