
# -*- coding: utf-8 -*-
"""s634：用 r 波段 S/N（snrr）重建分解样本 —— snru 不是 S/N（中位 0.27、snru>50 仅 2 颗）。
重建链路：EW 闸门 → Gaia 并表 → 视差质量/ruwe → 每 uid 取最大 EW → M_G>=6 → 0<|Z|<=400
然后按 §2.2 B 层清洗（SB1、哨兵、范围、mh_ok、dist>0）与六因素 Shapley。
"""
import os, sys, io, math, itertools, json
import numpy as np, pandas as pd
from astropy.coordinates import SkyCoord
import astropy.units as u
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
OD = r'C:\Users\lingz\OneDrive\Desktop\复现老师工作\data'
D  = r'C:\Users\lingz\Desktop\复现老师工作\APJS\多个图及讨论'
lam = ['uid','subclass','teff','logg','m_h','m_h_err','ewha','ewha_err','snrr','snru','gaia_source_id','gaia_g_mean_mag','ra','dec']
d = pd.read_csv(os.path.join(OD,'lamost','dr13','dr13_mstellar_dM.csv'), usecols=lam, low_memory=False)
print('catalogue', len(d), '| snrr median %.2f  p10 %.2f  p90 %.2f  n(0)=%d  n(-9999)=%d' % (
    d.snrr.median(), d.snrr.quantile(.1), d.snrr.quantile(.9), int((d.snrr==0).sum()), int((d.snrr==-9999).sum())))
d = d[(d.ewha>-20)&(d.ewha<=50)&(d.ewha_err>0)&(d.ewha_err<=5)]
g = pd.read_csv(os.path.join(OD,'gaia','gaia_dr3_mstars.csv'), usecols=['source_id','parallax','parallax_error','ruwe','phot_g_mean_mag'], low_memory=False)
d = d.merge(g, left_on='gaia_source_id', right_on='source_id', how='inner')
d = d[(d.parallax>0.2)&(d.parallax/d.parallax_error>5)&(d.ruwe<1.4)]
d = d.sort_values('ewha', ascending=False).drop_duplicates('uid')
d['MG'] = d.gaia_g_mean_mag.values - 5*np.log10(np.clip(1000.0/d.parallax.values,1,None)) + 5
d = d[d.MG>=6].copy(); d['dist_pc']=1000.0/d.parallax.values
sc = SkyCoord(ra=d.ra.values*u.deg, dec=d.dec.values*u.deg, distance=d.dist_pc.values*u.pc, frame='icrs')
d['absz'] = np.abs(d.dist_pc.values*np.sin(np.deg2rad(sc.galactic.b.deg)))
d = d[(d.absz>0)&(d.absz<=400)].copy()
d['active'] = ((d.ewha>=0.75)&(d.ewha>3*d.ewha_err)).astype(float)
sb1 = pd.read_csv(os.path.join(D,'RV变星_SB1候选_多历元.csv'), low_memory=False)
d = d[~d.uid.isin(set(sb1.uid))]
for c in ['teff','logg','m_h','snrr']: d = d[d[c].notna() & (d[c]!=-9999)]
d = d[(d.teff>=2000)&(d.teff<=4500)&(d.logg>=3)&(d.logg<=6)&(d.m_h.abs()<1)&(d.snrr>0)]
d = d[(d.m_h_err.notna())&(d.m_h.abs()<2)&(d.dist_pc>0)].copy()
print('analysis sample (snrr-based):', len(d), '| active %.3f' % d.active.mean())
d['zb'] = pd.cut(d.absz,[0,100,200,400],labels=['<100','100-200','200-400'])
DUM = pd.get_dummies(d.subclass, prefix='s', drop_first=True).astype(float)
for c,nm in [('teff','F2'),('logg','F3'),('m_h','F4')]:
    v=d[c]; d[nm]=v-v.mean()
d['F2']=d.F2/1000.0
lv=np.log10(d.snrr); d['F5']=lv-lv.mean()
ld=np.log10(d.dist_pc); d['F6']=ld-ld.mean()
X=pd.concat([DUM,d[['F2','F3','F4','F5','F6']]],axis=1)
blocks={'F1':list(DUM.columns),'F2':['F2'],'F3':['F3'],'F4':['F4'],'F5':['F5'],'F6':['F6']}
y=d.active.values; masks={b:(d.zb.values==b) for b in ['<100','100-200','200-400']}
f={b:100*y[m].mean() for b,m in masks.items()}; OBS={b:f['<100']-f[b] for b in ['100-200','200-400']}
print('bin rates:', {k:round(v,2) for k,v in f.items()}, '| observed D:', {k:round(v,2) for k,v in OBS.items()})
def shapley(keys, ref='<100', bins=('100-200','200-400'), logit=False):
    K=len(keys); cache={}
    def delta(S):
        cols=[c for k in S for c in blocks[k]]
        A=np.column_stack([np.ones(len(y))]+[X[c].values for c in cols]) if cols else np.ones((len(y),1))
        if logit:
            b=np.zeros(A.shape[1]); b[0]=np.log(y.mean()/(1-y.mean()))
            for _ in range(60):
                p=1/(1+np.exp(-(A@b))); W=p*(1-p)
                st=np.linalg.lstsq(A.T@(A*W[:,None])+1e-9*np.eye(len(b)), A.T@(y-p), rcond=None)[0]; b=b+st
                if np.max(np.abs(st))<1e-9: break
            pr=1/(1+np.exp(-(A@b)))
        else:
            beta,*_=np.linalg.lstsq(A,y,rcond=None); pr=A@beta
        v={bb:pr[mm].mean() for bb,mm in masks.items()}
        return {bb:100*(v[bb]-v[ref]) for bb in bins}
    for r in range(K+1):
        for S in itertools.combinations(keys,r): cache[frozenset(S)]=delta(S)
    phi={bb:{k:0.0 for k in keys} for bb in bins}
    for k in keys:
        others=[x for x in keys if x!=k]
        for r in range(len(others)+1):
            for S in itertools.combinations(others,r):
                w=math.factorial(len(S))*math.factorial(K-len(S)-1)/math.factorial(K)
                for bb in phi: phi[bb][k]+=w*(cache[frozenset(tuple(sorted(S+(k,))))][bb]-cache[frozenset(S)][bb])
    return phi, cache[frozenset(keys)]
phi, full = shapley(['F1','F2','F3','F4','F5','F6'])
print('\n=== main (LPM, snrr) ===')
rows=[]
for b in ['100-200','200-400']:
    print('  %-8s observed %6.2f | model %+6.2f | ' % (b, OBS[b], full[b]) + ', '.join('%s %+.2f' % (k, phi[b][k]) for k in ['F1','F2','F3','F4','F5','F6']) + ' | residual %+.2f' % (OBS[b]-full[b]))
    for k in ['F1','F2','F3','F4','F5','F6']:
        rows.append(dict(bin=b, factor=k, contribution_pp=round(phi[b][k],4), share_of_observed_pct=round(100*phi[b][k]/OBS[b],2),
                         share_of_explained_pct=round(100*phi[b][k]/full[b],2)))
    rows.append(dict(bin=b, factor='OBSERVED_D', contribution_pp=round(OBS[b],4), share_of_observed_pct=100.0, share_of_explained_pct=np.nan))
    rows.append(dict(bin=b, factor='EXPLAINED_SUM', contribution_pp=round(full[b],4), share_of_observed_pct=round(100*full[b]/OBS[b],2), share_of_explained_pct=100.0))
    rows.append(dict(bin=b, factor='RESIDUAL', contribution_pp=round(OBS[b]-full[b],4), share_of_observed_pct=round(100*(OBS[b]-full[b])/OBS[b],2), share_of_explained_pct=np.nan))
pd.DataFrame(rows).to_csv(os.path.join(D,'多因素_六因素贡献_snrr版.csv'), index=False, encoding='utf-8-sig')
# logit R3
phiL, fullL = shapley(['F1','F2','F3','F4','F5','F6'], logit=True)
print('\n=== R3 logit (snrr) ===')
for b in ['100-200','200-400']:
    print('  %-8s model %+6.2f | ' % (b, fullL[b]) + ', '.join('%s %+.2f' % (k, phiL[b][k]) for k in ['F1','F2','F3','F4','F5','F6']))
# R8 with snrr>50
m8 = d[d.snrr>50]
print('\nR8 sample (snrr>50 & m_h_err<0.2):', len(m8), 'of', len(d))
pd.DataFrame(rows).to_csv(os.path.join(D,'多因素_六因素贡献_snrr版.csv'), index=False, encoding='utf-8-sig')
print('wrote 多因素_六因素贡献_snrr版.csv')
