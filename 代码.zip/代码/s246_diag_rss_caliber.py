# -*- coding: utf-8 -*-
"""s246：ΔRSS 口径仲裁 + 谷结构判定（不产图，只打印）。

回答三件事：

1. **0.81 与 1.3 为什么并存**——两者是不同定义，不是口径漂移：
       ΔRSS(上支) = RSS(上支) − min_rs RSS      （与 s244 图纵轴同定义）
       跨度       = RSS(上支) − RSS(下支)        （上一轮报的 0.81）
   恒等式：ΔRSS = 跨度 + [RSS(下支) − RSS_min]。
   M0–M3 的 0.81 之所以小于 1.27，是因为下支 0.047 本身不在极小上（比 0.0457 高 2.8%）。

2. **谷结构**——用细网格 + prominence 判局部极小：
   M0–M3 是否双谷、M4–M6 是否单谷；谷间脊峰 ΔRSS 是多少（相对各面板极小）。

3. **RSS≈755 的归属**——是 M0–M3 面板的整段 RSS，还是坪区子集？
   与 s245 的 725.9（全体坪区，n=2,360）不是一个量。

口径：τ 二次项 −0.30（Li 2024 印刷式）；样本 `图5_逐星样本_严格3340行_⑤.csv`，
按 M、P 重算 Ro（该 CSV 的 Ro 列是 −0.31 旧口径）。
"""
import io, os, sys
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
import numpy as np, pandas as pd
from scipy.signal import find_peaks
from scipy.ndimage import gaussian_filter1d

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
SAMPLE = os.path.join(ROOT, '数据', '图5_逐星样本_严格3340行_⑤.csv')

TAU = -0.30
PAN = [('M0–M3', ['dM0', 'dM1', 'dM2', 'dM3']),
       ('M4–M6', ['dM4', 'dM5', 'dM6'])]
BRANCH = {'M0–M3': (0.047, 0.116), 'M4–M6': (0.050, 0.114)}
DOMAINS = [('图域 0.02–0.40 / 400 点', 0.02, 0.40, 400),
           ('宽域 0.004–0.50 / 1101 点', 0.004, 0.50, 1101),
           ('旧网格 0.0794–0.398 / 401 点', 10 ** -1.1, 10 ** -0.4, 401)]


def rss_beta(x, y, rs, minseg=20):
    s, u = x <= rs, x > rs
    if s.sum() < minseg or u.sum() < minseg:
        return np.inf, np.nan
    r = ((y[s] - y[s].mean()) ** 2).sum()
    sl, ic = np.polyfit(x[u], y[u], 1)
    r += ((y[u] - (sl * x[u] + ic)) ** 2).sum()
    return r, sl


def load():
    d = pd.read_csv(SAMPLE)
    d = d[(d.Ro > 0) & (d.RHa > 0) & (d.P > 0) & (d.M > 0)].copy()
    d['Ro30'] = d.P / 10 ** (2.33 - 1.50 * d.M + TAU * d.M ** 2)
    return d


def main():
    d = load()
    print('样本 n=%d（τ 二次项 %+0.2f）' % (len(d), TAU))

    print('\n' + '=' * 96)
    print('【一】ΔRSS 与「跨度」的恒等式（每面板每网格各减各的极小）')
    print('=' * 96)
    for nm, sel in PAN:
        q = d[d.spt.isin(sel)]
        x, y = np.log10(q.Ro30.values), np.log10(q.RHa.values)
        bp_lo, bp_up = BRANCH[nm]
        print('\n%s  n=%d   下支 %.3f / 上支 %.3f' % (nm, len(q), bp_lo, bp_up))
        for dn, lo, hi, n in DOMAINS:
            g = np.logspace(np.log10(lo), np.log10(hi), n)
            r = np.array([rss_beta(x, y, t)[0] for t in np.log10(g)])
            i = int(np.argmin(r)); rmin = r[i]
            r_up, b_up = rss_beta(x, y, np.log10(bp_up))
            r_lo, _ = rss_beta(x, y, np.log10(bp_lo))
            print('  %-30s 极小@%.4f  RSS_min=%.2f  RSS(下)=%.2f  RSS(上)=%.2f'
                  % (dn, g[i], rmin, r_lo, r_up))
            print('  %-30s   ΔRSS(上)=%+.2f  = 跨度 %+.2f  + [RSS(下)−RSS_min] %+.2f'
                  % ('', r_up - rmin, r_up - r_lo, r_lo - rmin))

    print('\n' + '=' * 96)
    print('【二】谷结构（对 0.01 dex 高斯平滑，抑制离散样本造成的锯齿；prominence ≥ 0.3 才计）')
    print('=' * 96)
    for nm, sel in PAN:
        q = d[d.spt.isin(sel)]
        x, y = np.log10(q.Ro30.values), np.log10(q.RHa.values)
        g = np.logspace(np.log10(0.02), np.log10(0.40), 1200)
        lg = np.log10(g)
        r = np.array([rss_beta(x, y, t)[0] for t in lg])
        # 在 log 轴等距网格上做高斯平滑（σ ≈ 0.01 dex）
        step = lg[1] - lg[0]
        sig = max(1.0, 0.010 / step)
        rs = gaussian_filter1d(r, sig, mode='nearest')
        drss = rs - rs.min()
        print('\n%s  n=%d  RSS_min=%.2f（平滑后）' % (nm, len(q), rs.min()))

        # 地标点表：直接给读者可核的剖面
        marks = [0.020, 0.030, 0.040, 0.046, 0.050, 0.060, 0.080, 0.100,
                 0.114, 0.116, 0.135, 0.160, 0.200, 0.300, 0.400]
        print('   Ro_sat : ' + ' '.join('%7.3f' % m for m in marks))
        print('   ΔRSS   : ' + ' '.join('%7.2f' % np.interp(np.log10(m), lg, drss) for m in marks))

        idx, prop = find_peaks(-drss, prominence=0.30)
        keep = sorted([(g[i], drss[i], prop['prominences'][k]) for k, i in enumerate(idx)])
        for bp, dv, prom in keep:
            print('   局部极小 Ro=%.4f  ΔRSS=%+.2f  prominence=%.2f' % (bp, dv, prom))
        if len(keep) >= 2:
            a, b = keep[0][0], keep[1][0]
            m = (g > a) & (g < b)
            j = int(np.argmax(np.where(m, drss, -np.inf)))
            print('   两谷 %.4f / %.4f → 脊峰 Ro=%.4f  ΔRSS=%+.2f'
                  % (a, b, g[j], drss[j]))
            print('   两谷深度差 = %.2f ；脊峰高出浅谷 = %.2f'
                  % (abs(keep[1][1] - keep[0][1]), drss[j] - max(keep[0][1], keep[1][1])))

    print('\n' + '=' * 96)
    print('【三】RSS≈755 的归属核对')
    print('=' * 96)
    for nm, sel in PAN:
        q = d[d.spt.isin(sel)]
        x, y = np.log10(q.Ro30.values), np.log10(q.RHa.values)
        g = np.logspace(np.log10(0.02), np.log10(0.40), 400)
        r = np.array([rss_beta(x, y, t)[0] for t in np.log10(g)])
        var0 = ((y - y.mean()) ** 2).sum()
        print('  %s：n=%d  整段 RSS_min=%.1f  零模型总平方和=%.1f  比值=%.3f'
              % (nm, len(q), r.min(), var0, r.min() / var0))
    plat = d[d.Ro30 < 0.135]
    yp = np.log10(plat.RHa.values)
    print('  全体坪区 Ro<0.135：n=%d  RSS(常数)=%.1f  ← s245 的 725.9 是这个量'
          % (len(plat), ((yp - yp.mean()) ** 2).sum()))
    print('\n结论：755 属 M0–M3 面板「整段」分段拟合的最小 RSS；725.9 属「全体坪区」的常数模型 RSS。')
    print('      两者样本不同（2,083 vs 2,360）、模型不同（分段 vs 纯常数），不可互代。')


if __name__ == '__main__':
    main()
