# -*- coding: utf-8 -*-
"""把图5相关的旧口径 CSV 统一加“旧版_”前缀，并更新周期样本说明与文档引用"""
import io, glob, os, sys
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
D = r'C:\Users\lingz\Desktop\复现老师工作\数据'
A = r'C:\Users\lingz\Desktop\APJS\图五及相关数据\数据'
REN = [(D, '图05_Rossby样本.csv', '旧版_图05_Rossby样本_Fetherolf口径.csv'),
       (D, '图05_稳健性表.csv', '旧版_图05_稳健性表_v2.csv'),
       (D, '图05_稳健性表_v3_nss与别名.csv', '旧版_图05_稳健性表_v3.csv'),
       (D, '图05_逐星样本_终版.csv', '旧版_图05_逐星样本_4612行旧口径.csv'),
       (A, '图5_逐星样本_终版.csv', '旧版_图5_逐星样本_4612行旧口径.csv')]
for d, o, n in REN:
    p, q = os.path.join(d, o), os.path.join(d, n)
    if os.path.exists(p):
        os.replace(p, q); print('  改名 %-32s -> %s' % (o, n))
TXT = os.path.join(D, '图05_周期样本说明.txt')
open(TXT, 'w', encoding='utf-8').write('''图5（R'Hα–Ro）数据说明  —— 2026-10-21 更新

【以本目录下 图5_*_v4 与 图5_逐星样本_* 为准】

一、怎么复现这张图
  1. 图5_逐星样本_周期4612行_①.csv    周期样本全量（含别名/双星/M3-M4边界），含 Ro、R'Hα、误差、各种标记
  2. 图5_逐星样本_对照4114行_⑤′.csv    ⑤′ 宽松口径（不去 ruwe、不去边界），β(OLS)=−0.817
  3. 图5_逐星样本_严格3340行_⑤.csv     ⑤ 采用口径（+ruwe<1.4 +去 M3/M4 边界），即图中红线的样本
  4. 图5_稳健性表_v4.csv               六级筛选的 β(OLS)/β(WLS)/β(ML)/Ro_sat/σ_int
  5. 图5_面板拟合_v4.csv                M0–M3 与 M4–M6 两面板的拟合参数

二、关键数字（与图、文档一致）
  ⑤  n=3,340  β(OLS)=−0.851±0.111  β(ML)=−0.855  Ro_sat=0.137(OLS)/0.121(ML)  σ_int=0.49 dex
  ⑤′ n=4,114  β(OLS)=−0.817          β(ML)=−0.842
  M0–M3 n=2,083 β=−0.935±0.085 ；M4–M6 n=1,245 β=−0.702±0.204
  论文 Li et al. (2024)：β=−0.91±0.16、Ro_sat=0.19±0.06

三、其余文件
  图05_TESS自转周期.csv              TESS/Fetherolf 周期原始匹配结果
  图05_VSX与Fetherolf周期对照.csv     117 颗同星两表周期对比（别名诊断）
  旧版_*                            早期口径留档，仅作溯源，不要用于出图
''')
print('  已重写 图05_周期样本说明.txt')
MAP = [('图05_Rossby样本.csv', '旧版_图05_Rossby样本_Fetherolf口径.csv'),
       ('图05_稳健性表.csv', '旧版_图05_稳健性表_v2.csv'),
       ('图05_稳健性表_v3_nss与别名.csv', '旧版_图05_稳健性表_v3.csv'),
       ('图05_逐星样本_终版.csv', '旧版_图05_逐星样本_4612行旧口径.csv'),
       ('图5_逐星样本_终版.csv', '旧版_图5_逐星样本_4612行旧口径.csv')]
docs = glob.glob(r'C:\Users\lingz\Desktop\复现老师工作\*.md') + glob.glob(r'C:\Users\lingz\Desktop\复现老师工作\文档\*.md') + \
       glob.glob(r'C:\Users\lingz\Desktop\复现老师工作\代码\*.md') + glob.glob(r'C:\Users\lingz\Desktop\APJS\图五及相关数据\**\*.md', recursive=True)
for p in docs:
    s = open(p, encoding='utf-8').read(); o = s
    for a, b in MAP: s = s.replace(a, b)
    if s != o: open(p, 'w', encoding='utf-8').write(s); print('  文档引用更新', os.path.basename(p))
print('\n=== 交付包 数据 最终 ===')
for f in sorted(os.listdir(D)):
    if '图5' in f or '图05' in f: print('   %-42s %7.0f KB' % (f, os.path.getsize(os.path.join(D, f))/1024))
