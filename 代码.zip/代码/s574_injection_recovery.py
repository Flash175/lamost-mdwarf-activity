# -*- coding: utf-8 -*-
"""s574：注入-回收实验——「低 S/N 会把测得的活动比例抬高还是压低？」

做法：从 data/lrs/dr13 抽 400 条目录判为活动、400 条判为非活动的谱，用与 s566 完全相同的
EW 管线（Yi 2014 窗口 + 线外稳健 rms）在原生 S/N 与一系列人为降低的 S/N 上重测，
按「EW >= 0.75 A 且 EW > 3sigma」判活动，给出活动/非活动谱的回收率随 S/N 的响应曲线，
并把它换算成「固定真实活动率下，测得活动比例随 S/N 的偏差」。

输出：
  injection_recovery_by_snr.csv   —— 各 S/N 档的回收率与 EW 偏差
  injection_recovery_bias.csv     —— 固定真实活动率下的偏差，以及按 §1 各 |Z| 档 S/N 中位的预测
"""
import io, sys, os, gzip
import numpy as np, pandas as pd
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
OUT = r'C:\Users\lingz\Desktop\复现老师工作\APJS\多个图及讨论'
DIR = 'data/lrs/dr13'
C_L, C_R, LINE = (6555.0, 6560.0), (6570.0, 6575.0), (6557.66, 6571.66)
SNRS = [30.0, 20.0, 12.0, 8.0, 5.0, 3.0, 2.0]
N_ACT, N_INACT = 400, 400
RNG = np.random.default_rng(20261029)

def save(df, name, comments):
    fp = os.path.join(OUT, name); df.to_csv(fp, index=False, encoding='utf-8')
    txt = open(fp, encoding='utf-8').read()
    with open(fp, 'w', encoding='utf-8-sig') as f:
        f.write('\n'.join('# ' + c for c in comments) + '\n' + txt)
    print('  写出 %s（%d 行）' % (name, len(df)))

def wilson(k, n, z=1.96):
    if n == 0: return (np.nan, np.nan)
    p = k/n; d = 1+z*z/n; c = (p+z*z/(2*n))/d
    h = z*np.sqrt(p*(1-p)/n + z*z/(4*n*n))/d
    return 100*(c-h), 100*(c+h)

def measure(w, f):
    """与 s566 相同：线性伪连续谱 + 积分 EW + 线外稳健 rms"""
    ok = np.isfinite(w) & np.isfinite(f); w, f = w[ok], f[ok]
    if len(w) < 100: return None
    o = np.argsort(w); w, f = w[o], f[o]
    mL = (w >= C_L[0]) & (w <= C_R[0]); mR = (w >= C_R[0]) & (w <= C_R[1])
    if mL.sum() < 2 or mR.sum() < 2: return None
    wl, fl = w[mL].mean(), f[mL].mean(); wr, fr = w[mR].mean(), f[mR].mean()
    if fr == fl: return None
    mm = (fr - fl)/(wr - wl); bb = fl - mm*wl
    g = np.arange(LINE[0], LINE[1] + 1e-9, 0.1)
    fg = np.interp(g, w, f); fc = mm*g + bb
    fcmed = float(np.nanmedian(fc))
    if fcmed <= 0: return None
    ew = -np.trapezoid(1.0 - fg/fc, g)
    cont = (w >= 6545) & (w <= 6585) & ~((w >= 6557) & (w <= 6572))
    if cont.sum() < 10: return None
    cm, cb = np.polyfit(w[cont], f[cont], 1)
    res = f[cont] - (cm*w[cont] + cb)
    sig = 1.4826*np.median(np.abs(res - np.median(res)))
    dl = np.median(np.diff(w)); npix = (LINE[1]-LINE[0])/dl
    err = sig/fcmed*dl*np.sqrt(npix)
    return dict(ew=ew, err=err, sig=sig, fcmed=fcmed)

def load(path, z):
    d = pd.read_csv(gzip.open(path, 'rt'), usecols=['Wavelength', 'Flux'])
    w = d.Wavelength.values/(1.0 + (z if np.isfinite(z) else 0.0))
    f = d.Flux.values.astype(float)
    return w, f

cat = pd.read_csv('data/lamost/dr13/dr13_mstellar_dM.csv', low_memory=False,
                  usecols=['obsid','subclass','ewha','ewha_err','snrr','z'])
cat = cat[(cat.ewha > -20) & (cat.ewha <= 50) & (cat.ewha_err > 0) & (cat.ewha_err <= 5)].copy()
cat['active_cat'] = (cat.ewha >= 0.75) & (cat.ewha > 3*cat.ewha_err)
have = set(os.path.splitext(os.path.splitext(x)[0])[0] for x in os.listdir(DIR) if x.endswith('.csv.gz'))
cat = cat[cat.obsid.astype(str).isin(have)]
act = cat[cat.active_cat].sample(n=min(N_ACT, int(cat.active_cat.sum())), random_state=20261029)
ina = cat[~cat.active_cat].sample(n=min(N_INACT, int((~cat.active_cat).sum())), random_state=20261029)
print('抽样：活动 %d 条、非活动 %d 条（本地谱且有目录 EW）' % (len(act), len(ina)))

rows = []
for grp, sub in (('active', act), ('inactive', ina)):
    for _, r in sub.iterrows():
        p = os.path.join(DIR, '%d.csv.gz' % int(r.obsid))
        try: w, f = load(p, r.z)
        except Exception: continue
        base = measure(w, f)
        if base is None: continue
        snr0 = base['fcmed']/base['sig'] if base['sig'] > 0 else np.nan
        for S in SNRS:
            if not np.isfinite(snr0) or snr0 <= S:      # 原生已低于目标，不降级
                continue
            sig_t = base['fcmed']/S
            sd = np.sqrt(max(sig_t**2 - base['sig']**2, 0.0))
            fd = f + RNG.normal(0.0, sd, size=f.shape)
            m = measure(w, fd)
            if m is None: continue
            rows.append(dict(grp=grp, obsid=int(r.obsid), snr_target=S, snr_native=snr0,
                             ew_true=base['ew'], ew=m['ew'], err=m['err'],
                             pass_act=bool((m['ew'] >= 0.75) and (m['ew'] > 3*m['err']))))
T = pd.DataFrame(rows)
print('有效注入点 %d 个' % len(T))

out = []
for S in SNRS:
    q = T[T.snr_target == S]
    if len(q) == 0: continue
    a = q[q.grp == 'active']; i = q[q.grp == 'inactive']
    pa = 100*a.pass_act.mean() if len(a) else np.nan
    pi = 100*i.pass_act.mean() if len(i) else np.nan
    out.append(dict(snr=S, n_act=len(a), pass_act=pa, n_inact=len(i), pass_inact=pi,
                    dEW_act=float((a.ew - a.ew_true).mean()) if len(a) else np.nan,
                    sdEW_act=float((a.ew - a.ew_true).std()) if len(a) else np.nan))
R = pd.DataFrame(out)
save(R, 'injection_recovery_by_snr.csv', [
    '注入-回收：把同一条谱按目标 S/N 加噪后，用与正文相同的判据（EW>=0.75 A 且 EW>3sigma）重判活动',
    'pass_act 为真活动谱的回收率、pass_inact 为真空非活动谱的误判率（均百分数）；dEW 为 EW 偏差中值',
    'snr 为线外连续谱的逐像元 S/N；样本来自 data/lrs/dr13 的本地谱，活动/非活动各 400 条',
    '生成脚本：代码/s574_injection_recovery.py'])

# 固定真实活动率下的偏差
bias = []
for f_true in (0.05, 0.08, 0.20, 0.50):
    for S in SNRS:
        q = R[R.snr == S]
        if len(q) == 0: continue
        pa = q.pass_act.iloc[0]/100; pi = q.pass_inact.iloc[0]/100
        f_meas = f_true*pa + (1-f_true)*pi
        bias.append(dict(f_true=f_true, snr=S, f_meas=100*f_meas, bias_pp=100*(f_meas-f_true),
                         ratio=f_meas/f_true))
B = pd.DataFrame(bias)
save(B, 'injection_recovery_bias.csv', [
    '固定真实活动率 f_true 下，测得活动比例随 S/N 的偏差（bias_pp 为百分点差，ratio 为测得/真实）',
    '由 injection_recovery_by_snr.csv 的 pass_act / pass_inact 按 f_meas = f_true*pass_act + (1-f_true)*pass_inact 得到',
    '用于回答：远档 S/N 中位较低时，测得活动比例会被系统压低还是抬高（比值 < 1 即压低）',
    '生成脚本：代码/s574_injection_recovery.py'])

print('\n=== 回收率随 S/N ===')
for _, r in R.iterrows():
    print('  S/N %5.1f  活动 %3d 条 回收 %5.1f%%   非活动 %3d 条 误判 %5.1f%%   dEW(活动) %+0.3f A'
          % (r.snr, r.n_act, r.pass_act, r.n_inact, r.pass_inact, r.dEW_act))

print('\n=== 测得活动比例相对真实值的比值（f_true = 0.08）===')
for _, r in B[B.f_true == 0.08].iterrows():
    print('  S/N %5.1f  测得 %.2f%%  （偏差 %+0.2f pp，比值 %.3f）' % (r.snr, r.f_meas, r.bias_pp, r.ratio))
print('s574 完成')
