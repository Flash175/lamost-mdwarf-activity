# -*- coding: utf-8 -*-
"""s591：星等通道到底能解释多少远档超出——反事实分解

问题：把远档限制到 S/N ≥ 15 得到 3.84% 与 5.45%，若某个模型「刚好凑到」这两个数，是否说明
分类与星等限选择根本不需要？答案要靠**独立**预测，不能靠凑。本脚本做反事实分解：
 1) logit：样条(|Z|) + 亚型FE（基准，只看组成）；
 2) 加 a_G·(G − G_ref) 或 a_MG·(M_G − M_ref)（星等通道）；
 3) 对每一档，把 G（或 M_G）强制设成 <100 pc 档的中位，算预测活动率的变化 Δ；
 4) 与「基准模型未能解释的超出部分」比较，给出星等通道的解释百分比。

输出：多个图及讨论/mag_channel_decomposition.csv
"""
import io, sys, os
import numpy as np, pandas as pd
from scipy.optimize import minimize
from scipy.special import expit
from astropy.coordinates import SkyCoord
import astropy.units as un

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
OUT = r'C:\Users\lingz\Desktop\复现老师工作\APJS\多个图及讨论'

def save(df, name, comments):
    fp = os.path.join(OUT, name)
    df.to_csv(fp, index=False, encoding='utf-8')
    txt = open(fp, encoding='utf-8').read()
    with open(fp, 'w', encoding='utf-8-sig') as f:
        f.write('\n'.join('# ' + c for c in comments) + '\n' + txt)
    print('  写出 %s（%d 行）' % (name, len(df)))

cat = pd.read_csv('data/lamost/dr13/dr13_mstellar_dM.csv', low_memory=False,
                  usecols=['uid','subclass','teff','ewha','ewha_err','snrr',
                           'ra','dec','gaia_source_id','gaia_g_mean_mag'])
cat = cat[(cat.ewha > -20) & (cat.ewha <= 50) & (cat.ewha_err > 0) & (cat.ewha_err <= 5)].copy()
cat['active'] = (cat.ewha >= 0.75) & (cat.ewha > 3*cat.ewha_err)
cat['gaia_source_id'] = pd.to_numeric(cat.gaia_source_id, errors='coerce')
g = pd.read_csv('data/gaia/gaia_dr3_mstars.csv', low_memory=False,
                usecols=['source_id','parallax','parallax_error','ruwe'])
m = cat.merge(g, left_on='gaia_source_id', right_on='source_id', how='inner')
m = m[(m.parallax > 0.2) & (m.parallax/m.parallax_error > 5) & (m.ruwe < 1.4)].copy()
u = m.sort_values('ewha', ascending=False).drop_duplicates('uid').copy()
u['MG'] = u.gaia_g_mean_mag.values - 5*np.log10(np.clip(1000.0/u.parallax.values, 1, None)) + 5
u = u[u.MG >= 6].copy()
d_pc = 1000.0/u.parallax.values
sc = SkyCoord(ra=u.ra.values*un.deg, dec=u.dec.values*un.deg, distance=d_pc*un.pc, frame='icrs')
u['absz'] = np.abs(d_pc*np.sin(np.deg2rad(sc.galactic.b.deg)))
u = u[u.absz <= 3000].copy()
u['subc'] = u.subclass.astype(str)
subs = [s for s in sorted(u.subc.unique()) if (u.subc == s).sum() >= 500]
u = u[u.subc.isin(subs)].copy()
print('样本 %d 颗，活动率 %.3f%%' % (len(u), 100*u.active.mean()))

z = u.absz.values/1000.0; y = u.active.values.astype(float)
G = pd.to_numeric(u.gaia_g_mean_mag, errors='coerce').values
MG = pd.to_numeric(u.MG, errors='coerce').values
sdum = np.column_stack([(u.subc.values == s).astype(float) for s in subs[1:]])
BINS = [(0,100,'<100'),(100,200,'100-200'),(200,400,'200-400'),(400,600,'400-600'),
        (600,1000,'600-1000'),(1000,3000,'>1000')]

def spline_cols(zv):
    cols = [np.ones_like(zv), zv]
    for k0 in (0.05, 0.1, 0.2, 0.4, 0.6, 1.0):
        cols.append(np.clip(zv-k0, 0, None))
    return cols

def fit(extra=None):
    cols = spline_cols(z)
    for j in range(sdum.shape[1]):
        cols.append(sdum[:, j])
    if extra is not None:
        cols.append(extra)
    X = np.column_stack(cols)
    def nll(b):
        p = expit(np.clip(X @ b, -30, 30))
        return -float((y*np.log(np.clip(p,1e-12,1)) + (1-y)*np.log(np.clip(1-p,1e-12,1))).sum())
    def gr(b):
        p = expit(np.clip(X @ b, -30, 30))
        return -(X.T @ (y - p))
    b0 = np.zeros(X.shape[1]); b0[0] = np.log(max(y.mean(),1e-6)/(1-max(y.mean(),1e-6)))
    r = minimize(nll, b0, method='BFGS', jac=gr, options=dict(maxiter=4000, gtol=1e-9))
    return X, r

X0, r0 = fit()
p0 = expit(np.clip(X0 @ r0.x, -30, 30))
Gref = np.nanmedian(G[(u.absz.values < 100)])
MGref = np.nanmedian(MG[(u.absz.values < 100)])
print('参考值（<100 pc 中位）：G = %.2f，M_G = %.2f' % (Gref, MGref))

XG, rG = fit(np.nan_to_num(G - Gref, nan=0.0))
XMG, rMG = fit(np.nan_to_num(MG - MGref, nan=0.0))
aG = rG.x[-1]; aMG = rMG.x[-1]
print('系数：a_G = %+.4f /mag，a_MG = %+.4f /mag' % (aG, aMG))

rows = []
for lo_, hi_, nm in BINS:
    s = (u.absz.values > lo_) & (u.absz.values <= hi_)
    if s.sum() < 50: continue
    obs = 100*y[s].mean()
    base = 100*p0[s].mean()
    # 反事实：把该档的 G / M_G 全部换成 <100 pc 的中位
    Xg = XG[s].copy(); Xg[:, -1] = 0.0
    Xm = XMG[s].copy(); Xm[:, -1] = 0.0
    cfG = 100*expit(np.clip(Xg @ rG.x, -30, 30)).mean()
    cfM = 100*expit(np.clip(Xm @ rMG.x, -30, 30)).mean()
    withG = 100*expit(np.clip(XG[s] @ rG.x, -30, 30)).mean()
    withM = 100*expit(np.clip(XMG[s] @ rMG.x, -30, 30)).mean()
    resid = obs - base                     # 基准（含组成）没解释的超出
    dG = cfG - withG                       # 星等通道对 G 的贡献
    dM = cfM - withM
    print('  %-9s n=%6d 实测 %6.2f%% | 基准(组成已控) %6.2f%% | 残差 %+5.2f pp | G 通道 %+5.2f pp | M_G 通道 %+5.2f pp'
          % (nm, s.sum(), obs, base, resid, dG, dM))
    rows.append(dict(zbin=nm, n=int(s.sum()), obs=obs, base_model=base, residual_pp=resid,
                     G_channel_pp=dG, MG_channel_pp=dM,
                     g_med=float(np.nanmedian(G[s])), mg_med=float(np.nanmedian(MG[s]))))
save(pd.DataFrame(rows), 'mag_channel_decomposition.csv', [
    's591：星等通道的反事实分解。base_model = 样条(|Z|)+亚型FE 的预测均值（组成已控）；residual_pp = 实测 - base_model',
    'G_channel_pp / MG_channel_pp = 把该档 G / M_G 全换成 <100 pc 中位后预测均值的变化（pp）',
    '不报 share：基准样条已把各档拟合到残差 ~0.1 pp，用 delta 除以它得到的百分比无意义（曾出现 9095%），只看 delta 列',
    '生成脚本：代码/s591_mag_channel_decomposition.py'])
print('\ns591 完成')
