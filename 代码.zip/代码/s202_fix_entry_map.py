# -*- coding: utf-8 -*-
"""同步桌面 复现入口.py 中的图5数据映射到新名字"""
import io, os, sys
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
P = r'C:\Users\lingz\Desktop\复现老师工作\复现入口.py'
s = open(P, encoding='utf-8').read(); o = s
MAP = [("'图05_Rossby样本.csv': 'data/processed/dr13/dr13_fig5_sample.csv'",
        "'图5_逐星样本_严格3340行_⑤.csv': 'data/processed/dr13/fig5_sample_strict_v4.csv',\n"
        "    '图5_稳健性表_v4.csv': 'data/processed/dr13/fig5_robustness_v4.csv',\n"
        "    '旧版_图05_Rossby样本_Fetherolf口径.csv': 'data/processed/dr13/dr13_fig5_sample.csv'"),
       ('"图05_Rossby样本.csv"', '"图5_逐星样本_严格3340行_⑤.csv"')]
for a, b in MAP:
    if a in s: s = s.replace(a, b)
if s != o: open(P, 'w', encoding='utf-8').write(s); print('  复现入口.py 已更新')
else: print('  复现入口.py 未匹配（可能格式不同），下面列出相关行供人工确认')
for line in open(P, encoding='utf-8').read().splitlines():
    if '图5' in line or '图05' in line: print('   ', line.strip()[:110])
