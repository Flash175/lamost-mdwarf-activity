
import io, sys
import numpy as np, pandas as pd
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
T = pd.read_csv('data/processed/dr13/ktype_pilot_ew.csv')
print('n =', len(T))
for q in (1, 5, 50, 95, 99, 99.9):
    print('  EW %4.1f%% 分位 = %+7.2f Å' % (q, np.percentile(T.ew, q)))
print('  EW 最大 = %+.2f Å' % T.ew.max())
print('  EW 误差：中位 %.3f，90%% 分位 %.3f' % (T.ew_err.median(), T.ew_err.quantile(.9)))
print('  EW > 0.75（不看误差）: %d 颗' % (T.ew > 0.75).sum())
print('  EW > 0.75 且 >2σ     : %d 颗' % ((T.ew > 0.75) & (T.ew > 2*T.ew_err)).sum())
print('  EW > 0.5  且 >3σ     : %d 颗' % ((T.ew > 0.5) & (T.ew > 3*T.ew_err)).sum())
print('  S/N 分布：中位 %.1f，10%% %.1f，90%% %.1f' % (T.snrr.median(), T.snrr.quantile(.1), T.snrr.quantile(.9)))
