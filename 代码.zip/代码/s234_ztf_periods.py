# -*- coding: utf-8 -*-
"""用 VizieR ZTF 周期变星表给 35 颗 IB2025 星查 P_rot（修正格式化）"""
import io, os, sys, time
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
import numpy as np, pandas as pd, requests
TAP = 'https://tapvizier.cds.unistra.fr/TAPVizieR/tap/sync'
H = {'User-Agent': 'repro-mstars/1.0'}
rows = []
for line in open('data/raw/ib2025/sources.dat', encoding='utf-8', errors='replace'):
    if len(line.strip()) < 12: continue
    name = line[:11].strip(); tok = line[11:].split()
    if len(tok) < 6: continue
    hh, mm, ss = float(tok[0]), float(tok[1]), float(tok[2]); dd, dm, ds = float(tok[3]), float(tok[4]), float(tok[5])
    rows.append(dict(star=name, ra=15*(hh+mm/60+ss/3600), dec=np.sign(dd)*(abs(dd)+dm/60+ds/3600)))
S = pd.DataFrame(rows)
out = []
for i, r in S.iterrows():
    q = ('SELECT TOP 20 RAJ2000,DEJ2000,Per,Type,gmag,rmag,"log(FAP-g)" AS fapg,"log(FAP-r)" AS fapr '
         'FROM "J/ApJS/249/18/table2" WHERE 1=CONTAINS(POINT(\'ICRS\',RAJ2000,DEJ2000),'
         'CIRCLE(\'ICRS\',{ra:.5f},{dec:.5f},0.0167))').format(ra=r.ra, dec=r.dec)
    got = None
    for _ in range(3):
        try:
            resp = requests.post(TAP, data={'REQUEST': 'doQuery', 'LANG': 'ADQL', 'FORMAT': 'csv', 'QUERY': q}, timeout=90, headers=H)
            if resp.status_code == 200:
                if len(resp.text.strip().splitlines()) > 1:
                    from io import StringIO
                    got = pd.read_csv(StringIO(resp.text))
                break
        except Exception:
            time.sleep(2)
    if got is None or not len(got):
        out.append(dict(star=r.star, ra=r.ra, dec=r.dec, P_ztf=np.nan, ztf_type='', gmag=np.nan, fapg=np.nan, sep_as=np.nan, n_cand=0)); continue
    got['sep_as'] = np.hypot((got.RAJ2000 - r.ra)*np.cos(np.radians(r.dec)), got.DEJ2000 - r.dec)*3600
    b = got.sort_values('sep_as').iloc[0]
    out.append(dict(star=r.star, ra=r.ra, dec=r.dec, P_ztf=b.Per, ztf_type=b.Type, gmag=b.gmag, fapg=b.fapg, sep_as=b.sep_as, n_cand=len(got)))
    print('   %-10s -> P=%.4f d  type=%-4s sep=%.1f" fapg=%.2f (候选 %d)' % (r.star, b.Per, str(b.Type), b.sep_as, b.fapg, len(got)))
Z = pd.DataFrame(out)
Z.to_csv('data/processed/dr13/ib2025_ztf_periods.csv', index=False)
print('\nZTF 命中 %d / %d 颗' % (int(Z.P_ztf.notna().sum()), len(Z)))
if Z.P_ztf.notna().any():
    print(Z[Z.P_ztf.notna()][['star','P_ztf','ztf_type','gmag','fapg','sep_as']].to_string(index=False))
