# -*- coding: utf-8 -*-
"""SDSS DR7 (West+2011) M 矮星分区域活跃统计：解释论文 Fig2 右板为何'赤道带全红、大块天区偏蓝'。"""
import io, sys
import numpy as np
import pandas as pd
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

df = pd.read_csv("data/vizier/aj141_97_sdss_dwarfs.csv")
ra = df["RAJ2000"].to_numpy(float); de = df["DEJ2000"].to_numpy(float)
w = df["W(Ha)"].to_numpy(float); ew = df["e_W(Ha)"].to_numpy(float)
sn = df["HaS/N"].to_numpy(float); hc = df["Ha/c"].to_numpy(float)
mha = df["MHa"].to_numpy() if "MHa" in df.columns else None

def region(name, mask):
    n = int(mask.sum())
    if n == 0:
        print(f"{name}: 0"); return
    d = dict(n=n)
    for lbl, m in [
        ("W>=0.75", w >= 0.75),
        ("W>=0.75 & 3sig", (w >= 0.75) & (w > 3 * np.abs(ew))),
        ("& Ha/c>3", (w >= 0.75) & (w > 3 * np.abs(ew)) & (hc > 3)),
        ("& HaS/N>3", (w >= 0.75) & (w > 3 * np.abs(ew)) & (sn > 3)),
        ("W>0.75 only", (w > 0.75)),
    ]:
        cnt = int((mask & m).sum())
        print(f"{name:26s} {lbl:14s} {cnt:7d}  ({100*cnt/n:5.1f}%)")
    print(f"{name:26s} 总星数        {n:7d}")

allm = np.ones(len(df), bool)
stripe = ((np.abs(((ra + 180) % 360) - 180) <= 60) & (np.abs(de) <= 2.0))
north  = ((ra >= 110) & (ra <= 260) & (de > 2.0))
other  = ~(stripe | north)
for nm, m in [("全体", allm), ("赤道带Stripe82 |RA|<=60,|Dec|<=2", stripe), ("北天大块 RA110-260,Dec>2", north), ("其余", other)]:
    region(nm, m)
print()
print("MHa 列存在:", mha is not None)
if mha is not None:
    print("MHa=1 总数:", int((mha == 1).sum()))
    for nm, m in [("赤道带", stripe), ("北天", north)]:
        print(f"  {nm}: MHa=1 {int((m & (mha==1)).sum())} / {int(m.sum())} = {100*(m&(mha==1)).sum()/max(m.sum(),1):.1f}%")
print()
print("W(Ha) 分布（全体/赤道带/北天）:")
for nm, m in [("全体", allm), ("赤道带", stripe), ("北天", north)]:
    v = w[m]
    print(f"  {nm}: median={np.median(v):.2f}  >0.75: {100*(v>0.75).mean():.1f}%  "
          f"<-1: {100*(v<-1).mean():.1f}%  |W|<=0.75: {100*(np.abs(v)<=0.75).mean():.1f}%")
print()
print("e_W(Ha) 中位数（赤道带 vs 北天）:", np.median(ew[stripe]), np.median(ew[north]))
print("HaS/N 中位数:", np.median(sn[stripe]), np.median(sn[north]))
print("Ha/c 中位数:", np.median(hc[stripe]), np.median(hc[north]))
print("SpT 分布（赤道带 vs 北天, 中位数）:", np.median(df['SpT'].to_numpy(float)[stripe]), np.median(df['SpT'].to_numpy(float)[north]))
