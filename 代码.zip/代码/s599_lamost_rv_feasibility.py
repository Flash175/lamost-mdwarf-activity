# -*- coding: utf-8 -*-
"""s599：LAMOST 视向速度能否把 6D 运动学子样本扩到暗端——可行性检查

目录里已有 LAMOST 管线的红移 z 与 z_err（rv = c·z，σ_rv = c·z_err），不必从谱上重测。
本脚本量化：①覆盖与精度；②与 Gaia RV 的一致性；③能新增多少「没有 Gaia RV」的星（按 |Z| 与 G 分档）。
输出：多个图及讨论/lamost_rv_feasibility.csv
"""
import io, sys, os
import numpy as np, pandas as pd
from astropy.coordinates import SkyCoord
import astropy.units as un

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
BASE = r'C:\Users\lingz\OneDrive\Desktop\复现老师工作'
OUT = r'C:\Users\lingz\Desktop\复现老师工作\APJS\多个图及讨论'
C_KMS = 299792.458

cat = pd.read_csv(os.path.join(BASE,'data','lamost','dr13','dr13_mstellar_dM.csv'), low_memory=False,
                  usecols=['obsid','uid','subclass','ewha','ewha_err','snrr','z','z_err','snrz',
                           'ra','dec','gaia_source_id','gaia_g_mean_mag'])
cat = cat[(cat.ewha > -20) & (cat.ewha <= 50) & (cat.ewha_err > 0) & (cat.ewha_err <= 5)].copy()
cat['active'] = (cat.ewha >= 0.75) & (cat.ewha > 3*cat.ewha_err)
cat['gaia_source_id'] = pd.to_numeric(cat.gaia_source_id, errors='coerce')
g = pd.read_csv(os.path.join(BASE,'data','gaia','gaia_dr3_mstars.csv'), low_memory=False,
                usecols=['source_id','parallax','parallax_error','ruwe','radial_velocity'])
m = cat.merge(g, left_on='gaia_source_id', right_on='source_id', how='inner')
m = m[(m.parallax > 0.2) & (m.parallax/m.parallax_error > 5) & (m.ruwe < 1.4)].copy()
u = m.sort_values('ewha', ascending=False).drop_duplicates('uid').copy()
u['MG'] = u.gaia_g_mean_mag.values - 5*np.log10(np.clip(1000.0/u.parallax.values, 1, None)) + 5
u = u[u.MG >= 6].copy()
d_pc = 1000.0/u.parallax.values
sc = SkyCoord(ra=u.ra.values*un.deg, dec=u.dec.values*un.deg, distance=d_pc*un.pc, frame='icrs')
u['absz'] = np.abs(d_pc*np.sin(np.deg2rad(sc.galactic.b.deg)))
u = u[u.absz <= 3000].copy()

u['rv_lam'] = C_KMS*u.z
u['sig_rv_lam'] = C_KMS*u.z_err.abs()
u['has_lam'] = np.isfinite(u.rv_lam) & (u.z_err > 0) & (u.z != 0)
u['has_gaia'] = np.isfinite(u.radial_velocity)
print('2D 样本 %d 颗' % len(u))
print('  有 LAMOST z（非 0 且有误差）: %d（%.1f%%）' % (u.has_lam.sum(), 100*u.has_lam.mean()))
print('  有 Gaia RV                    : %d（%.1f%%）' % (u.has_gaia.sum(), 100*u.has_gaia.mean()))
q = u[u.has_lam]
print('\nLAMOST RV 精度 σ_rv = c·z_err（km/s）：中位 %.1f，16%% %.1f，84%% %.1f；σ_rv<10 占 %.1f%%、<20 占 %.1f%%'
      % (q.sig_rv_lam.median(), q.sig_rv_lam.quantile(0.16), q.sig_rv_lam.quantile(0.84),
         100*(q.sig_rv_lam < 10).mean(), 100*(q.sig_rv_lam < 20).mean()))
print('  |RV_LAMOST| 中位 %.1f km/s；|RV|>500 的占 %.2f%%' % (q.rv_lam.abs().median(), 100*(q.rv_lam.abs() > 500).mean()))

both = u[u.has_lam & u.has_gaia].copy()
both['d'] = both.rv_lam - both.radial_velocity
core = both[both.d.abs() < 200]
print('\n与 Gaia RV 的重叠：%d 颗；偏差中位 %.1f km/s；稳健散布 %.1f km/s；|差|>50 km/s 占 %.1f%%（含双星/错配）'
      % (len(both), both.d.median(), 1.4826*np.median(np.abs(core.d - np.median(core.d))),
         100*(both.d.abs() > 50).mean()))

BINS = [(0,100,'<100'),(100,200,'100-200'),(200,400,'200-400'),(400,600,'400-600'),
        (600,1000,'600-1000'),(1000,3000,'>1000')]
rows = []
print('\n按 |Z| 档：能新增多少运动学星（无 Gaia RV、但有 LAMOST z 且 σ_rv<20）')
for lo, hi, nm in BINS:
    s = u[(u.absz > lo) & (u.absz <= hi)]
    if len(s) == 0: continue
    gain = s[(~s.has_gaia) & s.has_lam & (s.sig_rv_lam < 20)]
    print('  %-9s 总 %6d｜有 Gaia %6d｜有 LAMOST %6d｜**新增可用 %5d**（占该档 %.1f%%）'
          % (nm, len(s), int(s.has_gaia.sum()), int(s.has_lam.sum()), len(gain), 100*len(gain)/len(s)))
    rows.append(dict(zbin=nm, n=len(s), n_gaia=int(s.has_gaia.sum()), n_lam=int(s.has_lam.sum()),
                     n_gain_usable=len(gain), frac_gain=100*len(gain)/len(s),
                     sig_rv_med=float(s[s.has_lam].sig_rv_lam.median()) if s.has_lam.any() else np.nan,
                     g_med=float(np.nanmedian(s.gaia_g_mean_mag))))
T = pd.DataFrame(rows)
fp = os.path.join(OUT, 'lamost_rv_feasibility.csv')
T.to_csv(fp, index=False, encoding='utf-8')
txt = open(fp, encoding='utf-8').read()
hdr = ('# s599：LAMOST 管线 RV（rv = c·z，σ_rv = c·z_err）的覆盖、精度与对 6D 子样本的增量\n'
       '# n_gain_usable = 没有 Gaia RV、但有 LAMOST z 且 σ_rv < 20 km/s 的星数（可用于运动学）\n'
       '# 生成脚本：代码/s599_lamost_rv_feasibility.py\n')
open(fp, 'w', encoding='utf-8-sig').write(hdr + txt)
print('\n写出 lamost_rv_feasibility.csv（%d 行）' % len(T))
