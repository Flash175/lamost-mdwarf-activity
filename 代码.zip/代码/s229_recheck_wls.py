# -*- coding: utf-8 -*-
"""s229: 只跑 s227 的 A 段（逐级表 WLS/OLS/ML），用于 R1/R5 复核。"""
import numpy as np, pandas as pd
exec(open("s227_recompute_all_tau030.py", encoding="utf-8").read().split('print("=" * 78)')[0])

print("=" * 78)
print("A. 逐级筛选表（τ = 2.33 − 1.50M − 0.30M², Li 2024 印刷式）")
print("%-30s %6s %10s %10s %10s %8s %7s" % ("级", "N", "β(OLS)", "β(WLS)", "β(ML)", "Ro_sat", "σ_int"))
for k, d in load_levels().items():
    d = d.copy()
    d["Ro"] = ro(d.M.values, d.P.values)
    x, y = np.log10(d.Ro.values), np.log10(d.RHa.values)
    sy = d.sRHa.values
    rs_o, b_o = free_bp_ols(x, y)
    rs_w, b_w = free_bp_wls(x, y, sy / d.RHa.values)
    rs_m, b_m, si = ml_fit(x, y, sy)
    print("%-30s %6d %10.4f %10.4f %10.4f %8.4f %7.3f" % (k, len(d), b_o, b_w, b_m, rs_o, si))
