# -*- coding: utf-8 -*-
"""s576: use the catalog's own sigma(EW)-S/N relation to redo the s575 bias table."""
import io, sys, os
import numpy as np, pandas as pd
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
OUT = r'C:\Users\lingz\Desktop\复现老师工作\APJS\多个图及讨论'
print('reading catalog ...')
cat = pd.read_csv('data/lamost/dr13/dr13_mstellar_dM.csv', low_memory=False,
                  usecols=['ewha','ewha_err','snrr','subclass'])
cat = cat[(cat.ewha > -20) & (cat.ewha <= 50) & (cat.ewha_err > 0) & (cat.ewha_err <= 5) & (cat.snrr > 0)]
K = float(np.median(cat.ewha_err.values*cat.snrr.values))
print('N=%d  K_cat=median(ewha_err*snrr)=%.3f A' % (len(cat), K))
print('median EW=%.2f  ewha_err=%.3f  snrr=%.1f' % (cat.ewha.median(), cat.ewha_err.median(), cat.snrr.median()))
act = cat[(cat.ewha >= 0.75) & (cat.ewha > 3*cat.ewha_err)]
ina = cat[(cat.ewha < 0.75)]
print('active %d (%.1f%%)  inactive %d' % (len(act), 100*len(act)/len(cat), len(ina)))

RNG = np.random.default_rng(20261029)
NSIM = 300
def pass_prob(pool, snr, npick=4000):
    e0 = RNG.choice(pool, size=min(npick, len(pool)), replace=False)
    sig = K/snr
    e = e0[:, None] + RNG.normal(0.0, sig, size=(len(e0), NSIM))
    ok = (e >= 0.75) & (e > 3*sig)
    return ok.mean()

def save(df, name, comments):
    fp = os.path.join(OUT, name); df.to_csv(fp, index=False, encoding='utf-8')
    txt = open(fp, encoding='utf-8').read()
    with open(fp, 'w', encoding='utf-8-sig') as f:
        f.write('\n'.join('# ' + c for c in comments) + '\n' + txt)
    print('  wrote %s (%d rows)' % (name, len(df)))

bins = [('<100', 19.67, 23.81), ('100-200', 17.54, 12.90), ('200-400', 15.49, 7.78),
        ('400-600', 13.90, 6.65), ('600-1000', 12.27, 7.76)]
rows = []
lines = ['# Pure S/N effect on the measured activity fraction per |Z| bin (catalog pipeline, s576)', '',
         'sigma(EW) = %.3f / (S/N), K_cat from median(ewha_err * snrr) over %d rows' % (K, len(cat)), '',
         '| bin | snr_med | frac_obs | pass_active | pass_inactive | f_true solved | pure S/N shift vs <100 |',
         '|---|---|---|---|---|---|---|']
ref = None
for lb, s, fobs in bins:
    pa = pass_prob(act.ewha.values, s); pi = pass_prob(ina.ewha.values, s)
    ft = (fobs/100 - pi)/(pa - pi)
    if ref is None:
        ref = (pa, pi); rel = 'baseline'
    else:
        rel = '%+.2f pp' % (100*((ft*pa + (1-ft)*pi) - (ft*ref[0] + (1-ft)*ref[1])))
    rows.append(dict(zbin=lb, snr_med=s, frac_obs=fobs, pass_act=100*pa, pass_inact=100*pi, f_true_solved=100*ft))
    lines.append('| %s | %.1f | %.2f%% | %.1f%% | %.2f%% | %.2f%% | %s |' % (lb, s, fobs, 100*pa, 100*pi, 100*ft, rel))
save(pd.DataFrame(rows), 'snr_bias_catalog_pipeline.csv', [
    'Low-S/N bias estimated with the catalog own sigma(EW)-S/N relation (K_cat = median(ewha_err*snrr))',
    'pass_act/pass_inact: fraction passing EW>=0.75 and EW>3sigma after adding sigma=K/S noise to the catalog EW',
    'K_cat = %.3f A; sample: %d rows of dr13_mstellar_dM.csv passing the EW gate' % (K, len(cat)),
    'script: s576_snr_bias_catalog_pipeline.py'])
open(os.path.join(OUT,'snr_bias_catalog_summary.md'),'w',encoding='utf-8').write('\n'.join(lines)+'\n')
print('\n'.join(lines))
print('s576 done')
