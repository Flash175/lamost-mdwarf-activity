import io, sys, json, ssl, urllib.request, urllib.parse
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")
q = 'SELECT COUNT(*) AS n FROM "J/AJ/141/97/table1"'
url = ("https://tapvizier.cds.unistra.fr/TAPVizieR/tap/sync?request=doQuery&lang=ADQL&format=json&query="
       + urllib.parse.quote(q))
for kw in [dict(), dict(context=ssl._create_unverified_context())]:
    try:
        with urllib.request.urlopen(url, timeout=60, **kw) as r:
            j = json.load(r)
        print("VizieR TAP 官方行数:", j["data"][0][0]); break
    except Exception as e:
        print("失败:", type(e).__name__, str(e)[:120])
