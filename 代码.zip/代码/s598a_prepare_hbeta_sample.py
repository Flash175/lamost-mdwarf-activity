# -*- coding: utf-8 -*-
"""s598-A：为「Hβ 独立判据」准备样本清单

从 2D 样本中取 S/N >= 20 且有本地谱的星，按 |Z| 档分层抽样，写出待测清单（含谱文件路径）。
后续 s598-B 逐条测 Hα / Hβ 的 EW 与 σ。
"""
import io, sys, os
import numpy as np, pandas as pd
from astropy.coordinates import SkyCoord
import astropy.units as un

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
BASE = r'C:\Users\lingz\OneDrive\Desktop\复现老师工作'
OUT = r'C:\Users\lingz\Desktop\复现老师工作\APJS\多个图及讨论'

cat = pd.read_csv(os.path.join(BASE,'data','lamost','dr13','dr13_mstellar_dM.csv'), low_memory=False,
                  usecols=['obsid','uid','subclass','teff','ewha','ewha_err','snrr','ra','dec',
                           'gaia_source_id','gaia_g_mean_mag'])
cat = cat[(cat.ewha > -20) & (cat.ewha <= 50) & (cat.ewha_err > 0) & (cat.ewha_err <= 5)].copy()
cat['active'] = (cat.ewha >= 0.75) & (cat.ewha > 3*cat.ewha_err)
cat['gaia_source_id'] = pd.to_numeric(cat.gaia_source_id, errors='coerce')
g = pd.read_csv(os.path.join(BASE,'data','gaia','gaia_dr3_mstars.csv'), low_memory=False,
                usecols=['source_id','parallax','parallax_error','ruwe'])
m = cat.merge(g, left_on='gaia_source_id', right_on='source_id', how='inner')
m = m[(m.parallax > 0.2) & (m.parallax/m.parallax_error > 5) & (m.ruwe < 1.4)].copy()
u = m.sort_values('ewha', ascending=False).drop_duplicates('uid').copy()
u['MG'] = u.gaia_g_mean_mag.values - 5*np.log10(np.clip(1000.0/u.parallax.values, 1, None)) + 5
u = u[u.MG >= 6].copy()
d_pc = 1000.0/u.parallax.values
sc = SkyCoord(ra=u.ra.values*un.deg, dec=u.dec.values*un.deg, distance=d_pc*un.pc, frame='icrs')
u['absz'] = np.abs(d_pc*np.sin(np.deg2rad(sc.galactic.b.deg)))
u = u[(u.absz <= 3000) & (u.snrr >= 20)].copy()
paths = {}
for sub in ['lrs/dr13','lrs/dr13_rest']:
    dd = os.path.join(BASE,'data',sub)
    with os.scandir(dd) as it:
        for e in it:
            if e.name.endswith('.csv.gz') and e.stat().st_size > 500: paths[e.name[:-7]] = e.path
u['obsid_s'] = u.obsid.astype(str)
u = u[u.obsid_s.isin(paths)].copy()
u['path'] = u.obsid_s.map(paths)
print('S/N>=20 且有谱：%d 条谱 / %d 颗星' % (len(u), u.uid.nunique()))
BINS = [(0,100,'<100'),(100,200,'100-200'),(200,400,'200-400'),(400,600,'400-600'),
        (600,1000,'600-1000'),(1000,3000,'>1000')]
parts = []
for lo, hi, nm in BINS:
    q = u[(u.absz > lo) & (u.absz <= hi)]
    if len(q) == 0: continue
    n = min(800, len(q))
    parts.append(q.sample(n, random_state=7))
    print('  %-9s 池 %6d → 抽 %4d（活动率 %.1f%%）' % (nm, len(q), n, 100*q.active.mean()))
W = pd.concat(parts)
W = W[['obsid_s','path','subclass','snrr','ewha','ewha_err','active','absz']].rename(columns={'obsid_s':'obsid'})
fp = os.path.join(OUT, 'hbeta_work.csv')
W.to_csv(fp, index=False, encoding='utf-8')
print('写出 hbeta_work.csv：%d 行' % len(W))
