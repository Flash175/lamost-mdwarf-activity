# -*- coding: utf-8 -*-
"""s586：把「ln f = a + b·z」的两处硬伤修掉——logit 连接 + β-二项吸收过度弥散

s585 暴露的问题：
 1) log 连接在 f→1 处不自洽：带亚型固定效应时逐星预测出现过 273.58%；
 2) 过度弥散靠 √(χ²/dof) 临时放大，等于承认似然写错。

本脚本：
 A. 用 logit 连接重拟合同一批协变量组合（L1–L4），亚型效应改报 odds ratio；
 B. 用 β-二项（细胞级，亚型×5 pc 格）重拟合，直接估集中度 φ，给出
    「相对二项的标准误放大倍数」，与 s584 的 √(dev/dof) 对照。

输入：data/lamost/dr13/dr13_mstellar_dM.csv + data/gaia/gaia_dr3_mstars.csv（同 s551/s584 口径）
输出：多个图及讨论/lnf_fit_logit.csv、lnf_fit_betabinom.csv
"""
import io, sys, os
import numpy as np, pandas as pd
from scipy.optimize import minimize
from scipy.special import expit, gammaln
from astropy.coordinates import SkyCoord
import astropy.units as un

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
OUT = r'C:\Users\lingz\Desktop\复现老师工作\APJS\多个图及讨论'
CAT = 'data/lamost/dr13/dr13_mstellar_dM.csv'
GAI = 'data/gaia/gaia_dr3_mstars.csv'

def save(df, name, comments):
    fp = os.path.join(OUT, name)
    df.to_csv(fp, index=False, encoding='utf-8')
    txt = open(fp, encoding='utf-8').read()
    with open(fp, 'w', encoding='utf-8-sig') as f:
        f.write('\n'.join('# ' + c for c in comments) + '\n' + txt)
    print('  写出 %s（%d 行）' % (name, len(df)))

cat = pd.read_csv(CAT, low_memory=False,
                  usecols=['uid','subclass','teff','ewha','ewha_err','snrr',
                           'ra','dec','gaia_source_id','gaia_g_mean_mag'])
cat = cat[(cat.ewha > -20) & (cat.ewha <= 50) & (cat.ewha_err > 0) & (cat.ewha_err <= 5)].copy()
cat['active'] = (cat.ewha >= 0.75) & (cat.ewha > 3*cat.ewha_err)
cat['gaia_source_id'] = pd.to_numeric(cat.gaia_source_id, errors='coerce')
g = pd.read_csv(GAI, low_memory=False,
                usecols=['source_id','parallax','parallax_error','ruwe','radial_velocity'])
m = cat.merge(g, left_on='gaia_source_id', right_on='source_id', how='inner')
m = m[(m.parallax > 0.2) & (m.parallax/m.parallax_error > 5) & (m.ruwe < 1.4)].copy()
u = m.sort_values('ewha', ascending=False).drop_duplicates('uid').copy()
u['MG'] = u.gaia_g_mean_mag.values - 5*np.log10(np.clip(1000.0/u.parallax.values, 1, None)) + 5
u = u[u.MG >= 6].copy()
d_pc = 1000.0/u.parallax.values
sc = SkyCoord(ra=u.ra.values*un.deg, dec=u.dec.values*un.deg, distance=d_pc*un.pc, frame='icrs')
u['absz'] = np.abs(d_pc*np.sin(np.deg2rad(sc.galactic.b.deg)))
u = u[u.absz <= 3000].copy()
u['subc'] = u.subclass.astype(str)
keep = [s for s in u.subc.value_counts().index if (u.subc == s).sum() >= 500]
u = u[u.subc.isin(keep)].copy()
print('样本 %d 颗（保留亚型 %s），活动率 %.3f%%' % (len(u), '/'.join(keep), 100*u.active.mean()))

z = u.absz.values/1000.0
y = u.active.values.astype(float)
lnT = np.log(np.clip(pd.to_numeric(u.teff, errors='coerce').values, 2500, 4500)/3000.0)
lnS = np.log(np.clip(pd.to_numeric(u.snrr, errors='coerce').values, 1.0, None))
subs = sorted(keep)
sdum = np.column_stack([(u.subc.values == s).astype(float) for s in subs[1:]])

def design(form):
    cols = [np.ones_like(z), z]
    names = ['a', 'b_kpc']
    if form != 'lin':
        for k0 in (0.05, 0.1, 0.2, 0.4, 0.6, 1.0):
            cols.append(np.clip(z-k0, 0, None)); names.append('h%.2f' % k0)
    if 'teff' in form:
        cols.append(lnT); names.append('lnTeff')
    if 'snr' in form:
        cols.append(lnS); names.append('lnSNR')
    if 'fe' in form:
        for j, s in enumerate(subs[1:]):
            cols.append(sdum[:, j]); names.append('fe_'+s)
    return np.column_stack(cols), names

def nll_logit(beta, X):
    eta = np.clip(X @ beta, -30, 30)
    p = expit(eta)
    return -float((y*np.log(np.clip(p,1e-12,1)) + (1-y)*np.log(np.clip(1-p,1e-12,1))).sum())

def grad_logit(beta, X):
    eta = np.clip(X @ beta, -30, 30)
    return -(X.T @ (y - expit(eta)))

def hess_se(fun, beta, X, h=1e-4):
    P = len(beta); H = np.zeros((P,P)); g0 = fun(beta, X)
    for i in range(P):
        d = np.zeros(P); d[i] = h
        H[:, i] = (fun(beta+d, X)-g0)/h
    H = 0.5*(H+H.T)
    C = np.linalg.pinv(H)
    return np.sqrt(np.clip(np.diag(C), 0, None)), C

bins = [(0,100,'<100'),(100,200,'100-200'),(200,400,'200-400'),(400,600,'400-600'),
        (600,1000,'600-1000'),(1000,3000,'>1000')]
rows = []
rows2 = []
print('\n=== A. logit 连接（逐星，638k）===')
for form, tag in [('lin','L1 线性 logit'), ('spline','L2 样条 logit'),
                  ('spline_teff','L3 +lnTeff'), ('spline_fe_snr','L4 +亚型FE+lnSNR'),
                  ('spline_teff_fe_snr','L5 全上')]:
    X, names = design(form)
    b0 = np.zeros(X.shape[1]); b0[0] = np.log(max(y.mean(),1e-6)/(1-max(y.mean(),1e-6)))
    r = minimize(lambda b: nll_logit(b, X), b0, method='BFGS', jac=lambda b: grad_logit(b, X),
                 options=dict(maxiter=3000, gtol=1e-9))
    beta = r.x
    se, C = hess_se(grad_logit, beta, X)
    aic = 2*len(beta) + 2*r.fun
    p = expit(np.clip(X @ beta, -30, 30))
    rms = 0.0; lines = []
    for lo_, hi_, nm in bins:
        s = (u.absz.values > lo_) & (u.absz.values <= hi_)
        pr = 100*p[s].mean(); me = 100*y[s].mean()
        rms += (pr-me)**2; lines.append('%s %.2f/%.2f' % (nm, pr, me))
    rms = np.sqrt(rms/len(bins))
    print('\n%-20s 参数 %2d  nll = %.1f  AIC = %.1f  六档校准 RMS = %.2f pp'
          % (tag, len(beta), r.fun, aic, rms))
    print('    预测/实测: ' + ' | '.join(lines))
    if 'b_kpc' in names:
        i = names.index('b_kpc')
        print('    b_kpc = %+.4f ± %.4f（odds ratio per 100 pc = %.3f）' % (beta[i], se[i], np.exp(-0.1*beta[i])))
    for nm, v_, s_ in zip(names, beta, se):
        if nm.startswith('fe_'):
            print('    %-9s OR = %6.3f  [%.3f, %.3f]' % (nm, np.exp(v_), np.exp(v_-1.96*s_), np.exp(v_+1.96*s_)))
    rows.append(dict(model=tag, n_par=len(beta), nll=r.fun, aic=aic, calib_rms_pp=rms))
save(pd.DataFrame(rows), 'lnf_fit_logit.csv', [
    's586-A：logit 连接（逐星二项），亚型 fe 报 odds ratio；calib_rms_pp 为六档边际校准 RMS',
    '与 s585 的 log 连接相比，logit 在 f→1 处自洽（预测不会超过 100%）',
    '生成脚本：代码/s586_logit_betabinom.py'])

# B. β-二项（细胞级，亚型×5 pc）
print('\n=== B. β-二项（细胞级，吸收过度弥散）===')
u['zcell'] = (u.absz // 5).astype(int)
cell = u.groupby(['subc','zcell'], observed=True).agg(n=('active','size'), k=('active','sum'),
                                                     zmean=('absz','mean')).reset_index()
cn = cell.n.values.astype(float); ck = cell.k.values.astype(float); cz = cell.zmean.values/1000.0
print('  细胞数 %d（总星数 %d）' % (len(cell), int(cn.sum())))

def bd_design(with_fe):
    cols = [np.ones_like(cz), cz]
    for k0 in (0.05, 0.1, 0.2, 0.4, 0.6, 1.0):
        cols.append(np.clip(cz-k0, 0, None))
    if with_fe:
        for s in subs[1:]:
            cols.append((cell.subc.values == s).astype(float))
    return np.column_stack(cols)

def bb_nll(theta, X):
    beta = theta[:-1]; phi = np.exp(theta[-1])
    mu = np.clip(expit(X @ beta), 1e-8, 1-1e-8)
    a = mu*phi; b = (1-mu)*phi
    ll = (gammaln(cn+1) - gammaln(ck+1) - gammaln(cn-ck+1)
          + gammaln(ck+a) + gammaln(cn-ck+b) - gammaln(cn+phi)
          + gammaln(phi) - gammaln(a) - gammaln(b))
    return -float(ll.sum()), mu

for with_fe, tag in [(False,'B1 β-二项 仅样条'), (True,'B2 β-二项 样条+亚型FE')]:
    X = bd_design(with_fe)
    th0 = np.concatenate([np.zeros(X.shape[1]), [np.log(2.0)]])
    th0[0] = np.log(max(ck.sum()/cn.sum(),1e-6)/(1-max(ck.sum()/cn.sum(),1e-6)))
    r = minimize(lambda t: bb_nll(t, X)[0], th0, method='BFGS',
                 options=dict(maxiter=6000, gtol=1e-9))
    beta = r.x[:-1]; phi = np.exp(r.x[-1]); nll = r.fun
    # 二项基准：同设计、φ→∞
    def bin_nll(b):
        mu = np.clip(expit(X @ b), 1e-8, 1-1e-8)
        return -float((ck*np.log(mu) + (cn-ck)*np.log(1-mu)).sum())
    rb = minimize(bin_nll, np.zeros(X.shape[1]), method='BFGS', options=dict(maxiter=4000, gtol=1e-9))
    k = X.shape[1]
    aic_bb = 2*(k+1) + 2*nll; aic_bn = 2*k + 2*rb.fun
    _, mu = bb_nll(r.x, X)
    print('  %-24s φ = %.1f（细胞内相关 ρ = %.3f）  AIC(βB) = %.1f（只在 β-二项族内可比）' % (tag, phi, 1/(phi+1), aic_bb))
    dof = len(cell) - k
    pp_ = ck/cn
    with np.errstate(divide='ignore', invalid='ignore'):
        t1 = np.where(ck > 0, ck*np.log(np.where(ck > 0, pp_, 1.0)), 0.0)
        qq_ = 1-pp_
        t2 = np.where(cn-ck > 0, (cn-ck)*np.log(np.where(cn-ck > 0, qq_, 1.0)), 0.0)
    sat_ = float((t1+t2).sum())
    dev = 2*(sat_ + rb.fun)
    print('     二项拟合偏差/dof = %.2f → 标准误应按 √(dev/dof) = %.2f 放大；β-二项直接给出 ρ = %.3f（等效放大 %.2f）'
          % (dev/dof, np.sqrt(dev/dof), 1/(phi+1), np.sqrt(1+(cn.mean()-1)*1/(phi+1))))
    rows2.append(dict(model=tag, n_par=k+1, phi=phi, rho=1/(phi+1), aic_betabin=aic_bb,
                      dev_over_dof=dev/dof,
                      implied_se_inflation=np.sqrt(1+(cn.mean()-1)/(phi+1)),
                      n_cells=len(cell), n_stars=int(cn.sum())))
save(pd.DataFrame(rows2), 'lnf_fit_betabinom.csv', [
    's586-B：β-二项（细胞级 亚型×5pc）；phi 为集中度，rho = 1/(phi+1) 为细胞内相关',
    'implied_se_inflation = sqrt(1+(n_mean-1)*rho)，可与 s584 的 sqrt(dev/dof) 直接对照',
    '注意：aic_betabin 只在 β-二项族内可比（与二项/逐星似然的规范化常数不同，不可跨族比 AIC）',
    '生成脚本：代码/s586_logit_betabinom.py'])
print('\ns586 完成')
