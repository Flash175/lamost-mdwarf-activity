# -*- coding: utf-8 -*-
"""图5 数据独立核验：逐级计数、公式自洽、独立拟合复算、跨目录一致性"""
import io, os, sys, hashlib
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
import numpy as np, pandas as pd
from scipy.optimize import minimize

P = lambda f: os.path.join('data', 'processed', 'dr13', f)
A = pd.read_csv(P('fig5_sample_period_v4.csv'))
R = pd.read_csv(P('fig5_sample_relaxed_v4.csv'))
S = pd.read_csv(P('fig5_sample_strict_v4.csv'))
print('=== 1. 样本计数链（由逐星表重算，对照稳健性表 v4）===')
def dealias(d):
    m = np.ones(len(d), bool)
    for t in (0.5, 1.0, 2.0): m &= ~(np.abs(d.P.values/t - 1) < 0.05)
    return d[m]
ruwe_ok = lambda d: d[(d.ruwe.isna()) | (d.ruwe < 1.4)]
n1 = len(A); n2 = len(dealias(A)); n3 = len(ruwe_ok(dealias(A)))
n4 = len(ruwe_ok(dealias(A))[~ruwe_ok(dealias(A)).border34])
relax2 = dealias(A)[(dealias(A).non_single_star.fillna(0) == 0) & (dealias(A).Ro <= 3) & (~dealias(A).alias_flag.fillna(False))]
n5p = len(relax2)
n6 = len(ruwe_ok(relax2)[~ruwe_ok(relax2).border34])
tab = pd.read_csv(P('fig5_robustness_v4.csv'))
calc = [n1, n2, n3, n4, n5p, n6]; claim = tab.n.tolist()
for (nm, c, k) in zip(tab['样本'], calc, claim):
    print('   %-58s 重算 %5d | 表 %5d %s' % (nm.replace(' ', ''), c, k, 'OK' if c == k else '<<< 不一致'))
print('   ⑤ 样本表内行数 %d / 重算 %d | ⑤′ %d / 重算 %d' % (len(S), n6, len(R), n5p))

print('\n=== 2. 集合关系与唯一性 ===')
print('   ⑤ ⊂ ⑤′ ⊂ 周期全量：%s / %s' % (set(S.uid) <= set(R.uid), set(R.uid) <= set(A.uid)))
print('   uid 唯一：%s / %s / %s' % (S.uid.is_unique, R.uid.is_unique, A.uid.is_unique))
print('   NaN（拟合用列）：%s' % bool(S[['Ro','sRo','RHa','sRHa','P','M','chi']].isna().any().any()))
print('   周期来源：%s' % S.src.value_counts().to_dict())

print('\n=== 3. 物理量公式自洽（逐星重算）===')
tau = 10 ** (2.33 - 1.5*S.M - 0.30*S.M**2)
print('   Ro = P/τ 最大相对偏差 %.2e' % np.max(np.abs(S.Ro/(S.P/tau) - 1)))
print('   RHa = χ·EW 最大相对偏差 %.2e' % np.max(np.abs(S.RHa/(S.chi*S.ewha) - 1)))
print('   sRo = Ro·sqrt(fP²+0.10²) 最大相对偏差 %.2e' % np.max(np.abs(
    S.sRo/(S.Ro*np.sqrt(np.where(S.src == 'VSX', 0.075, 0.03)**2 + 0.10**2)) - 1)))
print('   RHa = χ·EW 最大相对偏差 %.2e' % np.max(np.abs(S.RHa/(S.chi*S.ewha) - 1)))

print('\n=== 4. 取值范围 ===')
for c, lo, hi in (('teff', 2800, 4600), ('P', 0.02, 400), ('Ro', 0, 3), ('RHa', 0, 1e-1), ('ewha', -20, 50)):
    v = S[c]
    print('   %-5s min %10.4g  median %10.4g  max %10.4g  | 越界 %d' % (c, v.min(), v.median(), v.max(), int(((v < lo) | (v > hi)).sum())))
print('   子型分布：', S.spt.value_counts().to_dict())
print('   落进两面板的点：M0–M3 %d + M4–M6 %d = %d（未入面板 %d）'
      % (S.spt.isin(['dM0','dM1','dM2','dM3']).sum(), S.spt.isin(['dM4','dM5','dM6']).sum(),
         S.spt.isin(['dM0','dM1','dM2','dM3','dM4','dM5','dM6']).sum(), (~S.spt.isin(['dM0','dM1','dM2','dM3','dM4','dM5','dM6'])).sum()))
print('   未入面板的子型：', S.loc[~S.spt.isin(['dM0','dM1','dM2','dM3','dM4','dM5','dM6']), 'spt'].value_counts().to_dict())

print('\n=== 5. 独立复算 β（不同求解方式）===')
x, y = np.log10(S.Ro.values), np.log10(S.RHa.values)
best = None
for rs in np.arange(-1.10, -0.40, 0.002):
    s, u = x <= rs, x > rs
    if s.sum() < 20 or u.sum() < 20: continue
    rss = ((y[s] - y[s].mean())**2).sum()
    sl, ic = np.polyfit(x[u], y[u], 1); rss += ((y[u] - (sl*x[u] + ic))**2).sum()
    if best is None or rss < best[0]: best = (rss, 10**rs, sl)
print('   网格+OLS（步长 0.002）：Ro_sat=%.4f  β=%.4f' % (best[1], best[2]))
print('   稳健回归（Theil-Sen 类：多分位中位斜率）：', end=' ')
slopes = []
for q in (0.6, 0.7, 0.8, 0.9):
    th = np.quantile(x, q); m = x > th
    slopes.append(np.polyfit(x[m], y[m], 1)[0])
print('β(上端 40%%/30%%/20%%/10%% 分位)=%s' % np.round(slopes, 3).tolist())
def ml2(d):
    xx, yy = np.log10(d.Ro.values), np.log10(d.RHa.values)
    sy = np.maximum(d.sRHa.values/np.maximum(d.RHa.values, 1e-12)/np.log(10), 0.02)
    def nll(p):
        l, b, c, ls = p; si = np.exp(ls)
        mm = np.where(xx <= l, c, c + b*(xx - l)); v = sy**2 + si**2
        return 0.5*np.sum((yy - mm)**2/v + np.log(v))
    out = []
    for seed in (1, 7, 42):
        rng = np.random.default_rng(seed)
        st = [np.log10(best[1]) + rng.normal(0, .05), best[2] + rng.normal(0, .05), np.median(yy), np.log(.3)]
        r = minimize(nll, st, method='Nelder-Mead', bounds=[(-1.3,-0.5),(-1.6,0.1),(-9,0),(-4,0)],
                     options={'maxiter': 20000, 'xatol': 1e-5, 'fatol': 1e-8})
        out.append((10**r.x[0], r.x[1], np.exp(r.x[3])))
    return np.array(out)
M2 = ml2(S)
print('   ML（3 组随机初值）：β=%s  Ro_sat=%s  σ_int=%s' % (np.round(M2[:,1], 4).tolist(),
      np.round(M2[:,0], 4).tolist(), np.round(M2[:,2], 3).tolist()))
print('   表内记录：β OLS=%.4f  β ML=%.4f  一致性 Δβ(OLS)=%.4f Δβ(ML)=%.4f'
      % (tab['β OLS'].iloc[-1], tab['β ML'].iloc[-1],
         abs(best[2] - tab['β OLS'].iloc[-1]), abs(M2[:,1].mean() - tab['β ML'].iloc[-1])))

print('\n=== 6. 文件一致性（md5 前 12 位）===')
h = lambda p: hashlib.md5(open(p, 'rb').read()).hexdigest()[:12]
W = r'C:\Users\lingz\OneDrive\Desktop\复现老师工作'; D = r'C:\Users\lingz\Desktop\复现老师工作'; AP = r'C:\Users\lingz\Desktop\APJS\图五及相关数据'
pairs = [('图5 两面板', os.path.join(W,'figures','dr13_fig5_rha_rossby.png'), os.path.join(D,'图','图05_Rossby_dr13_fig5_rha_rossby.png'), os.path.join(AP,'图','图5_两面板_终版.png')),
         ('稳健性表 v4', P('fig5_robustness_v4.csv'), os.path.join(D,'数据','图5_稳健性表_v4.csv'), os.path.join(AP,'数据','稳健性表_v4_逐级筛选.csv')),
         ('面板拟合 v4', P('fig5_panel_fits_v4.csv'), os.path.join(D,'数据','图5_面板拟合_v4.csv'), os.path.join(AP,'数据','面板拟合_v4.csv'))]
for nm, a, b, c in pairs:
    hh = [h(a), h(b), h(c)]
    print('   %-12s 工作区 %s | 交付包 %s | APJS %s  %s' % (nm, hh[0], hh[1], hh[2], 'OK' if len(set(hh)) == 1 else '<<< 不一致'))
