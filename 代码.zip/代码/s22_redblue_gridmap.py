# -*- coding: utf-8 -*-
"""把论文 Fig2 右板(SDSS) 与我的候选渲染都切成 30x14 网格，打印每格红色像素占比，
定位红色到底集中在哪（赤道带 or 北天大块）。"""
import io, sys
import numpy as np
from PIL import Image
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

def gridmap(path, label, nx=30, ny=14):
    a = np.asarray(Image.open(path).convert("RGB")).astype(int)
    H, W, _ = a.shape
    colored = (a.max(2) - a.min(2) > 40) & (a.min(2) < 240)
    r, b = a[:, :, 0], a[:, :, 2]
    red = colored & (r > b + 20)
    print(f"=== {label}  {W}x{H}  彩色 {int(colored.sum()):,}  红占比 {100*red.sum()/max(colored.sum(),1):.1f}%")
    ys = np.linspace(0, H, ny + 1).astype(int)
    xs = np.linspace(0, W, nx + 1).astype(int)
    hdr = "      " + "".join(f"{i:>5d}" for i in range(nx))
    print(hdr)
    for j in range(ny):
        row = []
        for i in range(nx):
            c = colored[ys[j]:ys[j+1], xs[i]:xs[i+1]]
            rr = red[ys[j]:ys[j+1], xs[i]:xs[i+1]]
            n = int(c.sum())
            row.append("    ." if n < 40 else f"{100*rr.sum()/n:5.0f}")
        print(f"y{j:<2d}{j*100//ny:>3d}%" + "".join(row))
    print()

gridmap("extract/pdf_images/fig2_SDSS_zoom.png", "论文 Fig2 右板 (SDSS)")
gridmap("figures/_tmp/sdss_red_then_blue_s2.6.png", "我的候选：红先蓝后")
gridmap("figures/_tmp/sdss_blue_then_red_s2.6.png", "我的候选：蓝先红后(当前fig2)")
