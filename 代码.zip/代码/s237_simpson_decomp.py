# -*- coding: utf-8 -*-
"""s237_simpson_decomp.py —— 坪区 Simpson 分解复核（draft L15 三个数全错的定案脚本）。

用途：核对「坪区倾斜」的组内/组间分解。台账 §6 登记的是
    全体 OLS +0.0015 = 组内 +0.0396 + 组间 −0.0381（Sxy/Sxx = 0.514/352.01）
本脚本同时给出「三组」与「两组」两种分法，用来解释 draft 旧值
    (+0.0003 = +0.0393 + −0.0364) 为什么既不是三组值、也不是两组值，
而且自身还不闭合（0.0393 − 0.0364 = 0.0029 ≠ 0.0003）。

口径：τ = 2.33 − 1.50M − 0.30M²（Li 2024 印刷式），坪区取 Ro ≤ 0.135。
"""
import numpy as np
import pandas as pd

D = "C:/Users/lingz/Desktop/APJS/图五及相关数据/数据/"
CSV = "图5_逐星样本_严格3340行_⑤.csv"
GROUP3 = [("dM0", "dM1", "dM2", "dM3"), ("dM4", "dM5", "dM6")]


def load(plateau=True):
    d = pd.read_csv(D + CSV)
    d = d[(d.RHa > 0) & (d.P > 0) & (d.M > 0)].copy()
    d["Ro"] = d.P.values / 10 ** (2.33 - 1.50 * d.M.values + (-0.30) * d.M.values ** 2)
    if plateau:
        d = d[d.Ro <= 0.135].copy()
    d["x"] = np.log10(d.Ro.values)
    d["y"] = np.log10(d.RHa.values)
    d["g2"] = np.where(d.spt.isin(GROUP3[0]), "M0M3", "M4M8")
    d["g3"] = np.select([d.spt.isin(GROUP3[0]), d.spt.isin(GROUP3[1])],
                        ["M0M3", "M4M6"], "M7M8")
    return d


def decomp(q, g):
    """返回 (n, 全体 b, 组内, 组间, Sxx, Sxy, 闭合差)。"""
    x, y = q.x.values, q.y.values
    Sxx = ((x - x.mean()) ** 2).sum()
    Sxy = ((x - x.mean()) * (y - y.mean())).sum()
    b = Sxy / Sxx
    within = between = 0.0
    for _, s in q.groupby(g):
        xs, ys = s.x.values, s.y.values
        within += ((xs - xs.mean()) * (ys - ys.mean())).sum()
        between += (xs.mean() - x.mean()) * (ys.mean() - y.mean()) * len(xs)
    return len(q), b, within / Sxx, between / Sxx, Sxx, Sxy, b - (within + between) / Sxx


if __name__ == "__main__":
    for lab, g in (("三组 M0-3/M4-6/dM7-8", "g3"), ("两组 M0-3/M4-8", "g2")):
        n, b, w, bt, sxx, sxy, gap = decomp(load(True), g)
        print("坪区 %-20s n=%d  全体=%+.5f  组内=%+.5f  组间=%+.5f  闭合=%.1e  Sxx=%.2f Sxy=%+.4f"
              % (lab, n, b, w, bt, gap, sxx, sxy))
    print("\n参照：台账 §6 登记值 = +0.0015 / +0.0396 / −0.0381（三组，Sxx 352.01）")
    print("      draft L15 旧值 = +0.0003 / +0.0393 / −0.0364 → 自身不闭合（差 0.0026），已改")
    # 全区间（非坪区）对照，说明为什么不能拿全区间数当坪区数
    n, b, w, bt, sxx, sxy, gap = decomp(load(False), "g3")
    print("\n全区间（Ro 不限）三组 n=%d 全体=%+.5f 组内=%+.5f 组间=%+.5f  —— 与坪区不可混用"
          % (n, b, w, bt))
