# -*- coding: utf-8 -*-
"""C6 权威复算（2026-11-04 闭环用）。

数据源：数据/图5_逐星样本_严格3340行_⑤_tau030.csv（钉死版，sha256[:16]=ab5c8345d144e71c）
该表 Ro 列 = −0.30 口径；+0.31 口径由 M、P 现场重算（同 s240 的做法）。

模型口径（与讨论体 C6 文字一致）：
  「固定断点」= 坪区常数 + 非饱和段独立直线（自由截距，断点处不连续），断点锁 0.132
  「自由断点」= 同上，但断点在 log10 ∈ [−2.4, −0.3] 的 1,101 点 linspace 网格上 argmin RSS
误差不动（C6 只比对点估计的移动量）。
"""
import csv, math, os

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
CSV = os.path.join(ROOT, '数据', '图5_逐星样本_严格3340行_⑤_tau030.csv')

def panel_of(s):
    return 'M0M3' if s in ('dM0', 'dM1', 'dM2', 'dM3') else 'M4M6'

rows = []
with open(CSV, encoding='utf-8-sig') as f:
    for r in csv.DictReader(f):
        M = float(r['M']); P = float(r['P']); y = math.log10(float(r['RHa']))
        Ro30 = P / 10 ** (2.33 - 1.50 * M - 0.30 * M * M)   # 表内口径（校验用）
        Ro31 = P / 10 ** (2.33 - 1.50 * M + 0.31 * M * M)   # Wright 原式
        rows.append(dict(pan=panel_of(r['spt']), y=y,
                         x30=math.log10(Ro30), x31=math.log10(Ro31)))

# 校验：表内 Ro 列确为 −0.30 口径
with open(CSV, encoding='utf-8-sig') as f:
    r0 = next(csv.DictReader(f))
print('校验 Ro 列口径: 表内 %.6f vs 重算 %.6f' % (float(r0['Ro']), 10 ** r0['x30'] if 'x30' in r0 else Ro30))

def fit_free(data, key):
    """自由断点（自由截距两段模型），1,101 点 linspace 网格 argmin RSS。"""
    best = None
    for i in range(1101):
        lbp = -2.4 + i * 2.1 / 1100
        lo = [d['y'] for d in data if d[key] <= lbp]
        hi = [(d[key], d['y']) for d in data if d[key] > lbp]
        if len(lo) < 5 or len(hi) < 5:
            continue
        c = sum(lo) / len(lo)
        rss = sum((y - c) ** 2 for y in lo)
        mx = sum(x for x, _ in hi) / len(hi)
        b = sum((x - mx) * (y - c2) for (x, y), c2 in zip(hi, [sum(yy for _, yy in hi) / len(hi)] * len(hi))) / sum((x - mx) ** 2 for x, _ in hi)
        my = sum(yy for _, yy in hi) / len(hi)
        rss += sum((y - (my + b * (x - mx))) ** 2 for x, y in hi)
        if best is None or rss < best[0]:
            best = (rss, 10 ** lbp, b)
    return best  # (RSS, Ro_sat, β)

def fit_fixed(data, key, bp=0.132):
    lbp = math.log10(bp)
    lo = [d['y'] for d in data if d[key] <= lbp]
    hi = [(d[key], d['y']) for d in data if d[key] > lbp]
    c = sum(lo) / len(lo)
    mx = sum(x for x, _ in hi) / len(hi)
    my = sum(y for _, y in hi) / len(hi)
    b = sum((x - mx) * (y - my) for x, y in hi) / sum((x - mx) ** 2 for x, _ in hi)
    return b, len(lo), len(hi)

print('\n=== τ = −0.30（Li 印刷式，本文主口径）===')
res30 = {}
for name, sub in [('全体', rows)] + [(p, [d for d in rows if d['pan'] == p]) for p in ('M0M3', 'M4M6')]:
    rss, bp, b = fit_free(sub, 'x30')
    bf, nlo, nhi = fit_fixed(sub, 'x30')
    res30[name] = dict(free_b=b, free_bp=bp, fix_b=bf)
    print('%-6s 自由断点: Ro_sat=%.4f β=%.4f | 固定0.132: β=%.4f (坪区n=%d, 非饱和n=%d)' % (name, bp, b, bf, nlo, nhi))

print('\n=== τ = +0.31（Wright 2018 原式）===')
res31 = {}
for name, sub in [('全体', rows)] + [(p, [d for d in rows if d['pan'] == p]) for p in ('M0M3', 'M4M6')]:
    rss, bp, b = fit_free(sub, 'x31')
    bf, nlo, nhi = fit_fixed(sub, 'x31')
    res31[name] = dict(free_b=b, free_bp=bp, fix_b=bf)
    print('%-6s 自由断点: Ro_sat=%.4f β=%.4f | 固定0.132: β=%.4f' % (name, bp, b, bf))

print('\n=== C6 移动量（权威复算）===')
print('全样本  |Δβ| = %.4f  (自由断点: %.4f → %.4f)' % (abs(res31['全体']['free_b'] - res30['全体']['free_b']), res30['全体']['free_b'], res31['全体']['free_b']))
print('M0–M3 固定0.132 |Δβ| = %.4f (%.4f → %.4f)' % (abs(res31['M0M3']['fix_b'] - res30['M0M3']['fix_b']), res30['M0M3']['fix_b'], res31['M0M3']['fix_b']))
print('M4–M6 固定0.132 |Δβ| = %.4f (%.4f → %.4f)' % (abs(res31['M4M6']['fix_b'] - res30['M4M6']['fix_b']), res30['M4M6']['fix_b'], res31['M4M6']['fix_b']))
print('M0–M3 自由断点 |Δβ| = %.4f (%.4f → %.4f)' % (abs(res31['M0M3']['free_b'] - res30['M0M3']['free_b']), res30['M0M3']['free_b'], res31['M0M3']['free_b']))
print('M4–M6 自由断点 |Δβ| = %.4f (%.4f → %.4f)' % (abs(res31['M4M6']['free_b'] - res30['M4M6']['free_b']), res30['M4M6']['free_b'], res31['M4M6']['free_b']))
print('\n对照: 讨论体 = 0.06 / 0.13 / 0.14 / 0.30 / 0.02 ; 中文.md = 0.058 / 0.13 / 0.14 / 0.30 / 0.02')
print('对照端点: 讨论体 −0.853→−0.913, −0.890→−1.021, −0.822→−0.679, −0.642→−0.931 ; 中文.md −0.857→−0.913, −0.631→−0.931 ; json M0M3 free −0.6432@0.0463')
