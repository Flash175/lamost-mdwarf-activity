
# -*- coding: utf-8 -*-
"""K 型 6,111 颗：LAMOST 取 Gaia ID → Gaia TAP 取 ruwe → 清理与 Teff 轴复核。"""
import io, os, sys, time, urllib.parse, urllib.request
import numpy as np, pandas as pd
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
OUT = r'C:\Users\lingz\Desktop\复现老师工作\APJS\多个图及讨论'
LAM = 'https://www.lamost.org/openapi'; token = open('extract/lamost_token.txt').read().strip()

def lam(sql):
    url = LAM + '/dr13/v1.0/sql?' + urllib.parse.urlencode({'sql': sql, 'output.fmt':'csv','token':token})
    return pd.read_csv(io.StringIO(urllib.request.urlopen(url, timeout=180).read().decode('utf-8').lstrip('\ufeff')))

sql = ("select obsid, gaia_source_id, logg_err, teff_err from stellar "
       "where subclass like 'K%' and logg > 3.8 and teff between 3900 and 5500 "
       "and obsid % 60 = 13 and snrr between 4 and 30 and gaia_g_mean_mag between 14.0 and 18.0 limit 30000")
meta = lam(sql)
meta['sid'] = pd.to_numeric(meta.gaia_source_id, errors='coerce')
meta = meta.dropna(subset=['sid']); meta['sid'] = meta.sid.astype('int64')
print('K 型 Gaia ID:', len(meta))

def gaia_tap(ids):
    q = ("select source_id, ruwe, parallax, parallax_error from gaiadr3.gaia_source where source_id in ("
         + ','.join(str(int(i)) for i in ids) + ')')
    url = 'https://gea.esac.esa.int/tap-server/tap/sync?' + urllib.parse.urlencode(
        {'REQUEST':'doQuery','LANG':'ADQL','FORMAT':'csv','QUERY':q})
    txt = urllib.request.urlopen(url, timeout=240).read().decode('utf-8', 'replace')
    return pd.read_csv(io.StringIO(txt))

ids = meta.sid.unique().tolist(); out = []
for i in range(0, len(ids), 100):
    try:
        out.append(gaia_tap(ids[i:i+100]))
    except Exception as e:
        print('批次失败', i, type(e).__name__)
    time.sleep(1)
G = pd.concat(out, ignore_index=True) if out else pd.DataFrame(columns=['source_id','ruwe','parallax','parallax_error'])
G['sid'] = G.source_id.astype('int64')
print('Gaia 返回:', len(G))
G.to_csv('data/gaia/gaia_dr3_ktype_pilot.csv', index=False, encoding='utf-8-sig')

K = pd.read_csv('data/processed/dr13/ktype_pilot_ew.csv').merge(meta[['obsid','sid','logg_err','teff_err']], on='obsid', how='left')
K = K.merge(G[['sid','ruwe','parallax','parallax_error']], on='sid', how='left')
print('K 侧 ruwe 非空: %d / %d' % (K.ruwe.notna().sum(), len(K)))

print('\n=== K 侧清理 ===')
print('  全部            n=%4d  %.2f%%' % (len(K), 100*K.active.mean()))
q1 = K[K.ruwe < 1.4];              print('  ruwe<1.4        n=%4d  %.2f%%' % (len(q1), 100*q1.active.mean()))
q2 = q1[(q1.logg_err < 0.5) & (q1.teff_err < 200)]; print('  + 参数精度      n=%4d  %.2f%%' % (len(q2), 100*q2.active.mean()))
q3 = q2[(q2.logg > 4.0) & (q2.logg < 5.2)];        print('  + logg 4.0-5.2  n=%4d  %.2f%%' % (len(q3), 100*q3.active.mean()))

cat = pd.read_csv('data/lamost/dr13/dr13_mstellar_dM.csv', low_memory=False,
                  usecols=['uid','subclass','teff','ewha','ewha_err','gaia_source_id','logg'])
cat = cat[(cat.ewha > -20) & (cat.ewha <= 50) & (cat.ewha_err > 0) & (cat.ewha_err <= 5)].copy()
cat['active'] = (cat.ewha >= 0.75) & (cat.ewha > 3*cat.ewha_err)
cat = cat.sort_values('ewha', ascending=False).drop_duplicates('uid')
gm = pd.read_csv('data/gaia/gaia_dr3_mstars.csv', low_memory=False, usecols=['source_id','ruwe'])
gm['sid'] = gm.source_id.astype('int64')
cat['sid'] = pd.to_numeric(cat.gaia_source_id, errors='coerce')
cat = cat.merge(gm[['sid','ruwe']].drop_duplicates('sid'), on='sid', how='left')
print('\n=== M 侧清理 ===')
print('  全部            n=%6d  %.2f%%' % (len(cat), 100*cat.active.mean()))
catq = cat[cat.ruwe < 1.4]; print('  ruwe<1.4        n=%6d  %.2f%%' % (len(catq), 100*catq.active.mean()))

edges = np.arange(3100, 5700, 100); rows = []
for lo in edges[:-1]:
    hi = lo + 100
    kk = q3[(q3.teff >= lo) & (q3.teff < hi)]; mm = catq[(catq.teff >= lo) & (catq.teff < hi)]
    if len(kk) < 20 and len(mm) < 20: continue
    rows.append(dict(teff_ctr=lo+50, n_K=len(kk), frac_K=100*kk.active.mean() if len(kk) else np.nan,
                     n_M=len(mm), frac_M=100*mm.active.mean() if len(mm) else np.nan))
T = pd.DataFrame(rows); T.to_csv(os.path.join(OUT,'新图4_Teff轴_K与M_清理后.csv'), index=False, encoding='utf-8-sig')
print('\n=== Teff 分箱（清理后）==='); print(T.round(2).to_string(index=False))

fig, ax = plt.subplots(figsize=(8.6, 4.6))
ax.plot(T.teff_ctr, T.frac_K, 'o-', color='#8e44ad', ms=5, label='K dwarfs (this work)')
ax.plot(T.teff_ctr, T.frac_M, 's-', color='#c0392b', ms=5, label='M dwarfs (catalogue)')
ax.axvline(3900, color='#999', ls='--', lw=1); ax.text(3915, 60, 'K/M ~3900 K', fontsize=8, color='#666')
ax.set_xlabel('Teff (K)'); ax.set_ylabel('Active fraction (%)'); ax.set_ylim(0, 80)
ax.set_title('Active fraction vs Teff (Gaia ruwe<1.4)'); ax.legend(fontsize=8)
plt.tight_layout(); plt.savefig(os.path.join(OUT,'新图4_Teff轴_K与M_清理后.png'), dpi=200); plt.close()
print('\n已写 新图4 与 CSV')
