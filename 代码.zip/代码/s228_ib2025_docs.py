# -*- coding: utf-8 -*-
"""IB2025 图标签位置微调 + 把自算结果写进方法说明"""
import io, os, shutil, sys
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
import numpy as np, pandas as pd
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt, matplotlib.ticker as mticker
W = r'C:\Users\lingz\OneDrive\Desktop\复现老师工作'
D = r'C:\Users\lingz\Desktop\复现老师工作'
A = r'C:\Users\lingz\Desktop\APJS\图五及相关数据'
g = lambda *a: os.path.join(W, *a)
r = pd.read_csv(g('data', 'processed', 'dr13', 'ib2025_periodogram_selfcomputed.csv'))
det = r[r.FAP < 0.05].sort_values('P_yr', ascending=False).reset_index(drop=True)
fig, ax = plt.subplots(figsize=(6.8, 5.2))
ax.axvspan(3, 19, color='#dfe9ff', zorder=0)
y = np.arange(len(det))
ax.errorbar(det.P_yr, y, xerr=np.abs(det.P2_yr - det.P_yr), fmt='none', elinewidth=0.7, ecolor='0.65', zorder=2)
ax.scatter(det.P_yr, y, s=34, c=np.where(det.FAP < 0.01, '#1f4fd8', 'white'), edgecolor='#1f4fd8', lw=1.0, zorder=3)
ax.set_yticks(y)
ax.set_yticklabels(['%s  (N=%d, %.0f yr)' % (s, n, b) for s, n, b in zip(det.star, det.N, det.baseline_yr)], fontsize=7.2)
ax.set_xscale('log'); ax.set_xlim(1.9, 32)
ax.xaxis.set_major_locator(mticker.FixedLocator([2, 3, 5, 10, 20]))
ax.xaxis.set_major_formatter(mticker.FixedFormatter(['2', '3', '5', '10', '20']))
ax.xaxis.set_minor_formatter(mticker.NullFormatter())
ax.text(0.02, 0.02, 'shaded: 3-19 yr (range reported by Ibanez Bustos et al. 2025)', transform=ax.transAxes, fontsize=7, color='0.35')
ax.set_xlabel('P$_{cyc}$ (yr) — our Lomb-Scargle recomputation', fontsize=10)
ax.set_title('Ibanez Bustos et al. (2025) Table B1: %d of %d stars show FAP < 0.05\n'
             'filled: FAP < 0.01;  horizontal bars: separation from the secondary peak' % (len(det), len(r)), fontsize=9)
ax.tick_params(direction='in', top=True, right=True, labelsize=8)
ax.grid(alpha=0.25, axis='x', lw=0.4)
ax.set_ylim(-0.8, len(det) - 0.2)
fig.text(0.5, 0.012, 'Recomputed by us from the published time series (2,806 points, 33 stars; Lomb-Scargle, 2-25 yr, baseline >= 8 yr).\n'
                     'These are OUR estimates, not the values published by the authors.', ha='center', fontsize=6.5, color='0.3', linespacing=1.5)
fig.tight_layout(rect=(0, 0.075, 1, 1))
o = g('figures', 'dr13_figIB2025_cycles.png'); fig.savefig(o, dpi=180); plt.close(fig)
for tgt in (os.path.join(D, '图', '对照与备选', '附_IB2025_自算周期_FAP.png'), os.path.join(A, '图', '附_IB2025_自算周期_FAP.png')):
    shutil.copy2(o, tgt)
print('  图已重绘同步')
OLD = '**本文未纳入该表的具体数值**（未取得机读表），如果需要在正文引用，请提供该表后我再补入并重绘。'
NEW = """**已用该文机读表复算（2026-10-21）**：解析 Table B1 得 2,806 个观测点、33 颗星；取 N ≥ 15 且基线 ≥ 8 yr 的 22 颗做 Lomb-Scargle（2–25 yr）：
20 颗 FAP < 0.05，其中 **15 颗落在 3–19 yr**，支持"周期活动跨饱和边界存在"。可重复性检验：
GJ 628 自算 9.83 yr vs SM2016 的 4.4 yr（**2.23 倍**，不可重复）；Gl 273 自算 **3.39 yr**（FAP = 3.5×10⁻⁹）vs GdS2012 的 3.5 yr（**0.97**，一致）——
因此 Gl 273 的 3.5 yr 并非"三源否证"，其时间序列本身支持该周期；Proxima 自算 21.1 yr 已超 16 yr 基线，仍按争议个例不入图。
图见 附_IB2025_自算周期_FAP.png，数据见 IB2025_时间序列自算周期_22星.csv（含原表 IB2025_TableB1_时间序列.dat / IB2025_sources.dat）。"""
for p in (os.path.join(D, '文档', '图05_Methods文字_中英文.md'), os.path.join(A, '方法说明', '图05_Methods文字_中英文.md')):
    s = open(p, encoding='utf-8').read()
    if OLD in s:
        s = s.replace(OLD, NEW); open(p, 'w', encoding='utf-8').write(s); print('  已改写 IB2025 段:', p.split('\\')[-3:])
    elif '已用该文机读表复算' in s:
        print('  已是新版:', p.split('\\')[-1])
    else:
        s = s.rstrip() + '\n' + NEW + '\n'; open(p, 'w', encoding='utf-8').write(s); print('  已追加 IB2025 段:', p.split('\\')[-3:])
p = os.path.join(A, 'README.md'); s = open(p, encoding='utf-8').read()
if '已用该文机读表复算' not in s:
    s += ('\n## 七、IB2025 时间序列复算（2026-10-21）\n\n'
          '* Table B1：2,806 点 / 33 星；可分析 22 星（N≥15、基线≥8 yr）。\n'
          '* Lomb-Scargle(2–25 yr)：20 颗 FAP<0.05，其中 15 颗在 3–19 yr —— 支持周期活动跨饱和边界存在。\n'
          '* 可重复性：GJ 628 自算 9.83 yr vs SM2016 4.4 yr（2.23×）；Gl 273 自算 3.39 yr vs GdS2012 3.5 yr（0.97，一致）。\n'
          '* Proxima 自算 21.1 yr 超过 16 yr 基线 → 仍按争议个例处理。\n'
          '* 文件：数据/IB2025_时间序列自算周期_22星.csv、IB2025_TableB1_时间序列.dat、IB2025_sources.dat；图：图/附_IB2025_自算周期_FAP.png\n')
    open(p, 'w', encoding='utf-8').write(s); print('  README 已加第七节')
