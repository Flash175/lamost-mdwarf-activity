# -*- coding: utf-8 -*-
"""s551：三处会改变结论的复核
 A. >400 pc：2D 档能否使用（把 6D 子集的星剔掉看整档）、分 400-600/600-1000/>1000、组成重加权
 B. <100 pc 运动学：档内 |Z| 匹配（0-50/50-100、100-150/150-200）与两类亚型组成
 C. S/N 匹配各格的 n（含 dM5/dM6 的 200-400 pc）
"""
import io, sys, os
import numpy as np, pandas as pd
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
from astropy.coordinates import SkyCoord, Galactic
import astropy.units as un

OUT = r'C:\Users\lingz\Desktop\复现老师工作\APJS\多个图及讨论'
CAT = 'data/lamost/dr13/dr13_mstellar_dM.csv'
GAI = 'data/gaia/gaia_dr3_mstars.csv'

def wilson(k, n, z=1.96):
    if n == 0: return (np.nan, np.nan)
    p = k/n; d = 1 + z*z/n
    c = (p + z*z/(2*n))/d
    h = z*np.sqrt(p*(1-p)/n + z*z/(4*n*n))/d
    return (100*(c-h), 100*(c+h))

def save(df, name, comments):
    fp = os.path.join(OUT, name)
    df.to_csv(fp, index=False, encoding='utf-8')
    txt = open(fp, encoding='utf-8').read()
    with open(fp, 'w', encoding='utf-8-sig') as f:
        f.write('\n'.join('# ' + c for c in comments) + '\n' + txt)
    print('  写出 %s（%d 行）' % (name, len(df)))

cat = pd.read_csv(CAT, low_memory=False,
                  usecols=['uid','subclass','teff','logg','logg_err','ewha','ewha_err','snrr',
                           'ra','dec','gaia_source_id','gaia_g_mean_mag','class'])
cat = cat[(cat.ewha > -20) & (cat.ewha <= 50) & (cat.ewha_err > 0) & (cat.ewha_err <= 5)].copy()
cat['active'] = (cat.ewha >= 0.75) & (cat.ewha > 3*cat.ewha_err)
cat['gaia_source_id'] = pd.to_numeric(cat.gaia_source_id, errors='coerce')
g = pd.read_csv(GAI, low_memory=False,
                usecols=['source_id','parallax','parallax_error','pmra','pmdec','radial_velocity','ruwe'])
m = cat.merge(g, left_on='gaia_source_id', right_on='source_id', how='inner')
m = m[(m.parallax > 0.2) & (m.parallax/m.parallax_error > 5) & (m.ruwe < 1.4)].copy()
m['rv'] = m.radial_velocity
u = m.sort_values('ewha', ascending=False).drop_duplicates('uid').copy()
# [giant-cut] 去巨星：M_G >= 6（M 矮星 +8~+16；切口同时含亚巨星与误分类早型矮星）
u['MG'] = u.gaia_g_mean_mag.values - 5*np.log10(np.clip(1000.0/u.parallax.values, 1, None)) + 5
u = u[u.MG >= 6].copy()
d_pc = 1000.0/u.parallax.values
sc = SkyCoord(ra=u.ra.values*un.deg, dec=u.dec.values*un.deg, distance=d_pc*un.pc, frame='icrs')
gal = sc.galactic
u['b'] = gal.b.deg
u['absz_pc'] = np.abs(d_pc*np.sin(np.deg2rad(u.b.values)))
u2 = u[u.absz_pc <= 3000].copy()
print('2D 样本（|Z|<=3 kpc）：%d 颗；含 |Z|>3 kpc 共 %d 颗' % (len(u2), len(u)))

EDGES = [0,100,200,400,600,1000,1e9]
LAB = ['<100','100-200','200-400','400-600','600-1000','>1000']
u2['zb'] = pd.cut(u2.absz_pc, EDGES, labels=LAB)
rows = []
for lb in LAB:
    s = u2[u2.zb == lb]; k = int(s.active.sum()); n = len(s)
    lo, hi = wilson(k, n)
    rows.append(dict(zbin=lb, n=n, n_act=k, frac=100*k/n if n else np.nan, lo=lo, hi=hi,
                     absz_med=float(s.absz_pc.median()) if n else np.nan,
                     dm0_share=100*(s.subclass == 'dM0').mean() if n else np.nan,
                     snr_med=float(s.snrr.median()) if n else np.nan,
                     g_med=float(s.gaia_g_mean_mag.median()) if n else np.nan,
                     logg_med=float(s.logg.median()) if n else np.nan,
                     teff_med=float(s.teff.median()) if n else np.nan))
A = pd.DataFrame(rows)
print('\n=== A1. 2D 样本按 |Z|（含 Wilson 95%）===')
print(A.to_string(index=False, float_format=lambda x: '%.2f' % x))

# 6D 子集：有 RV 且 |RV|<500
six = u[np.isfinite(u.rv) & (np.abs(u.rv) < 500)].copy()
print('\n6D 子集：%d 颗' % len(six))
far2d = u2[u2.absz_pc > 400]; farsix = six[six.absz_pc > 400]
print('>400 pc：2D %d 颗（活动 %d，%.2f%%）；6D %d 颗（活动 %d，%.2f%%）'
      % (len(far2d), far2d.active.sum(), 100*far2d.active.mean(),
         len(farsix), farsix.active.sum(), 100*farsix.active.mean()))
rem = far2d[~far2d.uid.isin(set(farsix.uid))]
k = int(rem.active.sum()); n = len(rem); lo, hi = wilson(k, n)
print('把 6D 的 %d 颗全剔掉后：%d 颗，活动 %d → %.2f%% [%.2f, %.2f]'
      % (len(farsix), n, k, 100*k/n, lo, hi))

print('\n>400 pc 的 2D 档属性（活动 / 非活动）：')
for nm, sel in (('active', far2d.active), ('inactive', ~far2d.active)):
    s = far2d[sel]
    print('  %-9s n=%6d  G中位 %.2f  logg中位 %.2f  Teff中位 %.0f  S/N中位 %.1f  logg<3.5 %.1f%%  S/N<3 %.1f%%'
          % (nm, len(s), s.gaia_g_mean_mag.median(), s.logg.median(), s.teff.median(), s.snrr.median(),
             100*(s.logg < 3.5).mean(), 100*(s.snrr < 3).mean()))

# 组成重加权：>400 用 <100 的亚型组成
base = u2[u2.absz_pc < 100]
w = base.subclass.value_counts(normalize=True)
far = far2d
fr = far.groupby('subclass').active.agg(['mean','size'])
common = [k for k in w.index if k in fr.index]
ww = w[common]/w[common].sum()
rw = float((ww*fr.loc[common,'mean']).sum()*100)
print('\n>400 pc 组成重加权到 <100 pc 的亚型组成：%.2f%%（实测合并 %.2f%%）' % (rw, 100*far.active.mean()))
print('  dM0 占比：<100 pc %.1f%% → >400 pc %.1f%%' % (100*w.get('dM0',0), 100*(far.subclass=='dM0').mean()))

save(A, 'far400_2d_audit.csv', [
    '2D 样本（只需视差）按 |Z| 分箱；active = EW(Ha)>=0.75 A 且 >3sigma',
    '列：n/n_act/frac_pct 与 Wilson 95% 区间；absz_med_pc 为该档 |Z| 中位',
    'dm0_share_pct 为 dM0 占比（组成效应的直接证据）；snr_med/g_med/logg_med/teff_med 为该档中位',
    '生成脚本：代码/s551_far400_2d_zmatch_coolend.py'])

print('\n=== A2. s521 的六档（对照 CSV 新图_活动率与运动学_按Z分箱.csv）===')
u2b = u[u.absz_pc <= 3000]
print('  四档合计 %d' % len(u2b[u2b.absz_pc <= 400]))


# ---------------- B. 6D 运动学：档内 |Z| 匹配与亚型组成 ----------------
print('\n=== B. 6D 运动学（astropy galactocentric）===')
c6 = SkyCoord(ra=six.ra.values*un.deg, dec=six.dec.values*un.deg,
              distance=(1000.0/six.parallax.values)*un.pc,
              pm_ra_cosdec=six.pmra.values*un.mas/un.yr, pm_dec=six.pmdec.values*un.mas/un.yr,
              radial_velocity=six.rv.values*un.km/un.s, frame='icrs')
gc = c6.transform_to('galactocentric')
v6 = gc.velocity.d_xyz.to(un.km/un.s).value
six = six.assign(vx=v6[0], vy=v6[1], vz=v6[2], zgc_pc=np.abs(gc.z.to(un.kpc).value)*1000)

def mad_sigma(x):
    x = np.asarray(x, float); x = x[np.isfinite(x)]
    if len(x) < 10: return np.nan
    return 1.4826*np.median(np.abs(x-np.median(x)))

BIN6 = [(0,50),(50,100),(100,150),(150,200),(200,400),(400,3000)]
LB6 = ['0-50','50-100','100-150','150-200','200-400','400-3000']
rowsB = []
for (lo,hi), lb in zip(BIN6, LB6):
    sel = six[(six.zgc_pc >= lo) & (six.zgc_pc < hi)]
    act, ina = sel[sel.active], sel[~sel.active]
    if len(act) < 5 or len(ina) < 5:
        continue
    rowsB.append(dict(zbin=lb, n_act=len(act), n_inact=len(ina),
                      zmed_act=float(act.zgc_pc.median()), zmed_inact=float(ina.zgc_pc.median()),
                      sub_act=float(act.teff.median()), sub_inact=float(ina.teff.median()),
                      svx_act=act.vx.std(), svy_act=act.vy.std(), svz_act=act.vz.std(),
                      svx_inact=ina.vx.std(), svy_inact=ina.vy.std(), svz_inact=ina.vz.std(),
                      svz_act_mad=mad_sigma(act.vz), svz_inact_mad=mad_sigma(ina.vz)))
B = pd.DataFrame(rowsB)
print(B.to_string(index=False, float_format=lambda x: '%.1f' % x))

print('\n--- B2. <100 pc 再切细：档内 |Z| 对不齐的影响 ---')
rowsM = []
for (lo,hi) in [(0,25),(25,50),(50,75),(75,100),(100,150),(150,200)]:
    sel = six[(six.zgc_pc >= lo) & (six.zgc_pc < hi)]
    act, ina = sel[sel.active], sel[~sel.active]
    if len(act) < 30 or len(ina) < 30: continue
    rowsM.append(dict(zslice='%d-%d' % (lo,hi), n_act=len(act), n_inact=len(ina),
                      zmed_act=float(act.zgc_pc.median()), zmed_inact=float(ina.zgc_pc.median()),
                      svz_act=act.vz.std(), svz_inact=ina.vz.std(),
                      dsz=act.vz.std()-ina.vz.std(),
                      svx_act=act.vx.std(), svx_inact=ina.vx.std(), svy_act=act.vy.std(), svy_inact=ina.vy.std()))
M = pd.DataFrame(rowsM)
print(M.to_string(index=False, float_format=lambda x: '%.1f' % x))
if len(M):
    wsum = M.n_act + M.n_inact
    print('  加权平均 Δσ(vz)（在 |Z| 细片内比较）= %.2f km/s' % float((M.dsz*wsum).sum()/wsum.sum()))

print('\n--- B3. 两类星同一 |Z| 窗口（40-80 pc）内的对比 ---')
sel = six[(six.zgc_pc >= 40) & (six.zgc_pc < 80)]
act, ina = sel[sel.active], sel[~sel.active]
print('  n_act=%d n_inact=%d | |Z| 中位 %.1f vs %.1f pc | σ(vz) %.1f vs %.1f | Teff中位 %.0f vs %.0f'
      % (len(act), len(ina), act.zgc_pc.median(), ina.zgc_pc.median(),
         act.vz.std(), ina.vz.std(), act.teff.median(), ina.teff.median()))
B2 = M.assign(zbin=M.zslice)
save(pd.concat([B[B.columns.intersection(B2.columns)], B2], ignore_index=True), 'zmatch_kinematics.csv', [
    '6D 子样本按 |Z| 细档：活动/非活动各自的 |Z| 中位、Teff 中位、三分量速度弥散（std 与 MAD）',
    '用途：检验 <100 pc 层 sigma(vz) 的差别是否只是 |Z| 梯度（若两类 |Z| 中位差很大，需按细档匹配）',
    '生成脚本：代码/s551_far400_2d_zmatch_coolend.py'])

# ---------------- C. S/N 匹配各格 n ----------------
print('\n=== C. S/N 匹配（10-30）各格的 n 与活动率 ===')
rowsC = []
for lb, (zl, zh) in (('<100', (0,100)), ('100-200', (100,200)), ('200-400', (200,400)), ('>400', (400,3000))):
    for sp in ['dM0','dM1','dM2','dM3','dM4','dM5','dM6','dM7','dM8']:
        s = u2[(u2.absz_pc >= zl) & (u2.absz_pc < zh) & (u2.subclass == sp)]
        if len(s) < 30: continue
        sm = s[(s.snrr >= 10) & (s.snrr <= 30)]
        k, n = int(sm.active.sum()), len(sm)
        lo, hi = wilson(k, n)
        rowsC.append(dict(zbin=lb, subtype=sp, n_all=len(s), frac_all=100*s.active.mean(),
                          n_match=n, frac_match=100*k/n if n else np.nan, lo=lo, hi=hi))
C = pd.DataFrame(rowsC)
print(C.to_string(index=False, float_format=lambda x: '%.1f' % x))

print('\n--- C2. 冷端 dM6/dM7/dM8：全样本与 S/N 匹配（Wilson 95%）---')
rowsD = []
for sp in ['dM5','dM6','dM7','dM8']:
    s = u2[u2.subclass == sp]
    for tag, sub in (('all', s), ('sn36', s[(s.snrr >= 3) & (s.snrr < 6)]),
                     ('sn612', s[(s.snrr >= 6) & (s.snrr < 12)]), ('sn620', s[(s.snrr >= 6) & (s.snrr <= 20)])):
        k, n = int(sub.active.sum()), len(sub)
        lo, hi = wilson(k, n)
        rowsD.append(dict(subtype=sp, cut=tag, n=n, n_act=k,
                          frac=100*k/n if n else np.nan, lo=lo, hi=hi,
                          detect_pct=100*(s.ewha_err*3 <= 0.75).mean()))
D = pd.DataFrame(rowsD)
print(D.to_string(index=False, float_format=lambda x: '%.1f' % x))
save(C, 'sn_matched_by_bin_with_n.csv', [
    '按 |Z| 档 x 亚型的 S/N 匹配（10-30）各格：n_all / frac_all 为匹配前，n_match / frac_match 为匹配后',
    'Wilson 95% 区间用于判断某格（如 dM5 200-400 pc 33.8%）是否可信',
    '生成脚本：代码/s551_far400_2d_zmatch_coolend.py'])
save(D, 'coolend_sn_cuts_with_n.csv', [
    '冷端 dM5-dM8：全样本与 S/N 匹配（3-6 / 6-12 / 6-20）各格的 n、活动率与 Wilson 95% 区间',
    'detect_pct = 3*sigma(EW) <= 0.75 A 的谱占比（探测能力）',
    '生成脚本：代码/s551_far400_2d_zmatch_coolend.py'])

# ---------------- D. 组成重加权（200-400 与 >400 各对 <100）与单历元 ----------------
print('\n=== D. 组成重加权（对 <100 pc 的亚型组成）===')
base = u2[u2.absz_pc < 100]
w = base.subclass.value_counts(normalize=True)
for lb, (zl, zh) in (('200-400', (200,400)), ('>400', (400,3000))):
    sub = u2[(u2.absz_pc >= zl) & (u2.absz_pc < zh)]
    fr = sub.groupby('subclass').active.agg(['mean','size'])
    common = [k for k in w.index if k in fr.index]
    ww = w[common]/w[common].sum()
    rw = float((ww*fr.loc[common,'mean']).sum()*100)
    print('  %-8s 实测 %.2f%%  → 重加权 %.2f%%  → 对 <100 pc(%.2f%%) 的比值 实测 %.2f 倍 / 重加权 %.2f 倍'
          % (lb, 100*sub.active.mean(), rw, 100*base.active.mean(),
             100*base.active.mean()/(100*sub.active.mean()), 100*base.active.mean()/rw))

print('\n=== E. 单历元样本（去掉“最大 EW”偏差）===')
ep = m.groupby('uid').size().rename('n_ep')
u2e = u2.join(ep, on='uid')
one = u2e[u2e.n_ep == 1]
print('  单历元星 %d / %d = %.1f%%' % (len(one), len(u2e), 100*len(one)/len(u2e)))
print('  亚型   <100 pc      200-400 pc    比值')
for sp in ['dM0','dM1','dM2','dM3','dM4','dM5','dM6']:
    a = one[(one.subclass == sp) & (one.absz_pc < 100)]
    b = one[(one.subclass == sp) & (one.absz_pc >= 200) & (one.absz_pc < 400)]
    if len(a) < 30 or len(b) < 30: continue
    fa, fb = 100*a.active.mean(), 100*b.active.mean()
    print('  %-5s %6.2f%% (n=%5d)  %6.2f%% (n=%4d)  %.2f 倍' % (sp, fa, len(a), fb, len(b), fa/fb))
print('  历元分布：中位 %.0f；≥2 历元占 %.1f%%'
      % (u2e.n_ep.median(), 100*(u2e.n_ep >= 2).mean()))

print('\ns551 完成')
