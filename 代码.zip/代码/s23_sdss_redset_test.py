# -*- coding: utf-8 -*-
"""检验：West 星表里是否存在'只集中在赤道带'的红点子集（对应论文右板外观）。"""
import io, sys
import numpy as np
import pandas as pd
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")

df = pd.read_csv("data/vizier/aj141_97_sdss_dwarfs.csv", low_memory=False)
ra = df["RAJ2000"].to_numpy(float); de = df["DEJ2000"].to_numpy(float)
w = pd.to_numeric(df["W(Ha)"], errors="coerce").to_numpy(float)
ew = pd.to_numeric(df["e_W(Ha)"], errors="coerce").to_numpy(float)
sn = pd.to_numeric(df["HaS/N"], errors="coerce").to_numpy(float)
hc = pd.to_numeric(df["Ha/c"], errors="coerce").to_numpy(float)
mha = df["MHa"].to_numpy()

band = (np.abs(((ra + 180) % 360) - 180) <= 60) & (np.abs(de) <= 2.0)
north = (ra >= 110) & (ra <= 260) & (de > 2.0)

def show(name, m):
    m = np.asarray(m, bool)
    tot = int(m.sum())
    if tot == 0:
        print(f"{name:34s} 0"); return
    nb = int((m & band).sum()); nn = int((m & north).sum())
    print(f"{name:34s} 红点 {tot:7d}  赤道带 {nb:6d} ({100*nb/tot:4.1f}%)  北天 {nn:6d} ({100*nn/tot:4.1f}%)")

show("W>=0.75", w >= 0.75)
show("W>=0.75 & 3sig", (w >= 0.75) & (w > 3 * np.abs(ew)))
show("MHa==1", mha == 1)
show("W>=0.75 & e_W<0.15", (w >= 0.75) & (ew < 0.15))
show("W>=0.75 & e_W<0.10", (w >= 0.75) & (ew < 0.10))
show("W>=0.75 & e_W<0.05", (w >= 0.75) & (ew < 0.05))
show("W>=0.75 & HaS/N>20", (w >= 0.75) & (sn > 20))
show("W>=0.75 & HaS/N>50", (w >= 0.75) & (sn > 50))
show("W>=0.75 & Ha/c>10", (w >= 0.75) & (hc > 10))
show("W>=0.75 & MJD>53000", (w >= 0.75) & (df["MJDr"].to_numpy(float) > 53000))
show("W>=2.0", w >= 2.0)
show("W>=5.0", w >= 5.0)
print()
# 全样本的区域占比，做参照
show("全部行(参照)", np.ones(len(df), bool))
print()
print("赤道带行数/北天行数:", int(band.sum()), int(north.sum()))
