# -*- coding: utf-8 -*-
"""s604：在图05 的严格样本上，按定稿口径（固定 Ro_sat = 0.132、同断点分面板拟合）重出两面板图

定稿口径（台账 §10.2 / §六十）：
  全体  OLS 固定 0.132 → β = −0.857 ± 0.083
  M0–M3 OLS 固定 0.132 → β = −0.890 ± 0.093
  M4–M6 OLS 固定 0.132 → β = −0.822 ± 0.178
本脚本断言这三个数，然后画图；不符则只打印、不画。
"""
import io, sys, os
import numpy as np, pandas as pd
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
BASE = r'C:\Users\lingz\OneDrive\Desktop\复现老师工作'
OUTDIR = r'C:\Users\lingz\Desktop\复现老师工作\APJS\图五及相关数据\图_20261103\新图'
os.makedirs(OUTDIR, exist_ok=True)
RS = 0.132

df = pd.read_csv(os.path.join(BASE,'data','processed','dr13','fig5_sample_strict_v4.csv'), low_memory=False)
print('严格样本 %d 行；列：%s' % (len(df), ', '.join(df.columns[:14])))

def fit_fixed(d, rs=RS):
    """固定断点、自由截距的分段线性 OLS（x=log Ro，y=log R'Hα），返回 (beta, se, c, n)。"""
    x = np.log10(d.Ro.values); y = np.log10(d.RHa.values)
    X = np.column_stack([np.ones_like(x), np.minimum(x - np.log10(rs), 0.0)])
    beta, *_ = np.linalg.lstsq(X, y, rcond=None)
    resid = y - X @ beta
    dof = len(y) - 2
    s2 = (resid @ resid)/dof
    cov = s2*np.linalg.inv(X.T @ X)
    return float(beta[1]), float(np.sqrt(cov[1,1])), float(beta[0]), len(y)

b_all, e_all, _, n_all = fit_fixed(df)
panels = [('M0-M3', df[df.subclass.astype(str).str.match(r'dM0|dM1|dM2|dM3')]),
          ('M4-M6', df[df.subclass.astype(str).str.match(r'dM4|dM5|dM6')])]
print('\n固定 Ro_sat = %.3f：' % RS)
print('  全体   n=%4d  β = %+.3f ± %.3f' % (n_all, b_all, e_all))
res = {}
for nm, d in panels:
    if len(d) < 50: continue
    b, e, c, n = fit_fixed(d)
    res[nm] = (b, e, n, c)
    print('  %-6s n=%4d  β = %+.3f ± %.3f' % (nm, b, e, n))

ok = (abs(b_all + 0.857) < 0.006 and abs(res['M0-M3'][0] + 0.890) < 0.006 and abs(res['M4-M6'][0] + 0.822) < 0.008)
print('\n与定稿口径一致：%s' % ('是' if ok else '否 —— 不画图'))
if ok:
    fig, ax = plt.subplots(1, 2, figsize=(11.6, 4.6), sharey=True)
    for a, (nm, d) in zip(ax, panels):
        b, e, n, c = res[nm]
        x = np.log10(d.Ro.values); y = np.log10(d.RHa.values)
        a.errorbar(10**x, 10**y, yerr=None, fmt='o', ms=2.2, alpha=.35, color='tab:blue', mew=0)
        xs = np.logspace(-2, np.log10(3), 120)
        ys = c + b*np.minimum(np.log10(xs) - np.log10(RS), 0.0)
        a.plot(xs, 10**ys, 'r-', lw=1.9)
        a.axvline(RS, color='gray', ls=':', lw=1.1)
        a.set_xscale('log'); a.set_yscale('log')
        a.set_xlabel(r'$R_{\rm o}=P_{\rm rot}/\tau$', fontsize=9)
        a.set_title('%s  (n=%d)   β = %.3f ± %.3f' % (nm.replace('-', '–'), n, b, e), fontsize=9.5)
        a.grid(alpha=.25); a.tick_params(labelsize=8)
    ax[0].set_ylabel(r"$R'_{\rm H\alpha}$", fontsize=10)
    fig.suptitle(r'LAMOST DR13 M dwarfs: activity vs Rossby number (fixed $R_{\rm o,sat}=0.132$, '
                 r'all-sample β = %.3f ± %.3f, σ_int = 0.49 dex)' % (b_all, e_all), fontsize=9.5)
    fig.tight_layout(rect=[0, 0, 1, 0.94])
    fp = os.path.join(OUTDIR, '新图_图05_两面板_定稿0p132.png')
    fig.savefig(fp, dpi=180); plt.close(fig)
    print('写出 %s（%d B）' % (fp, os.path.getsize(fp)))
