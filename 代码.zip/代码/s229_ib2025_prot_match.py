# -*- coding: utf-8 -*-
"""给 IB2025 的 33 颗星补 P_rot：VSX(本地) + Fetherolf/TESS(本地) 交叉 5 角秒"""
import io, os, sys
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
import numpy as np, pandas as pd
from scipy.spatial import cKDTree
rows = []
for line in open('data/raw/ib2025/sources.dat', encoding='utf-8', errors='replace'):
    if len(line.strip()) < 12: continue
    name = line[:11].strip(); tok = line[11:].split()
    if len(tok) < 7: continue
    hh, mm, ss = float(tok[0]), float(tok[1]), float(tok[2])
    dd, dm, ds = float(tok[3]), float(tok[4]), float(tok[5])
    ra = 15*(hh + mm/60 + ss/3600); dec = np.sign(dd)*(abs(dd) + dm/60 + ds/3600)
    rows.append(dict(star=name, ra=ra, dec=dec, extra=' '.join(tok[6:])))
S = pd.DataFrame(rows); print('IB2025 星表 %d 颗' % len(S))
def uv(ra, dec):
    ra = np.radians(np.asarray(ra, float)); dec = np.radians(np.asarray(dec, float))
    return np.column_stack([np.cos(dec)*np.cos(ra), np.cos(dec)*np.sin(ra), np.sin(dec)])
v = pd.read_csv('data/vizier/vsx_variables.csv', low_memory=False,
                usecols=lambda c: c in {'Name','Type','Period','RAJ2000','DEJ2000','SpType','Vmag'})
v = v[v.RAJ2000.notna() & v.DEJ2000.notna()]
v['Period'] = pd.to_numeric(v.Period, errors='coerce')
tree = cKDTree(uv(v.RAJ2000.values, v.DEJ2000.values))
d, i = tree.query(uv(S.ra.values, S.dec.values), k=1, distance_upper_bound=np.radians(5/3600))
ok = np.isfinite(d) & (i < len(v))
S['vsx_name'] = ''; S['vsx_type'] = ''; S['P_vsx'] = np.nan; S['sep_as'] = np.nan
S.loc[ok, 'vsx_name'] = v.Name.values[i[ok]]
S.loc[ok, 'vsx_type'] = v.Type.values[i[ok]]
S.loc[ok, 'P_vsx'] = v.Period.values[i[ok]]
S.loc[ok, 'sep_as'] = np.degrees(d[ok])*3600
rot = S.vsx_type.astype(str).str.upper().str.contains('ROT')
print('VSX 5" 内匹配 %d 颗；Type 含 ROT %d 颗；其中带周期 %d 颗' % (int(ok.sum()), int(rot.sum()), int((rot & S.P_vsx.notna()).sum())))
print(S[ok][['star','vsx_name','vsx_type','P_vsx','sep_as']].to_string(index=False))
tess = pd.read_csv('data/processed/dr13/tess_rotation_periods.csv', low_memory=False)
print('\nTESS 表列:', list(tess.columns)[:10])
S['P_tess'] = np.nan
cr = [c for c in tess.columns if c.lower() in ('ra','ra_deg','raj2000')]
cd = [c for c in tess.columns if c.lower() in ('dec','dec_deg','dej2000')]
cp = [c for c in tess.columns if 'period' in c.lower() or c.lower() in ('p','prot')]
if cr and cd and cp:
    t = tess.dropna(subset=[cr[0], cd[0], cp[0]])
    tt = cKDTree(uv(t[cr[0]].values, t[cd[0]].values))
    d2, i2 = tt.query(uv(S.ra.values, S.dec.values), k=1, distance_upper_bound=np.radians(5/3600))
    ok2 = np.isfinite(d2) & (i2 < len(t))
    S.loc[ok2, 'P_tess'] = pd.to_numeric(t[cp[0]].values[i2[ok2]], errors='coerce')
    print('   TESS/Fetherolf 5" 内匹配 %d 颗，带周期 %d 颗' % (int(ok2.sum()), int(S.P_tess.notna().sum())))
S['P_rot'] = S.P_vsx.where(rot, np.nan).fillna(S.P_tess)
S.to_csv('data/processed/dr13/ib2025_stars_with_prot.csv', index=False)
print('\n有 P_rot 的 %d 颗：' % int(S.P_rot.notna().sum()))
print(S[S.P_rot.notna()][['star','P_rot','P_vsx','P_tess','vsx_type']].to_string(index=False))
