# -*- coding: utf-8 -*-
"""s598-B：在 S/N >= 20 子样本上，用 Hβ 独立重测活动比例，与 Hα 口径对比

逐条谱用与 s574/s566 相同的管线测 Hα(6563) 与 Hβ(4861) 的 EW 与 σ，然后三套活动判据并列：
  A 目录 EW（论文现用）：ewha >= 0.75 且 > 3*ewha_err
  B 本地 Hα：EW 本地 >= 0.75 且 > 3σ
  C 本地 Hβ：EW 本地 >= 0.75 且 > 3σ
按 |Z| 档给活动比例与 Wilson 区间，比较三者的下降形态（是否依赖单一线）。
输出：多个图及讨论/hbeta_activity_by_zbin.csv
"""
import io, sys, os, gzip
import numpy as np, pandas as pd

sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
OUT = r'C:\Users\lingz\Desktop\复现老师工作\APJS\多个图及讨论'

C_HA = ((6555.0, 6560.0), (6570.0, 6575.0), (6557.66, 6571.66), (6545.0, 6585.0), (6557.0, 6572.0))
C_HB = ((4852.0, 4857.0), (4866.0, 4871.0), (4855.33, 4869.33), (4842.0, 4882.0), (4854.0, 4870.0))

def wilson(k, n, z=1.96):
    if n == 0: return (np.nan, np.nan)
    p = k/n; d = 1 + z*z/n; c = (p + z*z/(2*n))/d
    h = z*np.sqrt(p*(1-p)/n + z*z/(4*n*n))/d
    return (100*(c-h), 100*(c+h))

def measure(w, f, win):
    C_L, C_R, LINE, CT, CE = win
    ok = np.isfinite(w) & np.isfinite(f); w, f = w[ok], f[ok]
    if len(w) < 500: return np.nan, np.nan
    o = np.argsort(w); w, f = w[o], f[o]
    mL = (w >= C_L[0]) & (w <= C_L[1]); mR = (w >= C_R[0]) & (w <= C_R[1])
    if mL.sum() < 2 or mR.sum() < 2: return np.nan, np.nan
    wl_, fl_ = w[mL].mean(), f[mL].mean(); wr_, fr_ = w[mR].mean(), f[mR].mean()
    if fr_ == fl_: return np.nan, np.nan
    mm = (fr_ - fl_)/(wr_ - wl_); bb = fl_ - mm*wl_
    g = np.arange(LINE[0], LINE[1] + 1e-9, 0.1)
    fg = np.interp(g, w, f); fc = mm*g + bb
    fcmed = float(np.nanmedian(fc))
    if fcmed <= 0: return np.nan, np.nan
    ew = -np.trapezoid(1.0 - fg/fc, g)
    cont = (w >= CT[0]) & (w <= CT[1]) & ~((w >= CE[0]) & (w <= CE[1]))
    if cont.sum() < 10: return float(ew), np.nan
    cm, cb = np.polyfit(w[cont], f[cont], 1)
    res = f[cont] - (cm*w[cont] + cb)
    sig = 1.4826*np.median(np.abs(res - np.median(res)))
    dl = np.median(np.diff(w)); npix = (LINE[1]-LINE[0])/dl
    return float(ew), float(sig/fcmed*dl*np.sqrt(npix))

W = pd.read_csv(os.path.join(OUT, 'hbeta_work.csv'))
rows = []
for i, r in W.iterrows():
    try:
        with gzip.open(r.path, 'rt', encoding='utf-8', errors='replace') as fh:
            d = pd.read_csv(fh)
        wl = d.Wavelength.values.astype(float); fl = d.Flux.values.astype(float)
    except Exception:
        continue
    ha, ea = measure(wl, fl, C_HA); hb, eb = measure(wl, fl, C_HB)
    BINS = [(0,100,'<100'),(100,200,'100-200'),(200,400,'200-400'),(400,600,'400-600'),
            (600,1000,'600-1000'),(1000,3000,'>1000')]
    zb = next(nm for lo, hi, nm in BINS if lo < r.absz <= hi)
    rows.append(dict(obsid=r.obsid, zbin=zb, subclass=r.subclass, snr=r.snrr,
                     act_cat=bool(r.active), ew_ha=ha, sig_ha=ea, ew_hb=hb, sig_hb=eb))
T = pd.DataFrame(rows)
T['act_ha'] = (T.ew_ha >= 0.75) & (T.ew_ha > 3*T.sig_ha)
T['act_hb'] = (T.ew_hb >= 0.75) & (T.ew_hb > 3*T.sig_hb)
T.to_csv(os.path.join(OUT, 'hbeta_activity_per_spectrum.csv'), index=False, encoding='utf-8')
print('测完 %d 条谱' % len(T))
ORDER = ['<100','100-200','200-400','400-600','600-1000','>1000']
out = []
for zb in ORDER:
    q = T[T.zbin == zb]
    if len(q) == 0: continue
    row = dict(zbin=zb, n=len(q))
    for tag, col in [('cat', 'act_cat'), ('ha', 'act_ha'), ('hb', 'act_hb')]:
        k = int(q[col].sum()); n = len(q); lo, hi = wilson(k, n)
        row['f_%s' % tag] = 100*k/n; row['lo_%s' % tag] = lo; row['hi_%s' % tag] = hi
    out.append(row)
D = pd.DataFrame(out)
print('\n三套判据的活动比例（S/N>=20 子样本）：')
print(D[['zbin','n','f_cat','f_ha','f_hb']].to_string(index=False, float_format=lambda x: '%.2f' % x))
def ratio(a, b, col):
    da = D[D.zbin == a][col]; db = D[D.zbin == b][col]
    return float(da.iloc[0]/db.iloc[0]) if len(da) and len(db) and db.iloc[0] > 0 else np.nan
print('\n降幅（<100 pc ÷ 目标档）：')
for zb in ['100-200','200-400','400-600','600-1000']:
    print('  ÷%-9s 目录 %.2f×  本地 Hα %.2f×  **本地 Hβ %.2f×**'
          % (zb, ratio('<100', zb, 'f_cat'), ratio('<100', zb, 'f_ha'), ratio('<100', zb, 'f_hb')))
print('\n地板（400–600 ÷ 600–1000，<1 表示回升）：目录 %.2f  本地 Hα %.2f  本地 Hβ %.2f'
      % (ratio('400-600','600-1000','f_cat'), ratio('400-600','600-1000','f_ha'), ratio('400-600','600-1000','f_hb')))
D.to_csv(os.path.join(OUT, 'hbeta_activity_by_zbin.csv'), index=False, encoding='utf-8')
print('\n写出 hbeta_activity_by_zbin.csv 与 hbeta_activity_per_spectrum.csv')
