# -*- coding: utf-8 -*-
"""单面板图脚注改短并自动换行（原来文字超出画布被截断）"""
import io, sys
sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
P = 'repro/src/s189_fig5_official_v4.py'
s = open(P, encoding='utf-8').read()
if 'import textwrap' not in s:
    s = s.replace('import numpy as np, pandas as pd', 'import textwrap\nimport numpy as np, pandas as pd', 1)
OLD = "fig.text(0.5, 0.008, FOOT, ha='center', va='bottom', fontsize=5.4, color='0.3', linespacing=1.5)"
NEW = ("FOOT1 = textwrap.fill('LAMOST DR13 M dwarfs with VSX ROT or Fetherolf+2023 periods (n=%d). "
       "After removing Gaia non_single_star != 0, alias periods, M3/M4 border stars and Ro > 3: n=%d.' "
       "% (len(A), len(strict)), 88)\n"
       "fig.text(0.5, 0.010, FOOT1, ha='center', va='bottom', fontsize=6.4, color='0.3', linespacing=1.6)")
if OLD in s:
    s = s.replace(OLD, NEW, 1); print('  已改单面板脚注')
else:
    print('  !! 未匹配单面板脚注行')
open(P, 'w', encoding='utf-8').write(s)
